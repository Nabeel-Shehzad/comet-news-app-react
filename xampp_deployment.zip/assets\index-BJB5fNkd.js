(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))i(a);new MutationObserver(a=>{for(const l of a)if(l.type==="childList")for(const u of l.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&i(u)}).observe(document,{childList:!0,subtree:!0});function t(a){const l={};return a.integrity&&(l.integrity=a.integrity),a.referrerPolicy&&(l.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?l.credentials="include":a.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function i(a){if(a.ep)return;a.ep=!0;const l=t(a);fetch(a.href,l)}})();var bg={exports:{}},jc={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var QT;function sN(){if(QT)return jc;QT=1;var n=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function t(i,a,l){var u=null;if(l!==void 0&&(u=""+l),a.key!==void 0&&(u=""+a.key),"key"in a){l={};for(var d in a)d!=="key"&&(l[d]=a[d])}else l=a;return a=l.ref,{$$typeof:n,type:i,key:u,ref:a!==void 0?a:null,props:l}}return jc.Fragment=e,jc.jsx=t,jc.jsxs=t,jc}var YT;function rN(){return YT||(YT=1,bg.exports=sN()),bg.exports}var v=rN(),wg={exports:{}},xe={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var WT;function aN(){if(WT)return xe;WT=1;var n=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),t=Symbol.for("react.fragment"),i=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler"),l=Symbol.for("react.consumer"),u=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),y=Symbol.for("react.lazy"),T=Symbol.iterator;function w(V){return V===null||typeof V!="object"?null:(V=T&&V[T]||V["@@iterator"],typeof V=="function"?V:null)}var x={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},I=Object.assign,O={};function P(V,se,ue){this.props=V,this.context=se,this.refs=O,this.updater=ue||x}P.prototype.isReactComponent={},P.prototype.setState=function(V,se){if(typeof V!="object"&&typeof V!="function"&&V!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,V,se,"setState")},P.prototype.forceUpdate=function(V){this.updater.enqueueForceUpdate(this,V,"forceUpdate")};function B(){}B.prototype=P.prototype;function ee(V,se,ue){this.props=V,this.context=se,this.refs=O,this.updater=ue||x}var Y=ee.prototype=new B;Y.constructor=ee,I(Y,P.prototype),Y.isPureReactComponent=!0;var W=Array.isArray,re={H:null,A:null,T:null,S:null,V:null},he=Object.prototype.hasOwnProperty;function M(V,se,ue,ae,ye,ke){return ue=ke.ref,{$$typeof:n,type:V,key:se,ref:ue!==void 0?ue:null,props:ke}}function A(V,se){return M(V.type,se,void 0,void 0,void 0,V.props)}function C(V){return typeof V=="object"&&V!==null&&V.$$typeof===n}function N(V){var se={"=":"=0",":":"=2"};return"$"+V.replace(/[=:]/g,function(ue){return se[ue]})}var L=/\/+/g;function z(V,se){return typeof V=="object"&&V!==null&&V.key!=null?N(""+V.key):se.toString(36)}function D(){}function tt(V){switch(V.status){case"fulfilled":return V.value;case"rejected":throw V.reason;default:switch(typeof V.status=="string"?V.then(D,D):(V.status="pending",V.then(function(se){V.status==="pending"&&(V.status="fulfilled",V.value=se)},function(se){V.status==="pending"&&(V.status="rejected",V.reason=se)})),V.status){case"fulfilled":return V.value;case"rejected":throw V.reason}}throw V}function ze(V,se,ue,ae,ye){var ke=typeof V;(ke==="undefined"||ke==="boolean")&&(V=null);var Ae=!1;if(V===null)Ae=!0;else switch(ke){case"bigint":case"string":case"number":Ae=!0;break;case"object":switch(V.$$typeof){case n:case e:Ae=!0;break;case y:return Ae=V._init,ze(Ae(V._payload),se,ue,ae,ye)}}if(Ae)return ye=ye(V),Ae=ae===""?"."+z(V,0):ae,W(ye)?(ue="",Ae!=null&&(ue=Ae.replace(L,"$&/")+"/"),ze(ye,se,ue,"",function(Ai){return Ai})):ye!=null&&(C(ye)&&(ye=A(ye,ue+(ye.key==null||V&&V.key===ye.key?"":(""+ye.key).replace(L,"$&/")+"/")+Ae)),se.push(ye)),1;Ae=0;var qt=ae===""?".":ae+":";if(W(V))for(var ct=0;ct<V.length;ct++)ae=V[ct],ke=qt+z(ae,ct),Ae+=ze(ae,se,ue,ke,ye);else if(ct=w(V),typeof ct=="function")for(V=ct.call(V),ct=0;!(ae=V.next()).done;)ae=ae.value,ke=qt+z(ae,ct++),Ae+=ze(ae,se,ue,ke,ye);else if(ke==="object"){if(typeof V.then=="function")return ze(tt(V),se,ue,ae,ye);throw se=String(V),Error("Objects are not valid as a React child (found: "+(se==="[object Object]"?"object with keys {"+Object.keys(V).join(", ")+"}":se)+"). If you meant to render a collection of children, use an array instead.")}return Ae}function X(V,se,ue){if(V==null)return V;var ae=[],ye=0;return ze(V,ae,"","",function(ke){return se.call(ue,ke,ye++)}),ae}function ce(V){if(V._status===-1){var se=V._result;se=se(),se.then(function(ue){(V._status===0||V._status===-1)&&(V._status=1,V._result=ue)},function(ue){(V._status===0||V._status===-1)&&(V._status=2,V._result=ue)}),V._status===-1&&(V._status=0,V._result=se)}if(V._status===1)return V._result.default;throw V._result}var ge=typeof reportError=="function"?reportError:function(V){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var se=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof V=="object"&&V!==null&&typeof V.message=="string"?String(V.message):String(V),error:V});if(!window.dispatchEvent(se))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",V);return}console.error(V)};function Ke(){}return xe.Children={map:X,forEach:function(V,se,ue){X(V,function(){se.apply(this,arguments)},ue)},count:function(V){var se=0;return X(V,function(){se++}),se},toArray:function(V){return X(V,function(se){return se})||[]},only:function(V){if(!C(V))throw Error("React.Children.only expected to receive a single React element child.");return V}},xe.Component=P,xe.Fragment=t,xe.Profiler=a,xe.PureComponent=ee,xe.StrictMode=i,xe.Suspense=m,xe.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=re,xe.__COMPILER_RUNTIME={__proto__:null,c:function(V){return re.H.useMemoCache(V)}},xe.cache=function(V){return function(){return V.apply(null,arguments)}},xe.cloneElement=function(V,se,ue){if(V==null)throw Error("The argument must be a React element, but you passed "+V+".");var ae=I({},V.props),ye=V.key,ke=void 0;if(se!=null)for(Ae in se.ref!==void 0&&(ke=void 0),se.key!==void 0&&(ye=""+se.key),se)!he.call(se,Ae)||Ae==="key"||Ae==="__self"||Ae==="__source"||Ae==="ref"&&se.ref===void 0||(ae[Ae]=se[Ae]);var Ae=arguments.length-2;if(Ae===1)ae.children=ue;else if(1<Ae){for(var qt=Array(Ae),ct=0;ct<Ae;ct++)qt[ct]=arguments[ct+2];ae.children=qt}return M(V.type,ye,void 0,void 0,ke,ae)},xe.createContext=function(V){return V={$$typeof:u,_currentValue:V,_currentValue2:V,_threadCount:0,Provider:null,Consumer:null},V.Provider=V,V.Consumer={$$typeof:l,_context:V},V},xe.createElement=function(V,se,ue){var ae,ye={},ke=null;if(se!=null)for(ae in se.key!==void 0&&(ke=""+se.key),se)he.call(se,ae)&&ae!=="key"&&ae!=="__self"&&ae!=="__source"&&(ye[ae]=se[ae]);var Ae=arguments.length-2;if(Ae===1)ye.children=ue;else if(1<Ae){for(var qt=Array(Ae),ct=0;ct<Ae;ct++)qt[ct]=arguments[ct+2];ye.children=qt}if(V&&V.defaultProps)for(ae in Ae=V.defaultProps,Ae)ye[ae]===void 0&&(ye[ae]=Ae[ae]);return M(V,ke,void 0,void 0,null,ye)},xe.createRef=function(){return{current:null}},xe.forwardRef=function(V){return{$$typeof:d,render:V}},xe.isValidElement=C,xe.lazy=function(V){return{$$typeof:y,_payload:{_status:-1,_result:V},_init:ce}},xe.memo=function(V,se){return{$$typeof:p,type:V,compare:se===void 0?null:se}},xe.startTransition=function(V){var se=re.T,ue={};re.T=ue;try{var ae=V(),ye=re.S;ye!==null&&ye(ue,ae),typeof ae=="object"&&ae!==null&&typeof ae.then=="function"&&ae.then(Ke,ge)}catch(ke){ge(ke)}finally{re.T=se}},xe.unstable_useCacheRefresh=function(){return re.H.useCacheRefresh()},xe.use=function(V){return re.H.use(V)},xe.useActionState=function(V,se,ue){return re.H.useActionState(V,se,ue)},xe.useCallback=function(V,se){return re.H.useCallback(V,se)},xe.useContext=function(V){return re.H.useContext(V)},xe.useDebugValue=function(){},xe.useDeferredValue=function(V,se){return re.H.useDeferredValue(V,se)},xe.useEffect=function(V,se,ue){var ae=re.H;if(typeof ue=="function")throw Error("useEffect CRUD overload is not enabled in this build of React.");return ae.useEffect(V,se)},xe.useId=function(){return re.H.useId()},xe.useImperativeHandle=function(V,se,ue){return re.H.useImperativeHandle(V,se,ue)},xe.useInsertionEffect=function(V,se){return re.H.useInsertionEffect(V,se)},xe.useLayoutEffect=function(V,se){return re.H.useLayoutEffect(V,se)},xe.useMemo=function(V,se){return re.H.useMemo(V,se)},xe.useOptimistic=function(V,se){return re.H.useOptimistic(V,se)},xe.useReducer=function(V,se,ue){return re.H.useReducer(V,se,ue)},xe.useRef=function(V){return re.H.useRef(V)},xe.useState=function(V){return re.H.useState(V)},xe.useSyncExternalStore=function(V,se,ue){return re.H.useSyncExternalStore(V,se,ue)},xe.useTransition=function(){return re.H.useTransition()},xe.version="19.1.0",xe}var XT;function G_(){return XT||(XT=1,wg.exports=aN()),wg.exports}var j=G_(),Sg={exports:{}},zc={},Ag={exports:{}},Rg={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ZT;function oN(){return ZT||(ZT=1,function(n){function e(X,ce){var ge=X.length;X.push(ce);e:for(;0<ge;){var Ke=ge-1>>>1,V=X[Ke];if(0<a(V,ce))X[Ke]=ce,X[ge]=V,ge=Ke;else break e}}function t(X){return X.length===0?null:X[0]}function i(X){if(X.length===0)return null;var ce=X[0],ge=X.pop();if(ge!==ce){X[0]=ge;e:for(var Ke=0,V=X.length,se=V>>>1;Ke<se;){var ue=2*(Ke+1)-1,ae=X[ue],ye=ue+1,ke=X[ye];if(0>a(ae,ge))ye<V&&0>a(ke,ae)?(X[Ke]=ke,X[ye]=ge,Ke=ye):(X[Ke]=ae,X[ue]=ge,Ke=ue);else if(ye<V&&0>a(ke,ge))X[Ke]=ke,X[ye]=ge,Ke=ye;else break e}}return ce}function a(X,ce){var ge=X.sortIndex-ce.sortIndex;return ge!==0?ge:X.id-ce.id}if(n.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var l=performance;n.unstable_now=function(){return l.now()}}else{var u=Date,d=u.now();n.unstable_now=function(){return u.now()-d}}var m=[],p=[],y=1,T=null,w=3,x=!1,I=!1,O=!1,P=!1,B=typeof setTimeout=="function"?setTimeout:null,ee=typeof clearTimeout=="function"?clearTimeout:null,Y=typeof setImmediate<"u"?setImmediate:null;function W(X){for(var ce=t(p);ce!==null;){if(ce.callback===null)i(p);else if(ce.startTime<=X)i(p),ce.sortIndex=ce.expirationTime,e(m,ce);else break;ce=t(p)}}function re(X){if(O=!1,W(X),!I)if(t(m)!==null)I=!0,he||(he=!0,z());else{var ce=t(p);ce!==null&&ze(re,ce.startTime-X)}}var he=!1,M=-1,A=5,C=-1;function N(){return P?!0:!(n.unstable_now()-C<A)}function L(){if(P=!1,he){var X=n.unstable_now();C=X;var ce=!0;try{e:{I=!1,O&&(O=!1,ee(M),M=-1),x=!0;var ge=w;try{t:{for(W(X),T=t(m);T!==null&&!(T.expirationTime>X&&N());){var Ke=T.callback;if(typeof Ke=="function"){T.callback=null,w=T.priorityLevel;var V=Ke(T.expirationTime<=X);if(X=n.unstable_now(),typeof V=="function"){T.callback=V,W(X),ce=!0;break t}T===t(m)&&i(m),W(X)}else i(m);T=t(m)}if(T!==null)ce=!0;else{var se=t(p);se!==null&&ze(re,se.startTime-X),ce=!1}}break e}finally{T=null,w=ge,x=!1}ce=void 0}}finally{ce?z():he=!1}}}var z;if(typeof Y=="function")z=function(){Y(L)};else if(typeof MessageChannel<"u"){var D=new MessageChannel,tt=D.port2;D.port1.onmessage=L,z=function(){tt.postMessage(null)}}else z=function(){B(L,0)};function ze(X,ce){M=B(function(){X(n.unstable_now())},ce)}n.unstable_IdlePriority=5,n.unstable_ImmediatePriority=1,n.unstable_LowPriority=4,n.unstable_NormalPriority=3,n.unstable_Profiling=null,n.unstable_UserBlockingPriority=2,n.unstable_cancelCallback=function(X){X.callback=null},n.unstable_forceFrameRate=function(X){0>X||125<X?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):A=0<X?Math.floor(1e3/X):5},n.unstable_getCurrentPriorityLevel=function(){return w},n.unstable_next=function(X){switch(w){case 1:case 2:case 3:var ce=3;break;default:ce=w}var ge=w;w=ce;try{return X()}finally{w=ge}},n.unstable_requestPaint=function(){P=!0},n.unstable_runWithPriority=function(X,ce){switch(X){case 1:case 2:case 3:case 4:case 5:break;default:X=3}var ge=w;w=X;try{return ce()}finally{w=ge}},n.unstable_scheduleCallback=function(X,ce,ge){var Ke=n.unstable_now();switch(typeof ge=="object"&&ge!==null?(ge=ge.delay,ge=typeof ge=="number"&&0<ge?Ke+ge:Ke):ge=Ke,X){case 1:var V=-1;break;case 2:V=250;break;case 5:V=1073741823;break;case 4:V=1e4;break;default:V=5e3}return V=ge+V,X={id:y++,callback:ce,priorityLevel:X,startTime:ge,expirationTime:V,sortIndex:-1},ge>Ke?(X.sortIndex=ge,e(p,X),t(m)===null&&X===t(p)&&(O?(ee(M),M=-1):O=!0,ze(re,ge-Ke))):(X.sortIndex=V,e(m,X),I||x||(I=!0,he||(he=!0,z()))),X},n.unstable_shouldYield=N,n.unstable_wrapCallback=function(X){var ce=w;return function(){var ge=w;w=ce;try{return X.apply(this,arguments)}finally{w=ge}}}}(Rg)),Rg}var JT;function lN(){return JT||(JT=1,Ag.exports=oN()),Ag.exports}var Cg={exports:{}},un={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var eb;function cN(){if(eb)return un;eb=1;var n=G_();function e(m){var p="https://react.dev/errors/"+m;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var y=2;y<arguments.length;y++)p+="&args[]="+encodeURIComponent(arguments[y])}return"Minified React error #"+m+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function t(){}var i={d:{f:t,r:function(){throw Error(e(522))},D:t,C:t,L:t,m:t,X:t,S:t,M:t},p:0,findDOMNode:null},a=Symbol.for("react.portal");function l(m,p,y){var T=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:a,key:T==null?null:""+T,children:m,containerInfo:p,implementation:y}}var u=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function d(m,p){if(m==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return un.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,un.createPortal=function(m,p){var y=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(e(299));return l(m,p,null,y)},un.flushSync=function(m){var p=u.T,y=i.p;try{if(u.T=null,i.p=2,m)return m()}finally{u.T=p,i.p=y,i.d.f()}},un.preconnect=function(m,p){typeof m=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,i.d.C(m,p))},un.prefetchDNS=function(m){typeof m=="string"&&i.d.D(m)},un.preinit=function(m,p){if(typeof m=="string"&&p&&typeof p.as=="string"){var y=p.as,T=d(y,p.crossOrigin),w=typeof p.integrity=="string"?p.integrity:void 0,x=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;y==="style"?i.d.S(m,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:T,integrity:w,fetchPriority:x}):y==="script"&&i.d.X(m,{crossOrigin:T,integrity:w,fetchPriority:x,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},un.preinitModule=function(m,p){if(typeof m=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var y=d(p.as,p.crossOrigin);i.d.M(m,{crossOrigin:y,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0})}}else p==null&&i.d.M(m)},un.preload=function(m,p){if(typeof m=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var y=p.as,T=d(y,p.crossOrigin);i.d.L(m,y,{crossOrigin:T,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},un.preloadModule=function(m,p){if(typeof m=="string")if(p){var y=d(p.as,p.crossOrigin);i.d.m(m,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:y,integrity:typeof p.integrity=="string"?p.integrity:void 0})}else i.d.m(m)},un.requestFormReset=function(m){i.d.r(m)},un.unstable_batchedUpdates=function(m,p){return m(p)},un.useFormState=function(m,p,y){return u.H.useFormState(m,p,y)},un.useFormStatus=function(){return u.H.useHostTransitionStatus()},un.version="19.1.0",un}var tb;function uN(){if(tb)return Cg.exports;tb=1;function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}return n(),Cg.exports=cN(),Cg.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var nb;function hN(){if(nb)return zc;nb=1;var n=lN(),e=G_(),t=uN();function i(s){var r="https://react.dev/errors/"+s;if(1<arguments.length){r+="?args[]="+encodeURIComponent(arguments[1]);for(var o=2;o<arguments.length;o++)r+="&args[]="+encodeURIComponent(arguments[o])}return"Minified React error #"+s+"; visit "+r+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(s){return!(!s||s.nodeType!==1&&s.nodeType!==9&&s.nodeType!==11)}function l(s){var r=s,o=s;if(s.alternate)for(;r.return;)r=r.return;else{s=r;do r=s,(r.flags&4098)!==0&&(o=r.return),s=r.return;while(s)}return r.tag===3?o:null}function u(s){if(s.tag===13){var r=s.memoizedState;if(r===null&&(s=s.alternate,s!==null&&(r=s.memoizedState)),r!==null)return r.dehydrated}return null}function d(s){if(l(s)!==s)throw Error(i(188))}function m(s){var r=s.alternate;if(!r){if(r=l(s),r===null)throw Error(i(188));return r!==s?null:s}for(var o=s,c=r;;){var f=o.return;if(f===null)break;var g=f.alternate;if(g===null){if(c=f.return,c!==null){o=c;continue}break}if(f.child===g.child){for(g=f.child;g;){if(g===o)return d(f),s;if(g===c)return d(f),r;g=g.sibling}throw Error(i(188))}if(o.return!==c.return)o=f,c=g;else{for(var b=!1,S=f.child;S;){if(S===o){b=!0,o=f,c=g;break}if(S===c){b=!0,c=f,o=g;break}S=S.sibling}if(!b){for(S=g.child;S;){if(S===o){b=!0,o=g,c=f;break}if(S===c){b=!0,c=g,o=f;break}S=S.sibling}if(!b)throw Error(i(189))}}if(o.alternate!==c)throw Error(i(190))}if(o.tag!==3)throw Error(i(188));return o.stateNode.current===o?s:r}function p(s){var r=s.tag;if(r===5||r===26||r===27||r===6)return s;for(s=s.child;s!==null;){if(r=p(s),r!==null)return r;s=s.sibling}return null}var y=Object.assign,T=Symbol.for("react.element"),w=Symbol.for("react.transitional.element"),x=Symbol.for("react.portal"),I=Symbol.for("react.fragment"),O=Symbol.for("react.strict_mode"),P=Symbol.for("react.profiler"),B=Symbol.for("react.provider"),ee=Symbol.for("react.consumer"),Y=Symbol.for("react.context"),W=Symbol.for("react.forward_ref"),re=Symbol.for("react.suspense"),he=Symbol.for("react.suspense_list"),M=Symbol.for("react.memo"),A=Symbol.for("react.lazy"),C=Symbol.for("react.activity"),N=Symbol.for("react.memo_cache_sentinel"),L=Symbol.iterator;function z(s){return s===null||typeof s!="object"?null:(s=L&&s[L]||s["@@iterator"],typeof s=="function"?s:null)}var D=Symbol.for("react.client.reference");function tt(s){if(s==null)return null;if(typeof s=="function")return s.$$typeof===D?null:s.displayName||s.name||null;if(typeof s=="string")return s;switch(s){case I:return"Fragment";case P:return"Profiler";case O:return"StrictMode";case re:return"Suspense";case he:return"SuspenseList";case C:return"Activity"}if(typeof s=="object")switch(s.$$typeof){case x:return"Portal";case Y:return(s.displayName||"Context")+".Provider";case ee:return(s._context.displayName||"Context")+".Consumer";case W:var r=s.render;return s=s.displayName,s||(s=r.displayName||r.name||"",s=s!==""?"ForwardRef("+s+")":"ForwardRef"),s;case M:return r=s.displayName||null,r!==null?r:tt(s.type)||"Memo";case A:r=s._payload,s=s._init;try{return tt(s(r))}catch{}}return null}var ze=Array.isArray,X=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ce=t.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ge={pending:!1,data:null,method:null,action:null},Ke=[],V=-1;function se(s){return{current:s}}function ue(s){0>V||(s.current=Ke[V],Ke[V]=null,V--)}function ae(s,r){V++,Ke[V]=s.current,s.current=r}var ye=se(null),ke=se(null),Ae=se(null),qt=se(null);function ct(s,r){switch(ae(Ae,r),ae(ke,s),ae(ye,null),r.nodeType){case 9:case 11:s=(s=r.documentElement)&&(s=s.namespaceURI)?bT(s):0;break;default:if(s=r.tagName,r=r.namespaceURI)r=bT(r),s=wT(r,s);else switch(s){case"svg":s=1;break;case"math":s=2;break;default:s=0}}ue(ye),ae(ye,s)}function Ai(){ue(ye),ue(ke),ue(Ae)}function Hs(s){s.memoizedState!==null&&ae(qt,s);var r=ye.current,o=wT(r,s.type);r!==o&&(ae(ke,s),ae(ye,o))}function Zi(s){ke.current===s&&(ue(ye),ue(ke)),qt.current===s&&(ue(qt),Mc._currentValue=ge)}var Kr=Object.prototype.hasOwnProperty,Qr=n.unstable_scheduleCallback,Yr=n.unstable_cancelCallback,kl=n.unstable_shouldYield,th=n.unstable_requestPaint,Gn=n.unstable_now,bm=n.unstable_getCurrentPriorityLevel,Dl=n.unstable_ImmediatePriority,to=n.unstable_UserBlockingPriority,Wr=n.unstable_NormalPriority,wm=n.unstable_LowPriority,no=n.unstable_IdlePriority,Ol=n.log,nh=n.unstable_setDisableYieldValue,vt=null,Ze=null;function On(s){if(typeof Ol=="function"&&nh(s),Ze&&typeof Ze.setStrictMode=="function")try{Ze.setStrictMode(vt,s)}catch{}}var ln=Math.clz32?Math.clz32:Xr,ih=Math.log,Sm=Math.LN2;function Xr(s){return s>>>=0,s===0?32:31-(ih(s)/Sm|0)|0}var Zr=256,Jr=4194304;function li(s){var r=s&42;if(r!==0)return r;switch(s&-s){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return s&4194048;case 4194304:case 8388608:case 16777216:case 33554432:return s&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return s}}function io(s,r,o){var c=s.pendingLanes;if(c===0)return 0;var f=0,g=s.suspendedLanes,b=s.pingedLanes;s=s.warmLanes;var S=c&134217727;return S!==0?(c=S&~g,c!==0?f=li(c):(b&=S,b!==0?f=li(b):o||(o=S&~s,o!==0&&(f=li(o))))):(S=c&~g,S!==0?f=li(S):b!==0?f=li(b):o||(o=c&~s,o!==0&&(f=li(o)))),f===0?0:r!==0&&r!==f&&(r&g)===0&&(g=f&-f,o=r&-r,g>=o||g===32&&(o&4194048)!==0)?r:f}function ea(s,r){return(s.pendingLanes&~(s.suspendedLanes&~s.pingedLanes)&r)===0}function Ml(s,r){switch(s){case 1:case 2:case 4:case 8:case 64:return r+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return r+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Pl(){var s=Zr;return Zr<<=1,(Zr&4194048)===0&&(Zr=256),s}function Ll(){var s=Jr;return Jr<<=1,(Jr&62914560)===0&&(Jr=4194304),s}function Ji(s){for(var r=[],o=0;31>o;o++)r.push(s);return r}function es(s,r){s.pendingLanes|=r,r!==268435456&&(s.suspendedLanes=0,s.pingedLanes=0,s.warmLanes=0)}function Vl(s,r,o,c,f,g){var b=s.pendingLanes;s.pendingLanes=o,s.suspendedLanes=0,s.pingedLanes=0,s.warmLanes=0,s.expiredLanes&=o,s.entangledLanes&=o,s.errorRecoveryDisabledLanes&=o,s.shellSuspendCounter=0;var S=s.entanglements,k=s.expirationTimes,G=s.hiddenUpdates;for(o=b&~o;0<o;){var Z=31-ln(o),te=1<<Z;S[Z]=0,k[Z]=-1;var $=G[Z];if($!==null)for(G[Z]=null,Z=0;Z<$.length;Z++){var K=$[Z];K!==null&&(K.lane&=-536870913)}o&=~te}c!==0&&Ri(s,c,0),g!==0&&f===0&&s.tag!==0&&(s.suspendedLanes|=g&~(b&~r))}function Ri(s,r,o){s.pendingLanes|=r,s.suspendedLanes&=~r;var c=31-ln(r);s.entangledLanes|=r,s.entanglements[c]=s.entanglements[c]|1073741824|o&4194090}function Ul(s,r){var o=s.entangledLanes|=r;for(s=s.entanglements;o;){var c=31-ln(o),f=1<<c;f&r|s[c]&r&&(s[c]|=r),o&=~f}}function Gs(s){switch(s){case 2:s=1;break;case 8:s=4;break;case 32:s=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:s=128;break;case 268435456:s=134217728;break;default:s=0}return s}function so(s){return s&=-s,2<s?8<s?(s&134217727)!==0?32:268435456:8:2}function $s(){var s=ce.p;return s!==0?s:(s=window.event,s===void 0?32:BT(s.type))}function sh(s,r){var o=ce.p;try{return ce.p=s,r()}finally{ce.p=o}}var mt=Math.random().toString(36).slice(2),Pt="__reactFiber$"+mt,Ct="__reactProps$"+mt,$n="__reactContainer$"+mt,jl="__reactEvents$"+mt,Am="__reactListeners$"+mt,Ks="__reactHandles$"+mt,rh="__reactResources$"+mt,ta="__reactMarker$"+mt;function Qs(s){delete s[Pt],delete s[Ct],delete s[jl],delete s[Am],delete s[Ks]}function ts(s){var r=s[Pt];if(r)return r;for(var o=s.parentNode;o;){if(r=o[$n]||o[Pt]){if(o=r.alternate,r.child!==null||o!==null&&o.child!==null)for(s=CT(s);s!==null;){if(o=s[Pt])return o;s=CT(s)}return r}s=o,o=s.parentNode}return null}function Ci(s){if(s=s[Pt]||s[$n]){var r=s.tag;if(r===5||r===6||r===13||r===26||r===27||r===3)return s}return null}function xi(s){var r=s.tag;if(r===5||r===26||r===27||r===6)return s.stateNode;throw Error(i(33))}function _n(s){var r=s[rh];return r||(r=s[rh]={hoistableStyles:new Map,hoistableScripts:new Map}),r}function bt(s){s[ta]=!0}var zl=new Set,ro={};function ci(s,r){ns(s,r),ns(s+"Capture",r)}function ns(s,r){for(ro[s]=r,s=0;s<r.length;s++)zl.add(r[s])}var ah=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),oh={},na={};function lh(s){return Kr.call(na,s)?!0:Kr.call(oh,s)?!1:ah.test(s)?na[s]=!0:(oh[s]=!0,!1)}function Ys(s,r,o){if(lh(r))if(o===null)s.removeAttribute(r);else{switch(typeof o){case"undefined":case"function":case"symbol":s.removeAttribute(r);return;case"boolean":var c=r.toLowerCase().slice(0,5);if(c!=="data-"&&c!=="aria-"){s.removeAttribute(r);return}}s.setAttribute(r,""+o)}}function Ii(s,r,o){if(o===null)s.removeAttribute(r);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":s.removeAttribute(r);return}s.setAttribute(r,""+o)}}function Jt(s,r,o,c){if(c===null)s.removeAttribute(o);else{switch(typeof c){case"undefined":case"function":case"symbol":case"boolean":s.removeAttribute(o);return}s.setAttributeNS(r,o,""+c)}}var ia,ch;function is(s){if(ia===void 0)try{throw Error()}catch(o){var r=o.stack.trim().match(/\n( *(at )?)/);ia=r&&r[1]||"",ch=-1<o.stack.indexOf(`
    at`)?" (<anonymous>)":-1<o.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ia+s+ch}var ao=!1;function oo(s,r){if(!s||ao)return"";ao=!0;var o=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var c={DetermineComponentFrameRoot:function(){try{if(r){var te=function(){throw Error()};if(Object.defineProperty(te.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(te,[])}catch(K){var $=K}Reflect.construct(s,[],te)}else{try{te.call()}catch(K){$=K}s.call(te.prototype)}}else{try{throw Error()}catch(K){$=K}(te=s())&&typeof te.catch=="function"&&te.catch(function(){})}}catch(K){if(K&&$&&typeof K.stack=="string")return[K.stack,$.stack]}return[null,null]}};c.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var f=Object.getOwnPropertyDescriptor(c.DetermineComponentFrameRoot,"name");f&&f.configurable&&Object.defineProperty(c.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var g=c.DetermineComponentFrameRoot(),b=g[0],S=g[1];if(b&&S){var k=b.split(`
`),G=S.split(`
`);for(f=c=0;c<k.length&&!k[c].includes("DetermineComponentFrameRoot");)c++;for(;f<G.length&&!G[f].includes("DetermineComponentFrameRoot");)f++;if(c===k.length||f===G.length)for(c=k.length-1,f=G.length-1;1<=c&&0<=f&&k[c]!==G[f];)f--;for(;1<=c&&0<=f;c--,f--)if(k[c]!==G[f]){if(c!==1||f!==1)do if(c--,f--,0>f||k[c]!==G[f]){var Z=`
`+k[c].replace(" at new "," at ");return s.displayName&&Z.includes("<anonymous>")&&(Z=Z.replace("<anonymous>",s.displayName)),Z}while(1<=c&&0<=f);break}}}finally{ao=!1,Error.prepareStackTrace=o}return(o=s?s.displayName||s.name:"")?is(o):""}function Fl(s){switch(s.tag){case 26:case 27:case 5:return is(s.type);case 16:return is("Lazy");case 13:return is("Suspense");case 19:return is("SuspenseList");case 0:case 15:return oo(s.type,!1);case 11:return oo(s.type.render,!1);case 1:return oo(s.type,!0);case 31:return is("Activity");default:return""}}function lo(s){try{var r="";do r+=Fl(s),s=s.return;while(s);return r}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}function yn(s){switch(typeof s){case"bigint":case"boolean":case"number":case"string":case"undefined":return s;case"object":return s;default:return""}}function Bl(s){var r=s.type;return(s=s.nodeName)&&s.toLowerCase()==="input"&&(r==="checkbox"||r==="radio")}function Rm(s){var r=Bl(s)?"checked":"value",o=Object.getOwnPropertyDescriptor(s.constructor.prototype,r),c=""+s[r];if(!s.hasOwnProperty(r)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var f=o.get,g=o.set;return Object.defineProperty(s,r,{configurable:!0,get:function(){return f.call(this)},set:function(b){c=""+b,g.call(this,b)}}),Object.defineProperty(s,r,{enumerable:o.enumerable}),{getValue:function(){return c},setValue:function(b){c=""+b},stopTracking:function(){s._valueTracker=null,delete s[r]}}}}function co(s){s._valueTracker||(s._valueTracker=Rm(s))}function ql(s){if(!s)return!1;var r=s._valueTracker;if(!r)return!0;var o=r.getValue(),c="";return s&&(c=Bl(s)?s.checked?"true":"false":s.value),s=c,s!==o?(r.setValue(s),!0):!1}function sa(s){if(s=s||(typeof document<"u"?document:void 0),typeof s>"u")return null;try{return s.activeElement||s.body}catch{return s.body}}var Cm=/[\n"\\]/g;function xt(s){return s.replace(Cm,function(r){return"\\"+r.charCodeAt(0).toString(16)+" "})}function Mn(s,r,o,c,f,g,b,S){s.name="",b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"?s.type=b:s.removeAttribute("type"),r!=null?b==="number"?(r===0&&s.value===""||s.value!=r)&&(s.value=""+yn(r)):s.value!==""+yn(r)&&(s.value=""+yn(r)):b!=="submit"&&b!=="reset"||s.removeAttribute("value"),r!=null?Ws(s,b,yn(r)):o!=null?Ws(s,b,yn(o)):c!=null&&s.removeAttribute("value"),f==null&&g!=null&&(s.defaultChecked=!!g),f!=null&&(s.checked=f&&typeof f!="function"&&typeof f!="symbol"),S!=null&&typeof S!="function"&&typeof S!="symbol"&&typeof S!="boolean"?s.name=""+yn(S):s.removeAttribute("name")}function ra(s,r,o,c,f,g,b,S){if(g!=null&&typeof g!="function"&&typeof g!="symbol"&&typeof g!="boolean"&&(s.type=g),r!=null||o!=null){if(!(g!=="submit"&&g!=="reset"||r!=null))return;o=o!=null?""+yn(o):"",r=r!=null?""+yn(r):o,S||r===s.value||(s.value=r),s.defaultValue=r}c=c??f,c=typeof c!="function"&&typeof c!="symbol"&&!!c,s.checked=S?s.checked:!!c,s.defaultChecked=!!c,b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"&&(s.name=b)}function Ws(s,r,o){r==="number"&&sa(s.ownerDocument)===s||s.defaultValue===""+o||(s.defaultValue=""+o)}function ss(s,r,o,c){if(s=s.options,r){r={};for(var f=0;f<o.length;f++)r["$"+o[f]]=!0;for(o=0;o<s.length;o++)f=r.hasOwnProperty("$"+s[o].value),s[o].selected!==f&&(s[o].selected=f),f&&c&&(s[o].defaultSelected=!0)}else{for(o=""+yn(o),r=null,f=0;f<s.length;f++){if(s[f].value===o){s[f].selected=!0,c&&(s[f].defaultSelected=!0);return}r!==null||s[f].disabled||(r=s[f])}r!==null&&(r.selected=!0)}}function nt(s,r,o){if(r!=null&&(r=""+yn(r),r!==s.value&&(s.value=r),o==null)){s.defaultValue!==r&&(s.defaultValue=r);return}s.defaultValue=o!=null?""+yn(o):""}function aa(s,r,o,c){if(r==null){if(c!=null){if(o!=null)throw Error(i(92));if(ze(c)){if(1<c.length)throw Error(i(93));c=c[0]}o=c}o==null&&(o=""),r=o}o=yn(r),s.defaultValue=o,c=s.textContent,c===o&&c!==""&&c!==null&&(s.value=c)}function Kn(s,r){if(r){var o=s.firstChild;if(o&&o===s.lastChild&&o.nodeType===3){o.nodeValue=r;return}}s.textContent=r}var oa=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function uh(s,r,o){var c=r.indexOf("--")===0;o==null||typeof o=="boolean"||o===""?c?s.setProperty(r,""):r==="float"?s.cssFloat="":s[r]="":c?s.setProperty(r,o):typeof o!="number"||o===0||oa.has(r)?r==="float"?s.cssFloat=o:s[r]=(""+o).trim():s[r]=o+"px"}function Hl(s,r,o){if(r!=null&&typeof r!="object")throw Error(i(62));if(s=s.style,o!=null){for(var c in o)!o.hasOwnProperty(c)||r!=null&&r.hasOwnProperty(c)||(c.indexOf("--")===0?s.setProperty(c,""):c==="float"?s.cssFloat="":s[c]="");for(var f in r)c=r[f],r.hasOwnProperty(f)&&o[f]!==c&&uh(s,f,c)}else for(var g in r)r.hasOwnProperty(g)&&uh(s,g,r[g])}function Gl(s){if(s.indexOf("-")===-1)return!1;switch(s){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var xm=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Im=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function uo(s){return Im.test(""+s)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":s}var rs=null;function Qn(s){return s=s.target||s.srcElement||window,s.correspondingUseElement&&(s=s.correspondingUseElement),s.nodeType===3?s.parentNode:s}var as=null,os=null;function $l(s){var r=Ci(s);if(r&&(s=r.stateNode)){var o=s[Ct]||null;e:switch(s=r.stateNode,r.type){case"input":if(Mn(s,o.value,o.defaultValue,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name),r=o.name,o.type==="radio"&&r!=null){for(o=s;o.parentNode;)o=o.parentNode;for(o=o.querySelectorAll('input[name="'+xt(""+r)+'"][type="radio"]'),r=0;r<o.length;r++){var c=o[r];if(c!==s&&c.form===s.form){var f=c[Ct]||null;if(!f)throw Error(i(90));Mn(c,f.value,f.defaultValue,f.defaultValue,f.checked,f.defaultChecked,f.type,f.name)}}for(r=0;r<o.length;r++)c=o[r],c.form===s.form&&ql(c)}break e;case"textarea":nt(s,o.value,o.defaultValue);break e;case"select":r=o.value,r!=null&&ss(s,!!o.multiple,r,!1)}}}var Ni=!1;function hh(s,r,o){if(Ni)return s(r,o);Ni=!0;try{var c=s(r);return c}finally{if(Ni=!1,(as!==null||os!==null)&&(sd(),as&&(r=as,s=os,os=as=null,$l(r),s)))for(r=0;r<s.length;r++)$l(s[r])}}function la(s,r){var o=s.stateNode;if(o===null)return null;var c=o[Ct]||null;if(c===null)return null;o=c[r];e:switch(r){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(c=!c.disabled)||(s=s.type,c=!(s==="button"||s==="input"||s==="select"||s==="textarea")),s=!c;break e;default:s=!1}if(s)return null;if(o&&typeof o!="function")throw Error(i(231,r,typeof o));return o}var ui=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Yn=!1;if(ui)try{var ca={};Object.defineProperty(ca,"passive",{get:function(){Yn=!0}}),window.addEventListener("test",ca,ca),window.removeEventListener("test",ca,ca)}catch{Yn=!1}var ki=null,Xs=null,ls=null;function Kl(){if(ls)return ls;var s,r=Xs,o=r.length,c,f="value"in ki?ki.value:ki.textContent,g=f.length;for(s=0;s<o&&r[s]===f[s];s++);var b=o-s;for(c=1;c<=b&&r[o-c]===f[g-c];c++);return ls=f.slice(s,1<c?1-c:void 0)}function Di(s){var r=s.keyCode;return"charCode"in s?(s=s.charCode,s===0&&r===13&&(s=13)):s=r,s===10&&(s=13),32<=s||s===13?s:0}function Oi(){return!0}function Ql(){return!1}function Ht(s){function r(o,c,f,g,b){this._reactName=o,this._targetInst=f,this.type=c,this.nativeEvent=g,this.target=b,this.currentTarget=null;for(var S in s)s.hasOwnProperty(S)&&(o=s[S],this[S]=o?o(g):g[S]);return this.isDefaultPrevented=(g.defaultPrevented!=null?g.defaultPrevented:g.returnValue===!1)?Oi:Ql,this.isPropagationStopped=Ql,this}return y(r.prototype,{preventDefault:function(){this.defaultPrevented=!0;var o=this.nativeEvent;o&&(o.preventDefault?o.preventDefault():typeof o.returnValue!="unknown"&&(o.returnValue=!1),this.isDefaultPrevented=Oi)},stopPropagation:function(){var o=this.nativeEvent;o&&(o.stopPropagation?o.stopPropagation():typeof o.cancelBubble!="unknown"&&(o.cancelBubble=!0),this.isPropagationStopped=Oi)},persist:function(){},isPersistent:Oi}),r}var We={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(s){return s.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},ho=Ht(We),ua=y({},We,{view:0,detail:0}),dh=Ht(ua),fo,mo,Mi,ha=y({},ua,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ma,button:0,buttons:0,relatedTarget:function(s){return s.relatedTarget===void 0?s.fromElement===s.srcElement?s.toElement:s.fromElement:s.relatedTarget},movementX:function(s){return"movementX"in s?s.movementX:(s!==Mi&&(Mi&&s.type==="mousemove"?(fo=s.screenX-Mi.screenX,mo=s.screenY-Mi.screenY):mo=fo=0,Mi=s),fo)},movementY:function(s){return"movementY"in s?s.movementY:mo}}),Wn=Ht(ha),fh=y({},ha,{dataTransfer:0}),Nm=Ht(fh),da=y({},ua,{relatedTarget:0}),po=Ht(da),Yl=y({},We,{animationName:0,elapsedTime:0,pseudoElement:0}),go=Ht(Yl),mh=y({},We,{clipboardData:function(s){return"clipboardData"in s?s.clipboardData:window.clipboardData}}),_o=Ht(mh),km=y({},We,{data:0}),Wl=Ht(km),fa={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ph={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},gh={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Xl(s){var r=this.nativeEvent;return r.getModifierState?r.getModifierState(s):(s=gh[s])?!!r[s]:!1}function ma(){return Xl}var _h=y({},ua,{key:function(s){if(s.key){var r=fa[s.key]||s.key;if(r!=="Unidentified")return r}return s.type==="keypress"?(s=Di(s),s===13?"Enter":String.fromCharCode(s)):s.type==="keydown"||s.type==="keyup"?ph[s.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ma,charCode:function(s){return s.type==="keypress"?Di(s):0},keyCode:function(s){return s.type==="keydown"||s.type==="keyup"?s.keyCode:0},which:function(s){return s.type==="keypress"?Di(s):s.type==="keydown"||s.type==="keyup"?s.keyCode:0}}),yo=Ht(_h),yh=y({},ha,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Zl=Ht(yh),cs=y({},ua,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ma}),vh=Ht(cs),Eh=y({},We,{propertyName:0,elapsedTime:0,pseudoElement:0}),Th=Ht(Eh),bh=y({},ha,{deltaX:function(s){return"deltaX"in s?s.deltaX:"wheelDeltaX"in s?-s.wheelDeltaX:0},deltaY:function(s){return"deltaY"in s?s.deltaY:"wheelDeltaY"in s?-s.wheelDeltaY:"wheelDelta"in s?-s.wheelDelta:0},deltaZ:0,deltaMode:0}),vo=Ht(bh),vn=y({},We,{newState:0,oldState:0}),wh=Ht(vn),Sh=[9,13,27,32],Pi=ui&&"CompositionEvent"in window,h=null;ui&&"documentMode"in document&&(h=document.documentMode);var _=ui&&"TextEvent"in window&&!h,E=ui&&(!Pi||h&&8<h&&11>=h),R=" ",q=!1;function Q(s,r){switch(s){case"keyup":return Sh.indexOf(r.keyCode)!==-1;case"keydown":return r.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function le(s){return s=s.detail,typeof s=="object"&&"data"in s?s.data:null}var Fe=!1;function Lt(s,r){switch(s){case"compositionend":return le(r);case"keypress":return r.which!==32?null:(q=!0,R);case"textInput":return s=r.data,s===R&&q?null:s;default:return null}}function Be(s,r){if(Fe)return s==="compositionend"||!Pi&&Q(s,r)?(s=Kl(),ls=Xs=ki=null,Fe=!1,s):null;switch(s){case"paste":return null;case"keypress":if(!(r.ctrlKey||r.altKey||r.metaKey)||r.ctrlKey&&r.altKey){if(r.char&&1<r.char.length)return r.char;if(r.which)return String.fromCharCode(r.which)}return null;case"compositionend":return E&&r.locale!=="ko"?null:r.data;default:return null}}var Gt={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Vt(s){var r=s&&s.nodeName&&s.nodeName.toLowerCase();return r==="input"?!!Gt[s.type]:r==="textarea"}function us(s,r,o,c){as?os?os.push(c):os=[c]:as=c,r=ud(r,"onChange"),0<r.length&&(o=new ho("onChange","change",null,o,c),s.push({event:o,listeners:r}))}var en=null,Li=null;function Jl(s){_T(s,0)}function Ah(s){var r=xi(s);if(ql(r))return s}function Uv(s,r){if(s==="change")return r}var jv=!1;if(ui){var Dm;if(ui){var Om="oninput"in document;if(!Om){var zv=document.createElement("div");zv.setAttribute("oninput","return;"),Om=typeof zv.oninput=="function"}Dm=Om}else Dm=!1;jv=Dm&&(!document.documentMode||9<document.documentMode)}function Fv(){en&&(en.detachEvent("onpropertychange",Bv),Li=en=null)}function Bv(s){if(s.propertyName==="value"&&Ah(Li)){var r=[];us(r,Li,s,Qn(s)),hh(Jl,r)}}function MI(s,r,o){s==="focusin"?(Fv(),en=r,Li=o,en.attachEvent("onpropertychange",Bv)):s==="focusout"&&Fv()}function PI(s){if(s==="selectionchange"||s==="keyup"||s==="keydown")return Ah(Li)}function LI(s,r){if(s==="click")return Ah(r)}function VI(s,r){if(s==="input"||s==="change")return Ah(r)}function UI(s,r){return s===r&&(s!==0||1/s===1/r)||s!==s&&r!==r}var Pn=typeof Object.is=="function"?Object.is:UI;function ec(s,r){if(Pn(s,r))return!0;if(typeof s!="object"||s===null||typeof r!="object"||r===null)return!1;var o=Object.keys(s),c=Object.keys(r);if(o.length!==c.length)return!1;for(c=0;c<o.length;c++){var f=o[c];if(!Kr.call(r,f)||!Pn(s[f],r[f]))return!1}return!0}function qv(s){for(;s&&s.firstChild;)s=s.firstChild;return s}function Hv(s,r){var o=qv(s);s=0;for(var c;o;){if(o.nodeType===3){if(c=s+o.textContent.length,s<=r&&c>=r)return{node:o,offset:r-s};s=c}e:{for(;o;){if(o.nextSibling){o=o.nextSibling;break e}o=o.parentNode}o=void 0}o=qv(o)}}function Gv(s,r){return s&&r?s===r?!0:s&&s.nodeType===3?!1:r&&r.nodeType===3?Gv(s,r.parentNode):"contains"in s?s.contains(r):s.compareDocumentPosition?!!(s.compareDocumentPosition(r)&16):!1:!1}function $v(s){s=s!=null&&s.ownerDocument!=null&&s.ownerDocument.defaultView!=null?s.ownerDocument.defaultView:window;for(var r=sa(s.document);r instanceof s.HTMLIFrameElement;){try{var o=typeof r.contentWindow.location.href=="string"}catch{o=!1}if(o)s=r.contentWindow;else break;r=sa(s.document)}return r}function Mm(s){var r=s&&s.nodeName&&s.nodeName.toLowerCase();return r&&(r==="input"&&(s.type==="text"||s.type==="search"||s.type==="tel"||s.type==="url"||s.type==="password")||r==="textarea"||s.contentEditable==="true")}var jI=ui&&"documentMode"in document&&11>=document.documentMode,Eo=null,Pm=null,tc=null,Lm=!1;function Kv(s,r,o){var c=o.window===o?o.document:o.nodeType===9?o:o.ownerDocument;Lm||Eo==null||Eo!==sa(c)||(c=Eo,"selectionStart"in c&&Mm(c)?c={start:c.selectionStart,end:c.selectionEnd}:(c=(c.ownerDocument&&c.ownerDocument.defaultView||window).getSelection(),c={anchorNode:c.anchorNode,anchorOffset:c.anchorOffset,focusNode:c.focusNode,focusOffset:c.focusOffset}),tc&&ec(tc,c)||(tc=c,c=ud(Pm,"onSelect"),0<c.length&&(r=new ho("onSelect","select",null,r,o),s.push({event:r,listeners:c}),r.target=Eo)))}function pa(s,r){var o={};return o[s.toLowerCase()]=r.toLowerCase(),o["Webkit"+s]="webkit"+r,o["Moz"+s]="moz"+r,o}var To={animationend:pa("Animation","AnimationEnd"),animationiteration:pa("Animation","AnimationIteration"),animationstart:pa("Animation","AnimationStart"),transitionrun:pa("Transition","TransitionRun"),transitionstart:pa("Transition","TransitionStart"),transitioncancel:pa("Transition","TransitionCancel"),transitionend:pa("Transition","TransitionEnd")},Vm={},Qv={};ui&&(Qv=document.createElement("div").style,"AnimationEvent"in window||(delete To.animationend.animation,delete To.animationiteration.animation,delete To.animationstart.animation),"TransitionEvent"in window||delete To.transitionend.transition);function ga(s){if(Vm[s])return Vm[s];if(!To[s])return s;var r=To[s],o;for(o in r)if(r.hasOwnProperty(o)&&o in Qv)return Vm[s]=r[o];return s}var Yv=ga("animationend"),Wv=ga("animationiteration"),Xv=ga("animationstart"),zI=ga("transitionrun"),FI=ga("transitionstart"),BI=ga("transitioncancel"),Zv=ga("transitionend"),Jv=new Map,Um="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Um.push("scrollEnd");function hi(s,r){Jv.set(s,r),ci(r,[s])}var eE=new WeakMap;function Xn(s,r){if(typeof s=="object"&&s!==null){var o=eE.get(s);return o!==void 0?o:(r={value:s,source:r,stack:lo(r)},eE.set(s,r),r)}return{value:s,source:r,stack:lo(r)}}var Zn=[],bo=0,jm=0;function Rh(){for(var s=bo,r=jm=bo=0;r<s;){var o=Zn[r];Zn[r++]=null;var c=Zn[r];Zn[r++]=null;var f=Zn[r];Zn[r++]=null;var g=Zn[r];if(Zn[r++]=null,c!==null&&f!==null){var b=c.pending;b===null?f.next=f:(f.next=b.next,b.next=f),c.pending=f}g!==0&&tE(o,f,g)}}function Ch(s,r,o,c){Zn[bo++]=s,Zn[bo++]=r,Zn[bo++]=o,Zn[bo++]=c,jm|=c,s.lanes|=c,s=s.alternate,s!==null&&(s.lanes|=c)}function zm(s,r,o,c){return Ch(s,r,o,c),xh(s)}function wo(s,r){return Ch(s,null,null,r),xh(s)}function tE(s,r,o){s.lanes|=o;var c=s.alternate;c!==null&&(c.lanes|=o);for(var f=!1,g=s.return;g!==null;)g.childLanes|=o,c=g.alternate,c!==null&&(c.childLanes|=o),g.tag===22&&(s=g.stateNode,s===null||s._visibility&1||(f=!0)),s=g,g=g.return;return s.tag===3?(g=s.stateNode,f&&r!==null&&(f=31-ln(o),s=g.hiddenUpdates,c=s[f],c===null?s[f]=[r]:c.push(r),r.lane=o|536870912),g):null}function xh(s){if(50<Rc)throw Rc=0,$p=null,Error(i(185));for(var r=s.return;r!==null;)s=r,r=s.return;return s.tag===3?s.stateNode:null}var So={};function qI(s,r,o,c){this.tag=s,this.key=o,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=r,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=c,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ln(s,r,o,c){return new qI(s,r,o,c)}function Fm(s){return s=s.prototype,!(!s||!s.isReactComponent)}function hs(s,r){var o=s.alternate;return o===null?(o=Ln(s.tag,r,s.key,s.mode),o.elementType=s.elementType,o.type=s.type,o.stateNode=s.stateNode,o.alternate=s,s.alternate=o):(o.pendingProps=r,o.type=s.type,o.flags=0,o.subtreeFlags=0,o.deletions=null),o.flags=s.flags&65011712,o.childLanes=s.childLanes,o.lanes=s.lanes,o.child=s.child,o.memoizedProps=s.memoizedProps,o.memoizedState=s.memoizedState,o.updateQueue=s.updateQueue,r=s.dependencies,o.dependencies=r===null?null:{lanes:r.lanes,firstContext:r.firstContext},o.sibling=s.sibling,o.index=s.index,o.ref=s.ref,o.refCleanup=s.refCleanup,o}function nE(s,r){s.flags&=65011714;var o=s.alternate;return o===null?(s.childLanes=0,s.lanes=r,s.child=null,s.subtreeFlags=0,s.memoizedProps=null,s.memoizedState=null,s.updateQueue=null,s.dependencies=null,s.stateNode=null):(s.childLanes=o.childLanes,s.lanes=o.lanes,s.child=o.child,s.subtreeFlags=0,s.deletions=null,s.memoizedProps=o.memoizedProps,s.memoizedState=o.memoizedState,s.updateQueue=o.updateQueue,s.type=o.type,r=o.dependencies,s.dependencies=r===null?null:{lanes:r.lanes,firstContext:r.firstContext}),s}function Ih(s,r,o,c,f,g){var b=0;if(c=s,typeof s=="function")Fm(s)&&(b=1);else if(typeof s=="string")b=G1(s,o,ye.current)?26:s==="html"||s==="head"||s==="body"?27:5;else e:switch(s){case C:return s=Ln(31,o,r,f),s.elementType=C,s.lanes=g,s;case I:return _a(o.children,f,g,r);case O:b=8,f|=24;break;case P:return s=Ln(12,o,r,f|2),s.elementType=P,s.lanes=g,s;case re:return s=Ln(13,o,r,f),s.elementType=re,s.lanes=g,s;case he:return s=Ln(19,o,r,f),s.elementType=he,s.lanes=g,s;default:if(typeof s=="object"&&s!==null)switch(s.$$typeof){case B:case Y:b=10;break e;case ee:b=9;break e;case W:b=11;break e;case M:b=14;break e;case A:b=16,c=null;break e}b=29,o=Error(i(130,s===null?"null":typeof s,"")),c=null}return r=Ln(b,o,r,f),r.elementType=s,r.type=c,r.lanes=g,r}function _a(s,r,o,c){return s=Ln(7,s,c,r),s.lanes=o,s}function Bm(s,r,o){return s=Ln(6,s,null,r),s.lanes=o,s}function qm(s,r,o){return r=Ln(4,s.children!==null?s.children:[],s.key,r),r.lanes=o,r.stateNode={containerInfo:s.containerInfo,pendingChildren:null,implementation:s.implementation},r}var Ao=[],Ro=0,Nh=null,kh=0,Jn=[],ei=0,ya=null,ds=1,fs="";function va(s,r){Ao[Ro++]=kh,Ao[Ro++]=Nh,Nh=s,kh=r}function iE(s,r,o){Jn[ei++]=ds,Jn[ei++]=fs,Jn[ei++]=ya,ya=s;var c=ds;s=fs;var f=32-ln(c)-1;c&=~(1<<f),o+=1;var g=32-ln(r)+f;if(30<g){var b=f-f%5;g=(c&(1<<b)-1).toString(32),c>>=b,f-=b,ds=1<<32-ln(r)+f|o<<f|c,fs=g+s}else ds=1<<g|o<<f|c,fs=s}function Hm(s){s.return!==null&&(va(s,1),iE(s,1,0))}function Gm(s){for(;s===Nh;)Nh=Ao[--Ro],Ao[Ro]=null,kh=Ao[--Ro],Ao[Ro]=null;for(;s===ya;)ya=Jn[--ei],Jn[ei]=null,fs=Jn[--ei],Jn[ei]=null,ds=Jn[--ei],Jn[ei]=null}var En=null,Et=null,Qe=!1,Ea=null,Vi=!1,$m=Error(i(519));function Ta(s){var r=Error(i(418,""));throw sc(Xn(r,s)),$m}function sE(s){var r=s.stateNode,o=s.type,c=s.memoizedProps;switch(r[Pt]=s,r[Ct]=c,o){case"dialog":Ve("cancel",r),Ve("close",r);break;case"iframe":case"object":case"embed":Ve("load",r);break;case"video":case"audio":for(o=0;o<xc.length;o++)Ve(xc[o],r);break;case"source":Ve("error",r);break;case"img":case"image":case"link":Ve("error",r),Ve("load",r);break;case"details":Ve("toggle",r);break;case"input":Ve("invalid",r),ra(r,c.value,c.defaultValue,c.checked,c.defaultChecked,c.type,c.name,!0),co(r);break;case"select":Ve("invalid",r);break;case"textarea":Ve("invalid",r),aa(r,c.value,c.defaultValue,c.children),co(r)}o=c.children,typeof o!="string"&&typeof o!="number"&&typeof o!="bigint"||r.textContent===""+o||c.suppressHydrationWarning===!0||TT(r.textContent,o)?(c.popover!=null&&(Ve("beforetoggle",r),Ve("toggle",r)),c.onScroll!=null&&Ve("scroll",r),c.onScrollEnd!=null&&Ve("scrollend",r),c.onClick!=null&&(r.onclick=hd),r=!0):r=!1,r||Ta(s)}function rE(s){for(En=s.return;En;)switch(En.tag){case 5:case 13:Vi=!1;return;case 27:case 3:Vi=!0;return;default:En=En.return}}function nc(s){if(s!==En)return!1;if(!Qe)return rE(s),Qe=!0,!1;var r=s.tag,o;if((o=r!==3&&r!==27)&&((o=r===5)&&(o=s.type,o=!(o!=="form"&&o!=="button")||lg(s.type,s.memoizedProps)),o=!o),o&&Et&&Ta(s),rE(s),r===13){if(s=s.memoizedState,s=s!==null?s.dehydrated:null,!s)throw Error(i(317));e:{for(s=s.nextSibling,r=0;s;){if(s.nodeType===8)if(o=s.data,o==="/$"){if(r===0){Et=fi(s.nextSibling);break e}r--}else o!=="$"&&o!=="$!"&&o!=="$?"||r++;s=s.nextSibling}Et=null}}else r===27?(r=Et,fr(s.type)?(s=dg,dg=null,Et=s):Et=r):Et=En?fi(s.stateNode.nextSibling):null;return!0}function ic(){Et=En=null,Qe=!1}function aE(){var s=Ea;return s!==null&&(Sn===null?Sn=s:Sn.push.apply(Sn,s),Ea=null),s}function sc(s){Ea===null?Ea=[s]:Ea.push(s)}var Km=se(null),ba=null,ms=null;function Zs(s,r,o){ae(Km,r._currentValue),r._currentValue=o}function ps(s){s._currentValue=Km.current,ue(Km)}function Qm(s,r,o){for(;s!==null;){var c=s.alternate;if((s.childLanes&r)!==r?(s.childLanes|=r,c!==null&&(c.childLanes|=r)):c!==null&&(c.childLanes&r)!==r&&(c.childLanes|=r),s===o)break;s=s.return}}function Ym(s,r,o,c){var f=s.child;for(f!==null&&(f.return=s);f!==null;){var g=f.dependencies;if(g!==null){var b=f.child;g=g.firstContext;e:for(;g!==null;){var S=g;g=f;for(var k=0;k<r.length;k++)if(S.context===r[k]){g.lanes|=o,S=g.alternate,S!==null&&(S.lanes|=o),Qm(g.return,o,s),c||(b=null);break e}g=S.next}}else if(f.tag===18){if(b=f.return,b===null)throw Error(i(341));b.lanes|=o,g=b.alternate,g!==null&&(g.lanes|=o),Qm(b,o,s),b=null}else b=f.child;if(b!==null)b.return=f;else for(b=f;b!==null;){if(b===s){b=null;break}if(f=b.sibling,f!==null){f.return=b.return,b=f;break}b=b.return}f=b}}function rc(s,r,o,c){s=null;for(var f=r,g=!1;f!==null;){if(!g){if((f.flags&524288)!==0)g=!0;else if((f.flags&262144)!==0)break}if(f.tag===10){var b=f.alternate;if(b===null)throw Error(i(387));if(b=b.memoizedProps,b!==null){var S=f.type;Pn(f.pendingProps.value,b.value)||(s!==null?s.push(S):s=[S])}}else if(f===qt.current){if(b=f.alternate,b===null)throw Error(i(387));b.memoizedState.memoizedState!==f.memoizedState.memoizedState&&(s!==null?s.push(Mc):s=[Mc])}f=f.return}s!==null&&Ym(r,s,o,c),r.flags|=262144}function Dh(s){for(s=s.firstContext;s!==null;){if(!Pn(s.context._currentValue,s.memoizedValue))return!0;s=s.next}return!1}function wa(s){ba=s,ms=null,s=s.dependencies,s!==null&&(s.firstContext=null)}function cn(s){return oE(ba,s)}function Oh(s,r){return ba===null&&wa(s),oE(s,r)}function oE(s,r){var o=r._currentValue;if(r={context:r,memoizedValue:o,next:null},ms===null){if(s===null)throw Error(i(308));ms=r,s.dependencies={lanes:0,firstContext:r},s.flags|=524288}else ms=ms.next=r;return o}var HI=typeof AbortController<"u"?AbortController:function(){var s=[],r=this.signal={aborted:!1,addEventListener:function(o,c){s.push(c)}};this.abort=function(){r.aborted=!0,s.forEach(function(o){return o()})}},GI=n.unstable_scheduleCallback,$I=n.unstable_NormalPriority,Ut={$$typeof:Y,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Wm(){return{controller:new HI,data:new Map,refCount:0}}function ac(s){s.refCount--,s.refCount===0&&GI($I,function(){s.controller.abort()})}var oc=null,Xm=0,Co=0,xo=null;function KI(s,r){if(oc===null){var o=oc=[];Xm=0,Co=Jp(),xo={status:"pending",value:void 0,then:function(c){o.push(c)}}}return Xm++,r.then(lE,lE),r}function lE(){if(--Xm===0&&oc!==null){xo!==null&&(xo.status="fulfilled");var s=oc;oc=null,Co=0,xo=null;for(var r=0;r<s.length;r++)(0,s[r])()}}function QI(s,r){var o=[],c={status:"pending",value:null,reason:null,then:function(f){o.push(f)}};return s.then(function(){c.status="fulfilled",c.value=r;for(var f=0;f<o.length;f++)(0,o[f])(r)},function(f){for(c.status="rejected",c.reason=f,f=0;f<o.length;f++)(0,o[f])(void 0)}),c}var cE=X.S;X.S=function(s,r){typeof r=="object"&&r!==null&&typeof r.then=="function"&&KI(s,r),cE!==null&&cE(s,r)};var Sa=se(null);function Zm(){var s=Sa.current;return s!==null?s:ut.pooledCache}function Mh(s,r){r===null?ae(Sa,Sa.current):ae(Sa,r.pool)}function uE(){var s=Zm();return s===null?null:{parent:Ut._currentValue,pool:s}}var lc=Error(i(460)),hE=Error(i(474)),Ph=Error(i(542)),Jm={then:function(){}};function dE(s){return s=s.status,s==="fulfilled"||s==="rejected"}function Lh(){}function fE(s,r,o){switch(o=s[o],o===void 0?s.push(r):o!==r&&(r.then(Lh,Lh),r=o),r.status){case"fulfilled":return r.value;case"rejected":throw s=r.reason,pE(s),s;default:if(typeof r.status=="string")r.then(Lh,Lh);else{if(s=ut,s!==null&&100<s.shellSuspendCounter)throw Error(i(482));s=r,s.status="pending",s.then(function(c){if(r.status==="pending"){var f=r;f.status="fulfilled",f.value=c}},function(c){if(r.status==="pending"){var f=r;f.status="rejected",f.reason=c}})}switch(r.status){case"fulfilled":return r.value;case"rejected":throw s=r.reason,pE(s),s}throw cc=r,lc}}var cc=null;function mE(){if(cc===null)throw Error(i(459));var s=cc;return cc=null,s}function pE(s){if(s===lc||s===Ph)throw Error(i(483))}var Js=!1;function ep(s){s.updateQueue={baseState:s.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function tp(s,r){s=s.updateQueue,r.updateQueue===s&&(r.updateQueue={baseState:s.baseState,firstBaseUpdate:s.firstBaseUpdate,lastBaseUpdate:s.lastBaseUpdate,shared:s.shared,callbacks:null})}function er(s){return{lane:s,tag:0,payload:null,callback:null,next:null}}function tr(s,r,o){var c=s.updateQueue;if(c===null)return null;if(c=c.shared,(Je&2)!==0){var f=c.pending;return f===null?r.next=r:(r.next=f.next,f.next=r),c.pending=r,r=xh(s),tE(s,null,o),r}return Ch(s,c,r,o),xh(s)}function uc(s,r,o){if(r=r.updateQueue,r!==null&&(r=r.shared,(o&4194048)!==0)){var c=r.lanes;c&=s.pendingLanes,o|=c,r.lanes=o,Ul(s,o)}}function np(s,r){var o=s.updateQueue,c=s.alternate;if(c!==null&&(c=c.updateQueue,o===c)){var f=null,g=null;if(o=o.firstBaseUpdate,o!==null){do{var b={lane:o.lane,tag:o.tag,payload:o.payload,callback:null,next:null};g===null?f=g=b:g=g.next=b,o=o.next}while(o!==null);g===null?f=g=r:g=g.next=r}else f=g=r;o={baseState:c.baseState,firstBaseUpdate:f,lastBaseUpdate:g,shared:c.shared,callbacks:c.callbacks},s.updateQueue=o;return}s=o.lastBaseUpdate,s===null?o.firstBaseUpdate=r:s.next=r,o.lastBaseUpdate=r}var ip=!1;function hc(){if(ip){var s=xo;if(s!==null)throw s}}function dc(s,r,o,c){ip=!1;var f=s.updateQueue;Js=!1;var g=f.firstBaseUpdate,b=f.lastBaseUpdate,S=f.shared.pending;if(S!==null){f.shared.pending=null;var k=S,G=k.next;k.next=null,b===null?g=G:b.next=G,b=k;var Z=s.alternate;Z!==null&&(Z=Z.updateQueue,S=Z.lastBaseUpdate,S!==b&&(S===null?Z.firstBaseUpdate=G:S.next=G,Z.lastBaseUpdate=k))}if(g!==null){var te=f.baseState;b=0,Z=G=k=null,S=g;do{var $=S.lane&-536870913,K=$!==S.lane;if(K?(qe&$)===$:(c&$)===$){$!==0&&$===Co&&(ip=!0),Z!==null&&(Z=Z.next={lane:0,tag:S.tag,payload:S.payload,callback:null,next:null});e:{var be=s,ve=S;$=r;var rt=o;switch(ve.tag){case 1:if(be=ve.payload,typeof be=="function"){te=be.call(rt,te,$);break e}te=be;break e;case 3:be.flags=be.flags&-65537|128;case 0:if(be=ve.payload,$=typeof be=="function"?be.call(rt,te,$):be,$==null)break e;te=y({},te,$);break e;case 2:Js=!0}}$=S.callback,$!==null&&(s.flags|=64,K&&(s.flags|=8192),K=f.callbacks,K===null?f.callbacks=[$]:K.push($))}else K={lane:$,tag:S.tag,payload:S.payload,callback:S.callback,next:null},Z===null?(G=Z=K,k=te):Z=Z.next=K,b|=$;if(S=S.next,S===null){if(S=f.shared.pending,S===null)break;K=S,S=K.next,K.next=null,f.lastBaseUpdate=K,f.shared.pending=null}}while(!0);Z===null&&(k=te),f.baseState=k,f.firstBaseUpdate=G,f.lastBaseUpdate=Z,g===null&&(f.shared.lanes=0),cr|=b,s.lanes=b,s.memoizedState=te}}function gE(s,r){if(typeof s!="function")throw Error(i(191,s));s.call(r)}function _E(s,r){var o=s.callbacks;if(o!==null)for(s.callbacks=null,s=0;s<o.length;s++)gE(o[s],r)}var Io=se(null),Vh=se(0);function yE(s,r){s=bs,ae(Vh,s),ae(Io,r),bs=s|r.baseLanes}function sp(){ae(Vh,bs),ae(Io,Io.current)}function rp(){bs=Vh.current,ue(Io),ue(Vh)}var nr=0,Ie=null,it=null,It=null,Uh=!1,No=!1,Aa=!1,jh=0,fc=0,ko=null,YI=0;function wt(){throw Error(i(321))}function ap(s,r){if(r===null)return!1;for(var o=0;o<r.length&&o<s.length;o++)if(!Pn(s[o],r[o]))return!1;return!0}function op(s,r,o,c,f,g){return nr=g,Ie=r,r.memoizedState=null,r.updateQueue=null,r.lanes=0,X.H=s===null||s.memoizedState===null?t0:n0,Aa=!1,g=o(c,f),Aa=!1,No&&(g=EE(r,o,c,f)),vE(s),g}function vE(s){X.H=Gh;var r=it!==null&&it.next!==null;if(nr=0,It=it=Ie=null,Uh=!1,fc=0,ko=null,r)throw Error(i(300));s===null||$t||(s=s.dependencies,s!==null&&Dh(s)&&($t=!0))}function EE(s,r,o,c){Ie=s;var f=0;do{if(No&&(ko=null),fc=0,No=!1,25<=f)throw Error(i(301));if(f+=1,It=it=null,s.updateQueue!=null){var g=s.updateQueue;g.lastEffect=null,g.events=null,g.stores=null,g.memoCache!=null&&(g.memoCache.index=0)}X.H=n1,g=r(o,c)}while(No);return g}function WI(){var s=X.H,r=s.useState()[0];return r=typeof r.then=="function"?mc(r):r,s=s.useState()[0],(it!==null?it.memoizedState:null)!==s&&(Ie.flags|=1024),r}function lp(){var s=jh!==0;return jh=0,s}function cp(s,r,o){r.updateQueue=s.updateQueue,r.flags&=-2053,s.lanes&=~o}function up(s){if(Uh){for(s=s.memoizedState;s!==null;){var r=s.queue;r!==null&&(r.pending=null),s=s.next}Uh=!1}nr=0,It=it=Ie=null,No=!1,fc=jh=0,ko=null}function bn(){var s={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return It===null?Ie.memoizedState=It=s:It=It.next=s,It}function Nt(){if(it===null){var s=Ie.alternate;s=s!==null?s.memoizedState:null}else s=it.next;var r=It===null?Ie.memoizedState:It.next;if(r!==null)It=r,it=s;else{if(s===null)throw Ie.alternate===null?Error(i(467)):Error(i(310));it=s,s={memoizedState:it.memoizedState,baseState:it.baseState,baseQueue:it.baseQueue,queue:it.queue,next:null},It===null?Ie.memoizedState=It=s:It=It.next=s}return It}function hp(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function mc(s){var r=fc;return fc+=1,ko===null&&(ko=[]),s=fE(ko,s,r),r=Ie,(It===null?r.memoizedState:It.next)===null&&(r=r.alternate,X.H=r===null||r.memoizedState===null?t0:n0),s}function zh(s){if(s!==null&&typeof s=="object"){if(typeof s.then=="function")return mc(s);if(s.$$typeof===Y)return cn(s)}throw Error(i(438,String(s)))}function dp(s){var r=null,o=Ie.updateQueue;if(o!==null&&(r=o.memoCache),r==null){var c=Ie.alternate;c!==null&&(c=c.updateQueue,c!==null&&(c=c.memoCache,c!=null&&(r={data:c.data.map(function(f){return f.slice()}),index:0})))}if(r==null&&(r={data:[],index:0}),o===null&&(o=hp(),Ie.updateQueue=o),o.memoCache=r,o=r.data[r.index],o===void 0)for(o=r.data[r.index]=Array(s),c=0;c<s;c++)o[c]=N;return r.index++,o}function gs(s,r){return typeof r=="function"?r(s):r}function Fh(s){var r=Nt();return fp(r,it,s)}function fp(s,r,o){var c=s.queue;if(c===null)throw Error(i(311));c.lastRenderedReducer=o;var f=s.baseQueue,g=c.pending;if(g!==null){if(f!==null){var b=f.next;f.next=g.next,g.next=b}r.baseQueue=f=g,c.pending=null}if(g=s.baseState,f===null)s.memoizedState=g;else{r=f.next;var S=b=null,k=null,G=r,Z=!1;do{var te=G.lane&-536870913;if(te!==G.lane?(qe&te)===te:(nr&te)===te){var $=G.revertLane;if($===0)k!==null&&(k=k.next={lane:0,revertLane:0,action:G.action,hasEagerState:G.hasEagerState,eagerState:G.eagerState,next:null}),te===Co&&(Z=!0);else if((nr&$)===$){G=G.next,$===Co&&(Z=!0);continue}else te={lane:0,revertLane:G.revertLane,action:G.action,hasEagerState:G.hasEagerState,eagerState:G.eagerState,next:null},k===null?(S=k=te,b=g):k=k.next=te,Ie.lanes|=$,cr|=$;te=G.action,Aa&&o(g,te),g=G.hasEagerState?G.eagerState:o(g,te)}else $={lane:te,revertLane:G.revertLane,action:G.action,hasEagerState:G.hasEagerState,eagerState:G.eagerState,next:null},k===null?(S=k=$,b=g):k=k.next=$,Ie.lanes|=te,cr|=te;G=G.next}while(G!==null&&G!==r);if(k===null?b=g:k.next=S,!Pn(g,s.memoizedState)&&($t=!0,Z&&(o=xo,o!==null)))throw o;s.memoizedState=g,s.baseState=b,s.baseQueue=k,c.lastRenderedState=g}return f===null&&(c.lanes=0),[s.memoizedState,c.dispatch]}function mp(s){var r=Nt(),o=r.queue;if(o===null)throw Error(i(311));o.lastRenderedReducer=s;var c=o.dispatch,f=o.pending,g=r.memoizedState;if(f!==null){o.pending=null;var b=f=f.next;do g=s(g,b.action),b=b.next;while(b!==f);Pn(g,r.memoizedState)||($t=!0),r.memoizedState=g,r.baseQueue===null&&(r.baseState=g),o.lastRenderedState=g}return[g,c]}function TE(s,r,o){var c=Ie,f=Nt(),g=Qe;if(g){if(o===void 0)throw Error(i(407));o=o()}else o=r();var b=!Pn((it||f).memoizedState,o);b&&(f.memoizedState=o,$t=!0),f=f.queue;var S=SE.bind(null,c,f,s);if(pc(2048,8,S,[s]),f.getSnapshot!==r||b||It!==null&&It.memoizedState.tag&1){if(c.flags|=2048,Do(9,Bh(),wE.bind(null,c,f,o,r),null),ut===null)throw Error(i(349));g||(nr&124)!==0||bE(c,r,o)}return o}function bE(s,r,o){s.flags|=16384,s={getSnapshot:r,value:o},r=Ie.updateQueue,r===null?(r=hp(),Ie.updateQueue=r,r.stores=[s]):(o=r.stores,o===null?r.stores=[s]:o.push(s))}function wE(s,r,o,c){r.value=o,r.getSnapshot=c,AE(r)&&RE(s)}function SE(s,r,o){return o(function(){AE(r)&&RE(s)})}function AE(s){var r=s.getSnapshot;s=s.value;try{var o=r();return!Pn(s,o)}catch{return!0}}function RE(s){var r=wo(s,2);r!==null&&Fn(r,s,2)}function pp(s){var r=bn();if(typeof s=="function"){var o=s;if(s=o(),Aa){On(!0);try{o()}finally{On(!1)}}}return r.memoizedState=r.baseState=s,r.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:gs,lastRenderedState:s},r}function CE(s,r,o,c){return s.baseState=o,fp(s,it,typeof c=="function"?c:gs)}function XI(s,r,o,c,f){if(Hh(s))throw Error(i(485));if(s=r.action,s!==null){var g={payload:f,action:s,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(b){g.listeners.push(b)}};X.T!==null?o(!0):g.isTransition=!1,c(g),o=r.pending,o===null?(g.next=r.pending=g,xE(r,g)):(g.next=o.next,r.pending=o.next=g)}}function xE(s,r){var o=r.action,c=r.payload,f=s.state;if(r.isTransition){var g=X.T,b={};X.T=b;try{var S=o(f,c),k=X.S;k!==null&&k(b,S),IE(s,r,S)}catch(G){gp(s,r,G)}finally{X.T=g}}else try{g=o(f,c),IE(s,r,g)}catch(G){gp(s,r,G)}}function IE(s,r,o){o!==null&&typeof o=="object"&&typeof o.then=="function"?o.then(function(c){NE(s,r,c)},function(c){return gp(s,r,c)}):NE(s,r,o)}function NE(s,r,o){r.status="fulfilled",r.value=o,kE(r),s.state=o,r=s.pending,r!==null&&(o=r.next,o===r?s.pending=null:(o=o.next,r.next=o,xE(s,o)))}function gp(s,r,o){var c=s.pending;if(s.pending=null,c!==null){c=c.next;do r.status="rejected",r.reason=o,kE(r),r=r.next;while(r!==c)}s.action=null}function kE(s){s=s.listeners;for(var r=0;r<s.length;r++)(0,s[r])()}function DE(s,r){return r}function OE(s,r){if(Qe){var o=ut.formState;if(o!==null){e:{var c=Ie;if(Qe){if(Et){t:{for(var f=Et,g=Vi;f.nodeType!==8;){if(!g){f=null;break t}if(f=fi(f.nextSibling),f===null){f=null;break t}}g=f.data,f=g==="F!"||g==="F"?f:null}if(f){Et=fi(f.nextSibling),c=f.data==="F!";break e}}Ta(c)}c=!1}c&&(r=o[0])}}return o=bn(),o.memoizedState=o.baseState=r,c={pending:null,lanes:0,dispatch:null,lastRenderedReducer:DE,lastRenderedState:r},o.queue=c,o=ZE.bind(null,Ie,c),c.dispatch=o,c=pp(!1),g=Tp.bind(null,Ie,!1,c.queue),c=bn(),f={state:r,dispatch:null,action:s,pending:null},c.queue=f,o=XI.bind(null,Ie,f,g,o),f.dispatch=o,c.memoizedState=s,[r,o,!1]}function ME(s){var r=Nt();return PE(r,it,s)}function PE(s,r,o){if(r=fp(s,r,DE)[0],s=Fh(gs)[0],typeof r=="object"&&r!==null&&typeof r.then=="function")try{var c=mc(r)}catch(b){throw b===lc?Ph:b}else c=r;r=Nt();var f=r.queue,g=f.dispatch;return o!==r.memoizedState&&(Ie.flags|=2048,Do(9,Bh(),ZI.bind(null,f,o),null)),[c,g,s]}function ZI(s,r){s.action=r}function LE(s){var r=Nt(),o=it;if(o!==null)return PE(r,o,s);Nt(),r=r.memoizedState,o=Nt();var c=o.queue.dispatch;return o.memoizedState=s,[r,c,!1]}function Do(s,r,o,c){return s={tag:s,create:o,deps:c,inst:r,next:null},r=Ie.updateQueue,r===null&&(r=hp(),Ie.updateQueue=r),o=r.lastEffect,o===null?r.lastEffect=s.next=s:(c=o.next,o.next=s,s.next=c,r.lastEffect=s),s}function Bh(){return{destroy:void 0,resource:void 0}}function VE(){return Nt().memoizedState}function qh(s,r,o,c){var f=bn();c=c===void 0?null:c,Ie.flags|=s,f.memoizedState=Do(1|r,Bh(),o,c)}function pc(s,r,o,c){var f=Nt();c=c===void 0?null:c;var g=f.memoizedState.inst;it!==null&&c!==null&&ap(c,it.memoizedState.deps)?f.memoizedState=Do(r,g,o,c):(Ie.flags|=s,f.memoizedState=Do(1|r,g,o,c))}function UE(s,r){qh(8390656,8,s,r)}function jE(s,r){pc(2048,8,s,r)}function zE(s,r){return pc(4,2,s,r)}function FE(s,r){return pc(4,4,s,r)}function BE(s,r){if(typeof r=="function"){s=s();var o=r(s);return function(){typeof o=="function"?o():r(null)}}if(r!=null)return s=s(),r.current=s,function(){r.current=null}}function qE(s,r,o){o=o!=null?o.concat([s]):null,pc(4,4,BE.bind(null,r,s),o)}function _p(){}function HE(s,r){var o=Nt();r=r===void 0?null:r;var c=o.memoizedState;return r!==null&&ap(r,c[1])?c[0]:(o.memoizedState=[s,r],s)}function GE(s,r){var o=Nt();r=r===void 0?null:r;var c=o.memoizedState;if(r!==null&&ap(r,c[1]))return c[0];if(c=s(),Aa){On(!0);try{s()}finally{On(!1)}}return o.memoizedState=[c,r],c}function yp(s,r,o){return o===void 0||(nr&1073741824)!==0?s.memoizedState=r:(s.memoizedState=o,s=Q0(),Ie.lanes|=s,cr|=s,o)}function $E(s,r,o,c){return Pn(o,r)?o:Io.current!==null?(s=yp(s,o,c),Pn(s,r)||($t=!0),s):(nr&42)===0?($t=!0,s.memoizedState=o):(s=Q0(),Ie.lanes|=s,cr|=s,r)}function KE(s,r,o,c,f){var g=ce.p;ce.p=g!==0&&8>g?g:8;var b=X.T,S={};X.T=S,Tp(s,!1,r,o);try{var k=f(),G=X.S;if(G!==null&&G(S,k),k!==null&&typeof k=="object"&&typeof k.then=="function"){var Z=QI(k,c);gc(s,r,Z,zn(s))}else gc(s,r,c,zn(s))}catch(te){gc(s,r,{then:function(){},status:"rejected",reason:te},zn())}finally{ce.p=g,X.T=b}}function JI(){}function vp(s,r,o,c){if(s.tag!==5)throw Error(i(476));var f=QE(s).queue;KE(s,f,r,ge,o===null?JI:function(){return YE(s),o(c)})}function QE(s){var r=s.memoizedState;if(r!==null)return r;r={memoizedState:ge,baseState:ge,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:gs,lastRenderedState:ge},next:null};var o={};return r.next={memoizedState:o,baseState:o,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:gs,lastRenderedState:o},next:null},s.memoizedState=r,s=s.alternate,s!==null&&(s.memoizedState=r),r}function YE(s){var r=QE(s).next.queue;gc(s,r,{},zn())}function Ep(){return cn(Mc)}function WE(){return Nt().memoizedState}function XE(){return Nt().memoizedState}function e1(s){for(var r=s.return;r!==null;){switch(r.tag){case 24:case 3:var o=zn();s=er(o);var c=tr(r,s,o);c!==null&&(Fn(c,r,o),uc(c,r,o)),r={cache:Wm()},s.payload=r;return}r=r.return}}function t1(s,r,o){var c=zn();o={lane:c,revertLane:0,action:o,hasEagerState:!1,eagerState:null,next:null},Hh(s)?JE(r,o):(o=zm(s,r,o,c),o!==null&&(Fn(o,s,c),e0(o,r,c)))}function ZE(s,r,o){var c=zn();gc(s,r,o,c)}function gc(s,r,o,c){var f={lane:c,revertLane:0,action:o,hasEagerState:!1,eagerState:null,next:null};if(Hh(s))JE(r,f);else{var g=s.alternate;if(s.lanes===0&&(g===null||g.lanes===0)&&(g=r.lastRenderedReducer,g!==null))try{var b=r.lastRenderedState,S=g(b,o);if(f.hasEagerState=!0,f.eagerState=S,Pn(S,b))return Ch(s,r,f,0),ut===null&&Rh(),!1}catch{}finally{}if(o=zm(s,r,f,c),o!==null)return Fn(o,s,c),e0(o,r,c),!0}return!1}function Tp(s,r,o,c){if(c={lane:2,revertLane:Jp(),action:c,hasEagerState:!1,eagerState:null,next:null},Hh(s)){if(r)throw Error(i(479))}else r=zm(s,o,c,2),r!==null&&Fn(r,s,2)}function Hh(s){var r=s.alternate;return s===Ie||r!==null&&r===Ie}function JE(s,r){No=Uh=!0;var o=s.pending;o===null?r.next=r:(r.next=o.next,o.next=r),s.pending=r}function e0(s,r,o){if((o&4194048)!==0){var c=r.lanes;c&=s.pendingLanes,o|=c,r.lanes=o,Ul(s,o)}}var Gh={readContext:cn,use:zh,useCallback:wt,useContext:wt,useEffect:wt,useImperativeHandle:wt,useLayoutEffect:wt,useInsertionEffect:wt,useMemo:wt,useReducer:wt,useRef:wt,useState:wt,useDebugValue:wt,useDeferredValue:wt,useTransition:wt,useSyncExternalStore:wt,useId:wt,useHostTransitionStatus:wt,useFormState:wt,useActionState:wt,useOptimistic:wt,useMemoCache:wt,useCacheRefresh:wt},t0={readContext:cn,use:zh,useCallback:function(s,r){return bn().memoizedState=[s,r===void 0?null:r],s},useContext:cn,useEffect:UE,useImperativeHandle:function(s,r,o){o=o!=null?o.concat([s]):null,qh(4194308,4,BE.bind(null,r,s),o)},useLayoutEffect:function(s,r){return qh(4194308,4,s,r)},useInsertionEffect:function(s,r){qh(4,2,s,r)},useMemo:function(s,r){var o=bn();r=r===void 0?null:r;var c=s();if(Aa){On(!0);try{s()}finally{On(!1)}}return o.memoizedState=[c,r],c},useReducer:function(s,r,o){var c=bn();if(o!==void 0){var f=o(r);if(Aa){On(!0);try{o(r)}finally{On(!1)}}}else f=r;return c.memoizedState=c.baseState=f,s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:s,lastRenderedState:f},c.queue=s,s=s.dispatch=t1.bind(null,Ie,s),[c.memoizedState,s]},useRef:function(s){var r=bn();return s={current:s},r.memoizedState=s},useState:function(s){s=pp(s);var r=s.queue,o=ZE.bind(null,Ie,r);return r.dispatch=o,[s.memoizedState,o]},useDebugValue:_p,useDeferredValue:function(s,r){var o=bn();return yp(o,s,r)},useTransition:function(){var s=pp(!1);return s=KE.bind(null,Ie,s.queue,!0,!1),bn().memoizedState=s,[!1,s]},useSyncExternalStore:function(s,r,o){var c=Ie,f=bn();if(Qe){if(o===void 0)throw Error(i(407));o=o()}else{if(o=r(),ut===null)throw Error(i(349));(qe&124)!==0||bE(c,r,o)}f.memoizedState=o;var g={value:o,getSnapshot:r};return f.queue=g,UE(SE.bind(null,c,g,s),[s]),c.flags|=2048,Do(9,Bh(),wE.bind(null,c,g,o,r),null),o},useId:function(){var s=bn(),r=ut.identifierPrefix;if(Qe){var o=fs,c=ds;o=(c&~(1<<32-ln(c)-1)).toString(32)+o,r="«"+r+"R"+o,o=jh++,0<o&&(r+="H"+o.toString(32)),r+="»"}else o=YI++,r="«"+r+"r"+o.toString(32)+"»";return s.memoizedState=r},useHostTransitionStatus:Ep,useFormState:OE,useActionState:OE,useOptimistic:function(s){var r=bn();r.memoizedState=r.baseState=s;var o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return r.queue=o,r=Tp.bind(null,Ie,!0,o),o.dispatch=r,[s,r]},useMemoCache:dp,useCacheRefresh:function(){return bn().memoizedState=e1.bind(null,Ie)}},n0={readContext:cn,use:zh,useCallback:HE,useContext:cn,useEffect:jE,useImperativeHandle:qE,useInsertionEffect:zE,useLayoutEffect:FE,useMemo:GE,useReducer:Fh,useRef:VE,useState:function(){return Fh(gs)},useDebugValue:_p,useDeferredValue:function(s,r){var o=Nt();return $E(o,it.memoizedState,s,r)},useTransition:function(){var s=Fh(gs)[0],r=Nt().memoizedState;return[typeof s=="boolean"?s:mc(s),r]},useSyncExternalStore:TE,useId:WE,useHostTransitionStatus:Ep,useFormState:ME,useActionState:ME,useOptimistic:function(s,r){var o=Nt();return CE(o,it,s,r)},useMemoCache:dp,useCacheRefresh:XE},n1={readContext:cn,use:zh,useCallback:HE,useContext:cn,useEffect:jE,useImperativeHandle:qE,useInsertionEffect:zE,useLayoutEffect:FE,useMemo:GE,useReducer:mp,useRef:VE,useState:function(){return mp(gs)},useDebugValue:_p,useDeferredValue:function(s,r){var o=Nt();return it===null?yp(o,s,r):$E(o,it.memoizedState,s,r)},useTransition:function(){var s=mp(gs)[0],r=Nt().memoizedState;return[typeof s=="boolean"?s:mc(s),r]},useSyncExternalStore:TE,useId:WE,useHostTransitionStatus:Ep,useFormState:LE,useActionState:LE,useOptimistic:function(s,r){var o=Nt();return it!==null?CE(o,it,s,r):(o.baseState=s,[s,o.queue.dispatch])},useMemoCache:dp,useCacheRefresh:XE},Oo=null,_c=0;function $h(s){var r=_c;return _c+=1,Oo===null&&(Oo=[]),fE(Oo,s,r)}function yc(s,r){r=r.props.ref,s.ref=r!==void 0?r:null}function Kh(s,r){throw r.$$typeof===T?Error(i(525)):(s=Object.prototype.toString.call(r),Error(i(31,s==="[object Object]"?"object with keys {"+Object.keys(r).join(", ")+"}":s)))}function i0(s){var r=s._init;return r(s._payload)}function s0(s){function r(F,U){if(s){var H=F.deletions;H===null?(F.deletions=[U],F.flags|=16):H.push(U)}}function o(F,U){if(!s)return null;for(;U!==null;)r(F,U),U=U.sibling;return null}function c(F){for(var U=new Map;F!==null;)F.key!==null?U.set(F.key,F):U.set(F.index,F),F=F.sibling;return U}function f(F,U){return F=hs(F,U),F.index=0,F.sibling=null,F}function g(F,U,H){return F.index=H,s?(H=F.alternate,H!==null?(H=H.index,H<U?(F.flags|=67108866,U):H):(F.flags|=67108866,U)):(F.flags|=1048576,U)}function b(F){return s&&F.alternate===null&&(F.flags|=67108866),F}function S(F,U,H,J){return U===null||U.tag!==6?(U=Bm(H,F.mode,J),U.return=F,U):(U=f(U,H),U.return=F,U)}function k(F,U,H,J){var me=H.type;return me===I?Z(F,U,H.props.children,J,H.key):U!==null&&(U.elementType===me||typeof me=="object"&&me!==null&&me.$$typeof===A&&i0(me)===U.type)?(U=f(U,H.props),yc(U,H),U.return=F,U):(U=Ih(H.type,H.key,H.props,null,F.mode,J),yc(U,H),U.return=F,U)}function G(F,U,H,J){return U===null||U.tag!==4||U.stateNode.containerInfo!==H.containerInfo||U.stateNode.implementation!==H.implementation?(U=qm(H,F.mode,J),U.return=F,U):(U=f(U,H.children||[]),U.return=F,U)}function Z(F,U,H,J,me){return U===null||U.tag!==7?(U=_a(H,F.mode,J,me),U.return=F,U):(U=f(U,H),U.return=F,U)}function te(F,U,H){if(typeof U=="string"&&U!==""||typeof U=="number"||typeof U=="bigint")return U=Bm(""+U,F.mode,H),U.return=F,U;if(typeof U=="object"&&U!==null){switch(U.$$typeof){case w:return H=Ih(U.type,U.key,U.props,null,F.mode,H),yc(H,U),H.return=F,H;case x:return U=qm(U,F.mode,H),U.return=F,U;case A:var J=U._init;return U=J(U._payload),te(F,U,H)}if(ze(U)||z(U))return U=_a(U,F.mode,H,null),U.return=F,U;if(typeof U.then=="function")return te(F,$h(U),H);if(U.$$typeof===Y)return te(F,Oh(F,U),H);Kh(F,U)}return null}function $(F,U,H,J){var me=U!==null?U.key:null;if(typeof H=="string"&&H!==""||typeof H=="number"||typeof H=="bigint")return me!==null?null:S(F,U,""+H,J);if(typeof H=="object"&&H!==null){switch(H.$$typeof){case w:return H.key===me?k(F,U,H,J):null;case x:return H.key===me?G(F,U,H,J):null;case A:return me=H._init,H=me(H._payload),$(F,U,H,J)}if(ze(H)||z(H))return me!==null?null:Z(F,U,H,J,null);if(typeof H.then=="function")return $(F,U,$h(H),J);if(H.$$typeof===Y)return $(F,U,Oh(F,H),J);Kh(F,H)}return null}function K(F,U,H,J,me){if(typeof J=="string"&&J!==""||typeof J=="number"||typeof J=="bigint")return F=F.get(H)||null,S(U,F,""+J,me);if(typeof J=="object"&&J!==null){switch(J.$$typeof){case w:return F=F.get(J.key===null?H:J.key)||null,k(U,F,J,me);case x:return F=F.get(J.key===null?H:J.key)||null,G(U,F,J,me);case A:var De=J._init;return J=De(J._payload),K(F,U,H,J,me)}if(ze(J)||z(J))return F=F.get(H)||null,Z(U,F,J,me,null);if(typeof J.then=="function")return K(F,U,H,$h(J),me);if(J.$$typeof===Y)return K(F,U,H,Oh(U,J),me);Kh(U,J)}return null}function be(F,U,H,J){for(var me=null,De=null,pe=U,Ee=U=0,Qt=null;pe!==null&&Ee<H.length;Ee++){pe.index>Ee?(Qt=pe,pe=null):Qt=pe.sibling;var Ge=$(F,pe,H[Ee],J);if(Ge===null){pe===null&&(pe=Qt);break}s&&pe&&Ge.alternate===null&&r(F,pe),U=g(Ge,U,Ee),De===null?me=Ge:De.sibling=Ge,De=Ge,pe=Qt}if(Ee===H.length)return o(F,pe),Qe&&va(F,Ee),me;if(pe===null){for(;Ee<H.length;Ee++)pe=te(F,H[Ee],J),pe!==null&&(U=g(pe,U,Ee),De===null?me=pe:De.sibling=pe,De=pe);return Qe&&va(F,Ee),me}for(pe=c(pe);Ee<H.length;Ee++)Qt=K(pe,F,Ee,H[Ee],J),Qt!==null&&(s&&Qt.alternate!==null&&pe.delete(Qt.key===null?Ee:Qt.key),U=g(Qt,U,Ee),De===null?me=Qt:De.sibling=Qt,De=Qt);return s&&pe.forEach(function(yr){return r(F,yr)}),Qe&&va(F,Ee),me}function ve(F,U,H,J){if(H==null)throw Error(i(151));for(var me=null,De=null,pe=U,Ee=U=0,Qt=null,Ge=H.next();pe!==null&&!Ge.done;Ee++,Ge=H.next()){pe.index>Ee?(Qt=pe,pe=null):Qt=pe.sibling;var yr=$(F,pe,Ge.value,J);if(yr===null){pe===null&&(pe=Qt);break}s&&pe&&yr.alternate===null&&r(F,pe),U=g(yr,U,Ee),De===null?me=yr:De.sibling=yr,De=yr,pe=Qt}if(Ge.done)return o(F,pe),Qe&&va(F,Ee),me;if(pe===null){for(;!Ge.done;Ee++,Ge=H.next())Ge=te(F,Ge.value,J),Ge!==null&&(U=g(Ge,U,Ee),De===null?me=Ge:De.sibling=Ge,De=Ge);return Qe&&va(F,Ee),me}for(pe=c(pe);!Ge.done;Ee++,Ge=H.next())Ge=K(pe,F,Ee,Ge.value,J),Ge!==null&&(s&&Ge.alternate!==null&&pe.delete(Ge.key===null?Ee:Ge.key),U=g(Ge,U,Ee),De===null?me=Ge:De.sibling=Ge,De=Ge);return s&&pe.forEach(function(iN){return r(F,iN)}),Qe&&va(F,Ee),me}function rt(F,U,H,J){if(typeof H=="object"&&H!==null&&H.type===I&&H.key===null&&(H=H.props.children),typeof H=="object"&&H!==null){switch(H.$$typeof){case w:e:{for(var me=H.key;U!==null;){if(U.key===me){if(me=H.type,me===I){if(U.tag===7){o(F,U.sibling),J=f(U,H.props.children),J.return=F,F=J;break e}}else if(U.elementType===me||typeof me=="object"&&me!==null&&me.$$typeof===A&&i0(me)===U.type){o(F,U.sibling),J=f(U,H.props),yc(J,H),J.return=F,F=J;break e}o(F,U);break}else r(F,U);U=U.sibling}H.type===I?(J=_a(H.props.children,F.mode,J,H.key),J.return=F,F=J):(J=Ih(H.type,H.key,H.props,null,F.mode,J),yc(J,H),J.return=F,F=J)}return b(F);case x:e:{for(me=H.key;U!==null;){if(U.key===me)if(U.tag===4&&U.stateNode.containerInfo===H.containerInfo&&U.stateNode.implementation===H.implementation){o(F,U.sibling),J=f(U,H.children||[]),J.return=F,F=J;break e}else{o(F,U);break}else r(F,U);U=U.sibling}J=qm(H,F.mode,J),J.return=F,F=J}return b(F);case A:return me=H._init,H=me(H._payload),rt(F,U,H,J)}if(ze(H))return be(F,U,H,J);if(z(H)){if(me=z(H),typeof me!="function")throw Error(i(150));return H=me.call(H),ve(F,U,H,J)}if(typeof H.then=="function")return rt(F,U,$h(H),J);if(H.$$typeof===Y)return rt(F,U,Oh(F,H),J);Kh(F,H)}return typeof H=="string"&&H!==""||typeof H=="number"||typeof H=="bigint"?(H=""+H,U!==null&&U.tag===6?(o(F,U.sibling),J=f(U,H),J.return=F,F=J):(o(F,U),J=Bm(H,F.mode,J),J.return=F,F=J),b(F)):o(F,U)}return function(F,U,H,J){try{_c=0;var me=rt(F,U,H,J);return Oo=null,me}catch(pe){if(pe===lc||pe===Ph)throw pe;var De=Ln(29,pe,null,F.mode);return De.lanes=J,De.return=F,De}finally{}}}var Mo=s0(!0),r0=s0(!1),ti=se(null),Ui=null;function ir(s){var r=s.alternate;ae(jt,jt.current&1),ae(ti,s),Ui===null&&(r===null||Io.current!==null||r.memoizedState!==null)&&(Ui=s)}function a0(s){if(s.tag===22){if(ae(jt,jt.current),ae(ti,s),Ui===null){var r=s.alternate;r!==null&&r.memoizedState!==null&&(Ui=s)}}else sr()}function sr(){ae(jt,jt.current),ae(ti,ti.current)}function _s(s){ue(ti),Ui===s&&(Ui=null),ue(jt)}var jt=se(0);function Qh(s){for(var r=s;r!==null;){if(r.tag===13){var o=r.memoizedState;if(o!==null&&(o=o.dehydrated,o===null||o.data==="$?"||hg(o)))return r}else if(r.tag===19&&r.memoizedProps.revealOrder!==void 0){if((r.flags&128)!==0)return r}else if(r.child!==null){r.child.return=r,r=r.child;continue}if(r===s)break;for(;r.sibling===null;){if(r.return===null||r.return===s)return null;r=r.return}r.sibling.return=r.return,r=r.sibling}return null}function bp(s,r,o,c){r=s.memoizedState,o=o(c,r),o=o==null?r:y({},r,o),s.memoizedState=o,s.lanes===0&&(s.updateQueue.baseState=o)}var wp={enqueueSetState:function(s,r,o){s=s._reactInternals;var c=zn(),f=er(c);f.payload=r,o!=null&&(f.callback=o),r=tr(s,f,c),r!==null&&(Fn(r,s,c),uc(r,s,c))},enqueueReplaceState:function(s,r,o){s=s._reactInternals;var c=zn(),f=er(c);f.tag=1,f.payload=r,o!=null&&(f.callback=o),r=tr(s,f,c),r!==null&&(Fn(r,s,c),uc(r,s,c))},enqueueForceUpdate:function(s,r){s=s._reactInternals;var o=zn(),c=er(o);c.tag=2,r!=null&&(c.callback=r),r=tr(s,c,o),r!==null&&(Fn(r,s,o),uc(r,s,o))}};function o0(s,r,o,c,f,g,b){return s=s.stateNode,typeof s.shouldComponentUpdate=="function"?s.shouldComponentUpdate(c,g,b):r.prototype&&r.prototype.isPureReactComponent?!ec(o,c)||!ec(f,g):!0}function l0(s,r,o,c){s=r.state,typeof r.componentWillReceiveProps=="function"&&r.componentWillReceiveProps(o,c),typeof r.UNSAFE_componentWillReceiveProps=="function"&&r.UNSAFE_componentWillReceiveProps(o,c),r.state!==s&&wp.enqueueReplaceState(r,r.state,null)}function Ra(s,r){var o=r;if("ref"in r){o={};for(var c in r)c!=="ref"&&(o[c]=r[c])}if(s=s.defaultProps){o===r&&(o=y({},o));for(var f in s)o[f]===void 0&&(o[f]=s[f])}return o}var Yh=typeof reportError=="function"?reportError:function(s){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var r=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof s=="object"&&s!==null&&typeof s.message=="string"?String(s.message):String(s),error:s});if(!window.dispatchEvent(r))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",s);return}console.error(s)};function c0(s){Yh(s)}function u0(s){console.error(s)}function h0(s){Yh(s)}function Wh(s,r){try{var o=s.onUncaughtError;o(r.value,{componentStack:r.stack})}catch(c){setTimeout(function(){throw c})}}function d0(s,r,o){try{var c=s.onCaughtError;c(o.value,{componentStack:o.stack,errorBoundary:r.tag===1?r.stateNode:null})}catch(f){setTimeout(function(){throw f})}}function Sp(s,r,o){return o=er(o),o.tag=3,o.payload={element:null},o.callback=function(){Wh(s,r)},o}function f0(s){return s=er(s),s.tag=3,s}function m0(s,r,o,c){var f=o.type.getDerivedStateFromError;if(typeof f=="function"){var g=c.value;s.payload=function(){return f(g)},s.callback=function(){d0(r,o,c)}}var b=o.stateNode;b!==null&&typeof b.componentDidCatch=="function"&&(s.callback=function(){d0(r,o,c),typeof f!="function"&&(ur===null?ur=new Set([this]):ur.add(this));var S=c.stack;this.componentDidCatch(c.value,{componentStack:S!==null?S:""})})}function i1(s,r,o,c,f){if(o.flags|=32768,c!==null&&typeof c=="object"&&typeof c.then=="function"){if(r=o.alternate,r!==null&&rc(r,o,f,!0),o=ti.current,o!==null){switch(o.tag){case 13:return Ui===null?Qp():o.alternate===null&&Tt===0&&(Tt=3),o.flags&=-257,o.flags|=65536,o.lanes=f,c===Jm?o.flags|=16384:(r=o.updateQueue,r===null?o.updateQueue=new Set([c]):r.add(c),Wp(s,c,f)),!1;case 22:return o.flags|=65536,c===Jm?o.flags|=16384:(r=o.updateQueue,r===null?(r={transitions:null,markerInstances:null,retryQueue:new Set([c])},o.updateQueue=r):(o=r.retryQueue,o===null?r.retryQueue=new Set([c]):o.add(c)),Wp(s,c,f)),!1}throw Error(i(435,o.tag))}return Wp(s,c,f),Qp(),!1}if(Qe)return r=ti.current,r!==null?((r.flags&65536)===0&&(r.flags|=256),r.flags|=65536,r.lanes=f,c!==$m&&(s=Error(i(422),{cause:c}),sc(Xn(s,o)))):(c!==$m&&(r=Error(i(423),{cause:c}),sc(Xn(r,o))),s=s.current.alternate,s.flags|=65536,f&=-f,s.lanes|=f,c=Xn(c,o),f=Sp(s.stateNode,c,f),np(s,f),Tt!==4&&(Tt=2)),!1;var g=Error(i(520),{cause:c});if(g=Xn(g,o),Ac===null?Ac=[g]:Ac.push(g),Tt!==4&&(Tt=2),r===null)return!0;c=Xn(c,o),o=r;do{switch(o.tag){case 3:return o.flags|=65536,s=f&-f,o.lanes|=s,s=Sp(o.stateNode,c,s),np(o,s),!1;case 1:if(r=o.type,g=o.stateNode,(o.flags&128)===0&&(typeof r.getDerivedStateFromError=="function"||g!==null&&typeof g.componentDidCatch=="function"&&(ur===null||!ur.has(g))))return o.flags|=65536,f&=-f,o.lanes|=f,f=f0(f),m0(f,s,o,c),np(o,f),!1}o=o.return}while(o!==null);return!1}var p0=Error(i(461)),$t=!1;function tn(s,r,o,c){r.child=s===null?r0(r,null,o,c):Mo(r,s.child,o,c)}function g0(s,r,o,c,f){o=o.render;var g=r.ref;if("ref"in c){var b={};for(var S in c)S!=="ref"&&(b[S]=c[S])}else b=c;return wa(r),c=op(s,r,o,b,g,f),S=lp(),s!==null&&!$t?(cp(s,r,f),ys(s,r,f)):(Qe&&S&&Hm(r),r.flags|=1,tn(s,r,c,f),r.child)}function _0(s,r,o,c,f){if(s===null){var g=o.type;return typeof g=="function"&&!Fm(g)&&g.defaultProps===void 0&&o.compare===null?(r.tag=15,r.type=g,y0(s,r,g,c,f)):(s=Ih(o.type,null,c,r,r.mode,f),s.ref=r.ref,s.return=r,r.child=s)}if(g=s.child,!Dp(s,f)){var b=g.memoizedProps;if(o=o.compare,o=o!==null?o:ec,o(b,c)&&s.ref===r.ref)return ys(s,r,f)}return r.flags|=1,s=hs(g,c),s.ref=r.ref,s.return=r,r.child=s}function y0(s,r,o,c,f){if(s!==null){var g=s.memoizedProps;if(ec(g,c)&&s.ref===r.ref)if($t=!1,r.pendingProps=c=g,Dp(s,f))(s.flags&131072)!==0&&($t=!0);else return r.lanes=s.lanes,ys(s,r,f)}return Ap(s,r,o,c,f)}function v0(s,r,o){var c=r.pendingProps,f=c.children,g=s!==null?s.memoizedState:null;if(c.mode==="hidden"){if((r.flags&128)!==0){if(c=g!==null?g.baseLanes|o:o,s!==null){for(f=r.child=s.child,g=0;f!==null;)g=g|f.lanes|f.childLanes,f=f.sibling;r.childLanes=g&~c}else r.childLanes=0,r.child=null;return E0(s,r,c,o)}if((o&536870912)!==0)r.memoizedState={baseLanes:0,cachePool:null},s!==null&&Mh(r,g!==null?g.cachePool:null),g!==null?yE(r,g):sp(),a0(r);else return r.lanes=r.childLanes=536870912,E0(s,r,g!==null?g.baseLanes|o:o,o)}else g!==null?(Mh(r,g.cachePool),yE(r,g),sr(),r.memoizedState=null):(s!==null&&Mh(r,null),sp(),sr());return tn(s,r,f,o),r.child}function E0(s,r,o,c){var f=Zm();return f=f===null?null:{parent:Ut._currentValue,pool:f},r.memoizedState={baseLanes:o,cachePool:f},s!==null&&Mh(r,null),sp(),a0(r),s!==null&&rc(s,r,c,!0),null}function Xh(s,r){var o=r.ref;if(o===null)s!==null&&s.ref!==null&&(r.flags|=4194816);else{if(typeof o!="function"&&typeof o!="object")throw Error(i(284));(s===null||s.ref!==o)&&(r.flags|=4194816)}}function Ap(s,r,o,c,f){return wa(r),o=op(s,r,o,c,void 0,f),c=lp(),s!==null&&!$t?(cp(s,r,f),ys(s,r,f)):(Qe&&c&&Hm(r),r.flags|=1,tn(s,r,o,f),r.child)}function T0(s,r,o,c,f,g){return wa(r),r.updateQueue=null,o=EE(r,c,o,f),vE(s),c=lp(),s!==null&&!$t?(cp(s,r,g),ys(s,r,g)):(Qe&&c&&Hm(r),r.flags|=1,tn(s,r,o,g),r.child)}function b0(s,r,o,c,f){if(wa(r),r.stateNode===null){var g=So,b=o.contextType;typeof b=="object"&&b!==null&&(g=cn(b)),g=new o(c,g),r.memoizedState=g.state!==null&&g.state!==void 0?g.state:null,g.updater=wp,r.stateNode=g,g._reactInternals=r,g=r.stateNode,g.props=c,g.state=r.memoizedState,g.refs={},ep(r),b=o.contextType,g.context=typeof b=="object"&&b!==null?cn(b):So,g.state=r.memoizedState,b=o.getDerivedStateFromProps,typeof b=="function"&&(bp(r,o,b,c),g.state=r.memoizedState),typeof o.getDerivedStateFromProps=="function"||typeof g.getSnapshotBeforeUpdate=="function"||typeof g.UNSAFE_componentWillMount!="function"&&typeof g.componentWillMount!="function"||(b=g.state,typeof g.componentWillMount=="function"&&g.componentWillMount(),typeof g.UNSAFE_componentWillMount=="function"&&g.UNSAFE_componentWillMount(),b!==g.state&&wp.enqueueReplaceState(g,g.state,null),dc(r,c,g,f),hc(),g.state=r.memoizedState),typeof g.componentDidMount=="function"&&(r.flags|=4194308),c=!0}else if(s===null){g=r.stateNode;var S=r.memoizedProps,k=Ra(o,S);g.props=k;var G=g.context,Z=o.contextType;b=So,typeof Z=="object"&&Z!==null&&(b=cn(Z));var te=o.getDerivedStateFromProps;Z=typeof te=="function"||typeof g.getSnapshotBeforeUpdate=="function",S=r.pendingProps!==S,Z||typeof g.UNSAFE_componentWillReceiveProps!="function"&&typeof g.componentWillReceiveProps!="function"||(S||G!==b)&&l0(r,g,c,b),Js=!1;var $=r.memoizedState;g.state=$,dc(r,c,g,f),hc(),G=r.memoizedState,S||$!==G||Js?(typeof te=="function"&&(bp(r,o,te,c),G=r.memoizedState),(k=Js||o0(r,o,k,c,$,G,b))?(Z||typeof g.UNSAFE_componentWillMount!="function"&&typeof g.componentWillMount!="function"||(typeof g.componentWillMount=="function"&&g.componentWillMount(),typeof g.UNSAFE_componentWillMount=="function"&&g.UNSAFE_componentWillMount()),typeof g.componentDidMount=="function"&&(r.flags|=4194308)):(typeof g.componentDidMount=="function"&&(r.flags|=4194308),r.memoizedProps=c,r.memoizedState=G),g.props=c,g.state=G,g.context=b,c=k):(typeof g.componentDidMount=="function"&&(r.flags|=4194308),c=!1)}else{g=r.stateNode,tp(s,r),b=r.memoizedProps,Z=Ra(o,b),g.props=Z,te=r.pendingProps,$=g.context,G=o.contextType,k=So,typeof G=="object"&&G!==null&&(k=cn(G)),S=o.getDerivedStateFromProps,(G=typeof S=="function"||typeof g.getSnapshotBeforeUpdate=="function")||typeof g.UNSAFE_componentWillReceiveProps!="function"&&typeof g.componentWillReceiveProps!="function"||(b!==te||$!==k)&&l0(r,g,c,k),Js=!1,$=r.memoizedState,g.state=$,dc(r,c,g,f),hc();var K=r.memoizedState;b!==te||$!==K||Js||s!==null&&s.dependencies!==null&&Dh(s.dependencies)?(typeof S=="function"&&(bp(r,o,S,c),K=r.memoizedState),(Z=Js||o0(r,o,Z,c,$,K,k)||s!==null&&s.dependencies!==null&&Dh(s.dependencies))?(G||typeof g.UNSAFE_componentWillUpdate!="function"&&typeof g.componentWillUpdate!="function"||(typeof g.componentWillUpdate=="function"&&g.componentWillUpdate(c,K,k),typeof g.UNSAFE_componentWillUpdate=="function"&&g.UNSAFE_componentWillUpdate(c,K,k)),typeof g.componentDidUpdate=="function"&&(r.flags|=4),typeof g.getSnapshotBeforeUpdate=="function"&&(r.flags|=1024)):(typeof g.componentDidUpdate!="function"||b===s.memoizedProps&&$===s.memoizedState||(r.flags|=4),typeof g.getSnapshotBeforeUpdate!="function"||b===s.memoizedProps&&$===s.memoizedState||(r.flags|=1024),r.memoizedProps=c,r.memoizedState=K),g.props=c,g.state=K,g.context=k,c=Z):(typeof g.componentDidUpdate!="function"||b===s.memoizedProps&&$===s.memoizedState||(r.flags|=4),typeof g.getSnapshotBeforeUpdate!="function"||b===s.memoizedProps&&$===s.memoizedState||(r.flags|=1024),c=!1)}return g=c,Xh(s,r),c=(r.flags&128)!==0,g||c?(g=r.stateNode,o=c&&typeof o.getDerivedStateFromError!="function"?null:g.render(),r.flags|=1,s!==null&&c?(r.child=Mo(r,s.child,null,f),r.child=Mo(r,null,o,f)):tn(s,r,o,f),r.memoizedState=g.state,s=r.child):s=ys(s,r,f),s}function w0(s,r,o,c){return ic(),r.flags|=256,tn(s,r,o,c),r.child}var Rp={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Cp(s){return{baseLanes:s,cachePool:uE()}}function xp(s,r,o){return s=s!==null?s.childLanes&~o:0,r&&(s|=ni),s}function S0(s,r,o){var c=r.pendingProps,f=!1,g=(r.flags&128)!==0,b;if((b=g)||(b=s!==null&&s.memoizedState===null?!1:(jt.current&2)!==0),b&&(f=!0,r.flags&=-129),b=(r.flags&32)!==0,r.flags&=-33,s===null){if(Qe){if(f?ir(r):sr(),Qe){var S=Et,k;if(k=S){e:{for(k=S,S=Vi;k.nodeType!==8;){if(!S){S=null;break e}if(k=fi(k.nextSibling),k===null){S=null;break e}}S=k}S!==null?(r.memoizedState={dehydrated:S,treeContext:ya!==null?{id:ds,overflow:fs}:null,retryLane:536870912,hydrationErrors:null},k=Ln(18,null,null,0),k.stateNode=S,k.return=r,r.child=k,En=r,Et=null,k=!0):k=!1}k||Ta(r)}if(S=r.memoizedState,S!==null&&(S=S.dehydrated,S!==null))return hg(S)?r.lanes=32:r.lanes=536870912,null;_s(r)}return S=c.children,c=c.fallback,f?(sr(),f=r.mode,S=Zh({mode:"hidden",children:S},f),c=_a(c,f,o,null),S.return=r,c.return=r,S.sibling=c,r.child=S,f=r.child,f.memoizedState=Cp(o),f.childLanes=xp(s,b,o),r.memoizedState=Rp,c):(ir(r),Ip(r,S))}if(k=s.memoizedState,k!==null&&(S=k.dehydrated,S!==null)){if(g)r.flags&256?(ir(r),r.flags&=-257,r=Np(s,r,o)):r.memoizedState!==null?(sr(),r.child=s.child,r.flags|=128,r=null):(sr(),f=c.fallback,S=r.mode,c=Zh({mode:"visible",children:c.children},S),f=_a(f,S,o,null),f.flags|=2,c.return=r,f.return=r,c.sibling=f,r.child=c,Mo(r,s.child,null,o),c=r.child,c.memoizedState=Cp(o),c.childLanes=xp(s,b,o),r.memoizedState=Rp,r=f);else if(ir(r),hg(S)){if(b=S.nextSibling&&S.nextSibling.dataset,b)var G=b.dgst;b=G,c=Error(i(419)),c.stack="",c.digest=b,sc({value:c,source:null,stack:null}),r=Np(s,r,o)}else if($t||rc(s,r,o,!1),b=(o&s.childLanes)!==0,$t||b){if(b=ut,b!==null&&(c=o&-o,c=(c&42)!==0?1:Gs(c),c=(c&(b.suspendedLanes|o))!==0?0:c,c!==0&&c!==k.retryLane))throw k.retryLane=c,wo(s,c),Fn(b,s,c),p0;S.data==="$?"||Qp(),r=Np(s,r,o)}else S.data==="$?"?(r.flags|=192,r.child=s.child,r=null):(s=k.treeContext,Et=fi(S.nextSibling),En=r,Qe=!0,Ea=null,Vi=!1,s!==null&&(Jn[ei++]=ds,Jn[ei++]=fs,Jn[ei++]=ya,ds=s.id,fs=s.overflow,ya=r),r=Ip(r,c.children),r.flags|=4096);return r}return f?(sr(),f=c.fallback,S=r.mode,k=s.child,G=k.sibling,c=hs(k,{mode:"hidden",children:c.children}),c.subtreeFlags=k.subtreeFlags&65011712,G!==null?f=hs(G,f):(f=_a(f,S,o,null),f.flags|=2),f.return=r,c.return=r,c.sibling=f,r.child=c,c=f,f=r.child,S=s.child.memoizedState,S===null?S=Cp(o):(k=S.cachePool,k!==null?(G=Ut._currentValue,k=k.parent!==G?{parent:G,pool:G}:k):k=uE(),S={baseLanes:S.baseLanes|o,cachePool:k}),f.memoizedState=S,f.childLanes=xp(s,b,o),r.memoizedState=Rp,c):(ir(r),o=s.child,s=o.sibling,o=hs(o,{mode:"visible",children:c.children}),o.return=r,o.sibling=null,s!==null&&(b=r.deletions,b===null?(r.deletions=[s],r.flags|=16):b.push(s)),r.child=o,r.memoizedState=null,o)}function Ip(s,r){return r=Zh({mode:"visible",children:r},s.mode),r.return=s,s.child=r}function Zh(s,r){return s=Ln(22,s,null,r),s.lanes=0,s.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null},s}function Np(s,r,o){return Mo(r,s.child,null,o),s=Ip(r,r.pendingProps.children),s.flags|=2,r.memoizedState=null,s}function A0(s,r,o){s.lanes|=r;var c=s.alternate;c!==null&&(c.lanes|=r),Qm(s.return,r,o)}function kp(s,r,o,c,f){var g=s.memoizedState;g===null?s.memoizedState={isBackwards:r,rendering:null,renderingStartTime:0,last:c,tail:o,tailMode:f}:(g.isBackwards=r,g.rendering=null,g.renderingStartTime=0,g.last=c,g.tail=o,g.tailMode=f)}function R0(s,r,o){var c=r.pendingProps,f=c.revealOrder,g=c.tail;if(tn(s,r,c.children,o),c=jt.current,(c&2)!==0)c=c&1|2,r.flags|=128;else{if(s!==null&&(s.flags&128)!==0)e:for(s=r.child;s!==null;){if(s.tag===13)s.memoizedState!==null&&A0(s,o,r);else if(s.tag===19)A0(s,o,r);else if(s.child!==null){s.child.return=s,s=s.child;continue}if(s===r)break e;for(;s.sibling===null;){if(s.return===null||s.return===r)break e;s=s.return}s.sibling.return=s.return,s=s.sibling}c&=1}switch(ae(jt,c),f){case"forwards":for(o=r.child,f=null;o!==null;)s=o.alternate,s!==null&&Qh(s)===null&&(f=o),o=o.sibling;o=f,o===null?(f=r.child,r.child=null):(f=o.sibling,o.sibling=null),kp(r,!1,f,o,g);break;case"backwards":for(o=null,f=r.child,r.child=null;f!==null;){if(s=f.alternate,s!==null&&Qh(s)===null){r.child=f;break}s=f.sibling,f.sibling=o,o=f,f=s}kp(r,!0,o,null,g);break;case"together":kp(r,!1,null,null,void 0);break;default:r.memoizedState=null}return r.child}function ys(s,r,o){if(s!==null&&(r.dependencies=s.dependencies),cr|=r.lanes,(o&r.childLanes)===0)if(s!==null){if(rc(s,r,o,!1),(o&r.childLanes)===0)return null}else return null;if(s!==null&&r.child!==s.child)throw Error(i(153));if(r.child!==null){for(s=r.child,o=hs(s,s.pendingProps),r.child=o,o.return=r;s.sibling!==null;)s=s.sibling,o=o.sibling=hs(s,s.pendingProps),o.return=r;o.sibling=null}return r.child}function Dp(s,r){return(s.lanes&r)!==0?!0:(s=s.dependencies,!!(s!==null&&Dh(s)))}function s1(s,r,o){switch(r.tag){case 3:ct(r,r.stateNode.containerInfo),Zs(r,Ut,s.memoizedState.cache),ic();break;case 27:case 5:Hs(r);break;case 4:ct(r,r.stateNode.containerInfo);break;case 10:Zs(r,r.type,r.memoizedProps.value);break;case 13:var c=r.memoizedState;if(c!==null)return c.dehydrated!==null?(ir(r),r.flags|=128,null):(o&r.child.childLanes)!==0?S0(s,r,o):(ir(r),s=ys(s,r,o),s!==null?s.sibling:null);ir(r);break;case 19:var f=(s.flags&128)!==0;if(c=(o&r.childLanes)!==0,c||(rc(s,r,o,!1),c=(o&r.childLanes)!==0),f){if(c)return R0(s,r,o);r.flags|=128}if(f=r.memoizedState,f!==null&&(f.rendering=null,f.tail=null,f.lastEffect=null),ae(jt,jt.current),c)break;return null;case 22:case 23:return r.lanes=0,v0(s,r,o);case 24:Zs(r,Ut,s.memoizedState.cache)}return ys(s,r,o)}function C0(s,r,o){if(s!==null)if(s.memoizedProps!==r.pendingProps)$t=!0;else{if(!Dp(s,o)&&(r.flags&128)===0)return $t=!1,s1(s,r,o);$t=(s.flags&131072)!==0}else $t=!1,Qe&&(r.flags&1048576)!==0&&iE(r,kh,r.index);switch(r.lanes=0,r.tag){case 16:e:{s=r.pendingProps;var c=r.elementType,f=c._init;if(c=f(c._payload),r.type=c,typeof c=="function")Fm(c)?(s=Ra(c,s),r.tag=1,r=b0(null,r,c,s,o)):(r.tag=0,r=Ap(null,r,c,s,o));else{if(c!=null){if(f=c.$$typeof,f===W){r.tag=11,r=g0(null,r,c,s,o);break e}else if(f===M){r.tag=14,r=_0(null,r,c,s,o);break e}}throw r=tt(c)||c,Error(i(306,r,""))}}return r;case 0:return Ap(s,r,r.type,r.pendingProps,o);case 1:return c=r.type,f=Ra(c,r.pendingProps),b0(s,r,c,f,o);case 3:e:{if(ct(r,r.stateNode.containerInfo),s===null)throw Error(i(387));c=r.pendingProps;var g=r.memoizedState;f=g.element,tp(s,r),dc(r,c,null,o);var b=r.memoizedState;if(c=b.cache,Zs(r,Ut,c),c!==g.cache&&Ym(r,[Ut],o,!0),hc(),c=b.element,g.isDehydrated)if(g={element:c,isDehydrated:!1,cache:b.cache},r.updateQueue.baseState=g,r.memoizedState=g,r.flags&256){r=w0(s,r,c,o);break e}else if(c!==f){f=Xn(Error(i(424)),r),sc(f),r=w0(s,r,c,o);break e}else{switch(s=r.stateNode.containerInfo,s.nodeType){case 9:s=s.body;break;default:s=s.nodeName==="HTML"?s.ownerDocument.body:s}for(Et=fi(s.firstChild),En=r,Qe=!0,Ea=null,Vi=!0,o=r0(r,null,c,o),r.child=o;o;)o.flags=o.flags&-3|4096,o=o.sibling}else{if(ic(),c===f){r=ys(s,r,o);break e}tn(s,r,c,o)}r=r.child}return r;case 26:return Xh(s,r),s===null?(o=kT(r.type,null,r.pendingProps,null))?r.memoizedState=o:Qe||(o=r.type,s=r.pendingProps,c=dd(Ae.current).createElement(o),c[Pt]=r,c[Ct]=s,sn(c,o,s),bt(c),r.stateNode=c):r.memoizedState=kT(r.type,s.memoizedProps,r.pendingProps,s.memoizedState),null;case 27:return Hs(r),s===null&&Qe&&(c=r.stateNode=xT(r.type,r.pendingProps,Ae.current),En=r,Vi=!0,f=Et,fr(r.type)?(dg=f,Et=fi(c.firstChild)):Et=f),tn(s,r,r.pendingProps.children,o),Xh(s,r),s===null&&(r.flags|=4194304),r.child;case 5:return s===null&&Qe&&((f=c=Et)&&(c=D1(c,r.type,r.pendingProps,Vi),c!==null?(r.stateNode=c,En=r,Et=fi(c.firstChild),Vi=!1,f=!0):f=!1),f||Ta(r)),Hs(r),f=r.type,g=r.pendingProps,b=s!==null?s.memoizedProps:null,c=g.children,lg(f,g)?c=null:b!==null&&lg(f,b)&&(r.flags|=32),r.memoizedState!==null&&(f=op(s,r,WI,null,null,o),Mc._currentValue=f),Xh(s,r),tn(s,r,c,o),r.child;case 6:return s===null&&Qe&&((s=o=Et)&&(o=O1(o,r.pendingProps,Vi),o!==null?(r.stateNode=o,En=r,Et=null,s=!0):s=!1),s||Ta(r)),null;case 13:return S0(s,r,o);case 4:return ct(r,r.stateNode.containerInfo),c=r.pendingProps,s===null?r.child=Mo(r,null,c,o):tn(s,r,c,o),r.child;case 11:return g0(s,r,r.type,r.pendingProps,o);case 7:return tn(s,r,r.pendingProps,o),r.child;case 8:return tn(s,r,r.pendingProps.children,o),r.child;case 12:return tn(s,r,r.pendingProps.children,o),r.child;case 10:return c=r.pendingProps,Zs(r,r.type,c.value),tn(s,r,c.children,o),r.child;case 9:return f=r.type._context,c=r.pendingProps.children,wa(r),f=cn(f),c=c(f),r.flags|=1,tn(s,r,c,o),r.child;case 14:return _0(s,r,r.type,r.pendingProps,o);case 15:return y0(s,r,r.type,r.pendingProps,o);case 19:return R0(s,r,o);case 31:return c=r.pendingProps,o=r.mode,c={mode:c.mode,children:c.children},s===null?(o=Zh(c,o),o.ref=r.ref,r.child=o,o.return=r,r=o):(o=hs(s.child,c),o.ref=r.ref,r.child=o,o.return=r,r=o),r;case 22:return v0(s,r,o);case 24:return wa(r),c=cn(Ut),s===null?(f=Zm(),f===null&&(f=ut,g=Wm(),f.pooledCache=g,g.refCount++,g!==null&&(f.pooledCacheLanes|=o),f=g),r.memoizedState={parent:c,cache:f},ep(r),Zs(r,Ut,f)):((s.lanes&o)!==0&&(tp(s,r),dc(r,null,null,o),hc()),f=s.memoizedState,g=r.memoizedState,f.parent!==c?(f={parent:c,cache:c},r.memoizedState=f,r.lanes===0&&(r.memoizedState=r.updateQueue.baseState=f),Zs(r,Ut,c)):(c=g.cache,Zs(r,Ut,c),c!==f.cache&&Ym(r,[Ut],o,!0))),tn(s,r,r.pendingProps.children,o),r.child;case 29:throw r.pendingProps}throw Error(i(156,r.tag))}function vs(s){s.flags|=4}function x0(s,r){if(r.type!=="stylesheet"||(r.state.loading&4)!==0)s.flags&=-16777217;else if(s.flags|=16777216,!LT(r)){if(r=ti.current,r!==null&&((qe&4194048)===qe?Ui!==null:(qe&62914560)!==qe&&(qe&536870912)===0||r!==Ui))throw cc=Jm,hE;s.flags|=8192}}function Jh(s,r){r!==null&&(s.flags|=4),s.flags&16384&&(r=s.tag!==22?Ll():536870912,s.lanes|=r,Uo|=r)}function vc(s,r){if(!Qe)switch(s.tailMode){case"hidden":r=s.tail;for(var o=null;r!==null;)r.alternate!==null&&(o=r),r=r.sibling;o===null?s.tail=null:o.sibling=null;break;case"collapsed":o=s.tail;for(var c=null;o!==null;)o.alternate!==null&&(c=o),o=o.sibling;c===null?r||s.tail===null?s.tail=null:s.tail.sibling=null:c.sibling=null}}function _t(s){var r=s.alternate!==null&&s.alternate.child===s.child,o=0,c=0;if(r)for(var f=s.child;f!==null;)o|=f.lanes|f.childLanes,c|=f.subtreeFlags&65011712,c|=f.flags&65011712,f.return=s,f=f.sibling;else for(f=s.child;f!==null;)o|=f.lanes|f.childLanes,c|=f.subtreeFlags,c|=f.flags,f.return=s,f=f.sibling;return s.subtreeFlags|=c,s.childLanes=o,r}function r1(s,r,o){var c=r.pendingProps;switch(Gm(r),r.tag){case 31:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return _t(r),null;case 1:return _t(r),null;case 3:return o=r.stateNode,c=null,s!==null&&(c=s.memoizedState.cache),r.memoizedState.cache!==c&&(r.flags|=2048),ps(Ut),Ai(),o.pendingContext&&(o.context=o.pendingContext,o.pendingContext=null),(s===null||s.child===null)&&(nc(r)?vs(r):s===null||s.memoizedState.isDehydrated&&(r.flags&256)===0||(r.flags|=1024,aE())),_t(r),null;case 26:return o=r.memoizedState,s===null?(vs(r),o!==null?(_t(r),x0(r,o)):(_t(r),r.flags&=-16777217)):o?o!==s.memoizedState?(vs(r),_t(r),x0(r,o)):(_t(r),r.flags&=-16777217):(s.memoizedProps!==c&&vs(r),_t(r),r.flags&=-16777217),null;case 27:Zi(r),o=Ae.current;var f=r.type;if(s!==null&&r.stateNode!=null)s.memoizedProps!==c&&vs(r);else{if(!c){if(r.stateNode===null)throw Error(i(166));return _t(r),null}s=ye.current,nc(r)?sE(r):(s=xT(f,c,o),r.stateNode=s,vs(r))}return _t(r),null;case 5:if(Zi(r),o=r.type,s!==null&&r.stateNode!=null)s.memoizedProps!==c&&vs(r);else{if(!c){if(r.stateNode===null)throw Error(i(166));return _t(r),null}if(s=ye.current,nc(r))sE(r);else{switch(f=dd(Ae.current),s){case 1:s=f.createElementNS("http://www.w3.org/2000/svg",o);break;case 2:s=f.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;default:switch(o){case"svg":s=f.createElementNS("http://www.w3.org/2000/svg",o);break;case"math":s=f.createElementNS("http://www.w3.org/1998/Math/MathML",o);break;case"script":s=f.createElement("div"),s.innerHTML="<script><\/script>",s=s.removeChild(s.firstChild);break;case"select":s=typeof c.is=="string"?f.createElement("select",{is:c.is}):f.createElement("select"),c.multiple?s.multiple=!0:c.size&&(s.size=c.size);break;default:s=typeof c.is=="string"?f.createElement(o,{is:c.is}):f.createElement(o)}}s[Pt]=r,s[Ct]=c;e:for(f=r.child;f!==null;){if(f.tag===5||f.tag===6)s.appendChild(f.stateNode);else if(f.tag!==4&&f.tag!==27&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===r)break e;for(;f.sibling===null;){if(f.return===null||f.return===r)break e;f=f.return}f.sibling.return=f.return,f=f.sibling}r.stateNode=s;e:switch(sn(s,o,c),o){case"button":case"input":case"select":case"textarea":s=!!c.autoFocus;break e;case"img":s=!0;break e;default:s=!1}s&&vs(r)}}return _t(r),r.flags&=-16777217,null;case 6:if(s&&r.stateNode!=null)s.memoizedProps!==c&&vs(r);else{if(typeof c!="string"&&r.stateNode===null)throw Error(i(166));if(s=Ae.current,nc(r)){if(s=r.stateNode,o=r.memoizedProps,c=null,f=En,f!==null)switch(f.tag){case 27:case 5:c=f.memoizedProps}s[Pt]=r,s=!!(s.nodeValue===o||c!==null&&c.suppressHydrationWarning===!0||TT(s.nodeValue,o)),s||Ta(r)}else s=dd(s).createTextNode(c),s[Pt]=r,r.stateNode=s}return _t(r),null;case 13:if(c=r.memoizedState,s===null||s.memoizedState!==null&&s.memoizedState.dehydrated!==null){if(f=nc(r),c!==null&&c.dehydrated!==null){if(s===null){if(!f)throw Error(i(318));if(f=r.memoizedState,f=f!==null?f.dehydrated:null,!f)throw Error(i(317));f[Pt]=r}else ic(),(r.flags&128)===0&&(r.memoizedState=null),r.flags|=4;_t(r),f=!1}else f=aE(),s!==null&&s.memoizedState!==null&&(s.memoizedState.hydrationErrors=f),f=!0;if(!f)return r.flags&256?(_s(r),r):(_s(r),null)}if(_s(r),(r.flags&128)!==0)return r.lanes=o,r;if(o=c!==null,s=s!==null&&s.memoizedState!==null,o){c=r.child,f=null,c.alternate!==null&&c.alternate.memoizedState!==null&&c.alternate.memoizedState.cachePool!==null&&(f=c.alternate.memoizedState.cachePool.pool);var g=null;c.memoizedState!==null&&c.memoizedState.cachePool!==null&&(g=c.memoizedState.cachePool.pool),g!==f&&(c.flags|=2048)}return o!==s&&o&&(r.child.flags|=8192),Jh(r,r.updateQueue),_t(r),null;case 4:return Ai(),s===null&&ig(r.stateNode.containerInfo),_t(r),null;case 10:return ps(r.type),_t(r),null;case 19:if(ue(jt),f=r.memoizedState,f===null)return _t(r),null;if(c=(r.flags&128)!==0,g=f.rendering,g===null)if(c)vc(f,!1);else{if(Tt!==0||s!==null&&(s.flags&128)!==0)for(s=r.child;s!==null;){if(g=Qh(s),g!==null){for(r.flags|=128,vc(f,!1),s=g.updateQueue,r.updateQueue=s,Jh(r,s),r.subtreeFlags=0,s=o,o=r.child;o!==null;)nE(o,s),o=o.sibling;return ae(jt,jt.current&1|2),r.child}s=s.sibling}f.tail!==null&&Gn()>nd&&(r.flags|=128,c=!0,vc(f,!1),r.lanes=4194304)}else{if(!c)if(s=Qh(g),s!==null){if(r.flags|=128,c=!0,s=s.updateQueue,r.updateQueue=s,Jh(r,s),vc(f,!0),f.tail===null&&f.tailMode==="hidden"&&!g.alternate&&!Qe)return _t(r),null}else 2*Gn()-f.renderingStartTime>nd&&o!==536870912&&(r.flags|=128,c=!0,vc(f,!1),r.lanes=4194304);f.isBackwards?(g.sibling=r.child,r.child=g):(s=f.last,s!==null?s.sibling=g:r.child=g,f.last=g)}return f.tail!==null?(r=f.tail,f.rendering=r,f.tail=r.sibling,f.renderingStartTime=Gn(),r.sibling=null,s=jt.current,ae(jt,c?s&1|2:s&1),r):(_t(r),null);case 22:case 23:return _s(r),rp(),c=r.memoizedState!==null,s!==null?s.memoizedState!==null!==c&&(r.flags|=8192):c&&(r.flags|=8192),c?(o&536870912)!==0&&(r.flags&128)===0&&(_t(r),r.subtreeFlags&6&&(r.flags|=8192)):_t(r),o=r.updateQueue,o!==null&&Jh(r,o.retryQueue),o=null,s!==null&&s.memoizedState!==null&&s.memoizedState.cachePool!==null&&(o=s.memoizedState.cachePool.pool),c=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(c=r.memoizedState.cachePool.pool),c!==o&&(r.flags|=2048),s!==null&&ue(Sa),null;case 24:return o=null,s!==null&&(o=s.memoizedState.cache),r.memoizedState.cache!==o&&(r.flags|=2048),ps(Ut),_t(r),null;case 25:return null;case 30:return null}throw Error(i(156,r.tag))}function a1(s,r){switch(Gm(r),r.tag){case 1:return s=r.flags,s&65536?(r.flags=s&-65537|128,r):null;case 3:return ps(Ut),Ai(),s=r.flags,(s&65536)!==0&&(s&128)===0?(r.flags=s&-65537|128,r):null;case 26:case 27:case 5:return Zi(r),null;case 13:if(_s(r),s=r.memoizedState,s!==null&&s.dehydrated!==null){if(r.alternate===null)throw Error(i(340));ic()}return s=r.flags,s&65536?(r.flags=s&-65537|128,r):null;case 19:return ue(jt),null;case 4:return Ai(),null;case 10:return ps(r.type),null;case 22:case 23:return _s(r),rp(),s!==null&&ue(Sa),s=r.flags,s&65536?(r.flags=s&-65537|128,r):null;case 24:return ps(Ut),null;case 25:return null;default:return null}}function I0(s,r){switch(Gm(r),r.tag){case 3:ps(Ut),Ai();break;case 26:case 27:case 5:Zi(r);break;case 4:Ai();break;case 13:_s(r);break;case 19:ue(jt);break;case 10:ps(r.type);break;case 22:case 23:_s(r),rp(),s!==null&&ue(Sa);break;case 24:ps(Ut)}}function Ec(s,r){try{var o=r.updateQueue,c=o!==null?o.lastEffect:null;if(c!==null){var f=c.next;o=f;do{if((o.tag&s)===s){c=void 0;var g=o.create,b=o.inst;c=g(),b.destroy=c}o=o.next}while(o!==f)}}catch(S){lt(r,r.return,S)}}function rr(s,r,o){try{var c=r.updateQueue,f=c!==null?c.lastEffect:null;if(f!==null){var g=f.next;c=g;do{if((c.tag&s)===s){var b=c.inst,S=b.destroy;if(S!==void 0){b.destroy=void 0,f=r;var k=o,G=S;try{G()}catch(Z){lt(f,k,Z)}}}c=c.next}while(c!==g)}}catch(Z){lt(r,r.return,Z)}}function N0(s){var r=s.updateQueue;if(r!==null){var o=s.stateNode;try{_E(r,o)}catch(c){lt(s,s.return,c)}}}function k0(s,r,o){o.props=Ra(s.type,s.memoizedProps),o.state=s.memoizedState;try{o.componentWillUnmount()}catch(c){lt(s,r,c)}}function Tc(s,r){try{var o=s.ref;if(o!==null){switch(s.tag){case 26:case 27:case 5:var c=s.stateNode;break;case 30:c=s.stateNode;break;default:c=s.stateNode}typeof o=="function"?s.refCleanup=o(c):o.current=c}}catch(f){lt(s,r,f)}}function ji(s,r){var o=s.ref,c=s.refCleanup;if(o!==null)if(typeof c=="function")try{c()}catch(f){lt(s,r,f)}finally{s.refCleanup=null,s=s.alternate,s!=null&&(s.refCleanup=null)}else if(typeof o=="function")try{o(null)}catch(f){lt(s,r,f)}else o.current=null}function D0(s){var r=s.type,o=s.memoizedProps,c=s.stateNode;try{e:switch(r){case"button":case"input":case"select":case"textarea":o.autoFocus&&c.focus();break e;case"img":o.src?c.src=o.src:o.srcSet&&(c.srcset=o.srcSet)}}catch(f){lt(s,s.return,f)}}function Op(s,r,o){try{var c=s.stateNode;C1(c,s.type,o,r),c[Ct]=r}catch(f){lt(s,s.return,f)}}function O0(s){return s.tag===5||s.tag===3||s.tag===26||s.tag===27&&fr(s.type)||s.tag===4}function Mp(s){e:for(;;){for(;s.sibling===null;){if(s.return===null||O0(s.return))return null;s=s.return}for(s.sibling.return=s.return,s=s.sibling;s.tag!==5&&s.tag!==6&&s.tag!==18;){if(s.tag===27&&fr(s.type)||s.flags&2||s.child===null||s.tag===4)continue e;s.child.return=s,s=s.child}if(!(s.flags&2))return s.stateNode}}function Pp(s,r,o){var c=s.tag;if(c===5||c===6)s=s.stateNode,r?(o.nodeType===9?o.body:o.nodeName==="HTML"?o.ownerDocument.body:o).insertBefore(s,r):(r=o.nodeType===9?o.body:o.nodeName==="HTML"?o.ownerDocument.body:o,r.appendChild(s),o=o._reactRootContainer,o!=null||r.onclick!==null||(r.onclick=hd));else if(c!==4&&(c===27&&fr(s.type)&&(o=s.stateNode,r=null),s=s.child,s!==null))for(Pp(s,r,o),s=s.sibling;s!==null;)Pp(s,r,o),s=s.sibling}function ed(s,r,o){var c=s.tag;if(c===5||c===6)s=s.stateNode,r?o.insertBefore(s,r):o.appendChild(s);else if(c!==4&&(c===27&&fr(s.type)&&(o=s.stateNode),s=s.child,s!==null))for(ed(s,r,o),s=s.sibling;s!==null;)ed(s,r,o),s=s.sibling}function M0(s){var r=s.stateNode,o=s.memoizedProps;try{for(var c=s.type,f=r.attributes;f.length;)r.removeAttributeNode(f[0]);sn(r,c,o),r[Pt]=s,r[Ct]=o}catch(g){lt(s,s.return,g)}}var Es=!1,St=!1,Lp=!1,P0=typeof WeakSet=="function"?WeakSet:Set,Kt=null;function o1(s,r){if(s=s.containerInfo,ag=yd,s=$v(s),Mm(s)){if("selectionStart"in s)var o={start:s.selectionStart,end:s.selectionEnd};else e:{o=(o=s.ownerDocument)&&o.defaultView||window;var c=o.getSelection&&o.getSelection();if(c&&c.rangeCount!==0){o=c.anchorNode;var f=c.anchorOffset,g=c.focusNode;c=c.focusOffset;try{o.nodeType,g.nodeType}catch{o=null;break e}var b=0,S=-1,k=-1,G=0,Z=0,te=s,$=null;t:for(;;){for(var K;te!==o||f!==0&&te.nodeType!==3||(S=b+f),te!==g||c!==0&&te.nodeType!==3||(k=b+c),te.nodeType===3&&(b+=te.nodeValue.length),(K=te.firstChild)!==null;)$=te,te=K;for(;;){if(te===s)break t;if($===o&&++G===f&&(S=b),$===g&&++Z===c&&(k=b),(K=te.nextSibling)!==null)break;te=$,$=te.parentNode}te=K}o=S===-1||k===-1?null:{start:S,end:k}}else o=null}o=o||{start:0,end:0}}else o=null;for(og={focusedElem:s,selectionRange:o},yd=!1,Kt=r;Kt!==null;)if(r=Kt,s=r.child,(r.subtreeFlags&1024)!==0&&s!==null)s.return=r,Kt=s;else for(;Kt!==null;){switch(r=Kt,g=r.alternate,s=r.flags,r.tag){case 0:break;case 11:case 15:break;case 1:if((s&1024)!==0&&g!==null){s=void 0,o=r,f=g.memoizedProps,g=g.memoizedState,c=o.stateNode;try{var be=Ra(o.type,f,o.elementType===o.type);s=c.getSnapshotBeforeUpdate(be,g),c.__reactInternalSnapshotBeforeUpdate=s}catch(ve){lt(o,o.return,ve)}}break;case 3:if((s&1024)!==0){if(s=r.stateNode.containerInfo,o=s.nodeType,o===9)ug(s);else if(o===1)switch(s.nodeName){case"HEAD":case"HTML":case"BODY":ug(s);break;default:s.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((s&1024)!==0)throw Error(i(163))}if(s=r.sibling,s!==null){s.return=r.return,Kt=s;break}Kt=r.return}}function L0(s,r,o){var c=o.flags;switch(o.tag){case 0:case 11:case 15:ar(s,o),c&4&&Ec(5,o);break;case 1:if(ar(s,o),c&4)if(s=o.stateNode,r===null)try{s.componentDidMount()}catch(b){lt(o,o.return,b)}else{var f=Ra(o.type,r.memoizedProps);r=r.memoizedState;try{s.componentDidUpdate(f,r,s.__reactInternalSnapshotBeforeUpdate)}catch(b){lt(o,o.return,b)}}c&64&&N0(o),c&512&&Tc(o,o.return);break;case 3:if(ar(s,o),c&64&&(s=o.updateQueue,s!==null)){if(r=null,o.child!==null)switch(o.child.tag){case 27:case 5:r=o.child.stateNode;break;case 1:r=o.child.stateNode}try{_E(s,r)}catch(b){lt(o,o.return,b)}}break;case 27:r===null&&c&4&&M0(o);case 26:case 5:ar(s,o),r===null&&c&4&&D0(o),c&512&&Tc(o,o.return);break;case 12:ar(s,o);break;case 13:ar(s,o),c&4&&j0(s,o),c&64&&(s=o.memoizedState,s!==null&&(s=s.dehydrated,s!==null&&(o=g1.bind(null,o),M1(s,o))));break;case 22:if(c=o.memoizedState!==null||Es,!c){r=r!==null&&r.memoizedState!==null||St,f=Es;var g=St;Es=c,(St=r)&&!g?or(s,o,(o.subtreeFlags&8772)!==0):ar(s,o),Es=f,St=g}break;case 30:break;default:ar(s,o)}}function V0(s){var r=s.alternate;r!==null&&(s.alternate=null,V0(r)),s.child=null,s.deletions=null,s.sibling=null,s.tag===5&&(r=s.stateNode,r!==null&&Qs(r)),s.stateNode=null,s.return=null,s.dependencies=null,s.memoizedProps=null,s.memoizedState=null,s.pendingProps=null,s.stateNode=null,s.updateQueue=null}var pt=null,wn=!1;function Ts(s,r,o){for(o=o.child;o!==null;)U0(s,r,o),o=o.sibling}function U0(s,r,o){if(Ze&&typeof Ze.onCommitFiberUnmount=="function")try{Ze.onCommitFiberUnmount(vt,o)}catch{}switch(o.tag){case 26:St||ji(o,r),Ts(s,r,o),o.memoizedState?o.memoizedState.count--:o.stateNode&&(o=o.stateNode,o.parentNode.removeChild(o));break;case 27:St||ji(o,r);var c=pt,f=wn;fr(o.type)&&(pt=o.stateNode,wn=!1),Ts(s,r,o),Nc(o.stateNode),pt=c,wn=f;break;case 5:St||ji(o,r);case 6:if(c=pt,f=wn,pt=null,Ts(s,r,o),pt=c,wn=f,pt!==null)if(wn)try{(pt.nodeType===9?pt.body:pt.nodeName==="HTML"?pt.ownerDocument.body:pt).removeChild(o.stateNode)}catch(g){lt(o,r,g)}else try{pt.removeChild(o.stateNode)}catch(g){lt(o,r,g)}break;case 18:pt!==null&&(wn?(s=pt,RT(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,o.stateNode),Uc(s)):RT(pt,o.stateNode));break;case 4:c=pt,f=wn,pt=o.stateNode.containerInfo,wn=!0,Ts(s,r,o),pt=c,wn=f;break;case 0:case 11:case 14:case 15:St||rr(2,o,r),St||rr(4,o,r),Ts(s,r,o);break;case 1:St||(ji(o,r),c=o.stateNode,typeof c.componentWillUnmount=="function"&&k0(o,r,c)),Ts(s,r,o);break;case 21:Ts(s,r,o);break;case 22:St=(c=St)||o.memoizedState!==null,Ts(s,r,o),St=c;break;default:Ts(s,r,o)}}function j0(s,r){if(r.memoizedState===null&&(s=r.alternate,s!==null&&(s=s.memoizedState,s!==null&&(s=s.dehydrated,s!==null))))try{Uc(s)}catch(o){lt(r,r.return,o)}}function l1(s){switch(s.tag){case 13:case 19:var r=s.stateNode;return r===null&&(r=s.stateNode=new P0),r;case 22:return s=s.stateNode,r=s._retryCache,r===null&&(r=s._retryCache=new P0),r;default:throw Error(i(435,s.tag))}}function Vp(s,r){var o=l1(s);r.forEach(function(c){var f=_1.bind(null,s,c);o.has(c)||(o.add(c),c.then(f,f))})}function Vn(s,r){var o=r.deletions;if(o!==null)for(var c=0;c<o.length;c++){var f=o[c],g=s,b=r,S=b;e:for(;S!==null;){switch(S.tag){case 27:if(fr(S.type)){pt=S.stateNode,wn=!1;break e}break;case 5:pt=S.stateNode,wn=!1;break e;case 3:case 4:pt=S.stateNode.containerInfo,wn=!0;break e}S=S.return}if(pt===null)throw Error(i(160));U0(g,b,f),pt=null,wn=!1,g=f.alternate,g!==null&&(g.return=null),f.return=null}if(r.subtreeFlags&13878)for(r=r.child;r!==null;)z0(r,s),r=r.sibling}var di=null;function z0(s,r){var o=s.alternate,c=s.flags;switch(s.tag){case 0:case 11:case 14:case 15:Vn(r,s),Un(s),c&4&&(rr(3,s,s.return),Ec(3,s),rr(5,s,s.return));break;case 1:Vn(r,s),Un(s),c&512&&(St||o===null||ji(o,o.return)),c&64&&Es&&(s=s.updateQueue,s!==null&&(c=s.callbacks,c!==null&&(o=s.shared.hiddenCallbacks,s.shared.hiddenCallbacks=o===null?c:o.concat(c))));break;case 26:var f=di;if(Vn(r,s),Un(s),c&512&&(St||o===null||ji(o,o.return)),c&4){var g=o!==null?o.memoizedState:null;if(c=s.memoizedState,o===null)if(c===null)if(s.stateNode===null){e:{c=s.type,o=s.memoizedProps,f=f.ownerDocument||f;t:switch(c){case"title":g=f.getElementsByTagName("title")[0],(!g||g[ta]||g[Pt]||g.namespaceURI==="http://www.w3.org/2000/svg"||g.hasAttribute("itemprop"))&&(g=f.createElement(c),f.head.insertBefore(g,f.querySelector("head > title"))),sn(g,c,o),g[Pt]=s,bt(g),c=g;break e;case"link":var b=MT("link","href",f).get(c+(o.href||""));if(b){for(var S=0;S<b.length;S++)if(g=b[S],g.getAttribute("href")===(o.href==null||o.href===""?null:o.href)&&g.getAttribute("rel")===(o.rel==null?null:o.rel)&&g.getAttribute("title")===(o.title==null?null:o.title)&&g.getAttribute("crossorigin")===(o.crossOrigin==null?null:o.crossOrigin)){b.splice(S,1);break t}}g=f.createElement(c),sn(g,c,o),f.head.appendChild(g);break;case"meta":if(b=MT("meta","content",f).get(c+(o.content||""))){for(S=0;S<b.length;S++)if(g=b[S],g.getAttribute("content")===(o.content==null?null:""+o.content)&&g.getAttribute("name")===(o.name==null?null:o.name)&&g.getAttribute("property")===(o.property==null?null:o.property)&&g.getAttribute("http-equiv")===(o.httpEquiv==null?null:o.httpEquiv)&&g.getAttribute("charset")===(o.charSet==null?null:o.charSet)){b.splice(S,1);break t}}g=f.createElement(c),sn(g,c,o),f.head.appendChild(g);break;default:throw Error(i(468,c))}g[Pt]=s,bt(g),c=g}s.stateNode=c}else PT(f,s.type,s.stateNode);else s.stateNode=OT(f,c,s.memoizedProps);else g!==c?(g===null?o.stateNode!==null&&(o=o.stateNode,o.parentNode.removeChild(o)):g.count--,c===null?PT(f,s.type,s.stateNode):OT(f,c,s.memoizedProps)):c===null&&s.stateNode!==null&&Op(s,s.memoizedProps,o.memoizedProps)}break;case 27:Vn(r,s),Un(s),c&512&&(St||o===null||ji(o,o.return)),o!==null&&c&4&&Op(s,s.memoizedProps,o.memoizedProps);break;case 5:if(Vn(r,s),Un(s),c&512&&(St||o===null||ji(o,o.return)),s.flags&32){f=s.stateNode;try{Kn(f,"")}catch(K){lt(s,s.return,K)}}c&4&&s.stateNode!=null&&(f=s.memoizedProps,Op(s,f,o!==null?o.memoizedProps:f)),c&1024&&(Lp=!0);break;case 6:if(Vn(r,s),Un(s),c&4){if(s.stateNode===null)throw Error(i(162));c=s.memoizedProps,o=s.stateNode;try{o.nodeValue=c}catch(K){lt(s,s.return,K)}}break;case 3:if(pd=null,f=di,di=fd(r.containerInfo),Vn(r,s),di=f,Un(s),c&4&&o!==null&&o.memoizedState.isDehydrated)try{Uc(r.containerInfo)}catch(K){lt(s,s.return,K)}Lp&&(Lp=!1,F0(s));break;case 4:c=di,di=fd(s.stateNode.containerInfo),Vn(r,s),Un(s),di=c;break;case 12:Vn(r,s),Un(s);break;case 13:Vn(r,s),Un(s),s.child.flags&8192&&s.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(qp=Gn()),c&4&&(c=s.updateQueue,c!==null&&(s.updateQueue=null,Vp(s,c)));break;case 22:f=s.memoizedState!==null;var k=o!==null&&o.memoizedState!==null,G=Es,Z=St;if(Es=G||f,St=Z||k,Vn(r,s),St=Z,Es=G,Un(s),c&8192)e:for(r=s.stateNode,r._visibility=f?r._visibility&-2:r._visibility|1,f&&(o===null||k||Es||St||Ca(s)),o=null,r=s;;){if(r.tag===5||r.tag===26){if(o===null){k=o=r;try{if(g=k.stateNode,f)b=g.style,typeof b.setProperty=="function"?b.setProperty("display","none","important"):b.display="none";else{S=k.stateNode;var te=k.memoizedProps.style,$=te!=null&&te.hasOwnProperty("display")?te.display:null;S.style.display=$==null||typeof $=="boolean"?"":(""+$).trim()}}catch(K){lt(k,k.return,K)}}}else if(r.tag===6){if(o===null){k=r;try{k.stateNode.nodeValue=f?"":k.memoizedProps}catch(K){lt(k,k.return,K)}}}else if((r.tag!==22&&r.tag!==23||r.memoizedState===null||r===s)&&r.child!==null){r.child.return=r,r=r.child;continue}if(r===s)break e;for(;r.sibling===null;){if(r.return===null||r.return===s)break e;o===r&&(o=null),r=r.return}o===r&&(o=null),r.sibling.return=r.return,r=r.sibling}c&4&&(c=s.updateQueue,c!==null&&(o=c.retryQueue,o!==null&&(c.retryQueue=null,Vp(s,o))));break;case 19:Vn(r,s),Un(s),c&4&&(c=s.updateQueue,c!==null&&(s.updateQueue=null,Vp(s,c)));break;case 30:break;case 21:break;default:Vn(r,s),Un(s)}}function Un(s){var r=s.flags;if(r&2){try{for(var o,c=s.return;c!==null;){if(O0(c)){o=c;break}c=c.return}if(o==null)throw Error(i(160));switch(o.tag){case 27:var f=o.stateNode,g=Mp(s);ed(s,g,f);break;case 5:var b=o.stateNode;o.flags&32&&(Kn(b,""),o.flags&=-33);var S=Mp(s);ed(s,S,b);break;case 3:case 4:var k=o.stateNode.containerInfo,G=Mp(s);Pp(s,G,k);break;default:throw Error(i(161))}}catch(Z){lt(s,s.return,Z)}s.flags&=-3}r&4096&&(s.flags&=-4097)}function F0(s){if(s.subtreeFlags&1024)for(s=s.child;s!==null;){var r=s;F0(r),r.tag===5&&r.flags&1024&&r.stateNode.reset(),s=s.sibling}}function ar(s,r){if(r.subtreeFlags&8772)for(r=r.child;r!==null;)L0(s,r.alternate,r),r=r.sibling}function Ca(s){for(s=s.child;s!==null;){var r=s;switch(r.tag){case 0:case 11:case 14:case 15:rr(4,r,r.return),Ca(r);break;case 1:ji(r,r.return);var o=r.stateNode;typeof o.componentWillUnmount=="function"&&k0(r,r.return,o),Ca(r);break;case 27:Nc(r.stateNode);case 26:case 5:ji(r,r.return),Ca(r);break;case 22:r.memoizedState===null&&Ca(r);break;case 30:Ca(r);break;default:Ca(r)}s=s.sibling}}function or(s,r,o){for(o=o&&(r.subtreeFlags&8772)!==0,r=r.child;r!==null;){var c=r.alternate,f=s,g=r,b=g.flags;switch(g.tag){case 0:case 11:case 15:or(f,g,o),Ec(4,g);break;case 1:if(or(f,g,o),c=g,f=c.stateNode,typeof f.componentDidMount=="function")try{f.componentDidMount()}catch(G){lt(c,c.return,G)}if(c=g,f=c.updateQueue,f!==null){var S=c.stateNode;try{var k=f.shared.hiddenCallbacks;if(k!==null)for(f.shared.hiddenCallbacks=null,f=0;f<k.length;f++)gE(k[f],S)}catch(G){lt(c,c.return,G)}}o&&b&64&&N0(g),Tc(g,g.return);break;case 27:M0(g);case 26:case 5:or(f,g,o),o&&c===null&&b&4&&D0(g),Tc(g,g.return);break;case 12:or(f,g,o);break;case 13:or(f,g,o),o&&b&4&&j0(f,g);break;case 22:g.memoizedState===null&&or(f,g,o),Tc(g,g.return);break;case 30:break;default:or(f,g,o)}r=r.sibling}}function Up(s,r){var o=null;s!==null&&s.memoizedState!==null&&s.memoizedState.cachePool!==null&&(o=s.memoizedState.cachePool.pool),s=null,r.memoizedState!==null&&r.memoizedState.cachePool!==null&&(s=r.memoizedState.cachePool.pool),s!==o&&(s!=null&&s.refCount++,o!=null&&ac(o))}function jp(s,r){s=null,r.alternate!==null&&(s=r.alternate.memoizedState.cache),r=r.memoizedState.cache,r!==s&&(r.refCount++,s!=null&&ac(s))}function zi(s,r,o,c){if(r.subtreeFlags&10256)for(r=r.child;r!==null;)B0(s,r,o,c),r=r.sibling}function B0(s,r,o,c){var f=r.flags;switch(r.tag){case 0:case 11:case 15:zi(s,r,o,c),f&2048&&Ec(9,r);break;case 1:zi(s,r,o,c);break;case 3:zi(s,r,o,c),f&2048&&(s=null,r.alternate!==null&&(s=r.alternate.memoizedState.cache),r=r.memoizedState.cache,r!==s&&(r.refCount++,s!=null&&ac(s)));break;case 12:if(f&2048){zi(s,r,o,c),s=r.stateNode;try{var g=r.memoizedProps,b=g.id,S=g.onPostCommit;typeof S=="function"&&S(b,r.alternate===null?"mount":"update",s.passiveEffectDuration,-0)}catch(k){lt(r,r.return,k)}}else zi(s,r,o,c);break;case 13:zi(s,r,o,c);break;case 23:break;case 22:g=r.stateNode,b=r.alternate,r.memoizedState!==null?g._visibility&2?zi(s,r,o,c):bc(s,r):g._visibility&2?zi(s,r,o,c):(g._visibility|=2,Po(s,r,o,c,(r.subtreeFlags&10256)!==0)),f&2048&&Up(b,r);break;case 24:zi(s,r,o,c),f&2048&&jp(r.alternate,r);break;default:zi(s,r,o,c)}}function Po(s,r,o,c,f){for(f=f&&(r.subtreeFlags&10256)!==0,r=r.child;r!==null;){var g=s,b=r,S=o,k=c,G=b.flags;switch(b.tag){case 0:case 11:case 15:Po(g,b,S,k,f),Ec(8,b);break;case 23:break;case 22:var Z=b.stateNode;b.memoizedState!==null?Z._visibility&2?Po(g,b,S,k,f):bc(g,b):(Z._visibility|=2,Po(g,b,S,k,f)),f&&G&2048&&Up(b.alternate,b);break;case 24:Po(g,b,S,k,f),f&&G&2048&&jp(b.alternate,b);break;default:Po(g,b,S,k,f)}r=r.sibling}}function bc(s,r){if(r.subtreeFlags&10256)for(r=r.child;r!==null;){var o=s,c=r,f=c.flags;switch(c.tag){case 22:bc(o,c),f&2048&&Up(c.alternate,c);break;case 24:bc(o,c),f&2048&&jp(c.alternate,c);break;default:bc(o,c)}r=r.sibling}}var wc=8192;function Lo(s){if(s.subtreeFlags&wc)for(s=s.child;s!==null;)q0(s),s=s.sibling}function q0(s){switch(s.tag){case 26:Lo(s),s.flags&wc&&s.memoizedState!==null&&K1(di,s.memoizedState,s.memoizedProps);break;case 5:Lo(s);break;case 3:case 4:var r=di;di=fd(s.stateNode.containerInfo),Lo(s),di=r;break;case 22:s.memoizedState===null&&(r=s.alternate,r!==null&&r.memoizedState!==null?(r=wc,wc=16777216,Lo(s),wc=r):Lo(s));break;default:Lo(s)}}function H0(s){var r=s.alternate;if(r!==null&&(s=r.child,s!==null)){r.child=null;do r=s.sibling,s.sibling=null,s=r;while(s!==null)}}function Sc(s){var r=s.deletions;if((s.flags&16)!==0){if(r!==null)for(var o=0;o<r.length;o++){var c=r[o];Kt=c,$0(c,s)}H0(s)}if(s.subtreeFlags&10256)for(s=s.child;s!==null;)G0(s),s=s.sibling}function G0(s){switch(s.tag){case 0:case 11:case 15:Sc(s),s.flags&2048&&rr(9,s,s.return);break;case 3:Sc(s);break;case 12:Sc(s);break;case 22:var r=s.stateNode;s.memoizedState!==null&&r._visibility&2&&(s.return===null||s.return.tag!==13)?(r._visibility&=-3,td(s)):Sc(s);break;default:Sc(s)}}function td(s){var r=s.deletions;if((s.flags&16)!==0){if(r!==null)for(var o=0;o<r.length;o++){var c=r[o];Kt=c,$0(c,s)}H0(s)}for(s=s.child;s!==null;){switch(r=s,r.tag){case 0:case 11:case 15:rr(8,r,r.return),td(r);break;case 22:o=r.stateNode,o._visibility&2&&(o._visibility&=-3,td(r));break;default:td(r)}s=s.sibling}}function $0(s,r){for(;Kt!==null;){var o=Kt;switch(o.tag){case 0:case 11:case 15:rr(8,o,r);break;case 23:case 22:if(o.memoizedState!==null&&o.memoizedState.cachePool!==null){var c=o.memoizedState.cachePool.pool;c!=null&&c.refCount++}break;case 24:ac(o.memoizedState.cache)}if(c=o.child,c!==null)c.return=o,Kt=c;else e:for(o=s;Kt!==null;){c=Kt;var f=c.sibling,g=c.return;if(V0(c),c===o){Kt=null;break e}if(f!==null){f.return=g,Kt=f;break e}Kt=g}}}var c1={getCacheForType:function(s){var r=cn(Ut),o=r.data.get(s);return o===void 0&&(o=s(),r.data.set(s,o)),o}},u1=typeof WeakMap=="function"?WeakMap:Map,Je=0,ut=null,Le=null,qe=0,et=0,jn=null,lr=!1,Vo=!1,zp=!1,bs=0,Tt=0,cr=0,xa=0,Fp=0,ni=0,Uo=0,Ac=null,Sn=null,Bp=!1,qp=0,nd=1/0,id=null,ur=null,nn=0,hr=null,jo=null,zo=0,Hp=0,Gp=null,K0=null,Rc=0,$p=null;function zn(){if((Je&2)!==0&&qe!==0)return qe&-qe;if(X.T!==null){var s=Co;return s!==0?s:Jp()}return $s()}function Q0(){ni===0&&(ni=(qe&536870912)===0||Qe?Pl():536870912);var s=ti.current;return s!==null&&(s.flags|=32),ni}function Fn(s,r,o){(s===ut&&(et===2||et===9)||s.cancelPendingCommit!==null)&&(Fo(s,0),dr(s,qe,ni,!1)),es(s,o),((Je&2)===0||s!==ut)&&(s===ut&&((Je&2)===0&&(xa|=o),Tt===4&&dr(s,qe,ni,!1)),Fi(s))}function Y0(s,r,o){if((Je&6)!==0)throw Error(i(327));var c=!o&&(r&124)===0&&(r&s.expiredLanes)===0||ea(s,r),f=c?f1(s,r):Yp(s,r,!0),g=c;do{if(f===0){Vo&&!c&&dr(s,r,0,!1);break}else{if(o=s.current.alternate,g&&!h1(o)){f=Yp(s,r,!1),g=!1;continue}if(f===2){if(g=r,s.errorRecoveryDisabledLanes&g)var b=0;else b=s.pendingLanes&-536870913,b=b!==0?b:b&536870912?536870912:0;if(b!==0){r=b;e:{var S=s;f=Ac;var k=S.current.memoizedState.isDehydrated;if(k&&(Fo(S,b).flags|=256),b=Yp(S,b,!1),b!==2){if(zp&&!k){S.errorRecoveryDisabledLanes|=g,xa|=g,f=4;break e}g=Sn,Sn=f,g!==null&&(Sn===null?Sn=g:Sn.push.apply(Sn,g))}f=b}if(g=!1,f!==2)continue}}if(f===1){Fo(s,0),dr(s,r,0,!0);break}e:{switch(c=s,g=f,g){case 0:case 1:throw Error(i(345));case 4:if((r&4194048)!==r)break;case 6:dr(c,r,ni,!lr);break e;case 2:Sn=null;break;case 3:case 5:break;default:throw Error(i(329))}if((r&62914560)===r&&(f=qp+300-Gn(),10<f)){if(dr(c,r,ni,!lr),io(c,0,!0)!==0)break e;c.timeoutHandle=ST(W0.bind(null,c,o,Sn,id,Bp,r,ni,xa,Uo,lr,g,2,-0,0),f);break e}W0(c,o,Sn,id,Bp,r,ni,xa,Uo,lr,g,0,-0,0)}}break}while(!0);Fi(s)}function W0(s,r,o,c,f,g,b,S,k,G,Z,te,$,K){if(s.timeoutHandle=-1,te=r.subtreeFlags,(te&8192||(te&16785408)===16785408)&&(Oc={stylesheets:null,count:0,unsuspend:$1},q0(r),te=Q1(),te!==null)){s.cancelPendingCommit=te(iT.bind(null,s,r,g,o,c,f,b,S,k,Z,1,$,K)),dr(s,g,b,!G);return}iT(s,r,g,o,c,f,b,S,k)}function h1(s){for(var r=s;;){var o=r.tag;if((o===0||o===11||o===15)&&r.flags&16384&&(o=r.updateQueue,o!==null&&(o=o.stores,o!==null)))for(var c=0;c<o.length;c++){var f=o[c],g=f.getSnapshot;f=f.value;try{if(!Pn(g(),f))return!1}catch{return!1}}if(o=r.child,r.subtreeFlags&16384&&o!==null)o.return=r,r=o;else{if(r===s)break;for(;r.sibling===null;){if(r.return===null||r.return===s)return!0;r=r.return}r.sibling.return=r.return,r=r.sibling}}return!0}function dr(s,r,o,c){r&=~Fp,r&=~xa,s.suspendedLanes|=r,s.pingedLanes&=~r,c&&(s.warmLanes|=r),c=s.expirationTimes;for(var f=r;0<f;){var g=31-ln(f),b=1<<g;c[g]=-1,f&=~b}o!==0&&Ri(s,o,r)}function sd(){return(Je&6)===0?(Cc(0),!1):!0}function Kp(){if(Le!==null){if(et===0)var s=Le.return;else s=Le,ms=ba=null,up(s),Oo=null,_c=0,s=Le;for(;s!==null;)I0(s.alternate,s),s=s.return;Le=null}}function Fo(s,r){var o=s.timeoutHandle;o!==-1&&(s.timeoutHandle=-1,I1(o)),o=s.cancelPendingCommit,o!==null&&(s.cancelPendingCommit=null,o()),Kp(),ut=s,Le=o=hs(s.current,null),qe=r,et=0,jn=null,lr=!1,Vo=ea(s,r),zp=!1,Uo=ni=Fp=xa=cr=Tt=0,Sn=Ac=null,Bp=!1,(r&8)!==0&&(r|=r&32);var c=s.entangledLanes;if(c!==0)for(s=s.entanglements,c&=r;0<c;){var f=31-ln(c),g=1<<f;r|=s[f],c&=~g}return bs=r,Rh(),o}function X0(s,r){Ie=null,X.H=Gh,r===lc||r===Ph?(r=mE(),et=3):r===hE?(r=mE(),et=4):et=r===p0?8:r!==null&&typeof r=="object"&&typeof r.then=="function"?6:1,jn=r,Le===null&&(Tt=1,Wh(s,Xn(r,s.current)))}function Z0(){var s=X.H;return X.H=Gh,s===null?Gh:s}function J0(){var s=X.A;return X.A=c1,s}function Qp(){Tt=4,lr||(qe&4194048)!==qe&&ti.current!==null||(Vo=!0),(cr&134217727)===0&&(xa&134217727)===0||ut===null||dr(ut,qe,ni,!1)}function Yp(s,r,o){var c=Je;Je|=2;var f=Z0(),g=J0();(ut!==s||qe!==r)&&(id=null,Fo(s,r)),r=!1;var b=Tt;e:do try{if(et!==0&&Le!==null){var S=Le,k=jn;switch(et){case 8:Kp(),b=6;break e;case 3:case 2:case 9:case 6:ti.current===null&&(r=!0);var G=et;if(et=0,jn=null,Bo(s,S,k,G),o&&Vo){b=0;break e}break;default:G=et,et=0,jn=null,Bo(s,S,k,G)}}d1(),b=Tt;break}catch(Z){X0(s,Z)}while(!0);return r&&s.shellSuspendCounter++,ms=ba=null,Je=c,X.H=f,X.A=g,Le===null&&(ut=null,qe=0,Rh()),b}function d1(){for(;Le!==null;)eT(Le)}function f1(s,r){var o=Je;Je|=2;var c=Z0(),f=J0();ut!==s||qe!==r?(id=null,nd=Gn()+500,Fo(s,r)):Vo=ea(s,r);e:do try{if(et!==0&&Le!==null){r=Le;var g=jn;t:switch(et){case 1:et=0,jn=null,Bo(s,r,g,1);break;case 2:case 9:if(dE(g)){et=0,jn=null,tT(r);break}r=function(){et!==2&&et!==9||ut!==s||(et=7),Fi(s)},g.then(r,r);break e;case 3:et=7;break e;case 4:et=5;break e;case 7:dE(g)?(et=0,jn=null,tT(r)):(et=0,jn=null,Bo(s,r,g,7));break;case 5:var b=null;switch(Le.tag){case 26:b=Le.memoizedState;case 5:case 27:var S=Le;if(!b||LT(b)){et=0,jn=null;var k=S.sibling;if(k!==null)Le=k;else{var G=S.return;G!==null?(Le=G,rd(G)):Le=null}break t}}et=0,jn=null,Bo(s,r,g,5);break;case 6:et=0,jn=null,Bo(s,r,g,6);break;case 8:Kp(),Tt=6;break e;default:throw Error(i(462))}}m1();break}catch(Z){X0(s,Z)}while(!0);return ms=ba=null,X.H=c,X.A=f,Je=o,Le!==null?0:(ut=null,qe=0,Rh(),Tt)}function m1(){for(;Le!==null&&!kl();)eT(Le)}function eT(s){var r=C0(s.alternate,s,bs);s.memoizedProps=s.pendingProps,r===null?rd(s):Le=r}function tT(s){var r=s,o=r.alternate;switch(r.tag){case 15:case 0:r=T0(o,r,r.pendingProps,r.type,void 0,qe);break;case 11:r=T0(o,r,r.pendingProps,r.type.render,r.ref,qe);break;case 5:up(r);default:I0(o,r),r=Le=nE(r,bs),r=C0(o,r,bs)}s.memoizedProps=s.pendingProps,r===null?rd(s):Le=r}function Bo(s,r,o,c){ms=ba=null,up(r),Oo=null,_c=0;var f=r.return;try{if(i1(s,f,r,o,qe)){Tt=1,Wh(s,Xn(o,s.current)),Le=null;return}}catch(g){if(f!==null)throw Le=f,g;Tt=1,Wh(s,Xn(o,s.current)),Le=null;return}r.flags&32768?(Qe||c===1?s=!0:Vo||(qe&536870912)!==0?s=!1:(lr=s=!0,(c===2||c===9||c===3||c===6)&&(c=ti.current,c!==null&&c.tag===13&&(c.flags|=16384))),nT(r,s)):rd(r)}function rd(s){var r=s;do{if((r.flags&32768)!==0){nT(r,lr);return}s=r.return;var o=r1(r.alternate,r,bs);if(o!==null){Le=o;return}if(r=r.sibling,r!==null){Le=r;return}Le=r=s}while(r!==null);Tt===0&&(Tt=5)}function nT(s,r){do{var o=a1(s.alternate,s);if(o!==null){o.flags&=32767,Le=o;return}if(o=s.return,o!==null&&(o.flags|=32768,o.subtreeFlags=0,o.deletions=null),!r&&(s=s.sibling,s!==null)){Le=s;return}Le=s=o}while(s!==null);Tt=6,Le=null}function iT(s,r,o,c,f,g,b,S,k){s.cancelPendingCommit=null;do ad();while(nn!==0);if((Je&6)!==0)throw Error(i(327));if(r!==null){if(r===s.current)throw Error(i(177));if(g=r.lanes|r.childLanes,g|=jm,Vl(s,o,g,b,S,k),s===ut&&(Le=ut=null,qe=0),jo=r,hr=s,zo=o,Hp=g,Gp=f,K0=c,(r.subtreeFlags&10256)!==0||(r.flags&10256)!==0?(s.callbackNode=null,s.callbackPriority=0,y1(Wr,function(){return lT(),null})):(s.callbackNode=null,s.callbackPriority=0),c=(r.flags&13878)!==0,(r.subtreeFlags&13878)!==0||c){c=X.T,X.T=null,f=ce.p,ce.p=2,b=Je,Je|=4;try{o1(s,r,o)}finally{Je=b,ce.p=f,X.T=c}}nn=1,sT(),rT(),aT()}}function sT(){if(nn===1){nn=0;var s=hr,r=jo,o=(r.flags&13878)!==0;if((r.subtreeFlags&13878)!==0||o){o=X.T,X.T=null;var c=ce.p;ce.p=2;var f=Je;Je|=4;try{z0(r,s);var g=og,b=$v(s.containerInfo),S=g.focusedElem,k=g.selectionRange;if(b!==S&&S&&S.ownerDocument&&Gv(S.ownerDocument.documentElement,S)){if(k!==null&&Mm(S)){var G=k.start,Z=k.end;if(Z===void 0&&(Z=G),"selectionStart"in S)S.selectionStart=G,S.selectionEnd=Math.min(Z,S.value.length);else{var te=S.ownerDocument||document,$=te&&te.defaultView||window;if($.getSelection){var K=$.getSelection(),be=S.textContent.length,ve=Math.min(k.start,be),rt=k.end===void 0?ve:Math.min(k.end,be);!K.extend&&ve>rt&&(b=rt,rt=ve,ve=b);var F=Hv(S,ve),U=Hv(S,rt);if(F&&U&&(K.rangeCount!==1||K.anchorNode!==F.node||K.anchorOffset!==F.offset||K.focusNode!==U.node||K.focusOffset!==U.offset)){var H=te.createRange();H.setStart(F.node,F.offset),K.removeAllRanges(),ve>rt?(K.addRange(H),K.extend(U.node,U.offset)):(H.setEnd(U.node,U.offset),K.addRange(H))}}}}for(te=[],K=S;K=K.parentNode;)K.nodeType===1&&te.push({element:K,left:K.scrollLeft,top:K.scrollTop});for(typeof S.focus=="function"&&S.focus(),S=0;S<te.length;S++){var J=te[S];J.element.scrollLeft=J.left,J.element.scrollTop=J.top}}yd=!!ag,og=ag=null}finally{Je=f,ce.p=c,X.T=o}}s.current=r,nn=2}}function rT(){if(nn===2){nn=0;var s=hr,r=jo,o=(r.flags&8772)!==0;if((r.subtreeFlags&8772)!==0||o){o=X.T,X.T=null;var c=ce.p;ce.p=2;var f=Je;Je|=4;try{L0(s,r.alternate,r)}finally{Je=f,ce.p=c,X.T=o}}nn=3}}function aT(){if(nn===4||nn===3){nn=0,th();var s=hr,r=jo,o=zo,c=K0;(r.subtreeFlags&10256)!==0||(r.flags&10256)!==0?nn=5:(nn=0,jo=hr=null,oT(s,s.pendingLanes));var f=s.pendingLanes;if(f===0&&(ur=null),so(o),r=r.stateNode,Ze&&typeof Ze.onCommitFiberRoot=="function")try{Ze.onCommitFiberRoot(vt,r,void 0,(r.current.flags&128)===128)}catch{}if(c!==null){r=X.T,f=ce.p,ce.p=2,X.T=null;try{for(var g=s.onRecoverableError,b=0;b<c.length;b++){var S=c[b];g(S.value,{componentStack:S.stack})}}finally{X.T=r,ce.p=f}}(zo&3)!==0&&ad(),Fi(s),f=s.pendingLanes,(o&4194090)!==0&&(f&42)!==0?s===$p?Rc++:(Rc=0,$p=s):Rc=0,Cc(0)}}function oT(s,r){(s.pooledCacheLanes&=r)===0&&(r=s.pooledCache,r!=null&&(s.pooledCache=null,ac(r)))}function ad(s){return sT(),rT(),aT(),lT()}function lT(){if(nn!==5)return!1;var s=hr,r=Hp;Hp=0;var o=so(zo),c=X.T,f=ce.p;try{ce.p=32>o?32:o,X.T=null,o=Gp,Gp=null;var g=hr,b=zo;if(nn=0,jo=hr=null,zo=0,(Je&6)!==0)throw Error(i(331));var S=Je;if(Je|=4,G0(g.current),B0(g,g.current,b,o),Je=S,Cc(0,!1),Ze&&typeof Ze.onPostCommitFiberRoot=="function")try{Ze.onPostCommitFiberRoot(vt,g)}catch{}return!0}finally{ce.p=f,X.T=c,oT(s,r)}}function cT(s,r,o){r=Xn(o,r),r=Sp(s.stateNode,r,2),s=tr(s,r,2),s!==null&&(es(s,2),Fi(s))}function lt(s,r,o){if(s.tag===3)cT(s,s,o);else for(;r!==null;){if(r.tag===3){cT(r,s,o);break}else if(r.tag===1){var c=r.stateNode;if(typeof r.type.getDerivedStateFromError=="function"||typeof c.componentDidCatch=="function"&&(ur===null||!ur.has(c))){s=Xn(o,s),o=f0(2),c=tr(r,o,2),c!==null&&(m0(o,c,r,s),es(c,2),Fi(c));break}}r=r.return}}function Wp(s,r,o){var c=s.pingCache;if(c===null){c=s.pingCache=new u1;var f=new Set;c.set(r,f)}else f=c.get(r),f===void 0&&(f=new Set,c.set(r,f));f.has(o)||(zp=!0,f.add(o),s=p1.bind(null,s,r,o),r.then(s,s))}function p1(s,r,o){var c=s.pingCache;c!==null&&c.delete(r),s.pingedLanes|=s.suspendedLanes&o,s.warmLanes&=~o,ut===s&&(qe&o)===o&&(Tt===4||Tt===3&&(qe&62914560)===qe&&300>Gn()-qp?(Je&2)===0&&Fo(s,0):Fp|=o,Uo===qe&&(Uo=0)),Fi(s)}function uT(s,r){r===0&&(r=Ll()),s=wo(s,r),s!==null&&(es(s,r),Fi(s))}function g1(s){var r=s.memoizedState,o=0;r!==null&&(o=r.retryLane),uT(s,o)}function _1(s,r){var o=0;switch(s.tag){case 13:var c=s.stateNode,f=s.memoizedState;f!==null&&(o=f.retryLane);break;case 19:c=s.stateNode;break;case 22:c=s.stateNode._retryCache;break;default:throw Error(i(314))}c!==null&&c.delete(r),uT(s,o)}function y1(s,r){return Qr(s,r)}var od=null,qo=null,Xp=!1,ld=!1,Zp=!1,Ia=0;function Fi(s){s!==qo&&s.next===null&&(qo===null?od=qo=s:qo=qo.next=s),ld=!0,Xp||(Xp=!0,E1())}function Cc(s,r){if(!Zp&&ld){Zp=!0;do for(var o=!1,c=od;c!==null;){if(s!==0){var f=c.pendingLanes;if(f===0)var g=0;else{var b=c.suspendedLanes,S=c.pingedLanes;g=(1<<31-ln(42|s)+1)-1,g&=f&~(b&~S),g=g&201326741?g&201326741|1:g?g|2:0}g!==0&&(o=!0,mT(c,g))}else g=qe,g=io(c,c===ut?g:0,c.cancelPendingCommit!==null||c.timeoutHandle!==-1),(g&3)===0||ea(c,g)||(o=!0,mT(c,g));c=c.next}while(o);Zp=!1}}function v1(){hT()}function hT(){ld=Xp=!1;var s=0;Ia!==0&&(x1()&&(s=Ia),Ia=0);for(var r=Gn(),o=null,c=od;c!==null;){var f=c.next,g=dT(c,r);g===0?(c.next=null,o===null?od=f:o.next=f,f===null&&(qo=o)):(o=c,(s!==0||(g&3)!==0)&&(ld=!0)),c=f}Cc(s)}function dT(s,r){for(var o=s.suspendedLanes,c=s.pingedLanes,f=s.expirationTimes,g=s.pendingLanes&-62914561;0<g;){var b=31-ln(g),S=1<<b,k=f[b];k===-1?((S&o)===0||(S&c)!==0)&&(f[b]=Ml(S,r)):k<=r&&(s.expiredLanes|=S),g&=~S}if(r=ut,o=qe,o=io(s,s===r?o:0,s.cancelPendingCommit!==null||s.timeoutHandle!==-1),c=s.callbackNode,o===0||s===r&&(et===2||et===9)||s.cancelPendingCommit!==null)return c!==null&&c!==null&&Yr(c),s.callbackNode=null,s.callbackPriority=0;if((o&3)===0||ea(s,o)){if(r=o&-o,r===s.callbackPriority)return r;switch(c!==null&&Yr(c),so(o)){case 2:case 8:o=to;break;case 32:o=Wr;break;case 268435456:o=no;break;default:o=Wr}return c=fT.bind(null,s),o=Qr(o,c),s.callbackPriority=r,s.callbackNode=o,r}return c!==null&&c!==null&&Yr(c),s.callbackPriority=2,s.callbackNode=null,2}function fT(s,r){if(nn!==0&&nn!==5)return s.callbackNode=null,s.callbackPriority=0,null;var o=s.callbackNode;if(ad()&&s.callbackNode!==o)return null;var c=qe;return c=io(s,s===ut?c:0,s.cancelPendingCommit!==null||s.timeoutHandle!==-1),c===0?null:(Y0(s,c,r),dT(s,Gn()),s.callbackNode!=null&&s.callbackNode===o?fT.bind(null,s):null)}function mT(s,r){if(ad())return null;Y0(s,r,!0)}function E1(){N1(function(){(Je&6)!==0?Qr(Dl,v1):hT()})}function Jp(){return Ia===0&&(Ia=Pl()),Ia}function pT(s){return s==null||typeof s=="symbol"||typeof s=="boolean"?null:typeof s=="function"?s:uo(""+s)}function gT(s,r){var o=r.ownerDocument.createElement("input");return o.name=r.name,o.value=r.value,s.id&&o.setAttribute("form",s.id),r.parentNode.insertBefore(o,r),s=new FormData(s),o.parentNode.removeChild(o),s}function T1(s,r,o,c,f){if(r==="submit"&&o&&o.stateNode===f){var g=pT((f[Ct]||null).action),b=c.submitter;b&&(r=(r=b[Ct]||null)?pT(r.formAction):b.getAttribute("formAction"),r!==null&&(g=r,b=null));var S=new ho("action","action",null,c,f);s.push({event:S,listeners:[{instance:null,listener:function(){if(c.defaultPrevented){if(Ia!==0){var k=b?gT(f,b):new FormData(f);vp(o,{pending:!0,data:k,method:f.method,action:g},null,k)}}else typeof g=="function"&&(S.preventDefault(),k=b?gT(f,b):new FormData(f),vp(o,{pending:!0,data:k,method:f.method,action:g},g,k))},currentTarget:f}]})}}for(var eg=0;eg<Um.length;eg++){var tg=Um[eg],b1=tg.toLowerCase(),w1=tg[0].toUpperCase()+tg.slice(1);hi(b1,"on"+w1)}hi(Yv,"onAnimationEnd"),hi(Wv,"onAnimationIteration"),hi(Xv,"onAnimationStart"),hi("dblclick","onDoubleClick"),hi("focusin","onFocus"),hi("focusout","onBlur"),hi(zI,"onTransitionRun"),hi(FI,"onTransitionStart"),hi(BI,"onTransitionCancel"),hi(Zv,"onTransitionEnd"),ns("onMouseEnter",["mouseout","mouseover"]),ns("onMouseLeave",["mouseout","mouseover"]),ns("onPointerEnter",["pointerout","pointerover"]),ns("onPointerLeave",["pointerout","pointerover"]),ci("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),ci("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),ci("onBeforeInput",["compositionend","keypress","textInput","paste"]),ci("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),ci("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),ci("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var xc="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),S1=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(xc));function _T(s,r){r=(r&4)!==0;for(var o=0;o<s.length;o++){var c=s[o],f=c.event;c=c.listeners;e:{var g=void 0;if(r)for(var b=c.length-1;0<=b;b--){var S=c[b],k=S.instance,G=S.currentTarget;if(S=S.listener,k!==g&&f.isPropagationStopped())break e;g=S,f.currentTarget=G;try{g(f)}catch(Z){Yh(Z)}f.currentTarget=null,g=k}else for(b=0;b<c.length;b++){if(S=c[b],k=S.instance,G=S.currentTarget,S=S.listener,k!==g&&f.isPropagationStopped())break e;g=S,f.currentTarget=G;try{g(f)}catch(Z){Yh(Z)}f.currentTarget=null,g=k}}}}function Ve(s,r){var o=r[jl];o===void 0&&(o=r[jl]=new Set);var c=s+"__bubble";o.has(c)||(yT(r,s,2,!1),o.add(c))}function ng(s,r,o){var c=0;r&&(c|=4),yT(o,s,c,r)}var cd="_reactListening"+Math.random().toString(36).slice(2);function ig(s){if(!s[cd]){s[cd]=!0,zl.forEach(function(o){o!=="selectionchange"&&(S1.has(o)||ng(o,!1,s),ng(o,!0,s))});var r=s.nodeType===9?s:s.ownerDocument;r===null||r[cd]||(r[cd]=!0,ng("selectionchange",!1,r))}}function yT(s,r,o,c){switch(BT(r)){case 2:var f=X1;break;case 8:f=Z1;break;default:f=_g}o=f.bind(null,r,o,s),f=void 0,!Yn||r!=="touchstart"&&r!=="touchmove"&&r!=="wheel"||(f=!0),c?f!==void 0?s.addEventListener(r,o,{capture:!0,passive:f}):s.addEventListener(r,o,!0):f!==void 0?s.addEventListener(r,o,{passive:f}):s.addEventListener(r,o,!1)}function sg(s,r,o,c,f){var g=c;if((r&1)===0&&(r&2)===0&&c!==null)e:for(;;){if(c===null)return;var b=c.tag;if(b===3||b===4){var S=c.stateNode.containerInfo;if(S===f)break;if(b===4)for(b=c.return;b!==null;){var k=b.tag;if((k===3||k===4)&&b.stateNode.containerInfo===f)return;b=b.return}for(;S!==null;){if(b=ts(S),b===null)return;if(k=b.tag,k===5||k===6||k===26||k===27){c=g=b;continue e}S=S.parentNode}}c=c.return}hh(function(){var G=g,Z=Qn(o),te=[];e:{var $=Jv.get(s);if($!==void 0){var K=ho,be=s;switch(s){case"keypress":if(Di(o)===0)break e;case"keydown":case"keyup":K=yo;break;case"focusin":be="focus",K=po;break;case"focusout":be="blur",K=po;break;case"beforeblur":case"afterblur":K=po;break;case"click":if(o.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":K=Wn;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":K=Nm;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":K=vh;break;case Yv:case Wv:case Xv:K=go;break;case Zv:K=Th;break;case"scroll":case"scrollend":K=dh;break;case"wheel":K=vo;break;case"copy":case"cut":case"paste":K=_o;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":K=Zl;break;case"toggle":case"beforetoggle":K=wh}var ve=(r&4)!==0,rt=!ve&&(s==="scroll"||s==="scrollend"),F=ve?$!==null?$+"Capture":null:$;ve=[];for(var U=G,H;U!==null;){var J=U;if(H=J.stateNode,J=J.tag,J!==5&&J!==26&&J!==27||H===null||F===null||(J=la(U,F),J!=null&&ve.push(Ic(U,J,H))),rt)break;U=U.return}0<ve.length&&($=new K($,be,null,o,Z),te.push({event:$,listeners:ve}))}}if((r&7)===0){e:{if($=s==="mouseover"||s==="pointerover",K=s==="mouseout"||s==="pointerout",$&&o!==rs&&(be=o.relatedTarget||o.fromElement)&&(ts(be)||be[$n]))break e;if((K||$)&&($=Z.window===Z?Z:($=Z.ownerDocument)?$.defaultView||$.parentWindow:window,K?(be=o.relatedTarget||o.toElement,K=G,be=be?ts(be):null,be!==null&&(rt=l(be),ve=be.tag,be!==rt||ve!==5&&ve!==27&&ve!==6)&&(be=null)):(K=null,be=G),K!==be)){if(ve=Wn,J="onMouseLeave",F="onMouseEnter",U="mouse",(s==="pointerout"||s==="pointerover")&&(ve=Zl,J="onPointerLeave",F="onPointerEnter",U="pointer"),rt=K==null?$:xi(K),H=be==null?$:xi(be),$=new ve(J,U+"leave",K,o,Z),$.target=rt,$.relatedTarget=H,J=null,ts(Z)===G&&(ve=new ve(F,U+"enter",be,o,Z),ve.target=H,ve.relatedTarget=rt,J=ve),rt=J,K&&be)t:{for(ve=K,F=be,U=0,H=ve;H;H=Ho(H))U++;for(H=0,J=F;J;J=Ho(J))H++;for(;0<U-H;)ve=Ho(ve),U--;for(;0<H-U;)F=Ho(F),H--;for(;U--;){if(ve===F||F!==null&&ve===F.alternate)break t;ve=Ho(ve),F=Ho(F)}ve=null}else ve=null;K!==null&&vT(te,$,K,ve,!1),be!==null&&rt!==null&&vT(te,rt,be,ve,!0)}}e:{if($=G?xi(G):window,K=$.nodeName&&$.nodeName.toLowerCase(),K==="select"||K==="input"&&$.type==="file")var me=Uv;else if(Vt($))if(jv)me=VI;else{me=PI;var De=MI}else K=$.nodeName,!K||K.toLowerCase()!=="input"||$.type!=="checkbox"&&$.type!=="radio"?G&&Gl(G.elementType)&&(me=Uv):me=LI;if(me&&(me=me(s,G))){us(te,me,o,Z);break e}De&&De(s,$,G),s==="focusout"&&G&&$.type==="number"&&G.memoizedProps.value!=null&&Ws($,"number",$.value)}switch(De=G?xi(G):window,s){case"focusin":(Vt(De)||De.contentEditable==="true")&&(Eo=De,Pm=G,tc=null);break;case"focusout":tc=Pm=Eo=null;break;case"mousedown":Lm=!0;break;case"contextmenu":case"mouseup":case"dragend":Lm=!1,Kv(te,o,Z);break;case"selectionchange":if(jI)break;case"keydown":case"keyup":Kv(te,o,Z)}var pe;if(Pi)e:{switch(s){case"compositionstart":var Ee="onCompositionStart";break e;case"compositionend":Ee="onCompositionEnd";break e;case"compositionupdate":Ee="onCompositionUpdate";break e}Ee=void 0}else Fe?Q(s,o)&&(Ee="onCompositionEnd"):s==="keydown"&&o.keyCode===229&&(Ee="onCompositionStart");Ee&&(E&&o.locale!=="ko"&&(Fe||Ee!=="onCompositionStart"?Ee==="onCompositionEnd"&&Fe&&(pe=Kl()):(ki=Z,Xs="value"in ki?ki.value:ki.textContent,Fe=!0)),De=ud(G,Ee),0<De.length&&(Ee=new Wl(Ee,s,null,o,Z),te.push({event:Ee,listeners:De}),pe?Ee.data=pe:(pe=le(o),pe!==null&&(Ee.data=pe)))),(pe=_?Lt(s,o):Be(s,o))&&(Ee=ud(G,"onBeforeInput"),0<Ee.length&&(De=new Wl("onBeforeInput","beforeinput",null,o,Z),te.push({event:De,listeners:Ee}),De.data=pe)),T1(te,s,G,o,Z)}_T(te,r)})}function Ic(s,r,o){return{instance:s,listener:r,currentTarget:o}}function ud(s,r){for(var o=r+"Capture",c=[];s!==null;){var f=s,g=f.stateNode;if(f=f.tag,f!==5&&f!==26&&f!==27||g===null||(f=la(s,o),f!=null&&c.unshift(Ic(s,f,g)),f=la(s,r),f!=null&&c.push(Ic(s,f,g))),s.tag===3)return c;s=s.return}return[]}function Ho(s){if(s===null)return null;do s=s.return;while(s&&s.tag!==5&&s.tag!==27);return s||null}function vT(s,r,o,c,f){for(var g=r._reactName,b=[];o!==null&&o!==c;){var S=o,k=S.alternate,G=S.stateNode;if(S=S.tag,k!==null&&k===c)break;S!==5&&S!==26&&S!==27||G===null||(k=G,f?(G=la(o,g),G!=null&&b.unshift(Ic(o,G,k))):f||(G=la(o,g),G!=null&&b.push(Ic(o,G,k)))),o=o.return}b.length!==0&&s.push({event:r,listeners:b})}var A1=/\r\n?/g,R1=/\u0000|\uFFFD/g;function ET(s){return(typeof s=="string"?s:""+s).replace(A1,`
`).replace(R1,"")}function TT(s,r){return r=ET(r),ET(s)===r}function hd(){}function st(s,r,o,c,f,g){switch(o){case"children":typeof c=="string"?r==="body"||r==="textarea"&&c===""||Kn(s,c):(typeof c=="number"||typeof c=="bigint")&&r!=="body"&&Kn(s,""+c);break;case"className":Ii(s,"class",c);break;case"tabIndex":Ii(s,"tabindex",c);break;case"dir":case"role":case"viewBox":case"width":case"height":Ii(s,o,c);break;case"style":Hl(s,c,g);break;case"data":if(r!=="object"){Ii(s,"data",c);break}case"src":case"href":if(c===""&&(r!=="a"||o!=="href")){s.removeAttribute(o);break}if(c==null||typeof c=="function"||typeof c=="symbol"||typeof c=="boolean"){s.removeAttribute(o);break}c=uo(""+c),s.setAttribute(o,c);break;case"action":case"formAction":if(typeof c=="function"){s.setAttribute(o,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof g=="function"&&(o==="formAction"?(r!=="input"&&st(s,r,"name",f.name,f,null),st(s,r,"formEncType",f.formEncType,f,null),st(s,r,"formMethod",f.formMethod,f,null),st(s,r,"formTarget",f.formTarget,f,null)):(st(s,r,"encType",f.encType,f,null),st(s,r,"method",f.method,f,null),st(s,r,"target",f.target,f,null)));if(c==null||typeof c=="symbol"||typeof c=="boolean"){s.removeAttribute(o);break}c=uo(""+c),s.setAttribute(o,c);break;case"onClick":c!=null&&(s.onclick=hd);break;case"onScroll":c!=null&&Ve("scroll",s);break;case"onScrollEnd":c!=null&&Ve("scrollend",s);break;case"dangerouslySetInnerHTML":if(c!=null){if(typeof c!="object"||!("__html"in c))throw Error(i(61));if(o=c.__html,o!=null){if(f.children!=null)throw Error(i(60));s.innerHTML=o}}break;case"multiple":s.multiple=c&&typeof c!="function"&&typeof c!="symbol";break;case"muted":s.muted=c&&typeof c!="function"&&typeof c!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(c==null||typeof c=="function"||typeof c=="boolean"||typeof c=="symbol"){s.removeAttribute("xlink:href");break}o=uo(""+c),s.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",o);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":c!=null&&typeof c!="function"&&typeof c!="symbol"?s.setAttribute(o,""+c):s.removeAttribute(o);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":c&&typeof c!="function"&&typeof c!="symbol"?s.setAttribute(o,""):s.removeAttribute(o);break;case"capture":case"download":c===!0?s.setAttribute(o,""):c!==!1&&c!=null&&typeof c!="function"&&typeof c!="symbol"?s.setAttribute(o,c):s.removeAttribute(o);break;case"cols":case"rows":case"size":case"span":c!=null&&typeof c!="function"&&typeof c!="symbol"&&!isNaN(c)&&1<=c?s.setAttribute(o,c):s.removeAttribute(o);break;case"rowSpan":case"start":c==null||typeof c=="function"||typeof c=="symbol"||isNaN(c)?s.removeAttribute(o):s.setAttribute(o,c);break;case"popover":Ve("beforetoggle",s),Ve("toggle",s),Ys(s,"popover",c);break;case"xlinkActuate":Jt(s,"http://www.w3.org/1999/xlink","xlink:actuate",c);break;case"xlinkArcrole":Jt(s,"http://www.w3.org/1999/xlink","xlink:arcrole",c);break;case"xlinkRole":Jt(s,"http://www.w3.org/1999/xlink","xlink:role",c);break;case"xlinkShow":Jt(s,"http://www.w3.org/1999/xlink","xlink:show",c);break;case"xlinkTitle":Jt(s,"http://www.w3.org/1999/xlink","xlink:title",c);break;case"xlinkType":Jt(s,"http://www.w3.org/1999/xlink","xlink:type",c);break;case"xmlBase":Jt(s,"http://www.w3.org/XML/1998/namespace","xml:base",c);break;case"xmlLang":Jt(s,"http://www.w3.org/XML/1998/namespace","xml:lang",c);break;case"xmlSpace":Jt(s,"http://www.w3.org/XML/1998/namespace","xml:space",c);break;case"is":Ys(s,"is",c);break;case"innerText":case"textContent":break;default:(!(2<o.length)||o[0]!=="o"&&o[0]!=="O"||o[1]!=="n"&&o[1]!=="N")&&(o=xm.get(o)||o,Ys(s,o,c))}}function rg(s,r,o,c,f,g){switch(o){case"style":Hl(s,c,g);break;case"dangerouslySetInnerHTML":if(c!=null){if(typeof c!="object"||!("__html"in c))throw Error(i(61));if(o=c.__html,o!=null){if(f.children!=null)throw Error(i(60));s.innerHTML=o}}break;case"children":typeof c=="string"?Kn(s,c):(typeof c=="number"||typeof c=="bigint")&&Kn(s,""+c);break;case"onScroll":c!=null&&Ve("scroll",s);break;case"onScrollEnd":c!=null&&Ve("scrollend",s);break;case"onClick":c!=null&&(s.onclick=hd);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!ro.hasOwnProperty(o))e:{if(o[0]==="o"&&o[1]==="n"&&(f=o.endsWith("Capture"),r=o.slice(2,f?o.length-7:void 0),g=s[Ct]||null,g=g!=null?g[o]:null,typeof g=="function"&&s.removeEventListener(r,g,f),typeof c=="function")){typeof g!="function"&&g!==null&&(o in s?s[o]=null:s.hasAttribute(o)&&s.removeAttribute(o)),s.addEventListener(r,c,f);break e}o in s?s[o]=c:c===!0?s.setAttribute(o,""):Ys(s,o,c)}}}function sn(s,r,o){switch(r){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ve("error",s),Ve("load",s);var c=!1,f=!1,g;for(g in o)if(o.hasOwnProperty(g)){var b=o[g];if(b!=null)switch(g){case"src":c=!0;break;case"srcSet":f=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(i(137,r));default:st(s,r,g,b,o,null)}}f&&st(s,r,"srcSet",o.srcSet,o,null),c&&st(s,r,"src",o.src,o,null);return;case"input":Ve("invalid",s);var S=g=b=f=null,k=null,G=null;for(c in o)if(o.hasOwnProperty(c)){var Z=o[c];if(Z!=null)switch(c){case"name":f=Z;break;case"type":b=Z;break;case"checked":k=Z;break;case"defaultChecked":G=Z;break;case"value":g=Z;break;case"defaultValue":S=Z;break;case"children":case"dangerouslySetInnerHTML":if(Z!=null)throw Error(i(137,r));break;default:st(s,r,c,Z,o,null)}}ra(s,g,S,k,G,b,f,!1),co(s);return;case"select":Ve("invalid",s),c=b=g=null;for(f in o)if(o.hasOwnProperty(f)&&(S=o[f],S!=null))switch(f){case"value":g=S;break;case"defaultValue":b=S;break;case"multiple":c=S;default:st(s,r,f,S,o,null)}r=g,o=b,s.multiple=!!c,r!=null?ss(s,!!c,r,!1):o!=null&&ss(s,!!c,o,!0);return;case"textarea":Ve("invalid",s),g=f=c=null;for(b in o)if(o.hasOwnProperty(b)&&(S=o[b],S!=null))switch(b){case"value":c=S;break;case"defaultValue":f=S;break;case"children":g=S;break;case"dangerouslySetInnerHTML":if(S!=null)throw Error(i(91));break;default:st(s,r,b,S,o,null)}aa(s,c,f,g),co(s);return;case"option":for(k in o)if(o.hasOwnProperty(k)&&(c=o[k],c!=null))switch(k){case"selected":s.selected=c&&typeof c!="function"&&typeof c!="symbol";break;default:st(s,r,k,c,o,null)}return;case"dialog":Ve("beforetoggle",s),Ve("toggle",s),Ve("cancel",s),Ve("close",s);break;case"iframe":case"object":Ve("load",s);break;case"video":case"audio":for(c=0;c<xc.length;c++)Ve(xc[c],s);break;case"image":Ve("error",s),Ve("load",s);break;case"details":Ve("toggle",s);break;case"embed":case"source":case"link":Ve("error",s),Ve("load",s);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(G in o)if(o.hasOwnProperty(G)&&(c=o[G],c!=null))switch(G){case"children":case"dangerouslySetInnerHTML":throw Error(i(137,r));default:st(s,r,G,c,o,null)}return;default:if(Gl(r)){for(Z in o)o.hasOwnProperty(Z)&&(c=o[Z],c!==void 0&&rg(s,r,Z,c,o,void 0));return}}for(S in o)o.hasOwnProperty(S)&&(c=o[S],c!=null&&st(s,r,S,c,o,null))}function C1(s,r,o,c){switch(r){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var f=null,g=null,b=null,S=null,k=null,G=null,Z=null;for(K in o){var te=o[K];if(o.hasOwnProperty(K)&&te!=null)switch(K){case"checked":break;case"value":break;case"defaultValue":k=te;default:c.hasOwnProperty(K)||st(s,r,K,null,c,te)}}for(var $ in c){var K=c[$];if(te=o[$],c.hasOwnProperty($)&&(K!=null||te!=null))switch($){case"type":g=K;break;case"name":f=K;break;case"checked":G=K;break;case"defaultChecked":Z=K;break;case"value":b=K;break;case"defaultValue":S=K;break;case"children":case"dangerouslySetInnerHTML":if(K!=null)throw Error(i(137,r));break;default:K!==te&&st(s,r,$,K,c,te)}}Mn(s,b,S,k,G,Z,g,f);return;case"select":K=b=S=$=null;for(g in o)if(k=o[g],o.hasOwnProperty(g)&&k!=null)switch(g){case"value":break;case"multiple":K=k;default:c.hasOwnProperty(g)||st(s,r,g,null,c,k)}for(f in c)if(g=c[f],k=o[f],c.hasOwnProperty(f)&&(g!=null||k!=null))switch(f){case"value":$=g;break;case"defaultValue":S=g;break;case"multiple":b=g;default:g!==k&&st(s,r,f,g,c,k)}r=S,o=b,c=K,$!=null?ss(s,!!o,$,!1):!!c!=!!o&&(r!=null?ss(s,!!o,r,!0):ss(s,!!o,o?[]:"",!1));return;case"textarea":K=$=null;for(S in o)if(f=o[S],o.hasOwnProperty(S)&&f!=null&&!c.hasOwnProperty(S))switch(S){case"value":break;case"children":break;default:st(s,r,S,null,c,f)}for(b in c)if(f=c[b],g=o[b],c.hasOwnProperty(b)&&(f!=null||g!=null))switch(b){case"value":$=f;break;case"defaultValue":K=f;break;case"children":break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(i(91));break;default:f!==g&&st(s,r,b,f,c,g)}nt(s,$,K);return;case"option":for(var be in o)if($=o[be],o.hasOwnProperty(be)&&$!=null&&!c.hasOwnProperty(be))switch(be){case"selected":s.selected=!1;break;default:st(s,r,be,null,c,$)}for(k in c)if($=c[k],K=o[k],c.hasOwnProperty(k)&&$!==K&&($!=null||K!=null))switch(k){case"selected":s.selected=$&&typeof $!="function"&&typeof $!="symbol";break;default:st(s,r,k,$,c,K)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ve in o)$=o[ve],o.hasOwnProperty(ve)&&$!=null&&!c.hasOwnProperty(ve)&&st(s,r,ve,null,c,$);for(G in c)if($=c[G],K=o[G],c.hasOwnProperty(G)&&$!==K&&($!=null||K!=null))switch(G){case"children":case"dangerouslySetInnerHTML":if($!=null)throw Error(i(137,r));break;default:st(s,r,G,$,c,K)}return;default:if(Gl(r)){for(var rt in o)$=o[rt],o.hasOwnProperty(rt)&&$!==void 0&&!c.hasOwnProperty(rt)&&rg(s,r,rt,void 0,c,$);for(Z in c)$=c[Z],K=o[Z],!c.hasOwnProperty(Z)||$===K||$===void 0&&K===void 0||rg(s,r,Z,$,c,K);return}}for(var F in o)$=o[F],o.hasOwnProperty(F)&&$!=null&&!c.hasOwnProperty(F)&&st(s,r,F,null,c,$);for(te in c)$=c[te],K=o[te],!c.hasOwnProperty(te)||$===K||$==null&&K==null||st(s,r,te,$,c,K)}var ag=null,og=null;function dd(s){return s.nodeType===9?s:s.ownerDocument}function bT(s){switch(s){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function wT(s,r){if(s===0)switch(r){case"svg":return 1;case"math":return 2;default:return 0}return s===1&&r==="foreignObject"?0:s}function lg(s,r){return s==="textarea"||s==="noscript"||typeof r.children=="string"||typeof r.children=="number"||typeof r.children=="bigint"||typeof r.dangerouslySetInnerHTML=="object"&&r.dangerouslySetInnerHTML!==null&&r.dangerouslySetInnerHTML.__html!=null}var cg=null;function x1(){var s=window.event;return s&&s.type==="popstate"?s===cg?!1:(cg=s,!0):(cg=null,!1)}var ST=typeof setTimeout=="function"?setTimeout:void 0,I1=typeof clearTimeout=="function"?clearTimeout:void 0,AT=typeof Promise=="function"?Promise:void 0,N1=typeof queueMicrotask=="function"?queueMicrotask:typeof AT<"u"?function(s){return AT.resolve(null).then(s).catch(k1)}:ST;function k1(s){setTimeout(function(){throw s})}function fr(s){return s==="head"}function RT(s,r){var o=r,c=0,f=0;do{var g=o.nextSibling;if(s.removeChild(o),g&&g.nodeType===8)if(o=g.data,o==="/$"){if(0<c&&8>c){o=c;var b=s.ownerDocument;if(o&1&&Nc(b.documentElement),o&2&&Nc(b.body),o&4)for(o=b.head,Nc(o),b=o.firstChild;b;){var S=b.nextSibling,k=b.nodeName;b[ta]||k==="SCRIPT"||k==="STYLE"||k==="LINK"&&b.rel.toLowerCase()==="stylesheet"||o.removeChild(b),b=S}}if(f===0){s.removeChild(g),Uc(r);return}f--}else o==="$"||o==="$?"||o==="$!"?f++:c=o.charCodeAt(0)-48;else c=0;o=g}while(o);Uc(r)}function ug(s){var r=s.firstChild;for(r&&r.nodeType===10&&(r=r.nextSibling);r;){var o=r;switch(r=r.nextSibling,o.nodeName){case"HTML":case"HEAD":case"BODY":ug(o),Qs(o);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(o.rel.toLowerCase()==="stylesheet")continue}s.removeChild(o)}}function D1(s,r,o,c){for(;s.nodeType===1;){var f=o;if(s.nodeName.toLowerCase()!==r.toLowerCase()){if(!c&&(s.nodeName!=="INPUT"||s.type!=="hidden"))break}else if(c){if(!s[ta])switch(r){case"meta":if(!s.hasAttribute("itemprop"))break;return s;case"link":if(g=s.getAttribute("rel"),g==="stylesheet"&&s.hasAttribute("data-precedence"))break;if(g!==f.rel||s.getAttribute("href")!==(f.href==null||f.href===""?null:f.href)||s.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin)||s.getAttribute("title")!==(f.title==null?null:f.title))break;return s;case"style":if(s.hasAttribute("data-precedence"))break;return s;case"script":if(g=s.getAttribute("src"),(g!==(f.src==null?null:f.src)||s.getAttribute("type")!==(f.type==null?null:f.type)||s.getAttribute("crossorigin")!==(f.crossOrigin==null?null:f.crossOrigin))&&g&&s.hasAttribute("async")&&!s.hasAttribute("itemprop"))break;return s;default:return s}}else if(r==="input"&&s.type==="hidden"){var g=f.name==null?null:""+f.name;if(f.type==="hidden"&&s.getAttribute("name")===g)return s}else return s;if(s=fi(s.nextSibling),s===null)break}return null}function O1(s,r,o){if(r==="")return null;for(;s.nodeType!==3;)if((s.nodeType!==1||s.nodeName!=="INPUT"||s.type!=="hidden")&&!o||(s=fi(s.nextSibling),s===null))return null;return s}function hg(s){return s.data==="$!"||s.data==="$?"&&s.ownerDocument.readyState==="complete"}function M1(s,r){var o=s.ownerDocument;if(s.data!=="$?"||o.readyState==="complete")r();else{var c=function(){r(),o.removeEventListener("DOMContentLoaded",c)};o.addEventListener("DOMContentLoaded",c),s._reactRetry=c}}function fi(s){for(;s!=null;s=s.nextSibling){var r=s.nodeType;if(r===1||r===3)break;if(r===8){if(r=s.data,r==="$"||r==="$!"||r==="$?"||r==="F!"||r==="F")break;if(r==="/$")return null}}return s}var dg=null;function CT(s){s=s.previousSibling;for(var r=0;s;){if(s.nodeType===8){var o=s.data;if(o==="$"||o==="$!"||o==="$?"){if(r===0)return s;r--}else o==="/$"&&r++}s=s.previousSibling}return null}function xT(s,r,o){switch(r=dd(o),s){case"html":if(s=r.documentElement,!s)throw Error(i(452));return s;case"head":if(s=r.head,!s)throw Error(i(453));return s;case"body":if(s=r.body,!s)throw Error(i(454));return s;default:throw Error(i(451))}}function Nc(s){for(var r=s.attributes;r.length;)s.removeAttributeNode(r[0]);Qs(s)}var ii=new Map,IT=new Set;function fd(s){return typeof s.getRootNode=="function"?s.getRootNode():s.nodeType===9?s:s.ownerDocument}var ws=ce.d;ce.d={f:P1,r:L1,D:V1,C:U1,L:j1,m:z1,X:B1,S:F1,M:q1};function P1(){var s=ws.f(),r=sd();return s||r}function L1(s){var r=Ci(s);r!==null&&r.tag===5&&r.type==="form"?YE(r):ws.r(s)}var Go=typeof document>"u"?null:document;function NT(s,r,o){var c=Go;if(c&&typeof r=="string"&&r){var f=xt(r);f='link[rel="'+s+'"][href="'+f+'"]',typeof o=="string"&&(f+='[crossorigin="'+o+'"]'),IT.has(f)||(IT.add(f),s={rel:s,crossOrigin:o,href:r},c.querySelector(f)===null&&(r=c.createElement("link"),sn(r,"link",s),bt(r),c.head.appendChild(r)))}}function V1(s){ws.D(s),NT("dns-prefetch",s,null)}function U1(s,r){ws.C(s,r),NT("preconnect",s,r)}function j1(s,r,o){ws.L(s,r,o);var c=Go;if(c&&s&&r){var f='link[rel="preload"][as="'+xt(r)+'"]';r==="image"&&o&&o.imageSrcSet?(f+='[imagesrcset="'+xt(o.imageSrcSet)+'"]',typeof o.imageSizes=="string"&&(f+='[imagesizes="'+xt(o.imageSizes)+'"]')):f+='[href="'+xt(s)+'"]';var g=f;switch(r){case"style":g=$o(s);break;case"script":g=Ko(s)}ii.has(g)||(s=y({rel:"preload",href:r==="image"&&o&&o.imageSrcSet?void 0:s,as:r},o),ii.set(g,s),c.querySelector(f)!==null||r==="style"&&c.querySelector(kc(g))||r==="script"&&c.querySelector(Dc(g))||(r=c.createElement("link"),sn(r,"link",s),bt(r),c.head.appendChild(r)))}}function z1(s,r){ws.m(s,r);var o=Go;if(o&&s){var c=r&&typeof r.as=="string"?r.as:"script",f='link[rel="modulepreload"][as="'+xt(c)+'"][href="'+xt(s)+'"]',g=f;switch(c){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":g=Ko(s)}if(!ii.has(g)&&(s=y({rel:"modulepreload",href:s},r),ii.set(g,s),o.querySelector(f)===null)){switch(c){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(o.querySelector(Dc(g)))return}c=o.createElement("link"),sn(c,"link",s),bt(c),o.head.appendChild(c)}}}function F1(s,r,o){ws.S(s,r,o);var c=Go;if(c&&s){var f=_n(c).hoistableStyles,g=$o(s);r=r||"default";var b=f.get(g);if(!b){var S={loading:0,preload:null};if(b=c.querySelector(kc(g)))S.loading=5;else{s=y({rel:"stylesheet",href:s,"data-precedence":r},o),(o=ii.get(g))&&fg(s,o);var k=b=c.createElement("link");bt(k),sn(k,"link",s),k._p=new Promise(function(G,Z){k.onload=G,k.onerror=Z}),k.addEventListener("load",function(){S.loading|=1}),k.addEventListener("error",function(){S.loading|=2}),S.loading|=4,md(b,r,c)}b={type:"stylesheet",instance:b,count:1,state:S},f.set(g,b)}}}function B1(s,r){ws.X(s,r);var o=Go;if(o&&s){var c=_n(o).hoistableScripts,f=Ko(s),g=c.get(f);g||(g=o.querySelector(Dc(f)),g||(s=y({src:s,async:!0},r),(r=ii.get(f))&&mg(s,r),g=o.createElement("script"),bt(g),sn(g,"link",s),o.head.appendChild(g)),g={type:"script",instance:g,count:1,state:null},c.set(f,g))}}function q1(s,r){ws.M(s,r);var o=Go;if(o&&s){var c=_n(o).hoistableScripts,f=Ko(s),g=c.get(f);g||(g=o.querySelector(Dc(f)),g||(s=y({src:s,async:!0,type:"module"},r),(r=ii.get(f))&&mg(s,r),g=o.createElement("script"),bt(g),sn(g,"link",s),o.head.appendChild(g)),g={type:"script",instance:g,count:1,state:null},c.set(f,g))}}function kT(s,r,o,c){var f=(f=Ae.current)?fd(f):null;if(!f)throw Error(i(446));switch(s){case"meta":case"title":return null;case"style":return typeof o.precedence=="string"&&typeof o.href=="string"?(r=$o(o.href),o=_n(f).hoistableStyles,c=o.get(r),c||(c={type:"style",instance:null,count:0,state:null},o.set(r,c)),c):{type:"void",instance:null,count:0,state:null};case"link":if(o.rel==="stylesheet"&&typeof o.href=="string"&&typeof o.precedence=="string"){s=$o(o.href);var g=_n(f).hoistableStyles,b=g.get(s);if(b||(f=f.ownerDocument||f,b={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},g.set(s,b),(g=f.querySelector(kc(s)))&&!g._p&&(b.instance=g,b.state.loading=5),ii.has(s)||(o={rel:"preload",as:"style",href:o.href,crossOrigin:o.crossOrigin,integrity:o.integrity,media:o.media,hrefLang:o.hrefLang,referrerPolicy:o.referrerPolicy},ii.set(s,o),g||H1(f,s,o,b.state))),r&&c===null)throw Error(i(528,""));return b}if(r&&c!==null)throw Error(i(529,""));return null;case"script":return r=o.async,o=o.src,typeof o=="string"&&r&&typeof r!="function"&&typeof r!="symbol"?(r=Ko(o),o=_n(f).hoistableScripts,c=o.get(r),c||(c={type:"script",instance:null,count:0,state:null},o.set(r,c)),c):{type:"void",instance:null,count:0,state:null};default:throw Error(i(444,s))}}function $o(s){return'href="'+xt(s)+'"'}function kc(s){return'link[rel="stylesheet"]['+s+"]"}function DT(s){return y({},s,{"data-precedence":s.precedence,precedence:null})}function H1(s,r,o,c){s.querySelector('link[rel="preload"][as="style"]['+r+"]")?c.loading=1:(r=s.createElement("link"),c.preload=r,r.addEventListener("load",function(){return c.loading|=1}),r.addEventListener("error",function(){return c.loading|=2}),sn(r,"link",o),bt(r),s.head.appendChild(r))}function Ko(s){return'[src="'+xt(s)+'"]'}function Dc(s){return"script[async]"+s}function OT(s,r,o){if(r.count++,r.instance===null)switch(r.type){case"style":var c=s.querySelector('style[data-href~="'+xt(o.href)+'"]');if(c)return r.instance=c,bt(c),c;var f=y({},o,{"data-href":o.href,"data-precedence":o.precedence,href:null,precedence:null});return c=(s.ownerDocument||s).createElement("style"),bt(c),sn(c,"style",f),md(c,o.precedence,s),r.instance=c;case"stylesheet":f=$o(o.href);var g=s.querySelector(kc(f));if(g)return r.state.loading|=4,r.instance=g,bt(g),g;c=DT(o),(f=ii.get(f))&&fg(c,f),g=(s.ownerDocument||s).createElement("link"),bt(g);var b=g;return b._p=new Promise(function(S,k){b.onload=S,b.onerror=k}),sn(g,"link",c),r.state.loading|=4,md(g,o.precedence,s),r.instance=g;case"script":return g=Ko(o.src),(f=s.querySelector(Dc(g)))?(r.instance=f,bt(f),f):(c=o,(f=ii.get(g))&&(c=y({},o),mg(c,f)),s=s.ownerDocument||s,f=s.createElement("script"),bt(f),sn(f,"link",c),s.head.appendChild(f),r.instance=f);case"void":return null;default:throw Error(i(443,r.type))}else r.type==="stylesheet"&&(r.state.loading&4)===0&&(c=r.instance,r.state.loading|=4,md(c,o.precedence,s));return r.instance}function md(s,r,o){for(var c=o.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),f=c.length?c[c.length-1]:null,g=f,b=0;b<c.length;b++){var S=c[b];if(S.dataset.precedence===r)g=S;else if(g!==f)break}g?g.parentNode.insertBefore(s,g.nextSibling):(r=o.nodeType===9?o.head:o,r.insertBefore(s,r.firstChild))}function fg(s,r){s.crossOrigin==null&&(s.crossOrigin=r.crossOrigin),s.referrerPolicy==null&&(s.referrerPolicy=r.referrerPolicy),s.title==null&&(s.title=r.title)}function mg(s,r){s.crossOrigin==null&&(s.crossOrigin=r.crossOrigin),s.referrerPolicy==null&&(s.referrerPolicy=r.referrerPolicy),s.integrity==null&&(s.integrity=r.integrity)}var pd=null;function MT(s,r,o){if(pd===null){var c=new Map,f=pd=new Map;f.set(o,c)}else f=pd,c=f.get(o),c||(c=new Map,f.set(o,c));if(c.has(s))return c;for(c.set(s,null),o=o.getElementsByTagName(s),f=0;f<o.length;f++){var g=o[f];if(!(g[ta]||g[Pt]||s==="link"&&g.getAttribute("rel")==="stylesheet")&&g.namespaceURI!=="http://www.w3.org/2000/svg"){var b=g.getAttribute(r)||"";b=s+b;var S=c.get(b);S?S.push(g):c.set(b,[g])}}return c}function PT(s,r,o){s=s.ownerDocument||s,s.head.insertBefore(o,r==="title"?s.querySelector("head > title"):null)}function G1(s,r,o){if(o===1||r.itemProp!=null)return!1;switch(s){case"meta":case"title":return!0;case"style":if(typeof r.precedence!="string"||typeof r.href!="string"||r.href==="")break;return!0;case"link":if(typeof r.rel!="string"||typeof r.href!="string"||r.href===""||r.onLoad||r.onError)break;switch(r.rel){case"stylesheet":return s=r.disabled,typeof r.precedence=="string"&&s==null;default:return!0}case"script":if(r.async&&typeof r.async!="function"&&typeof r.async!="symbol"&&!r.onLoad&&!r.onError&&r.src&&typeof r.src=="string")return!0}return!1}function LT(s){return!(s.type==="stylesheet"&&(s.state.loading&3)===0)}var Oc=null;function $1(){}function K1(s,r,o){if(Oc===null)throw Error(i(475));var c=Oc;if(r.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(r.state.loading&4)===0){if(r.instance===null){var f=$o(o.href),g=s.querySelector(kc(f));if(g){s=g._p,s!==null&&typeof s=="object"&&typeof s.then=="function"&&(c.count++,c=gd.bind(c),s.then(c,c)),r.state.loading|=4,r.instance=g,bt(g);return}g=s.ownerDocument||s,o=DT(o),(f=ii.get(f))&&fg(o,f),g=g.createElement("link"),bt(g);var b=g;b._p=new Promise(function(S,k){b.onload=S,b.onerror=k}),sn(g,"link",o),r.instance=g}c.stylesheets===null&&(c.stylesheets=new Map),c.stylesheets.set(r,s),(s=r.state.preload)&&(r.state.loading&3)===0&&(c.count++,r=gd.bind(c),s.addEventListener("load",r),s.addEventListener("error",r))}}function Q1(){if(Oc===null)throw Error(i(475));var s=Oc;return s.stylesheets&&s.count===0&&pg(s,s.stylesheets),0<s.count?function(r){var o=setTimeout(function(){if(s.stylesheets&&pg(s,s.stylesheets),s.unsuspend){var c=s.unsuspend;s.unsuspend=null,c()}},6e4);return s.unsuspend=r,function(){s.unsuspend=null,clearTimeout(o)}}:null}function gd(){if(this.count--,this.count===0){if(this.stylesheets)pg(this,this.stylesheets);else if(this.unsuspend){var s=this.unsuspend;this.unsuspend=null,s()}}}var _d=null;function pg(s,r){s.stylesheets=null,s.unsuspend!==null&&(s.count++,_d=new Map,r.forEach(Y1,s),_d=null,gd.call(s))}function Y1(s,r){if(!(r.state.loading&4)){var o=_d.get(s);if(o)var c=o.get(null);else{o=new Map,_d.set(s,o);for(var f=s.querySelectorAll("link[data-precedence],style[data-precedence]"),g=0;g<f.length;g++){var b=f[g];(b.nodeName==="LINK"||b.getAttribute("media")!=="not all")&&(o.set(b.dataset.precedence,b),c=b)}c&&o.set(null,c)}f=r.instance,b=f.getAttribute("data-precedence"),g=o.get(b)||c,g===c&&o.set(null,f),o.set(b,f),this.count++,c=gd.bind(this),f.addEventListener("load",c),f.addEventListener("error",c),g?g.parentNode.insertBefore(f,g.nextSibling):(s=s.nodeType===9?s.head:s,s.insertBefore(f,s.firstChild)),r.state.loading|=4}}var Mc={$$typeof:Y,Provider:null,Consumer:null,_currentValue:ge,_currentValue2:ge,_threadCount:0};function W1(s,r,o,c,f,g,b,S){this.tag=1,this.containerInfo=s,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Ji(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ji(0),this.hiddenUpdates=Ji(null),this.identifierPrefix=c,this.onUncaughtError=f,this.onCaughtError=g,this.onRecoverableError=b,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=S,this.incompleteTransitions=new Map}function VT(s,r,o,c,f,g,b,S,k,G,Z,te){return s=new W1(s,r,o,b,S,k,G,te),r=1,g===!0&&(r|=24),g=Ln(3,null,null,r),s.current=g,g.stateNode=s,r=Wm(),r.refCount++,s.pooledCache=r,r.refCount++,g.memoizedState={element:c,isDehydrated:o,cache:r},ep(g),s}function UT(s){return s?(s=So,s):So}function jT(s,r,o,c,f,g){f=UT(f),c.context===null?c.context=f:c.pendingContext=f,c=er(r),c.payload={element:o},g=g===void 0?null:g,g!==null&&(c.callback=g),o=tr(s,c,r),o!==null&&(Fn(o,s,r),uc(o,s,r))}function zT(s,r){if(s=s.memoizedState,s!==null&&s.dehydrated!==null){var o=s.retryLane;s.retryLane=o!==0&&o<r?o:r}}function gg(s,r){zT(s,r),(s=s.alternate)&&zT(s,r)}function FT(s){if(s.tag===13){var r=wo(s,67108864);r!==null&&Fn(r,s,67108864),gg(s,67108864)}}var yd=!0;function X1(s,r,o,c){var f=X.T;X.T=null;var g=ce.p;try{ce.p=2,_g(s,r,o,c)}finally{ce.p=g,X.T=f}}function Z1(s,r,o,c){var f=X.T;X.T=null;var g=ce.p;try{ce.p=8,_g(s,r,o,c)}finally{ce.p=g,X.T=f}}function _g(s,r,o,c){if(yd){var f=yg(c);if(f===null)sg(s,r,c,vd,o),qT(s,c);else if(eN(f,s,r,o,c))c.stopPropagation();else if(qT(s,c),r&4&&-1<J1.indexOf(s)){for(;f!==null;){var g=Ci(f);if(g!==null)switch(g.tag){case 3:if(g=g.stateNode,g.current.memoizedState.isDehydrated){var b=li(g.pendingLanes);if(b!==0){var S=g;for(S.pendingLanes|=2,S.entangledLanes|=2;b;){var k=1<<31-ln(b);S.entanglements[1]|=k,b&=~k}Fi(g),(Je&6)===0&&(nd=Gn()+500,Cc(0))}}break;case 13:S=wo(g,2),S!==null&&Fn(S,g,2),sd(),gg(g,2)}if(g=yg(c),g===null&&sg(s,r,c,vd,o),g===f)break;f=g}f!==null&&c.stopPropagation()}else sg(s,r,c,null,o)}}function yg(s){return s=Qn(s),vg(s)}var vd=null;function vg(s){if(vd=null,s=ts(s),s!==null){var r=l(s);if(r===null)s=null;else{var o=r.tag;if(o===13){if(s=u(r),s!==null)return s;s=null}else if(o===3){if(r.stateNode.current.memoizedState.isDehydrated)return r.tag===3?r.stateNode.containerInfo:null;s=null}else r!==s&&(s=null)}}return vd=s,null}function BT(s){switch(s){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(bm()){case Dl:return 2;case to:return 8;case Wr:case wm:return 32;case no:return 268435456;default:return 32}default:return 32}}var Eg=!1,mr=null,pr=null,gr=null,Pc=new Map,Lc=new Map,_r=[],J1="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function qT(s,r){switch(s){case"focusin":case"focusout":mr=null;break;case"dragenter":case"dragleave":pr=null;break;case"mouseover":case"mouseout":gr=null;break;case"pointerover":case"pointerout":Pc.delete(r.pointerId);break;case"gotpointercapture":case"lostpointercapture":Lc.delete(r.pointerId)}}function Vc(s,r,o,c,f,g){return s===null||s.nativeEvent!==g?(s={blockedOn:r,domEventName:o,eventSystemFlags:c,nativeEvent:g,targetContainers:[f]},r!==null&&(r=Ci(r),r!==null&&FT(r)),s):(s.eventSystemFlags|=c,r=s.targetContainers,f!==null&&r.indexOf(f)===-1&&r.push(f),s)}function eN(s,r,o,c,f){switch(r){case"focusin":return mr=Vc(mr,s,r,o,c,f),!0;case"dragenter":return pr=Vc(pr,s,r,o,c,f),!0;case"mouseover":return gr=Vc(gr,s,r,o,c,f),!0;case"pointerover":var g=f.pointerId;return Pc.set(g,Vc(Pc.get(g)||null,s,r,o,c,f)),!0;case"gotpointercapture":return g=f.pointerId,Lc.set(g,Vc(Lc.get(g)||null,s,r,o,c,f)),!0}return!1}function HT(s){var r=ts(s.target);if(r!==null){var o=l(r);if(o!==null){if(r=o.tag,r===13){if(r=u(o),r!==null){s.blockedOn=r,sh(s.priority,function(){if(o.tag===13){var c=zn();c=Gs(c);var f=wo(o,c);f!==null&&Fn(f,o,c),gg(o,c)}});return}}else if(r===3&&o.stateNode.current.memoizedState.isDehydrated){s.blockedOn=o.tag===3?o.stateNode.containerInfo:null;return}}}s.blockedOn=null}function Ed(s){if(s.blockedOn!==null)return!1;for(var r=s.targetContainers;0<r.length;){var o=yg(s.nativeEvent);if(o===null){o=s.nativeEvent;var c=new o.constructor(o.type,o);rs=c,o.target.dispatchEvent(c),rs=null}else return r=Ci(o),r!==null&&FT(r),s.blockedOn=o,!1;r.shift()}return!0}function GT(s,r,o){Ed(s)&&o.delete(r)}function tN(){Eg=!1,mr!==null&&Ed(mr)&&(mr=null),pr!==null&&Ed(pr)&&(pr=null),gr!==null&&Ed(gr)&&(gr=null),Pc.forEach(GT),Lc.forEach(GT)}function Td(s,r){s.blockedOn===r&&(s.blockedOn=null,Eg||(Eg=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,tN)))}var bd=null;function $T(s){bd!==s&&(bd=s,n.unstable_scheduleCallback(n.unstable_NormalPriority,function(){bd===s&&(bd=null);for(var r=0;r<s.length;r+=3){var o=s[r],c=s[r+1],f=s[r+2];if(typeof c!="function"){if(vg(c||o)===null)continue;break}var g=Ci(o);g!==null&&(s.splice(r,3),r-=3,vp(g,{pending:!0,data:f,method:o.method,action:c},c,f))}}))}function Uc(s){function r(k){return Td(k,s)}mr!==null&&Td(mr,s),pr!==null&&Td(pr,s),gr!==null&&Td(gr,s),Pc.forEach(r),Lc.forEach(r);for(var o=0;o<_r.length;o++){var c=_r[o];c.blockedOn===s&&(c.blockedOn=null)}for(;0<_r.length&&(o=_r[0],o.blockedOn===null);)HT(o),o.blockedOn===null&&_r.shift();if(o=(s.ownerDocument||s).$$reactFormReplay,o!=null)for(c=0;c<o.length;c+=3){var f=o[c],g=o[c+1],b=f[Ct]||null;if(typeof g=="function")b||$T(o);else if(b){var S=null;if(g&&g.hasAttribute("formAction")){if(f=g,b=g[Ct]||null)S=b.formAction;else if(vg(f)!==null)continue}else S=b.action;typeof S=="function"?o[c+1]=S:(o.splice(c,3),c-=3),$T(o)}}}function Tg(s){this._internalRoot=s}wd.prototype.render=Tg.prototype.render=function(s){var r=this._internalRoot;if(r===null)throw Error(i(409));var o=r.current,c=zn();jT(o,c,s,r,null,null)},wd.prototype.unmount=Tg.prototype.unmount=function(){var s=this._internalRoot;if(s!==null){this._internalRoot=null;var r=s.containerInfo;jT(s.current,2,null,s,null,null),sd(),r[$n]=null}};function wd(s){this._internalRoot=s}wd.prototype.unstable_scheduleHydration=function(s){if(s){var r=$s();s={blockedOn:null,target:s,priority:r};for(var o=0;o<_r.length&&r!==0&&r<_r[o].priority;o++);_r.splice(o,0,s),o===0&&HT(s)}};var KT=e.version;if(KT!=="19.1.0")throw Error(i(527,KT,"19.1.0"));ce.findDOMNode=function(s){var r=s._reactInternals;if(r===void 0)throw typeof s.render=="function"?Error(i(188)):(s=Object.keys(s).join(","),Error(i(268,s)));return s=m(r),s=s!==null?p(s):null,s=s===null?null:s.stateNode,s};var nN={bundleType:0,version:"19.1.0",rendererPackageName:"react-dom",currentDispatcherRef:X,reconcilerVersion:"19.1.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Sd=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Sd.isDisabled&&Sd.supportsFiber)try{vt=Sd.inject(nN),Ze=Sd}catch{}}return zc.createRoot=function(s,r){if(!a(s))throw Error(i(299));var o=!1,c="",f=c0,g=u0,b=h0,S=null;return r!=null&&(r.unstable_strictMode===!0&&(o=!0),r.identifierPrefix!==void 0&&(c=r.identifierPrefix),r.onUncaughtError!==void 0&&(f=r.onUncaughtError),r.onCaughtError!==void 0&&(g=r.onCaughtError),r.onRecoverableError!==void 0&&(b=r.onRecoverableError),r.unstable_transitionCallbacks!==void 0&&(S=r.unstable_transitionCallbacks)),r=VT(s,1,!1,null,null,o,c,f,g,b,S,null),s[$n]=r.current,ig(s),new Tg(r)},zc.hydrateRoot=function(s,r,o){if(!a(s))throw Error(i(299));var c=!1,f="",g=c0,b=u0,S=h0,k=null,G=null;return o!=null&&(o.unstable_strictMode===!0&&(c=!0),o.identifierPrefix!==void 0&&(f=o.identifierPrefix),o.onUncaughtError!==void 0&&(g=o.onUncaughtError),o.onCaughtError!==void 0&&(b=o.onCaughtError),o.onRecoverableError!==void 0&&(S=o.onRecoverableError),o.unstable_transitionCallbacks!==void 0&&(k=o.unstable_transitionCallbacks),o.formState!==void 0&&(G=o.formState)),r=VT(s,1,!0,r,o??null,c,f,g,b,S,k,G),r.context=UT(null),o=r.current,c=zn(),c=Gs(c),f=er(c),f.callback=null,tr(o,f,c),o=c,r.current.lanes=o,es(r,o),Fi(r),s[$n]=r.current,ig(s),new wd(r)},zc.version="19.1.0",zc}var ib;function dN(){if(ib)return Sg.exports;ib=1;function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(e){console.error(e)}}return n(),Sg.exports=hN(),Sg.exports}var fN=dN(),Fc={},sb;function mN(){if(sb)return Fc;sb=1,Object.defineProperty(Fc,"__esModule",{value:!0}),Fc.parse=u,Fc.serialize=p;const n=/^[\u0021-\u003A\u003C\u003E-\u007E]+$/,e=/^[\u0021-\u003A\u003C-\u007E]*$/,t=/^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i,i=/^[\u0020-\u003A\u003D-\u007E]*$/,a=Object.prototype.toString,l=(()=>{const w=function(){};return w.prototype=Object.create(null),w})();function u(w,x){const I=new l,O=w.length;if(O<2)return I;const P=(x==null?void 0:x.decode)||y;let B=0;do{const ee=w.indexOf("=",B);if(ee===-1)break;const Y=w.indexOf(";",B),W=Y===-1?O:Y;if(ee>W){B=w.lastIndexOf(";",ee-1)+1;continue}const re=d(w,B,ee),he=m(w,ee,re),M=w.slice(re,he);if(I[M]===void 0){let A=d(w,ee+1,W),C=m(w,W,A);const N=P(w.slice(A,C));I[M]=N}B=W+1}while(B<O);return I}function d(w,x,I){do{const O=w.charCodeAt(x);if(O!==32&&O!==9)return x}while(++x<I);return I}function m(w,x,I){for(;x>I;){const O=w.charCodeAt(--x);if(O!==32&&O!==9)return x+1}return I}function p(w,x,I){const O=(I==null?void 0:I.encode)||encodeURIComponent;if(!n.test(w))throw new TypeError(`argument name is invalid: ${w}`);const P=O(x);if(!e.test(P))throw new TypeError(`argument val is invalid: ${x}`);let B=w+"="+P;if(!I)return B;if(I.maxAge!==void 0){if(!Number.isInteger(I.maxAge))throw new TypeError(`option maxAge is invalid: ${I.maxAge}`);B+="; Max-Age="+I.maxAge}if(I.domain){if(!t.test(I.domain))throw new TypeError(`option domain is invalid: ${I.domain}`);B+="; Domain="+I.domain}if(I.path){if(!i.test(I.path))throw new TypeError(`option path is invalid: ${I.path}`);B+="; Path="+I.path}if(I.expires){if(!T(I.expires)||!Number.isFinite(I.expires.valueOf()))throw new TypeError(`option expires is invalid: ${I.expires}`);B+="; Expires="+I.expires.toUTCString()}if(I.httpOnly&&(B+="; HttpOnly"),I.secure&&(B+="; Secure"),I.partitioned&&(B+="; Partitioned"),I.priority)switch(typeof I.priority=="string"?I.priority.toLowerCase():void 0){case"low":B+="; Priority=Low";break;case"medium":B+="; Priority=Medium";break;case"high":B+="; Priority=High";break;default:throw new TypeError(`option priority is invalid: ${I.priority}`)}if(I.sameSite)switch(typeof I.sameSite=="string"?I.sameSite.toLowerCase():I.sameSite){case!0:case"strict":B+="; SameSite=Strict";break;case"lax":B+="; SameSite=Lax";break;case"none":B+="; SameSite=None";break;default:throw new TypeError(`option sameSite is invalid: ${I.sameSite}`)}return B}function y(w){if(w.indexOf("%")===-1)return w;try{return decodeURIComponent(w)}catch{return w}}function T(w){return a.call(w)==="[object Date]"}return Fc}mN();/**
 * react-router v7.5.1
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */var rb="popstate";function pN(n={}){function e(i,a){let{pathname:l,search:u,hash:d}=i.location;return Jg("",{pathname:l,search:u,hash:d},a.state&&a.state.usr||null,a.state&&a.state.key||"default")}function t(i,a){return typeof a=="string"?a:du(a)}return _N(e,t,null,n)}function gt(n,e){if(n===!1||n===null||typeof n>"u")throw new Error(e)}function Ei(n,e){if(!n){typeof console<"u"&&console.warn(e);try{throw new Error(e)}catch{}}}function gN(){return Math.random().toString(36).substring(2,10)}function ab(n,e){return{usr:n.state,key:n.key,idx:e}}function Jg(n,e,t=null,i){return{pathname:typeof n=="string"?n:n.pathname,search:"",hash:"",...typeof e=="string"?_l(e):e,state:t,key:e&&e.key||i||gN()}}function du({pathname:n="/",search:e="",hash:t=""}){return e&&e!=="?"&&(n+=e.charAt(0)==="?"?e:"?"+e),t&&t!=="#"&&(n+=t.charAt(0)==="#"?t:"#"+t),n}function _l(n){let e={};if(n){let t=n.indexOf("#");t>=0&&(e.hash=n.substring(t),n=n.substring(0,t));let i=n.indexOf("?");i>=0&&(e.search=n.substring(i),n=n.substring(0,i)),n&&(e.pathname=n)}return e}function _N(n,e,t,i={}){let{window:a=document.defaultView,v5Compat:l=!1}=i,u=a.history,d="POP",m=null,p=y();p==null&&(p=0,u.replaceState({...u.state,idx:p},""));function y(){return(u.state||{idx:null}).idx}function T(){d="POP";let P=y(),B=P==null?null:P-p;p=P,m&&m({action:d,location:O.location,delta:B})}function w(P,B){d="PUSH";let ee=Jg(O.location,P,B);p=y()+1;let Y=ab(ee,p),W=O.createHref(ee);try{u.pushState(Y,"",W)}catch(re){if(re instanceof DOMException&&re.name==="DataCloneError")throw re;a.location.assign(W)}l&&m&&m({action:d,location:O.location,delta:1})}function x(P,B){d="REPLACE";let ee=Jg(O.location,P,B);p=y();let Y=ab(ee,p),W=O.createHref(ee);u.replaceState(Y,"",W),l&&m&&m({action:d,location:O.location,delta:0})}function I(P){let B=a.location.origin!=="null"?a.location.origin:a.location.href,ee=typeof P=="string"?P:du(P);return ee=ee.replace(/ $/,"%20"),gt(B,`No window.location.(origin|href) available to create URL for href: ${ee}`),new URL(ee,B)}let O={get action(){return d},get location(){return n(a,u)},listen(P){if(m)throw new Error("A history only accepts one active listener");return a.addEventListener(rb,T),m=P,()=>{a.removeEventListener(rb,T),m=null}},createHref(P){return e(a,P)},createURL:I,encodeLocation(P){let B=I(P);return{pathname:B.pathname,search:B.search,hash:B.hash}},push:w,replace:x,go(P){return u.go(P)}};return O}function jS(n,e,t="/"){return yN(n,e,t,!1)}function yN(n,e,t,i){let a=typeof e=="string"?_l(e):e,l=Ms(a.pathname||"/",t);if(l==null)return null;let u=zS(n);vN(u);let d=null;for(let m=0;d==null&&m<u.length;++m){let p=NN(l);d=xN(u[m],p,i)}return d}function zS(n,e=[],t=[],i=""){let a=(l,u,d)=>{let m={relativePath:d===void 0?l.path||"":d,caseSensitive:l.caseSensitive===!0,childrenIndex:u,route:l};m.relativePath.startsWith("/")&&(gt(m.relativePath.startsWith(i),`Absolute route path "${m.relativePath}" nested under path "${i}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),m.relativePath=m.relativePath.slice(i.length));let p=Ns([i,m.relativePath]),y=t.concat(m);l.children&&l.children.length>0&&(gt(l.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${p}".`),zS(l.children,e,y,p)),!(l.path==null&&!l.index)&&e.push({path:p,score:RN(p,l.index),routesMeta:y})};return n.forEach((l,u)=>{var d;if(l.path===""||!((d=l.path)!=null&&d.includes("?")))a(l,u);else for(let m of FS(l.path))a(l,u,m)}),e}function FS(n){let e=n.split("/");if(e.length===0)return[];let[t,...i]=e,a=t.endsWith("?"),l=t.replace(/\?$/,"");if(i.length===0)return a?[l,""]:[l];let u=FS(i.join("/")),d=[];return d.push(...u.map(m=>m===""?l:[l,m].join("/"))),a&&d.push(...u),d.map(m=>n.startsWith("/")&&m===""?"/":m)}function vN(n){n.sort((e,t)=>e.score!==t.score?t.score-e.score:CN(e.routesMeta.map(i=>i.childrenIndex),t.routesMeta.map(i=>i.childrenIndex)))}var EN=/^:[\w-]+$/,TN=3,bN=2,wN=1,SN=10,AN=-2,ob=n=>n==="*";function RN(n,e){let t=n.split("/"),i=t.length;return t.some(ob)&&(i+=AN),e&&(i+=bN),t.filter(a=>!ob(a)).reduce((a,l)=>a+(EN.test(l)?TN:l===""?wN:SN),i)}function CN(n,e){return n.length===e.length&&n.slice(0,-1).every((i,a)=>i===e[a])?n[n.length-1]-e[e.length-1]:0}function xN(n,e,t=!1){let{routesMeta:i}=n,a={},l="/",u=[];for(let d=0;d<i.length;++d){let m=i[d],p=d===i.length-1,y=l==="/"?e:e.slice(l.length)||"/",T=Zd({path:m.relativePath,caseSensitive:m.caseSensitive,end:p},y),w=m.route;if(!T&&p&&t&&!i[i.length-1].route.index&&(T=Zd({path:m.relativePath,caseSensitive:m.caseSensitive,end:!1},y)),!T)return null;Object.assign(a,T.params),u.push({params:a,pathname:Ns([l,T.pathname]),pathnameBase:MN(Ns([l,T.pathnameBase])),route:w}),T.pathnameBase!=="/"&&(l=Ns([l,T.pathnameBase]))}return u}function Zd(n,e){typeof n=="string"&&(n={path:n,caseSensitive:!1,end:!0});let[t,i]=IN(n.path,n.caseSensitive,n.end),a=e.match(t);if(!a)return null;let l=a[0],u=l.replace(/(.)\/+$/,"$1"),d=a.slice(1);return{params:i.reduce((p,{paramName:y,isOptional:T},w)=>{if(y==="*"){let I=d[w]||"";u=l.slice(0,l.length-I.length).replace(/(.)\/+$/,"$1")}const x=d[w];return T&&!x?p[y]=void 0:p[y]=(x||"").replace(/%2F/g,"/"),p},{}),pathname:l,pathnameBase:u,pattern:n}}function IN(n,e=!1,t=!0){Ei(n==="*"||!n.endsWith("*")||n.endsWith("/*"),`Route path "${n}" will be treated as if it were "${n.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${n.replace(/\*$/,"/*")}".`);let i=[],a="^"+n.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(u,d,m)=>(i.push({paramName:d,isOptional:m!=null}),m?"/?([^\\/]+)?":"/([^\\/]+)"));return n.endsWith("*")?(i.push({paramName:"*"}),a+=n==="*"||n==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):t?a+="\\/*$":n!==""&&n!=="/"&&(a+="(?:(?=\\/|$))"),[new RegExp(a,e?void 0:"i"),i]}function NN(n){try{return n.split("/").map(e=>decodeURIComponent(e).replace(/\//g,"%2F")).join("/")}catch(e){return Ei(!1,`The URL path "${n}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${e}).`),n}}function Ms(n,e){if(e==="/")return n;if(!n.toLowerCase().startsWith(e.toLowerCase()))return null;let t=e.endsWith("/")?e.length-1:e.length,i=n.charAt(t);return i&&i!=="/"?null:n.slice(t)||"/"}function kN(n,e="/"){let{pathname:t,search:i="",hash:a=""}=typeof n=="string"?_l(n):n;return{pathname:t?t.startsWith("/")?t:DN(t,e):e,search:PN(i),hash:LN(a)}}function DN(n,e){let t=e.replace(/\/+$/,"").split("/");return n.split("/").forEach(a=>{a===".."?t.length>1&&t.pop():a!=="."&&t.push(a)}),t.length>1?t.join("/"):"/"}function xg(n,e,t,i){return`Cannot include a '${n}' character in a manually specified \`to.${e}\` field [${JSON.stringify(i)}].  Please separate it out to the \`to.${t}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function ON(n){return n.filter((e,t)=>t===0||e.route.path&&e.route.path.length>0)}function $_(n){let e=ON(n);return e.map((t,i)=>i===e.length-1?t.pathname:t.pathnameBase)}function K_(n,e,t,i=!1){let a;typeof n=="string"?a=_l(n):(a={...n},gt(!a.pathname||!a.pathname.includes("?"),xg("?","pathname","search",a)),gt(!a.pathname||!a.pathname.includes("#"),xg("#","pathname","hash",a)),gt(!a.search||!a.search.includes("#"),xg("#","search","hash",a)));let l=n===""||a.pathname==="",u=l?"/":a.pathname,d;if(u==null)d=t;else{let T=e.length-1;if(!i&&u.startsWith("..")){let w=u.split("/");for(;w[0]==="..";)w.shift(),T-=1;a.pathname=w.join("/")}d=T>=0?e[T]:"/"}let m=kN(a,d),p=u&&u!=="/"&&u.endsWith("/"),y=(l||u===".")&&t.endsWith("/");return!m.pathname.endsWith("/")&&(p||y)&&(m.pathname+="/"),m}var Ns=n=>n.join("/").replace(/\/\/+/g,"/"),MN=n=>n.replace(/\/+$/,"").replace(/^\/*/,"/"),PN=n=>!n||n==="?"?"":n.startsWith("?")?n:"?"+n,LN=n=>!n||n==="#"?"":n.startsWith("#")?n:"#"+n;function VN(n){return n!=null&&typeof n.status=="number"&&typeof n.statusText=="string"&&typeof n.internal=="boolean"&&"data"in n}var BS=["POST","PUT","PATCH","DELETE"];new Set(BS);var UN=["GET",...BS];new Set(UN);var yl=j.createContext(null);yl.displayName="DataRouter";var zf=j.createContext(null);zf.displayName="DataRouterState";var qS=j.createContext({isTransitioning:!1});qS.displayName="ViewTransition";var jN=j.createContext(new Map);jN.displayName="Fetchers";var zN=j.createContext(null);zN.displayName="Await";var Si=j.createContext(null);Si.displayName="Navigation";var Mu=j.createContext(null);Mu.displayName="Location";var ai=j.createContext({outlet:null,matches:[],isDataRoute:!1});ai.displayName="Route";var Q_=j.createContext(null);Q_.displayName="RouteError";function FN(n,{relative:e}={}){gt(vl(),"useHref() may be used only in the context of a <Router> component.");let{basename:t,navigator:i}=j.useContext(Si),{hash:a,pathname:l,search:u}=Pu(n,{relative:e}),d=l;return t!=="/"&&(d=l==="/"?t:Ns([t,l])),i.createHref({pathname:d,search:u,hash:a})}function vl(){return j.useContext(Mu)!=null}function Yi(){return gt(vl(),"useLocation() may be used only in the context of a <Router> component."),j.useContext(Mu).location}var HS="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function GS(n){j.useContext(Si).static||j.useLayoutEffect(n)}function Bs(){let{isDataRoute:n}=j.useContext(ai);return n?n2():BN()}function BN(){gt(vl(),"useNavigate() may be used only in the context of a <Router> component.");let n=j.useContext(yl),{basename:e,navigator:t}=j.useContext(Si),{matches:i}=j.useContext(ai),{pathname:a}=Yi(),l=JSON.stringify($_(i)),u=j.useRef(!1);return GS(()=>{u.current=!0}),j.useCallback((m,p={})=>{if(Ei(u.current,HS),!u.current)return;if(typeof m=="number"){t.go(m);return}let y=K_(m,JSON.parse(l),a,p.relative==="path");n==null&&e!=="/"&&(y.pathname=y.pathname==="/"?e:Ns([e,y.pathname])),(p.replace?t.replace:t.push)(y,p.state,p)},[e,t,l,a,n])}var qN=j.createContext(null);function HN(n){let e=j.useContext(ai).outlet;return e&&j.createElement(qN.Provider,{value:n},e)}function $S(){let{matches:n}=j.useContext(ai),e=n[n.length-1];return e?e.params:{}}function Pu(n,{relative:e}={}){let{matches:t}=j.useContext(ai),{pathname:i}=Yi(),a=JSON.stringify($_(t));return j.useMemo(()=>K_(n,JSON.parse(a),i,e==="path"),[n,a,i,e])}function GN(n,e){return KS(n,e)}function KS(n,e,t,i){var ee;gt(vl(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:a,static:l}=j.useContext(Si),{matches:u}=j.useContext(ai),d=u[u.length-1],m=d?d.params:{},p=d?d.pathname:"/",y=d?d.pathnameBase:"/",T=d&&d.route;{let Y=T&&T.path||"";QS(p,!T||Y.endsWith("*")||Y.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${p}" (under <Route path="${Y}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${Y}"> to <Route path="${Y==="/"?"*":`${Y}/*`}">.`)}let w=Yi(),x;if(e){let Y=typeof e=="string"?_l(e):e;gt(y==="/"||((ee=Y.pathname)==null?void 0:ee.startsWith(y)),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${y}" but pathname "${Y.pathname}" was given in the \`location\` prop.`),x=Y}else x=w;let I=x.pathname||"/",O=I;if(y!=="/"){let Y=y.replace(/^\//,"").split("/");O="/"+I.replace(/^\//,"").split("/").slice(Y.length).join("/")}let P=!l&&t&&t.matches&&t.matches.length>0?t.matches:jS(n,{pathname:O});Ei(T||P!=null,`No routes matched location "${x.pathname}${x.search}${x.hash}" `),Ei(P==null||P[P.length-1].route.element!==void 0||P[P.length-1].route.Component!==void 0||P[P.length-1].route.lazy!==void 0,`Matched leaf route at location "${x.pathname}${x.search}${x.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let B=WN(P&&P.map(Y=>Object.assign({},Y,{params:Object.assign({},m,Y.params),pathname:Ns([y,a.encodeLocation?a.encodeLocation(Y.pathname).pathname:Y.pathname]),pathnameBase:Y.pathnameBase==="/"?y:Ns([y,a.encodeLocation?a.encodeLocation(Y.pathnameBase).pathname:Y.pathnameBase])})),u,t,i);return e&&B?j.createElement(Mu.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",...x},navigationType:"POP"}},B):B}function $N(){let n=t2(),e=VN(n)?`${n.status} ${n.statusText}`:n instanceof Error?n.message:JSON.stringify(n),t=n instanceof Error?n.stack:null,i="rgba(200,200,200, 0.5)",a={padding:"0.5rem",backgroundColor:i},l={padding:"2px 4px",backgroundColor:i},u=null;return console.error("Error handled by React Router default ErrorBoundary:",n),u=j.createElement(j.Fragment,null,j.createElement("p",null,"💿 Hey developer 👋"),j.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",j.createElement("code",{style:l},"ErrorBoundary")," or"," ",j.createElement("code",{style:l},"errorElement")," prop on your route.")),j.createElement(j.Fragment,null,j.createElement("h2",null,"Unexpected Application Error!"),j.createElement("h3",{style:{fontStyle:"italic"}},e),t?j.createElement("pre",{style:a},t):null,u)}var KN=j.createElement($N,null),QN=class extends j.Component{constructor(n){super(n),this.state={location:n.location,revalidation:n.revalidation,error:n.error}}static getDerivedStateFromError(n){return{error:n}}static getDerivedStateFromProps(n,e){return e.location!==n.location||e.revalidation!=="idle"&&n.revalidation==="idle"?{error:n.error,location:n.location,revalidation:n.revalidation}:{error:n.error!==void 0?n.error:e.error,location:e.location,revalidation:n.revalidation||e.revalidation}}componentDidCatch(n,e){console.error("React Router caught the following error during render",n,e)}render(){return this.state.error!==void 0?j.createElement(ai.Provider,{value:this.props.routeContext},j.createElement(Q_.Provider,{value:this.state.error,children:this.props.component})):this.props.children}};function YN({routeContext:n,match:e,children:t}){let i=j.useContext(yl);return i&&i.static&&i.staticContext&&(e.route.errorElement||e.route.ErrorBoundary)&&(i.staticContext._deepestRenderedBoundaryId=e.route.id),j.createElement(ai.Provider,{value:n},t)}function WN(n,e=[],t=null,i=null){if(n==null){if(!t)return null;if(t.errors)n=t.matches;else if(e.length===0&&!t.initialized&&t.matches.length>0)n=t.matches;else return null}let a=n,l=t==null?void 0:t.errors;if(l!=null){let m=a.findIndex(p=>p.route.id&&(l==null?void 0:l[p.route.id])!==void 0);gt(m>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(l).join(",")}`),a=a.slice(0,Math.min(a.length,m+1))}let u=!1,d=-1;if(t)for(let m=0;m<a.length;m++){let p=a[m];if((p.route.HydrateFallback||p.route.hydrateFallbackElement)&&(d=m),p.route.id){let{loaderData:y,errors:T}=t,w=p.route.loader&&!y.hasOwnProperty(p.route.id)&&(!T||T[p.route.id]===void 0);if(p.route.lazy||w){u=!0,d>=0?a=a.slice(0,d+1):a=[a[0]];break}}}return a.reduceRight((m,p,y)=>{let T,w=!1,x=null,I=null;t&&(T=l&&p.route.id?l[p.route.id]:void 0,x=p.route.errorElement||KN,u&&(d<0&&y===0?(QS("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),w=!0,I=null):d===y&&(w=!0,I=p.route.hydrateFallbackElement||null)));let O=e.concat(a.slice(0,y+1)),P=()=>{let B;return T?B=x:w?B=I:p.route.Component?B=j.createElement(p.route.Component,null):p.route.element?B=p.route.element:B=m,j.createElement(YN,{match:p,routeContext:{outlet:m,matches:O,isDataRoute:t!=null},children:B})};return t&&(p.route.ErrorBoundary||p.route.errorElement||y===0)?j.createElement(QN,{location:t.location,revalidation:t.revalidation,component:x,error:T,children:P(),routeContext:{outlet:null,matches:O,isDataRoute:!0}}):P()},null)}function Y_(n){return`${n} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function XN(n){let e=j.useContext(yl);return gt(e,Y_(n)),e}function ZN(n){let e=j.useContext(zf);return gt(e,Y_(n)),e}function JN(n){let e=j.useContext(ai);return gt(e,Y_(n)),e}function W_(n){let e=JN(n),t=e.matches[e.matches.length-1];return gt(t.route.id,`${n} can only be used on routes that contain a unique "id"`),t.route.id}function e2(){return W_("useRouteId")}function t2(){var i;let n=j.useContext(Q_),e=ZN("useRouteError"),t=W_("useRouteError");return n!==void 0?n:(i=e.errors)==null?void 0:i[t]}function n2(){let{router:n}=XN("useNavigate"),e=W_("useNavigate"),t=j.useRef(!1);return GS(()=>{t.current=!0}),j.useCallback(async(a,l={})=>{Ei(t.current,HS),t.current&&(typeof a=="number"?n.navigate(a):await n.navigate(a,{fromRouteId:e,...l}))},[n,e])}var lb={};function QS(n,e,t){!e&&!lb[n]&&(lb[n]=!0,Ei(!1,t))}j.memo(i2);function i2({routes:n,future:e,state:t}){return KS(n,void 0,t,e)}function s2({to:n,replace:e,state:t,relative:i}){gt(vl(),"<Navigate> may be used only in the context of a <Router> component.");let{static:a}=j.useContext(Si);Ei(!a,"<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");let{matches:l}=j.useContext(ai),{pathname:u}=Yi(),d=Bs(),m=K_(n,$_(l),u,i==="path"),p=JSON.stringify(m);return j.useEffect(()=>{d(JSON.parse(p),{replace:e,state:t,relative:i})},[d,p,i,e,t]),null}function r2(n){return HN(n.context)}function Er(n){gt(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function a2({basename:n="/",children:e=null,location:t,navigationType:i="POP",navigator:a,static:l=!1}){gt(!vl(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let u=n.replace(/^\/*/,"/"),d=j.useMemo(()=>({basename:u,navigator:a,static:l,future:{}}),[u,a,l]);typeof t=="string"&&(t=_l(t));let{pathname:m="/",search:p="",hash:y="",state:T=null,key:w="default"}=t,x=j.useMemo(()=>{let I=Ms(m,u);return I==null?null:{location:{pathname:I,search:p,hash:y,state:T,key:w},navigationType:i}},[u,m,p,y,T,w,i]);return Ei(x!=null,`<Router basename="${u}"> is not able to match the URL "${m}${p}${y}" because it does not start with the basename, so the <Router> won't render anything.`),x==null?null:j.createElement(Si.Provider,{value:d},j.createElement(Mu.Provider,{children:e,value:x}))}function o2({children:n,location:e}){return GN(e_(n),e)}function e_(n,e=[]){let t=[];return j.Children.forEach(n,(i,a)=>{if(!j.isValidElement(i))return;let l=[...e,a];if(i.type===j.Fragment){t.push.apply(t,e_(i.props.children,l));return}gt(i.type===Er,`[${typeof i.type=="string"?i.type:i.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),gt(!i.props.index||!i.props.children,"An index route cannot have child routes.");let u={id:i.props.id||l.join("-"),caseSensitive:i.props.caseSensitive,element:i.props.element,Component:i.props.Component,index:i.props.index,path:i.props.path,loader:i.props.loader,action:i.props.action,hydrateFallbackElement:i.props.hydrateFallbackElement,HydrateFallback:i.props.HydrateFallback,errorElement:i.props.errorElement,ErrorBoundary:i.props.ErrorBoundary,hasErrorBoundary:i.props.hasErrorBoundary===!0||i.props.ErrorBoundary!=null||i.props.errorElement!=null,shouldRevalidate:i.props.shouldRevalidate,handle:i.props.handle,lazy:i.props.lazy};i.props.children&&(u.children=e_(i.props.children,l)),t.push(u)}),t}var jd="get",zd="application/x-www-form-urlencoded";function Ff(n){return n!=null&&typeof n.tagName=="string"}function l2(n){return Ff(n)&&n.tagName.toLowerCase()==="button"}function c2(n){return Ff(n)&&n.tagName.toLowerCase()==="form"}function u2(n){return Ff(n)&&n.tagName.toLowerCase()==="input"}function h2(n){return!!(n.metaKey||n.altKey||n.ctrlKey||n.shiftKey)}function d2(n,e){return n.button===0&&(!e||e==="_self")&&!h2(n)}var Ad=null;function f2(){if(Ad===null)try{new FormData(document.createElement("form"),0),Ad=!1}catch{Ad=!0}return Ad}var m2=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function Ig(n){return n!=null&&!m2.has(n)?(Ei(!1,`"${n}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${zd}"`),null):n}function p2(n,e){let t,i,a,l,u;if(c2(n)){let d=n.getAttribute("action");i=d?Ms(d,e):null,t=n.getAttribute("method")||jd,a=Ig(n.getAttribute("enctype"))||zd,l=new FormData(n)}else if(l2(n)||u2(n)&&(n.type==="submit"||n.type==="image")){let d=n.form;if(d==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let m=n.getAttribute("formaction")||d.getAttribute("action");if(i=m?Ms(m,e):null,t=n.getAttribute("formmethod")||d.getAttribute("method")||jd,a=Ig(n.getAttribute("formenctype"))||Ig(d.getAttribute("enctype"))||zd,l=new FormData(d,n),!f2()){let{name:p,type:y,value:T}=n;if(y==="image"){let w=p?`${p}.`:"";l.append(`${w}x`,"0"),l.append(`${w}y`,"0")}else p&&l.append(p,T)}}else{if(Ff(n))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');t=jd,i=null,a=zd,u=n}return l&&a==="text/plain"&&(u=l,l=void 0),{action:i,method:t.toLowerCase(),encType:a,formData:l,body:u}}function X_(n,e){if(n===!1||n===null||typeof n>"u")throw new Error(e)}async function g2(n,e){if(n.id in e)return e[n.id];try{let t=await import(n.module);return e[n.id]=t,t}catch(t){return console.error(`Error loading route module \`${n.module}\`, reloading page...`),console.error(t),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function _2(n){return n==null?!1:n.href==null?n.rel==="preload"&&typeof n.imageSrcSet=="string"&&typeof n.imageSizes=="string":typeof n.rel=="string"&&typeof n.href=="string"}async function y2(n,e,t){let i=await Promise.all(n.map(async a=>{let l=e.routes[a.route.id];if(l){let u=await g2(l,t);return u.links?u.links():[]}return[]}));return b2(i.flat(1).filter(_2).filter(a=>a.rel==="stylesheet"||a.rel==="preload").map(a=>a.rel==="stylesheet"?{...a,rel:"prefetch",as:"style"}:{...a,rel:"prefetch"}))}function cb(n,e,t,i,a,l){let u=(m,p)=>t[p]?m.route.id!==t[p].route.id:!0,d=(m,p)=>{var y;return t[p].pathname!==m.pathname||((y=t[p].route.path)==null?void 0:y.endsWith("*"))&&t[p].params["*"]!==m.params["*"]};return l==="assets"?e.filter((m,p)=>u(m,p)||d(m,p)):l==="data"?e.filter((m,p)=>{var T;let y=i.routes[m.route.id];if(!y||!y.hasLoader)return!1;if(u(m,p)||d(m,p))return!0;if(m.route.shouldRevalidate){let w=m.route.shouldRevalidate({currentUrl:new URL(a.pathname+a.search+a.hash,window.origin),currentParams:((T=t[0])==null?void 0:T.params)||{},nextUrl:new URL(n,window.origin),nextParams:m.params,defaultShouldRevalidate:!0});if(typeof w=="boolean")return w}return!0}):[]}function v2(n,e,{includeHydrateFallback:t}={}){return E2(n.map(i=>{let a=e.routes[i.route.id];if(!a)return[];let l=[a.module];return a.clientActionModule&&(l=l.concat(a.clientActionModule)),a.clientLoaderModule&&(l=l.concat(a.clientLoaderModule)),t&&a.hydrateFallbackModule&&(l=l.concat(a.hydrateFallbackModule)),a.imports&&(l=l.concat(a.imports)),l}).flat(1))}function E2(n){return[...new Set(n)]}function T2(n){let e={},t=Object.keys(n).sort();for(let i of t)e[i]=n[i];return e}function b2(n,e){let t=new Set;return new Set(e),n.reduce((i,a)=>{let l=JSON.stringify(T2(a));return t.has(l)||(t.add(l),i.push({key:l,link:a})),i},[])}var w2=new Set([100,101,204,205]);function S2(n,e){let t=typeof n=="string"?new URL(n,typeof window>"u"?"server://singlefetch/":window.location.origin):n;return t.pathname==="/"?t.pathname="_root.data":e&&Ms(t.pathname,e)==="/"?t.pathname=`${e.replace(/\/$/,"")}/_root.data`:t.pathname=`${t.pathname.replace(/\/$/,"")}.data`,t}function YS(){let n=j.useContext(yl);return X_(n,"You must render this element inside a <DataRouterContext.Provider> element"),n}function A2(){let n=j.useContext(zf);return X_(n,"You must render this element inside a <DataRouterStateContext.Provider> element"),n}var Z_=j.createContext(void 0);Z_.displayName="FrameworkContext";function WS(){let n=j.useContext(Z_);return X_(n,"You must render this element inside a <HydratedRouter> element"),n}function R2(n,e){let t=j.useContext(Z_),[i,a]=j.useState(!1),[l,u]=j.useState(!1),{onFocus:d,onBlur:m,onMouseEnter:p,onMouseLeave:y,onTouchStart:T}=e,w=j.useRef(null);j.useEffect(()=>{if(n==="render"&&u(!0),n==="viewport"){let O=B=>{B.forEach(ee=>{u(ee.isIntersecting)})},P=new IntersectionObserver(O,{threshold:.5});return w.current&&P.observe(w.current),()=>{P.disconnect()}}},[n]),j.useEffect(()=>{if(i){let O=setTimeout(()=>{u(!0)},100);return()=>{clearTimeout(O)}}},[i]);let x=()=>{a(!0)},I=()=>{a(!1),u(!1)};return t?n!=="intent"?[l,w,{}]:[l,w,{onFocus:Bc(d,x),onBlur:Bc(m,I),onMouseEnter:Bc(p,x),onMouseLeave:Bc(y,I),onTouchStart:Bc(T,x)}]:[!1,w,{}]}function Bc(n,e){return t=>{n&&n(t),t.defaultPrevented||e(t)}}function C2({page:n,...e}){let{router:t}=YS(),i=j.useMemo(()=>jS(t.routes,n,t.basename),[t.routes,n,t.basename]);return i?j.createElement(I2,{page:n,matches:i,...e}):null}function x2(n){let{manifest:e,routeModules:t}=WS(),[i,a]=j.useState([]);return j.useEffect(()=>{let l=!1;return y2(n,e,t).then(u=>{l||a(u)}),()=>{l=!0}},[n,e,t]),i}function I2({page:n,matches:e,...t}){let i=Yi(),{manifest:a,routeModules:l}=WS(),{basename:u}=YS(),{loaderData:d,matches:m}=A2(),p=j.useMemo(()=>cb(n,e,m,a,i,"data"),[n,e,m,a,i]),y=j.useMemo(()=>cb(n,e,m,a,i,"assets"),[n,e,m,a,i]),T=j.useMemo(()=>{if(n===i.pathname+i.search+i.hash)return[];let I=new Set,O=!1;if(e.forEach(B=>{var Y;let ee=a.routes[B.route.id];!ee||!ee.hasLoader||(!p.some(W=>W.route.id===B.route.id)&&B.route.id in d&&((Y=l[B.route.id])!=null&&Y.shouldRevalidate)||ee.hasClientLoader?O=!0:I.add(B.route.id))}),I.size===0)return[];let P=S2(n,u);return O&&I.size>0&&P.searchParams.set("_routes",e.filter(B=>I.has(B.route.id)).map(B=>B.route.id).join(",")),[P.pathname+P.search]},[u,d,i,a,p,e,n,l]),w=j.useMemo(()=>v2(y,a),[y,a]),x=x2(y);return j.createElement(j.Fragment,null,T.map(I=>j.createElement("link",{key:I,rel:"prefetch",as:"fetch",href:I,...t})),w.map(I=>j.createElement("link",{key:I,rel:"modulepreload",href:I,...t})),x.map(({key:I,link:O})=>j.createElement("link",{key:I,...O})))}function N2(...n){return e=>{n.forEach(t=>{typeof t=="function"?t(e):t!=null&&(t.current=e)})}}var XS=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{XS&&(window.__reactRouterVersion="7.5.1")}catch{}function k2({basename:n,children:e,window:t}){let i=j.useRef();i.current==null&&(i.current=pN({window:t,v5Compat:!0}));let a=i.current,[l,u]=j.useState({action:a.action,location:a.location}),d=j.useCallback(m=>{j.startTransition(()=>u(m))},[u]);return j.useLayoutEffect(()=>a.listen(d),[a,d]),j.createElement(a2,{basename:n,children:e,location:l.location,navigationType:l.action,navigator:a})}var ZS=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,At=j.forwardRef(function({onClick:e,discover:t="render",prefetch:i="none",relative:a,reloadDocument:l,replace:u,state:d,target:m,to:p,preventScrollReset:y,viewTransition:T,...w},x){let{basename:I}=j.useContext(Si),O=typeof p=="string"&&ZS.test(p),P,B=!1;if(typeof p=="string"&&O&&(P=p,XS))try{let C=new URL(window.location.href),N=p.startsWith("//")?new URL(C.protocol+p):new URL(p),L=Ms(N.pathname,I);N.origin===C.origin&&L!=null?p=L+N.search+N.hash:B=!0}catch{Ei(!1,`<Link to="${p}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}let ee=FN(p,{relative:a}),[Y,W,re]=R2(i,w),he=P2(p,{replace:u,state:d,target:m,preventScrollReset:y,relative:a,viewTransition:T});function M(C){e&&e(C),C.defaultPrevented||he(C)}let A=j.createElement("a",{...w,...re,href:P||ee,onClick:B||l?e:M,ref:N2(x,W),target:m,"data-discover":!O&&t==="render"?"true":void 0});return Y&&!O?j.createElement(j.Fragment,null,A,j.createElement(C2,{page:ee})):A});At.displayName="Link";var D2=j.forwardRef(function({"aria-current":e="page",caseSensitive:t=!1,className:i="",end:a=!1,style:l,to:u,viewTransition:d,children:m,...p},y){let T=Pu(u,{relative:p.relative}),w=Yi(),x=j.useContext(zf),{navigator:I,basename:O}=j.useContext(Si),P=x!=null&&z2(T)&&d===!0,B=I.encodeLocation?I.encodeLocation(T).pathname:T.pathname,ee=w.pathname,Y=x&&x.navigation&&x.navigation.location?x.navigation.location.pathname:null;t||(ee=ee.toLowerCase(),Y=Y?Y.toLowerCase():null,B=B.toLowerCase()),Y&&O&&(Y=Ms(Y,O)||Y);const W=B!=="/"&&B.endsWith("/")?B.length-1:B.length;let re=ee===B||!a&&ee.startsWith(B)&&ee.charAt(W)==="/",he=Y!=null&&(Y===B||!a&&Y.startsWith(B)&&Y.charAt(B.length)==="/"),M={isActive:re,isPending:he,isTransitioning:P},A=re?e:void 0,C;typeof i=="function"?C=i(M):C=[i,re?"active":null,he?"pending":null,P?"transitioning":null].filter(Boolean).join(" ");let N=typeof l=="function"?l(M):l;return j.createElement(At,{...p,"aria-current":A,className:C,ref:y,style:N,to:u,viewTransition:d},typeof m=="function"?m(M):m)});D2.displayName="NavLink";var O2=j.forwardRef(({discover:n="render",fetcherKey:e,navigate:t,reloadDocument:i,replace:a,state:l,method:u=jd,action:d,onSubmit:m,relative:p,preventScrollReset:y,viewTransition:T,...w},x)=>{let I=U2(),O=j2(d,{relative:p}),P=u.toLowerCase()==="get"?"get":"post",B=typeof d=="string"&&ZS.test(d),ee=Y=>{if(m&&m(Y),Y.defaultPrevented)return;Y.preventDefault();let W=Y.nativeEvent.submitter,re=(W==null?void 0:W.getAttribute("formmethod"))||u;I(W||Y.currentTarget,{fetcherKey:e,method:re,navigate:t,replace:a,state:l,relative:p,preventScrollReset:y,viewTransition:T})};return j.createElement("form",{ref:x,method:P,action:O,onSubmit:i?m:ee,...w,"data-discover":!B&&n==="render"?"true":void 0})});O2.displayName="Form";function M2(n){return`${n} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function JS(n){let e=j.useContext(yl);return gt(e,M2(n)),e}function P2(n,{target:e,replace:t,state:i,preventScrollReset:a,relative:l,viewTransition:u}={}){let d=Bs(),m=Yi(),p=Pu(n,{relative:l});return j.useCallback(y=>{if(d2(y,e)){y.preventDefault();let T=t!==void 0?t:du(m)===du(p);d(n,{replace:T,state:i,preventScrollReset:a,relative:l,viewTransition:u})}},[m,d,p,t,i,e,n,a,l,u])}var L2=0,V2=()=>`__${String(++L2)}__`;function U2(){let{router:n}=JS("useSubmit"),{basename:e}=j.useContext(Si),t=e2();return j.useCallback(async(i,a={})=>{let{action:l,method:u,encType:d,formData:m,body:p}=p2(i,e);if(a.navigate===!1){let y=a.fetcherKey||V2();await n.fetch(y,t,a.action||l,{preventScrollReset:a.preventScrollReset,formData:m,body:p,formMethod:a.method||u,formEncType:a.encType||d,flushSync:a.flushSync})}else await n.navigate(a.action||l,{preventScrollReset:a.preventScrollReset,formData:m,body:p,formMethod:a.method||u,formEncType:a.encType||d,replace:a.replace,state:a.state,fromRouteId:t,flushSync:a.flushSync,viewTransition:a.viewTransition})},[n,e,t])}function j2(n,{relative:e}={}){let{basename:t}=j.useContext(Si),i=j.useContext(ai);gt(i,"useFormAction must be used inside a RouteContext");let[a]=i.matches.slice(-1),l={...Pu(n||".",{relative:e})},u=Yi();if(n==null){l.search=u.search;let d=new URLSearchParams(l.search),m=d.getAll("index");if(m.some(y=>y==="")){d.delete("index"),m.filter(T=>T).forEach(T=>d.append("index",T));let y=d.toString();l.search=y?`?${y}`:""}}return(!n||n===".")&&a.route.index&&(l.search=l.search?l.search.replace(/^\?/,"?index&"):"?index"),t!=="/"&&(l.pathname=l.pathname==="/"?t:Ns([t,l.pathname])),du(l)}function z2(n,e={}){let t=j.useContext(qS);gt(t!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:i}=JS("useViewTransitionState"),a=Pu(n,{relative:e.relative});if(!t.isTransitioning)return!1;let l=Ms(t.currentLocation.pathname,i)||t.currentLocation.pathname,u=Ms(t.nextLocation.pathname,i)||t.nextLocation.pathname;return Zd(a.pathname,u)!=null||Zd(a.pathname,l)!=null}new TextEncoder;[...w2];/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F2=n=>n.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),B2=n=>n.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,i)=>i?i.toUpperCase():t.toLowerCase()),ub=n=>{const e=B2(n);return e.charAt(0).toUpperCase()+e.slice(1)},eA=(...n)=>n.filter((e,t,i)=>!!e&&e.trim()!==""&&i.indexOf(e)===t).join(" ").trim(),q2=n=>{for(const e in n)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var H2={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G2=j.forwardRef(({color:n="currentColor",size:e=24,strokeWidth:t=2,absoluteStrokeWidth:i,className:a="",children:l,iconNode:u,...d},m)=>j.createElement("svg",{ref:m,...H2,width:e,height:e,stroke:n,strokeWidth:i?Number(t)*24/Number(e):t,className:eA("lucide",a),...!l&&!q2(d)&&{"aria-hidden":"true"},...d},[...u.map(([p,y])=>j.createElement(p,y)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $e=(n,e)=>{const t=j.forwardRef(({className:i,...a},l)=>j.createElement(G2,{ref:l,iconNode:e,className:eA(`lucide-${F2(ub(n))}`,`lucide-${n}`,i),...a}));return t.displayName=ub(n),t};/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $2=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],K2=$e("arrow-left",$2);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q2=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],Y2=$e("chevron-down",Q2);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W2=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],X2=$e("chevron-up",W2);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z2=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]],Jd=$e("clock",Z2);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J2=[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"12",cy:"5",r:"1",key:"gxeob9"}],["circle",{cx:"12",cy:"19",r:"1",key:"lyex9k"}]],ek=$e("ellipsis-vertical",J2);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tk=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],nk=$e("eye",tk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ik=[["path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",key:"1jg4f8"}]],sk=$e("facebook",ik);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rk=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"1d0kgt"}]],ak=$e("house",rk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ok=[["rect",{width:"20",height:"20",x:"2",y:"2",rx:"5",ry:"5",key:"2e1cvw"}],["path",{d:"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",key:"9exkf1"}],["line",{x1:"17.5",x2:"17.51",y1:"6.5",y2:"6.5",key:"r4j83e"}]],lk=$e("instagram",ok);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ck=[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",key:"c2jq9f"}],["rect",{width:"4",height:"12",x:"2",y:"9",key:"mk3on5"}],["circle",{cx:"4",cy:"4",r:"2",key:"bt5ra8"}]],uk=$e("linkedin",ck);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hk=[["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}],["polyline",{points:"10 17 15 12 10 7",key:"1ail0h"}],["line",{x1:"15",x2:"3",y1:"12",y2:"12",key:"v6grx8"}]],dk=$e("log-in",hk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fk=[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]],mk=$e("log-out",fk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pk=[["path",{d:"M8 3H5a2 2 0 0 0-2 2v3",key:"1dcmit"}],["path",{d:"M21 8V5a2 2 0 0 0-2-2h-3",key:"1e4gt3"}],["path",{d:"M3 16v3a2 2 0 0 0 2 2h3",key:"wsl5sc"}],["path",{d:"M16 21h3a2 2 0 0 0 2-2v-3",key:"18trek"}]],gk=$e("maximize",pk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _k=[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]],yk=$e("menu",_k);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vk=[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]],As=$e("message-square",vk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ek=[["path",{d:"M8 3v3a2 2 0 0 1-2 2H3",key:"hohbtr"}],["path",{d:"M21 8h-3a2 2 0 0 1-2-2V3",key:"5jw1f3"}],["path",{d:"M3 16h3a2 2 0 0 1 2 2v3",key:"198tvr"}],["path",{d:"M16 21v-3a2 2 0 0 1 2-2h3",key:"ph8mxp"}]],Tk=$e("minimize",Ek);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const bk=[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]],tA=$e("moon",bk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wk=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],Rd=$e("plus",wk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Sk=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],Ak=$e("save",Sk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rk=[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]],nA=$e("search",Rk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ck=[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]],xk=$e("send",Ck);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ik=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],iA=$e("settings",Ik);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Nk=[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",key:"ohrbg2"}]],hb=$e("square-pen",Nk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kk=[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]],sA=$e("sun",kk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Dk=[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]],Ok=$e("trash-2",Dk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mk=[["polyline",{points:"22 7 13.5 15.5 8.5 10.5 2 17",key:"126l90"}],["polyline",{points:"16 7 22 7 22 13",key:"kwv8wd"}]],t_=$e("trending-up",Mk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pk=[["path",{d:"M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",key:"pff0z6"}]],Lk=$e("twitter",Pk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vk=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]],Uk=$e("user",Vk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jk=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]],Jc=$e("users",jk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zk=[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]],Fk=$e("volume-2",zk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bk=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],fu=$e("x",Bk);/**
 * @license lucide-react v0.501.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qk=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],rA=$e("zap",qk),mu=({size:n="md",className:e=""})=>{const t={sm:"h-4 w-4 border-2",md:"h-6 w-6 border-2",lg:"h-8 w-8 border-3",xl:"h-12 w-12 border-4"},i=t[n]||t.md;return v.jsx("div",{className:`inline-block animate-spin rounded-full border-solid border-primary border-t-transparent ${i} ${e}`,role:"status","aria-label":"loading",children:v.jsx("span",{className:"sr-only",children:"Loading..."})})};function Hk(...n){return n.filter(Boolean).join(" ")}const Dt=j.forwardRef(({className:n,variant:e="primary",size:t="md",children:i,disabled:a,isLoading:l,leftIcon:u,rightIcon:d,...m},p)=>{const y={primary:"bg-primary text-primary-foreground hover:opacity-90",secondary:"bg-[hsl(var(--secondary))] hover:bg-[hsl(var(--accent))]",outline:"bg-transparent border border-[hsl(var(--border))] hover:bg-[hsl(var(--secondary))]",ghost:"bg-transparent hover:bg-[hsl(var(--secondary))]",destructive:"bg-[hsl(var(--destructive))] text-[hsl(var(--destructive-foreground))] hover:opacity-90"},T={sm:"px-3 py-1 text-sm",md:"px-4 py-2",lg:"px-6 py-3 text-lg"};return v.jsxs("button",{className:Hk("inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--ring))] disabled:pointer-events-none disabled:opacity-50",y[e],T[t],n),disabled:a||l,ref:p,...m,children:[l&&v.jsx(mu,{size:"sm",className:"mr-2"}),!l&&u&&v.jsx("span",{className:"mr-2",children:u}),i,d&&v.jsx("span",{className:"ml-2",children:d})]})});Dt.displayName="Button";const aA=j.createContext(),Gk=({children:n})=>{const[e,t]=j.useState("dark"),i=()=>{t(e==="dark"?"light":"dark")};return j.useEffect(()=>{const a=document.documentElement;a.classList.remove(e==="dark"?"light":"dark"),a.classList.add(e)},[e]),v.jsx(aA.Provider,{value:{theme:e,toggleTheme:i},children:n})},oA=()=>{const n=j.useContext(aA);if(n===void 0)throw new Error("useTheme must be used within a ThemeProvider");return n},$k=()=>{};var db={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lA={NODE_ADMIN:!1,SDK_VERSION:"${JSCORE_VERSION}"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oe=function(n,e){if(!n)throw El(e)},El=function(n){return new Error("Firebase Database ("+lA.SDK_VERSION+") INTERNAL ASSERT FAILED: "+n)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cA=function(n){const e=[];let t=0;for(let i=0;i<n.length;i++){let a=n.charCodeAt(i);a<128?e[t++]=a:a<2048?(e[t++]=a>>6|192,e[t++]=a&63|128):(a&64512)===55296&&i+1<n.length&&(n.charCodeAt(i+1)&64512)===56320?(a=65536+((a&1023)<<10)+(n.charCodeAt(++i)&1023),e[t++]=a>>18|240,e[t++]=a>>12&63|128,e[t++]=a>>6&63|128,e[t++]=a&63|128):(e[t++]=a>>12|224,e[t++]=a>>6&63|128,e[t++]=a&63|128)}return e},Kk=function(n){const e=[];let t=0,i=0;for(;t<n.length;){const a=n[t++];if(a<128)e[i++]=String.fromCharCode(a);else if(a>191&&a<224){const l=n[t++];e[i++]=String.fromCharCode((a&31)<<6|l&63)}else if(a>239&&a<365){const l=n[t++],u=n[t++],d=n[t++],m=((a&7)<<18|(l&63)<<12|(u&63)<<6|d&63)-65536;e[i++]=String.fromCharCode(55296+(m>>10)),e[i++]=String.fromCharCode(56320+(m&1023))}else{const l=n[t++],u=n[t++];e[i++]=String.fromCharCode((a&15)<<12|(l&63)<<6|u&63)}}return e.join("")},J_={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(n,e){if(!Array.isArray(n))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,i=[];for(let a=0;a<n.length;a+=3){const l=n[a],u=a+1<n.length,d=u?n[a+1]:0,m=a+2<n.length,p=m?n[a+2]:0,y=l>>2,T=(l&3)<<4|d>>4;let w=(d&15)<<2|p>>6,x=p&63;m||(x=64,u||(w=64)),i.push(t[y],t[T],t[w],t[x])}return i.join("")},encodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(n):this.encodeByteArray(cA(n),e)},decodeString(n,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(n):Kk(this.decodeStringToByteArray(n,e))},decodeStringToByteArray(n,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,i=[];for(let a=0;a<n.length;){const l=t[n.charAt(a++)],d=a<n.length?t[n.charAt(a)]:0;++a;const p=a<n.length?t[n.charAt(a)]:64;++a;const T=a<n.length?t[n.charAt(a)]:64;if(++a,l==null||d==null||p==null||T==null)throw new Qk;const w=l<<2|d>>4;if(i.push(w),p!==64){const x=d<<4&240|p>>2;if(i.push(x),T!==64){const I=p<<6&192|T;i.push(I)}}}return i},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let n=0;n<this.ENCODED_VALS.length;n++)this.byteToCharMap_[n]=this.ENCODED_VALS.charAt(n),this.charToByteMap_[this.byteToCharMap_[n]]=n,this.byteToCharMapWebSafe_[n]=this.ENCODED_VALS_WEBSAFE.charAt(n),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[n]]=n,n>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(n)]=n,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(n)]=n)}}};class Qk extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const uA=function(n){const e=cA(n);return J_.encodeByteArray(e,!0)},ef=function(n){return uA(n).replace(/\./g,"")},tf=function(n){try{return J_.decodeString(n,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Yk(n){return hA(void 0,n)}function hA(n,e){if(!(e instanceof Object))return e;switch(e.constructor){case Date:const t=e;return new Date(t.getTime());case Object:n===void 0&&(n={});break;case Array:n=[];break;default:return e}for(const t in e)!e.hasOwnProperty(t)||!Wk(t)||(n[t]=hA(n[t],e[t]));return n}function Wk(n){return n!=="__proto__"}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xk(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zk=()=>Xk().__FIREBASE_DEFAULTS__,Jk=()=>{if(typeof process>"u"||typeof db>"u")return;const n=db.__FIREBASE_DEFAULTS__;if(n)return JSON.parse(n)},eD=()=>{if(typeof document>"u")return;let n;try{n=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=n&&tf(n[1]);return e&&JSON.parse(e)},Bf=()=>{try{return $k()||Zk()||Jk()||eD()}catch(n){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${n}`);return}},dA=n=>{var e,t;return(t=(e=Bf())===null||e===void 0?void 0:e.emulatorHosts)===null||t===void 0?void 0:t[n]},ey=n=>{const e=dA(n);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const i=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),i]:[e.substring(0,t),i]},fA=()=>{var n;return(n=Bf())===null||n===void 0?void 0:n.config},mA=n=>{var e;return(e=Bf())===null||e===void 0?void 0:e[`_${n}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qf{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,i)=>{t?this.reject(t):this.resolve(i),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,i))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ty(n,e){if(n.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},i=e||"demo-project",a=n.iat||0,l=n.sub||n.user_id;if(!l)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const u=Object.assign({iss:`https://securetoken.google.com/${i}`,aud:i,iat:a,exp:a+3600,auth_time:a,sub:l,user_id:l,firebase:{sign_in_provider:"custom",identities:{}}},n);return[ef(JSON.stringify(t)),ef(JSON.stringify(u)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gn(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function ny(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(gn())}function tD(){var n;const e=(n=Bf())===null||n===void 0?void 0:n.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function nD(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function pA(){const n=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof n=="object"&&n.id!==void 0}function gA(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function iD(){const n=gn();return n.indexOf("MSIE ")>=0||n.indexOf("Trident/")>=0}function sD(){return lA.NODE_ADMIN===!0}function rD(){return!tD()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function _A(){try{return typeof indexedDB=="object"}catch{return!1}}function yA(){return new Promise((n,e)=>{try{let t=!0;const i="validate-browser-context-for-indexeddb-analytics-module",a=self.indexedDB.open(i);a.onsuccess=()=>{a.result.close(),t||self.indexedDB.deleteDatabase(i),n(!0)},a.onupgradeneeded=()=>{t=!1},a.onerror=()=>{var l;e(((l=a.error)===null||l===void 0?void 0:l.message)||"")}}catch(t){e(t)}})}function aD(){return!(typeof navigator>"u"||!navigator.cookieEnabled)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oD="FirebaseError";class oi extends Error{constructor(e,t,i){super(t),this.code=e,this.customData=i,this.name=oD,Object.setPrototypeOf(this,oi.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,Qa.prototype.create)}}class Qa{constructor(e,t,i){this.service=e,this.serviceName=t,this.errors=i}create(e,...t){const i=t[0]||{},a=`${this.service}/${e}`,l=this.errors[e],u=l?lD(l,i):"Error",d=`${this.serviceName}: ${u} (${a}).`;return new oi(a,d,i)}}function lD(n,e){return n.replace(cD,(t,i)=>{const a=e[i];return a!=null?String(a):`<${i}?>`})}const cD=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pu(n){return JSON.parse(n)}function Zt(n){return JSON.stringify(n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vA=function(n){let e={},t={},i={},a="";try{const l=n.split(".");e=pu(tf(l[0])||""),t=pu(tf(l[1])||""),a=l[2],i=t.d||{},delete t.d}catch{}return{header:e,claims:t,data:i,signature:a}},uD=function(n){const e=vA(n),t=e.claims;return!!t&&typeof t=="object"&&t.hasOwnProperty("iat")},hD=function(n){const e=vA(n).claims;return typeof e=="object"&&e.admin===!0};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wi(n,e){return Object.prototype.hasOwnProperty.call(n,e)}function ol(n,e){if(Object.prototype.hasOwnProperty.call(n,e))return n[e]}function n_(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}function nf(n,e,t){const i={};for(const a in n)Object.prototype.hasOwnProperty.call(n,a)&&(i[a]=e.call(t,n[a],a,n));return i}function Ps(n,e){if(n===e)return!0;const t=Object.keys(n),i=Object.keys(e);for(const a of t){if(!i.includes(a))return!1;const l=n[a],u=e[a];if(fb(l)&&fb(u)){if(!Ps(l,u))return!1}else if(l!==u)return!1}for(const a of i)if(!t.includes(a))return!1;return!0}function fb(n){return n!==null&&typeof n=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Tl(n){const e=[];for(const[t,i]of Object.entries(n))Array.isArray(i)?i.forEach(a=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(a))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(i));return e.length?"&"+e.join("&"):""}function Kc(n){const e={};return n.replace(/^\?/,"").split("&").forEach(i=>{if(i){const[a,l]=i.split("=");e[decodeURIComponent(a)]=decodeURIComponent(l)}}),e}function Qc(n){const e=n.indexOf("?");if(!e)return"";const t=n.indexOf("#",e);return n.substring(e,t>0?t:void 0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dD{constructor(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=512/8,this.pad_[0]=128;for(let e=1;e<this.blockSize;++e)this.pad_[e]=0;this.reset()}reset(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0}compress_(e,t){t||(t=0);const i=this.W_;if(typeof e=="string")for(let T=0;T<16;T++)i[T]=e.charCodeAt(t)<<24|e.charCodeAt(t+1)<<16|e.charCodeAt(t+2)<<8|e.charCodeAt(t+3),t+=4;else for(let T=0;T<16;T++)i[T]=e[t]<<24|e[t+1]<<16|e[t+2]<<8|e[t+3],t+=4;for(let T=16;T<80;T++){const w=i[T-3]^i[T-8]^i[T-14]^i[T-16];i[T]=(w<<1|w>>>31)&4294967295}let a=this.chain_[0],l=this.chain_[1],u=this.chain_[2],d=this.chain_[3],m=this.chain_[4],p,y;for(let T=0;T<80;T++){T<40?T<20?(p=d^l&(u^d),y=1518500249):(p=l^u^d,y=1859775393):T<60?(p=l&u|d&(l|u),y=2400959708):(p=l^u^d,y=3395469782);const w=(a<<5|a>>>27)+p+m+y+i[T]&4294967295;m=d,d=u,u=(l<<30|l>>>2)&4294967295,l=a,a=w}this.chain_[0]=this.chain_[0]+a&4294967295,this.chain_[1]=this.chain_[1]+l&4294967295,this.chain_[2]=this.chain_[2]+u&4294967295,this.chain_[3]=this.chain_[3]+d&4294967295,this.chain_[4]=this.chain_[4]+m&4294967295}update(e,t){if(e==null)return;t===void 0&&(t=e.length);const i=t-this.blockSize;let a=0;const l=this.buf_;let u=this.inbuf_;for(;a<t;){if(u===0)for(;a<=i;)this.compress_(e,a),a+=this.blockSize;if(typeof e=="string"){for(;a<t;)if(l[u]=e.charCodeAt(a),++u,++a,u===this.blockSize){this.compress_(l),u=0;break}}else for(;a<t;)if(l[u]=e[a],++u,++a,u===this.blockSize){this.compress_(l),u=0;break}}this.inbuf_=u,this.total_+=t}digest(){const e=[];let t=this.total_*8;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(let a=this.blockSize-1;a>=56;a--)this.buf_[a]=t&255,t/=256;this.compress_(this.buf_);let i=0;for(let a=0;a<5;a++)for(let l=24;l>=0;l-=8)e[i]=this.chain_[a]>>l&255,++i;return e}}function fD(n,e){const t=new mD(n,e);return t.subscribe.bind(t)}class mD{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(i=>{this.error(i)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,i){let a;if(e===void 0&&t===void 0&&i===void 0)throw new Error("Missing Observer.");pD(e,["next","error","complete"])?a=e:a={next:e,error:t,complete:i},a.next===void 0&&(a.next=Ng),a.error===void 0&&(a.error=Ng),a.complete===void 0&&(a.complete=Ng);const l=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?a.error(this.finalError):a.complete()}catch{}}),this.observers.push(a),l}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(i){typeof console<"u"&&console.error&&console.error(i)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function pD(n,e){if(typeof n!="object"||n===null)return!1;for(const t of e)if(t in n&&typeof n[t]=="function")return!0;return!1}function Ng(){}function iy(n,e){return`${n} failed: ${e} argument `}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gD=function(n){const e=[];let t=0;for(let i=0;i<n.length;i++){let a=n.charCodeAt(i);if(a>=55296&&a<=56319){const l=a-55296;i++,oe(i<n.length,"Surrogate pair missing trail surrogate.");const u=n.charCodeAt(i)-56320;a=65536+(l<<10)+u}a<128?e[t++]=a:a<2048?(e[t++]=a>>6|192,e[t++]=a&63|128):a<65536?(e[t++]=a>>12|224,e[t++]=a>>6&63|128,e[t++]=a&63|128):(e[t++]=a>>18|240,e[t++]=a>>12&63|128,e[t++]=a>>6&63|128,e[t++]=a&63|128)}return e},Hf=function(n){let e=0;for(let t=0;t<n.length;t++){const i=n.charCodeAt(t);i<128?e++:i<2048?e+=2:i>=55296&&i<=56319?(e+=4,t++):e+=3}return e};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _D=1e3,yD=2,vD=4*60*60*1e3,ED=.5;function mb(n,e=_D,t=yD){const i=e*Math.pow(t,n),a=Math.round(ED*i*(Math.random()-.5)*2);return Math.min(vD,i+a)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function at(n){return n&&n._delegate?n._delegate:n}class Hn{constructor(e,t,i){this.name=e,this.instanceFactory=t,this.type=i,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Na="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TD{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const i=new qf;if(this.instancesDeferred.set(t,i),this.isInitialized(t)||this.shouldAutoInitialize())try{const a=this.getOrInitializeService({instanceIdentifier:t});a&&i.resolve(a)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;const i=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),a=(t=e==null?void 0:e.optional)!==null&&t!==void 0?t:!1;if(this.isInitialized(i)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:i})}catch(l){if(a)return null;throw l}else{if(a)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if(wD(e))try{this.getOrInitializeService({instanceIdentifier:Na})}catch{}for(const[t,i]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(t);try{const l=this.getOrInitializeService({instanceIdentifier:a});i.resolve(l)}catch{}}}}clearInstance(e=Na){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Na){return this.instances.has(e)}getOptions(e=Na){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,i=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(i))throw Error(`${this.name}(${i}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const a=this.getOrInitializeService({instanceIdentifier:i,options:t});for(const[l,u]of this.instancesDeferred.entries()){const d=this.normalizeInstanceIdentifier(l);i===d&&u.resolve(a)}return a}onInit(e,t){var i;const a=this.normalizeInstanceIdentifier(t),l=(i=this.onInitCallbacks.get(a))!==null&&i!==void 0?i:new Set;l.add(e),this.onInitCallbacks.set(a,l);const u=this.instances.get(a);return u&&e(u,a),()=>{l.delete(e)}}invokeOnInitCallbacks(e,t){const i=this.onInitCallbacks.get(t);if(i)for(const a of i)try{a(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let i=this.instances.get(e);if(!i&&this.component&&(i=this.component.instanceFactory(this.container,{instanceIdentifier:bD(e),options:t}),this.instances.set(e,i),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(i,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,i)}catch{}return i||null}normalizeInstanceIdentifier(e=Na){return this.component?this.component.multipleInstances?e:Na:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function bD(n){return n===Na?void 0:n}function wD(n){return n.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SD{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new TD(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ue;(function(n){n[n.DEBUG=0]="DEBUG",n[n.VERBOSE=1]="VERBOSE",n[n.INFO=2]="INFO",n[n.WARN=3]="WARN",n[n.ERROR=4]="ERROR",n[n.SILENT=5]="SILENT"})(Ue||(Ue={}));const AD={debug:Ue.DEBUG,verbose:Ue.VERBOSE,info:Ue.INFO,warn:Ue.WARN,error:Ue.ERROR,silent:Ue.SILENT},RD=Ue.INFO,CD={[Ue.DEBUG]:"log",[Ue.VERBOSE]:"log",[Ue.INFO]:"info",[Ue.WARN]:"warn",[Ue.ERROR]:"error"},xD=(n,e,...t)=>{if(e<n.logLevel)return;const i=new Date().toISOString(),a=CD[e];if(a)console[a](`[${i}]  ${n.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Lu{constructor(e){this.name=e,this._logLevel=RD,this._logHandler=xD,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in Ue))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?AD[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,Ue.DEBUG,...e),this._logHandler(this,Ue.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,Ue.VERBOSE,...e),this._logHandler(this,Ue.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,Ue.INFO,...e),this._logHandler(this,Ue.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,Ue.WARN,...e),this._logHandler(this,Ue.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,Ue.ERROR,...e),this._logHandler(this,Ue.ERROR,...e)}}const ID=(n,e)=>e.some(t=>n instanceof t);let pb,gb;function ND(){return pb||(pb=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function kD(){return gb||(gb=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const EA=new WeakMap,i_=new WeakMap,TA=new WeakMap,kg=new WeakMap,sy=new WeakMap;function DD(n){const e=new Promise((t,i)=>{const a=()=>{n.removeEventListener("success",l),n.removeEventListener("error",u)},l=()=>{t(Rr(n.result)),a()},u=()=>{i(n.error),a()};n.addEventListener("success",l),n.addEventListener("error",u)});return e.then(t=>{t instanceof IDBCursor&&EA.set(t,n)}).catch(()=>{}),sy.set(e,n),e}function OD(n){if(i_.has(n))return;const e=new Promise((t,i)=>{const a=()=>{n.removeEventListener("complete",l),n.removeEventListener("error",u),n.removeEventListener("abort",u)},l=()=>{t(),a()},u=()=>{i(n.error||new DOMException("AbortError","AbortError")),a()};n.addEventListener("complete",l),n.addEventListener("error",u),n.addEventListener("abort",u)});i_.set(n,e)}let s_={get(n,e,t){if(n instanceof IDBTransaction){if(e==="done")return i_.get(n);if(e==="objectStoreNames")return n.objectStoreNames||TA.get(n);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return Rr(n[e])},set(n,e,t){return n[e]=t,!0},has(n,e){return n instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in n}};function MD(n){s_=n(s_)}function PD(n){return n===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const i=n.call(Dg(this),e,...t);return TA.set(i,e.sort?e.sort():[e]),Rr(i)}:kD().includes(n)?function(...e){return n.apply(Dg(this),e),Rr(EA.get(this))}:function(...e){return Rr(n.apply(Dg(this),e))}}function LD(n){return typeof n=="function"?PD(n):(n instanceof IDBTransaction&&OD(n),ID(n,ND())?new Proxy(n,s_):n)}function Rr(n){if(n instanceof IDBRequest)return DD(n);if(kg.has(n))return kg.get(n);const e=LD(n);return e!==n&&(kg.set(n,e),sy.set(e,n)),e}const Dg=n=>sy.get(n);function bA(n,e,{blocked:t,upgrade:i,blocking:a,terminated:l}={}){const u=indexedDB.open(n,e),d=Rr(u);return i&&u.addEventListener("upgradeneeded",m=>{i(Rr(u.result),m.oldVersion,m.newVersion,Rr(u.transaction),m)}),t&&u.addEventListener("blocked",m=>t(m.oldVersion,m.newVersion,m)),d.then(m=>{l&&m.addEventListener("close",()=>l()),a&&m.addEventListener("versionchange",p=>a(p.oldVersion,p.newVersion,p))}).catch(()=>{}),d}const VD=["get","getKey","getAll","getAllKeys","count"],UD=["put","add","delete","clear"],Og=new Map;function _b(n,e){if(!(n instanceof IDBDatabase&&!(e in n)&&typeof e=="string"))return;if(Og.get(e))return Og.get(e);const t=e.replace(/FromIndex$/,""),i=e!==t,a=UD.includes(t);if(!(t in(i?IDBIndex:IDBObjectStore).prototype)||!(a||VD.includes(t)))return;const l=async function(u,...d){const m=this.transaction(u,a?"readwrite":"readonly");let p=m.store;return i&&(p=p.index(d.shift())),(await Promise.all([p[t](...d),a&&m.done]))[0]};return Og.set(e,l),l}MD(n=>({...n,get:(e,t,i)=>_b(e,t)||n.get(e,t,i),has:(e,t)=>!!_b(e,t)||n.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jD{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(zD(t)){const i=t.getImmediate();return`${i.library}/${i.version}`}else return null}).filter(t=>t).join(" ")}}function zD(n){const e=n.getComponent();return(e==null?void 0:e.type)==="VERSION"}const r_="@firebase/app",yb="0.11.4";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ls=new Lu("@firebase/app"),FD="@firebase/app-compat",BD="@firebase/analytics-compat",qD="@firebase/analytics",HD="@firebase/app-check-compat",GD="@firebase/app-check",$D="@firebase/auth",KD="@firebase/auth-compat",QD="@firebase/database",YD="@firebase/data-connect",WD="@firebase/database-compat",XD="@firebase/functions",ZD="@firebase/functions-compat",JD="@firebase/installations",eO="@firebase/installations-compat",tO="@firebase/messaging",nO="@firebase/messaging-compat",iO="@firebase/performance",sO="@firebase/performance-compat",rO="@firebase/remote-config",aO="@firebase/remote-config-compat",oO="@firebase/storage",lO="@firebase/storage-compat",cO="@firebase/firestore",uO="@firebase/vertexai",hO="@firebase/firestore-compat",dO="firebase",fO="11.6.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const a_="[DEFAULT]",mO={[r_]:"fire-core",[FD]:"fire-core-compat",[qD]:"fire-analytics",[BD]:"fire-analytics-compat",[GD]:"fire-app-check",[HD]:"fire-app-check-compat",[$D]:"fire-auth",[KD]:"fire-auth-compat",[QD]:"fire-rtdb",[YD]:"fire-data-connect",[WD]:"fire-rtdb-compat",[XD]:"fire-fn",[ZD]:"fire-fn-compat",[JD]:"fire-iid",[eO]:"fire-iid-compat",[tO]:"fire-fcm",[nO]:"fire-fcm-compat",[iO]:"fire-perf",[sO]:"fire-perf-compat",[rO]:"fire-rc",[aO]:"fire-rc-compat",[oO]:"fire-gcs",[lO]:"fire-gcs-compat",[cO]:"fire-fst",[hO]:"fire-fst-compat",[uO]:"fire-vertex","fire-js":"fire-js",[dO]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sf=new Map,pO=new Map,o_=new Map;function vb(n,e){try{n.container.addComponent(e)}catch(t){Ls.debug(`Component ${e.name} failed to register with FirebaseApp ${n.name}`,t)}}function ri(n){const e=n.name;if(o_.has(e))return Ls.debug(`There were multiple attempts to register component ${e}.`),!1;o_.set(e,n);for(const t of sf.values())vb(t,n);for(const t of pO.values())vb(t,n);return!0}function qs(n,e){const t=n.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),n.container.getProvider(e)}function Rn(n){return n==null?!1:n.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gO={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Cr=new Qa("app","Firebase",gO);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _O{constructor(e,t,i){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=i,this.container.addComponent(new Hn("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Cr.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fr=fO;function wA(n,e={}){let t=n;typeof e!="object"&&(e={name:e});const i=Object.assign({name:a_,automaticDataCollectionEnabled:!1},e),a=i.name;if(typeof a!="string"||!a)throw Cr.create("bad-app-name",{appName:String(a)});if(t||(t=fA()),!t)throw Cr.create("no-options");const l=sf.get(a);if(l){if(Ps(t,l.options)&&Ps(i,l.config))return l;throw Cr.create("duplicate-app",{appName:a})}const u=new SD(a);for(const m of o_.values())u.addComponent(m);const d=new _O(t,i,u);return sf.set(a,d),d}function Vu(n=a_){const e=sf.get(n);if(!e&&n===a_&&fA())return wA();if(!e)throw Cr.create("no-app",{appName:n});return e}function pn(n,e,t){var i;let a=(i=mO[n])!==null&&i!==void 0?i:n;t&&(a+=`-${t}`);const l=a.match(/\s|\//),u=e.match(/\s|\//);if(l||u){const d=[`Unable to register library "${a}" with version "${e}":`];l&&d.push(`library name "${a}" contains illegal characters (whitespace or "/")`),l&&u&&d.push("and"),u&&d.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Ls.warn(d.join(" "));return}ri(new Hn(`${a}-version`,()=>({library:a,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yO="firebase-heartbeat-database",vO=1,gu="firebase-heartbeat-store";let Mg=null;function SA(){return Mg||(Mg=bA(yO,vO,{upgrade:(n,e)=>{switch(e){case 0:try{n.createObjectStore(gu)}catch(t){console.warn(t)}}}}).catch(n=>{throw Cr.create("idb-open",{originalErrorMessage:n.message})})),Mg}async function EO(n){try{const t=(await SA()).transaction(gu),i=await t.objectStore(gu).get(AA(n));return await t.done,i}catch(e){if(e instanceof oi)Ls.warn(e.message);else{const t=Cr.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Ls.warn(t.message)}}}async function Eb(n,e){try{const i=(await SA()).transaction(gu,"readwrite");await i.objectStore(gu).put(e,AA(n)),await i.done}catch(t){if(t instanceof oi)Ls.warn(t.message);else{const i=Cr.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Ls.warn(i.message)}}}function AA(n){return`${n.name}!${n.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const TO=1024,bO=30;class wO{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new AO(t),this._heartbeatsCachePromise=this._storage.read().then(i=>(this._heartbeatsCache=i,i))}async triggerHeartbeat(){var e,t;try{const a=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),l=Tb();if(((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)===null||t===void 0?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===l||this._heartbeatsCache.heartbeats.some(u=>u.date===l))return;if(this._heartbeatsCache.heartbeats.push({date:l,agent:a}),this._heartbeatsCache.heartbeats.length>bO){const u=RO(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(u,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(i){Ls.warn(i)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)===null||e===void 0?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=Tb(),{heartbeatsToSend:i,unsentEntries:a}=SO(this._heartbeatsCache.heartbeats),l=ef(JSON.stringify({version:2,heartbeats:i}));return this._heartbeatsCache.lastSentHeartbeatDate=t,a.length>0?(this._heartbeatsCache.heartbeats=a,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),l}catch(t){return Ls.warn(t),""}}}function Tb(){return new Date().toISOString().substring(0,10)}function SO(n,e=TO){const t=[];let i=n.slice();for(const a of n){const l=t.find(u=>u.agent===a.agent);if(l){if(l.dates.push(a.date),bb(t)>e){l.dates.pop();break}}else if(t.push({agent:a.agent,dates:[a.date]}),bb(t)>e){t.pop();break}i=i.slice(1)}return{heartbeatsToSend:t,unsentEntries:i}}class AO{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return _A()?yA().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await EO(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){var t;if(await this._canUseIndexedDBPromise){const a=await this.read();return Eb(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:a.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){var t;if(await this._canUseIndexedDBPromise){const a=await this.read();return Eb(this.app,{lastSentHeartbeatDate:(t=e.lastSentHeartbeatDate)!==null&&t!==void 0?t:a.lastSentHeartbeatDate,heartbeats:[...a.heartbeats,...e.heartbeats]})}else return}}function bb(n){return ef(JSON.stringify({version:2,heartbeats:n})).length}function RO(n){if(n.length===0)return-1;let e=0,t=n[0].date;for(let i=1;i<n.length;i++)n[i].date<t&&(t=n[i].date,e=i);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function CO(n){ri(new Hn("platform-logger",e=>new jD(e),"PRIVATE")),ri(new Hn("heartbeat",e=>new wO(e),"PRIVATE")),pn(r_,yb,n),pn(r_,yb,"esm2017"),pn("fire-js","")}CO("");var xO="firebase",IO="11.6.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */pn(xO,IO,"app");const RA="@firebase/installations",ry="0.6.13";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const CA=1e4,xA=`w:${ry}`,IA="FIS_v2",NO="https://firebaseinstallations.googleapis.com/v1",kO=60*60*1e3,DO="installations",OO="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const MO={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},Va=new Qa(DO,OO,MO);function NA(n){return n instanceof oi&&n.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function kA({projectId:n}){return`${NO}/projects/${n}/installations`}function DA(n){return{token:n.token,requestStatus:2,expiresIn:LO(n.expiresIn),creationTime:Date.now()}}async function OA(n,e){const i=(await e.json()).error;return Va.create("request-failed",{requestName:n,serverCode:i.code,serverMessage:i.message,serverStatus:i.status})}function MA({apiKey:n}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":n})}function PO(n,{refreshToken:e}){const t=MA(n);return t.append("Authorization",VO(e)),t}async function PA(n){const e=await n();return e.status>=500&&e.status<600?n():e}function LO(n){return Number(n.replace("s","000"))}function VO(n){return`${IA} ${n}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function UO({appConfig:n,heartbeatServiceProvider:e},{fid:t}){const i=kA(n),a=MA(n),l=e.getImmediate({optional:!0});if(l){const p=await l.getHeartbeatsHeader();p&&a.append("x-firebase-client",p)}const u={fid:t,authVersion:IA,appId:n.appId,sdkVersion:xA},d={method:"POST",headers:a,body:JSON.stringify(u)},m=await PA(()=>fetch(i,d));if(m.ok){const p=await m.json();return{fid:p.fid||t,registrationStatus:2,refreshToken:p.refreshToken,authToken:DA(p.authToken)}}else throw await OA("Create Installation",m)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function LA(n){return new Promise(e=>{setTimeout(e,n)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jO(n){return btoa(String.fromCharCode(...n)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zO=/^[cdef][\w-]{21}$/,l_="";function FO(){try{const n=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(n),n[0]=112+n[0]%16;const t=BO(n);return zO.test(t)?t:l_}catch{return l_}}function BO(n){return jO(n).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gf(n){return`${n.appName}!${n.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const VA=new Map;function UA(n,e){const t=Gf(n);jA(t,e),qO(t,e)}function jA(n,e){const t=VA.get(n);if(t)for(const i of t)i(e)}function qO(n,e){const t=HO();t&&t.postMessage({key:n,fid:e}),GO()}let Da=null;function HO(){return!Da&&"BroadcastChannel"in self&&(Da=new BroadcastChannel("[Firebase] FID Change"),Da.onmessage=n=>{jA(n.data.key,n.data.fid)}),Da}function GO(){VA.size===0&&Da&&(Da.close(),Da=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $O="firebase-installations-database",KO=1,Ua="firebase-installations-store";let Pg=null;function ay(){return Pg||(Pg=bA($O,KO,{upgrade:(n,e)=>{switch(e){case 0:n.createObjectStore(Ua)}}})),Pg}async function rf(n,e){const t=Gf(n),a=(await ay()).transaction(Ua,"readwrite"),l=a.objectStore(Ua),u=await l.get(t);return await l.put(e,t),await a.done,(!u||u.fid!==e.fid)&&UA(n,e.fid),e}async function zA(n){const e=Gf(n),i=(await ay()).transaction(Ua,"readwrite");await i.objectStore(Ua).delete(e),await i.done}async function $f(n,e){const t=Gf(n),a=(await ay()).transaction(Ua,"readwrite"),l=a.objectStore(Ua),u=await l.get(t),d=e(u);return d===void 0?await l.delete(t):await l.put(d,t),await a.done,d&&(!u||u.fid!==d.fid)&&UA(n,d.fid),d}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function oy(n){let e;const t=await $f(n.appConfig,i=>{const a=QO(i),l=YO(n,a);return e=l.registrationPromise,l.installationEntry});return t.fid===l_?{installationEntry:await e}:{installationEntry:t,registrationPromise:e}}function QO(n){const e=n||{fid:FO(),registrationStatus:0};return FA(e)}function YO(n,e){if(e.registrationStatus===0){if(!navigator.onLine){const a=Promise.reject(Va.create("app-offline"));return{installationEntry:e,registrationPromise:a}}const t={fid:e.fid,registrationStatus:1,registrationTime:Date.now()},i=WO(n,t);return{installationEntry:t,registrationPromise:i}}else return e.registrationStatus===1?{installationEntry:e,registrationPromise:XO(n)}:{installationEntry:e}}async function WO(n,e){try{const t=await UO(n,e);return rf(n.appConfig,t)}catch(t){throw NA(t)&&t.customData.serverCode===409?await zA(n.appConfig):await rf(n.appConfig,{fid:e.fid,registrationStatus:0}),t}}async function XO(n){let e=await wb(n.appConfig);for(;e.registrationStatus===1;)await LA(100),e=await wb(n.appConfig);if(e.registrationStatus===0){const{installationEntry:t,registrationPromise:i}=await oy(n);return i||t}return e}function wb(n){return $f(n,e=>{if(!e)throw Va.create("installation-not-found");return FA(e)})}function FA(n){return ZO(n)?{fid:n.fid,registrationStatus:0}:n}function ZO(n){return n.registrationStatus===1&&n.registrationTime+CA<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function JO({appConfig:n,heartbeatServiceProvider:e},t){const i=eM(n,t),a=PO(n,t),l=e.getImmediate({optional:!0});if(l){const p=await l.getHeartbeatsHeader();p&&a.append("x-firebase-client",p)}const u={installation:{sdkVersion:xA,appId:n.appId}},d={method:"POST",headers:a,body:JSON.stringify(u)},m=await PA(()=>fetch(i,d));if(m.ok){const p=await m.json();return DA(p)}else throw await OA("Generate Auth Token",m)}function eM(n,{fid:e}){return`${kA(n)}/${e}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ly(n,e=!1){let t;const i=await $f(n.appConfig,l=>{if(!BA(l))throw Va.create("not-registered");const u=l.authToken;if(!e&&iM(u))return l;if(u.requestStatus===1)return t=tM(n,e),l;{if(!navigator.onLine)throw Va.create("app-offline");const d=rM(l);return t=nM(n,d),d}});return t?await t:i.authToken}async function tM(n,e){let t=await Sb(n.appConfig);for(;t.authToken.requestStatus===1;)await LA(100),t=await Sb(n.appConfig);const i=t.authToken;return i.requestStatus===0?ly(n,e):i}function Sb(n){return $f(n,e=>{if(!BA(e))throw Va.create("not-registered");const t=e.authToken;return aM(t)?Object.assign(Object.assign({},e),{authToken:{requestStatus:0}}):e})}async function nM(n,e){try{const t=await JO(n,e),i=Object.assign(Object.assign({},e),{authToken:t});return await rf(n.appConfig,i),t}catch(t){if(NA(t)&&(t.customData.serverCode===401||t.customData.serverCode===404))await zA(n.appConfig);else{const i=Object.assign(Object.assign({},e),{authToken:{requestStatus:0}});await rf(n.appConfig,i)}throw t}}function BA(n){return n!==void 0&&n.registrationStatus===2}function iM(n){return n.requestStatus===2&&!sM(n)}function sM(n){const e=Date.now();return e<n.creationTime||n.creationTime+n.expiresIn<e+kO}function rM(n){const e={requestStatus:1,requestTime:Date.now()};return Object.assign(Object.assign({},n),{authToken:e})}function aM(n){return n.requestStatus===1&&n.requestTime+CA<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function oM(n){const e=n,{installationEntry:t,registrationPromise:i}=await oy(e);return i?i.catch(console.error):ly(e).catch(console.error),t.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function lM(n,e=!1){const t=n;return await cM(t),(await ly(t,e)).token}async function cM(n){const{registrationPromise:e}=await oy(n);e&&await e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function uM(n){if(!n||!n.options)throw Lg("App Configuration");if(!n.name)throw Lg("App Name");const e=["projectId","apiKey","appId"];for(const t of e)if(!n.options[t])throw Lg(t);return{appName:n.name,projectId:n.options.projectId,apiKey:n.options.apiKey,appId:n.options.appId}}function Lg(n){return Va.create("missing-app-config-values",{valueName:n})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qA="installations",hM="installations-internal",dM=n=>{const e=n.getProvider("app").getImmediate(),t=uM(e),i=qs(e,"heartbeat");return{app:e,appConfig:t,heartbeatServiceProvider:i,_delete:()=>Promise.resolve()}},fM=n=>{const e=n.getProvider("app").getImmediate(),t=qs(e,qA).getImmediate();return{getId:()=>oM(t),getToken:a=>lM(t,a)}};function mM(){ri(new Hn(qA,dM,"PUBLIC")),ri(new Hn(hM,fM,"PRIVATE"))}mM();pn(RA,ry);pn(RA,ry,"esm2017");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const af="analytics",pM="firebase_id",gM="origin",_M=60*1e3,yM="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig",cy="https://www.googletagmanager.com/gtag/js";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nn=new Lu("@firebase/analytics");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vM={"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-initialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":"Firebase Analytics Interop Component failed to instantiate: {$reason}","invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":"Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}","no-api-key":'The "apiKey" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.',"no-app-id":'The "appId" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.',"no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":"Trusted Types detected an invalid gtag resource: {$gtagURL}."},qn=new Qa("analytics","Analytics",vM);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function EM(n){if(!n.startsWith(cy)){const e=qn.create("invalid-gtag-resource",{gtagURL:n});return Nn.warn(e.message),""}return n}function HA(n){return Promise.all(n.map(e=>e.catch(t=>t)))}function TM(n,e){let t;return window.trustedTypes&&(t=window.trustedTypes.createPolicy(n,e)),t}function bM(n,e){const t=TM("firebase-js-sdk-policy",{createScriptURL:EM}),i=document.createElement("script"),a=`${cy}?l=${n}&id=${e}`;i.src=t?t==null?void 0:t.createScriptURL(a):a,i.async=!0,document.head.appendChild(i)}function wM(n){let e=[];return Array.isArray(window[n])?e=window[n]:window[n]=e,e}async function SM(n,e,t,i,a,l){const u=i[a];try{if(u)await e[u];else{const m=(await HA(t)).find(p=>p.measurementId===a);m&&await e[m.appId]}}catch(d){Nn.error(d)}n("config",a,l)}async function AM(n,e,t,i,a){try{let l=[];if(a&&a.send_to){let u=a.send_to;Array.isArray(u)||(u=[u]);const d=await HA(t);for(const m of u){const p=d.find(T=>T.measurementId===m),y=p&&e[p.appId];if(y)l.push(y);else{l=[];break}}}l.length===0&&(l=Object.values(e)),await Promise.all(l),n("event",i,a||{})}catch(l){Nn.error(l)}}function RM(n,e,t,i){async function a(l,...u){try{if(l==="event"){const[d,m]=u;await AM(n,e,t,d,m)}else if(l==="config"){const[d,m]=u;await SM(n,e,t,i,d,m)}else if(l==="consent"){const[d,m]=u;n("consent",d,m)}else if(l==="get"){const[d,m,p]=u;n("get",d,m,p)}else if(l==="set"){const[d]=u;n("set",d)}else n(l,...u)}catch(d){Nn.error(d)}}return a}function CM(n,e,t,i,a){let l=function(...u){window[i].push(arguments)};return window[a]&&typeof window[a]=="function"&&(l=window[a]),window[a]=RM(l,n,e,t),{gtagCore:l,wrappedGtag:window[a]}}function xM(n){const e=window.document.getElementsByTagName("script");for(const t of Object.values(e))if(t.src&&t.src.includes(cy)&&t.src.includes(n))return t;return null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const IM=30,NM=1e3;class kM{constructor(e={},t=NM){this.throttleMetadata=e,this.intervalMillis=t}getThrottleMetadata(e){return this.throttleMetadata[e]}setThrottleMetadata(e,t){this.throttleMetadata[e]=t}deleteThrottleMetadata(e){delete this.throttleMetadata[e]}}const GA=new kM;function DM(n){return new Headers({Accept:"application/json","x-goog-api-key":n})}async function OM(n){var e;const{appId:t,apiKey:i}=n,a={method:"GET",headers:DM(i)},l=yM.replace("{app-id}",t),u=await fetch(l,a);if(u.status!==200&&u.status!==304){let d="";try{const m=await u.json();!((e=m.error)===null||e===void 0)&&e.message&&(d=m.error.message)}catch{}throw qn.create("config-fetch-failed",{httpStatus:u.status,responseMessage:d})}return u.json()}async function MM(n,e=GA,t){const{appId:i,apiKey:a,measurementId:l}=n.options;if(!i)throw qn.create("no-app-id");if(!a){if(l)return{measurementId:l,appId:i};throw qn.create("no-api-key")}const u=e.getThrottleMetadata(i)||{backoffCount:0,throttleEndTimeMillis:Date.now()},d=new VM;return setTimeout(async()=>{d.abort()},_M),$A({appId:i,apiKey:a,measurementId:l},u,d,e)}async function $A(n,{throttleEndTimeMillis:e,backoffCount:t},i,a=GA){var l;const{appId:u,measurementId:d}=n;try{await PM(i,e)}catch(m){if(d)return Nn.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${d} provided in the "measurementId" field in the local Firebase config. [${m==null?void 0:m.message}]`),{appId:u,measurementId:d};throw m}try{const m=await OM(n);return a.deleteThrottleMetadata(u),m}catch(m){const p=m;if(!LM(p)){if(a.deleteThrottleMetadata(u),d)return Nn.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${d} provided in the "measurementId" field in the local Firebase config. [${p==null?void 0:p.message}]`),{appId:u,measurementId:d};throw m}const y=Number((l=p==null?void 0:p.customData)===null||l===void 0?void 0:l.httpStatus)===503?mb(t,a.intervalMillis,IM):mb(t,a.intervalMillis),T={throttleEndTimeMillis:Date.now()+y,backoffCount:t+1};return a.setThrottleMetadata(u,T),Nn.debug(`Calling attemptFetch again in ${y} millis`),$A(n,T,i,a)}}function PM(n,e){return new Promise((t,i)=>{const a=Math.max(e-Date.now(),0),l=setTimeout(t,a);n.addEventListener(()=>{clearTimeout(l),i(qn.create("fetch-throttle",{throttleEndTimeMillis:e}))})})}function LM(n){if(!(n instanceof oi)||!n.customData)return!1;const e=Number(n.customData.httpStatus);return e===429||e===500||e===503||e===504}class VM{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}async function UM(n,e,t,i,a){if(a&&a.global){n("event",t,i);return}else{const l=await e,u=Object.assign(Object.assign({},i),{send_to:l});n("event",t,u)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function jM(){if(_A())try{await yA()}catch(n){return Nn.warn(qn.create("indexeddb-unavailable",{errorInfo:n==null?void 0:n.toString()}).message),!1}else return Nn.warn(qn.create("indexeddb-unavailable",{errorInfo:"IndexedDB is not available in this environment."}).message),!1;return!0}async function zM(n,e,t,i,a,l,u){var d;const m=MM(n);m.then(x=>{t[x.measurementId]=x.appId,n.options.measurementId&&x.measurementId!==n.options.measurementId&&Nn.warn(`The measurement ID in the local Firebase config (${n.options.measurementId}) does not match the measurement ID fetched from the server (${x.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(x=>Nn.error(x)),e.push(m);const p=jM().then(x=>{if(x)return i.getId()}),[y,T]=await Promise.all([m,p]);xM(l)||bM(l,y.measurementId),a("js",new Date);const w=(d=u==null?void 0:u.config)!==null&&d!==void 0?d:{};return w[gM]="firebase",w.update=!0,T!=null&&(w[pM]=T),a("config",y.measurementId,w),y.measurementId}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class FM{constructor(e){this.app=e}_delete(){return delete eu[this.app.options.appId],Promise.resolve()}}let eu={},Ab=[];const Rb={};let Vg="dataLayer",BM="gtag",Cb,KA,xb=!1;function qM(){const n=[];if(pA()&&n.push("This is a browser extension environment."),aD()||n.push("Cookies are not available."),n.length>0){const e=n.map((i,a)=>`(${a+1}) ${i}`).join(" "),t=qn.create("invalid-analytics-context",{errorInfo:e});Nn.warn(t.message)}}function HM(n,e,t){qM();const i=n.options.appId;if(!i)throw qn.create("no-app-id");if(!n.options.apiKey)if(n.options.measurementId)Nn.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${n.options.measurementId} provided in the "measurementId" field in the local Firebase config.`);else throw qn.create("no-api-key");if(eu[i]!=null)throw qn.create("already-exists",{id:i});if(!xb){wM(Vg);const{wrappedGtag:l,gtagCore:u}=CM(eu,Ab,Rb,Vg,BM);KA=l,Cb=u,xb=!0}return eu[i]=zM(n,Ab,Rb,e,Cb,Vg,t),new FM(n)}function GM(n=Vu()){n=at(n);const e=qs(n,af);return e.isInitialized()?e.getImmediate():$M(n)}function $M(n,e={}){const t=qs(n,af);if(t.isInitialized()){const a=t.getImmediate();if(Ps(e,t.getOptions()))return a;throw qn.create("already-initialized")}return t.initialize({options:e})}function KM(n,e,t,i){n=at(n),UM(KA,eu[n.app.options.appId],e,t,i).catch(a=>Nn.error(a))}const Ib="@firebase/analytics",Nb="0.10.12";function QM(){ri(new Hn(af,(e,{options:t})=>{const i=e.getProvider("app").getImmediate(),a=e.getProvider("installations-internal").getImmediate();return HM(i,a,t)},"PUBLIC")),ri(new Hn("analytics-internal",n,"PRIVATE")),pn(Ib,Nb),pn(Ib,Nb,"esm2017");function n(e){try{const t=e.getProvider(af).getImmediate();return{logEvent:(i,a,l)=>KM(t,i,a,l)}}catch(t){throw qn.create("interop-component-reg-failed",{reason:t})}}}QM();var kb=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var xr,QA;(function(){var n;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(M,A){function C(){}C.prototype=A.prototype,M.D=A.prototype,M.prototype=new C,M.prototype.constructor=M,M.C=function(N,L,z){for(var D=Array(arguments.length-2),tt=2;tt<arguments.length;tt++)D[tt-2]=arguments[tt];return A.prototype[L].apply(N,D)}}function t(){this.blockSize=-1}function i(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.B=Array(this.blockSize),this.o=this.h=0,this.s()}e(i,t),i.prototype.s=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function a(M,A,C){C||(C=0);var N=Array(16);if(typeof A=="string")for(var L=0;16>L;++L)N[L]=A.charCodeAt(C++)|A.charCodeAt(C++)<<8|A.charCodeAt(C++)<<16|A.charCodeAt(C++)<<24;else for(L=0;16>L;++L)N[L]=A[C++]|A[C++]<<8|A[C++]<<16|A[C++]<<24;A=M.g[0],C=M.g[1],L=M.g[2];var z=M.g[3],D=A+(z^C&(L^z))+N[0]+3614090360&4294967295;A=C+(D<<7&4294967295|D>>>25),D=z+(L^A&(C^L))+N[1]+3905402710&4294967295,z=A+(D<<12&4294967295|D>>>20),D=L+(C^z&(A^C))+N[2]+606105819&4294967295,L=z+(D<<17&4294967295|D>>>15),D=C+(A^L&(z^A))+N[3]+3250441966&4294967295,C=L+(D<<22&4294967295|D>>>10),D=A+(z^C&(L^z))+N[4]+4118548399&4294967295,A=C+(D<<7&4294967295|D>>>25),D=z+(L^A&(C^L))+N[5]+1200080426&4294967295,z=A+(D<<12&4294967295|D>>>20),D=L+(C^z&(A^C))+N[6]+2821735955&4294967295,L=z+(D<<17&4294967295|D>>>15),D=C+(A^L&(z^A))+N[7]+4249261313&4294967295,C=L+(D<<22&4294967295|D>>>10),D=A+(z^C&(L^z))+N[8]+1770035416&4294967295,A=C+(D<<7&4294967295|D>>>25),D=z+(L^A&(C^L))+N[9]+2336552879&4294967295,z=A+(D<<12&4294967295|D>>>20),D=L+(C^z&(A^C))+N[10]+4294925233&4294967295,L=z+(D<<17&4294967295|D>>>15),D=C+(A^L&(z^A))+N[11]+2304563134&4294967295,C=L+(D<<22&4294967295|D>>>10),D=A+(z^C&(L^z))+N[12]+1804603682&4294967295,A=C+(D<<7&4294967295|D>>>25),D=z+(L^A&(C^L))+N[13]+4254626195&4294967295,z=A+(D<<12&4294967295|D>>>20),D=L+(C^z&(A^C))+N[14]+2792965006&4294967295,L=z+(D<<17&4294967295|D>>>15),D=C+(A^L&(z^A))+N[15]+1236535329&4294967295,C=L+(D<<22&4294967295|D>>>10),D=A+(L^z&(C^L))+N[1]+4129170786&4294967295,A=C+(D<<5&4294967295|D>>>27),D=z+(C^L&(A^C))+N[6]+3225465664&4294967295,z=A+(D<<9&4294967295|D>>>23),D=L+(A^C&(z^A))+N[11]+643717713&4294967295,L=z+(D<<14&4294967295|D>>>18),D=C+(z^A&(L^z))+N[0]+3921069994&4294967295,C=L+(D<<20&4294967295|D>>>12),D=A+(L^z&(C^L))+N[5]+3593408605&4294967295,A=C+(D<<5&4294967295|D>>>27),D=z+(C^L&(A^C))+N[10]+38016083&4294967295,z=A+(D<<9&4294967295|D>>>23),D=L+(A^C&(z^A))+N[15]+3634488961&4294967295,L=z+(D<<14&4294967295|D>>>18),D=C+(z^A&(L^z))+N[4]+3889429448&4294967295,C=L+(D<<20&4294967295|D>>>12),D=A+(L^z&(C^L))+N[9]+568446438&4294967295,A=C+(D<<5&4294967295|D>>>27),D=z+(C^L&(A^C))+N[14]+3275163606&4294967295,z=A+(D<<9&4294967295|D>>>23),D=L+(A^C&(z^A))+N[3]+4107603335&4294967295,L=z+(D<<14&4294967295|D>>>18),D=C+(z^A&(L^z))+N[8]+1163531501&4294967295,C=L+(D<<20&4294967295|D>>>12),D=A+(L^z&(C^L))+N[13]+2850285829&4294967295,A=C+(D<<5&4294967295|D>>>27),D=z+(C^L&(A^C))+N[2]+4243563512&4294967295,z=A+(D<<9&4294967295|D>>>23),D=L+(A^C&(z^A))+N[7]+1735328473&4294967295,L=z+(D<<14&4294967295|D>>>18),D=C+(z^A&(L^z))+N[12]+2368359562&4294967295,C=L+(D<<20&4294967295|D>>>12),D=A+(C^L^z)+N[5]+4294588738&4294967295,A=C+(D<<4&4294967295|D>>>28),D=z+(A^C^L)+N[8]+2272392833&4294967295,z=A+(D<<11&4294967295|D>>>21),D=L+(z^A^C)+N[11]+1839030562&4294967295,L=z+(D<<16&4294967295|D>>>16),D=C+(L^z^A)+N[14]+4259657740&4294967295,C=L+(D<<23&4294967295|D>>>9),D=A+(C^L^z)+N[1]+2763975236&4294967295,A=C+(D<<4&4294967295|D>>>28),D=z+(A^C^L)+N[4]+1272893353&4294967295,z=A+(D<<11&4294967295|D>>>21),D=L+(z^A^C)+N[7]+4139469664&4294967295,L=z+(D<<16&4294967295|D>>>16),D=C+(L^z^A)+N[10]+3200236656&4294967295,C=L+(D<<23&4294967295|D>>>9),D=A+(C^L^z)+N[13]+681279174&4294967295,A=C+(D<<4&4294967295|D>>>28),D=z+(A^C^L)+N[0]+3936430074&4294967295,z=A+(D<<11&4294967295|D>>>21),D=L+(z^A^C)+N[3]+3572445317&4294967295,L=z+(D<<16&4294967295|D>>>16),D=C+(L^z^A)+N[6]+76029189&4294967295,C=L+(D<<23&4294967295|D>>>9),D=A+(C^L^z)+N[9]+3654602809&4294967295,A=C+(D<<4&4294967295|D>>>28),D=z+(A^C^L)+N[12]+3873151461&4294967295,z=A+(D<<11&4294967295|D>>>21),D=L+(z^A^C)+N[15]+530742520&4294967295,L=z+(D<<16&4294967295|D>>>16),D=C+(L^z^A)+N[2]+3299628645&4294967295,C=L+(D<<23&4294967295|D>>>9),D=A+(L^(C|~z))+N[0]+4096336452&4294967295,A=C+(D<<6&4294967295|D>>>26),D=z+(C^(A|~L))+N[7]+1126891415&4294967295,z=A+(D<<10&4294967295|D>>>22),D=L+(A^(z|~C))+N[14]+2878612391&4294967295,L=z+(D<<15&4294967295|D>>>17),D=C+(z^(L|~A))+N[5]+4237533241&4294967295,C=L+(D<<21&4294967295|D>>>11),D=A+(L^(C|~z))+N[12]+1700485571&4294967295,A=C+(D<<6&4294967295|D>>>26),D=z+(C^(A|~L))+N[3]+2399980690&4294967295,z=A+(D<<10&4294967295|D>>>22),D=L+(A^(z|~C))+N[10]+4293915773&4294967295,L=z+(D<<15&4294967295|D>>>17),D=C+(z^(L|~A))+N[1]+2240044497&4294967295,C=L+(D<<21&4294967295|D>>>11),D=A+(L^(C|~z))+N[8]+1873313359&4294967295,A=C+(D<<6&4294967295|D>>>26),D=z+(C^(A|~L))+N[15]+4264355552&4294967295,z=A+(D<<10&4294967295|D>>>22),D=L+(A^(z|~C))+N[6]+2734768916&4294967295,L=z+(D<<15&4294967295|D>>>17),D=C+(z^(L|~A))+N[13]+1309151649&4294967295,C=L+(D<<21&4294967295|D>>>11),D=A+(L^(C|~z))+N[4]+4149444226&4294967295,A=C+(D<<6&4294967295|D>>>26),D=z+(C^(A|~L))+N[11]+3174756917&4294967295,z=A+(D<<10&4294967295|D>>>22),D=L+(A^(z|~C))+N[2]+718787259&4294967295,L=z+(D<<15&4294967295|D>>>17),D=C+(z^(L|~A))+N[9]+3951481745&4294967295,M.g[0]=M.g[0]+A&4294967295,M.g[1]=M.g[1]+(L+(D<<21&4294967295|D>>>11))&4294967295,M.g[2]=M.g[2]+L&4294967295,M.g[3]=M.g[3]+z&4294967295}i.prototype.u=function(M,A){A===void 0&&(A=M.length);for(var C=A-this.blockSize,N=this.B,L=this.h,z=0;z<A;){if(L==0)for(;z<=C;)a(this,M,z),z+=this.blockSize;if(typeof M=="string"){for(;z<A;)if(N[L++]=M.charCodeAt(z++),L==this.blockSize){a(this,N),L=0;break}}else for(;z<A;)if(N[L++]=M[z++],L==this.blockSize){a(this,N),L=0;break}}this.h=L,this.o+=A},i.prototype.v=function(){var M=Array((56>this.h?this.blockSize:2*this.blockSize)-this.h);M[0]=128;for(var A=1;A<M.length-8;++A)M[A]=0;var C=8*this.o;for(A=M.length-8;A<M.length;++A)M[A]=C&255,C/=256;for(this.u(M),M=Array(16),A=C=0;4>A;++A)for(var N=0;32>N;N+=8)M[C++]=this.g[A]>>>N&255;return M};function l(M,A){var C=d;return Object.prototype.hasOwnProperty.call(C,M)?C[M]:C[M]=A(M)}function u(M,A){this.h=A;for(var C=[],N=!0,L=M.length-1;0<=L;L--){var z=M[L]|0;N&&z==A||(C[L]=z,N=!1)}this.g=C}var d={};function m(M){return-128<=M&&128>M?l(M,function(A){return new u([A|0],0>A?-1:0)}):new u([M|0],0>M?-1:0)}function p(M){if(isNaN(M)||!isFinite(M))return T;if(0>M)return P(p(-M));for(var A=[],C=1,N=0;M>=C;N++)A[N]=M/C|0,C*=4294967296;return new u(A,0)}function y(M,A){if(M.length==0)throw Error("number format error: empty string");if(A=A||10,2>A||36<A)throw Error("radix out of range: "+A);if(M.charAt(0)=="-")return P(y(M.substring(1),A));if(0<=M.indexOf("-"))throw Error('number format error: interior "-" character');for(var C=p(Math.pow(A,8)),N=T,L=0;L<M.length;L+=8){var z=Math.min(8,M.length-L),D=parseInt(M.substring(L,L+z),A);8>z?(z=p(Math.pow(A,z)),N=N.j(z).add(p(D))):(N=N.j(C),N=N.add(p(D)))}return N}var T=m(0),w=m(1),x=m(16777216);n=u.prototype,n.m=function(){if(O(this))return-P(this).m();for(var M=0,A=1,C=0;C<this.g.length;C++){var N=this.i(C);M+=(0<=N?N:4294967296+N)*A,A*=4294967296}return M},n.toString=function(M){if(M=M||10,2>M||36<M)throw Error("radix out of range: "+M);if(I(this))return"0";if(O(this))return"-"+P(this).toString(M);for(var A=p(Math.pow(M,6)),C=this,N="";;){var L=W(C,A).g;C=B(C,L.j(A));var z=((0<C.g.length?C.g[0]:C.h)>>>0).toString(M);if(C=L,I(C))return z+N;for(;6>z.length;)z="0"+z;N=z+N}},n.i=function(M){return 0>M?0:M<this.g.length?this.g[M]:this.h};function I(M){if(M.h!=0)return!1;for(var A=0;A<M.g.length;A++)if(M.g[A]!=0)return!1;return!0}function O(M){return M.h==-1}n.l=function(M){return M=B(this,M),O(M)?-1:I(M)?0:1};function P(M){for(var A=M.g.length,C=[],N=0;N<A;N++)C[N]=~M.g[N];return new u(C,~M.h).add(w)}n.abs=function(){return O(this)?P(this):this},n.add=function(M){for(var A=Math.max(this.g.length,M.g.length),C=[],N=0,L=0;L<=A;L++){var z=N+(this.i(L)&65535)+(M.i(L)&65535),D=(z>>>16)+(this.i(L)>>>16)+(M.i(L)>>>16);N=D>>>16,z&=65535,D&=65535,C[L]=D<<16|z}return new u(C,C[C.length-1]&-2147483648?-1:0)};function B(M,A){return M.add(P(A))}n.j=function(M){if(I(this)||I(M))return T;if(O(this))return O(M)?P(this).j(P(M)):P(P(this).j(M));if(O(M))return P(this.j(P(M)));if(0>this.l(x)&&0>M.l(x))return p(this.m()*M.m());for(var A=this.g.length+M.g.length,C=[],N=0;N<2*A;N++)C[N]=0;for(N=0;N<this.g.length;N++)for(var L=0;L<M.g.length;L++){var z=this.i(N)>>>16,D=this.i(N)&65535,tt=M.i(L)>>>16,ze=M.i(L)&65535;C[2*N+2*L]+=D*ze,ee(C,2*N+2*L),C[2*N+2*L+1]+=z*ze,ee(C,2*N+2*L+1),C[2*N+2*L+1]+=D*tt,ee(C,2*N+2*L+1),C[2*N+2*L+2]+=z*tt,ee(C,2*N+2*L+2)}for(N=0;N<A;N++)C[N]=C[2*N+1]<<16|C[2*N];for(N=A;N<2*A;N++)C[N]=0;return new u(C,0)};function ee(M,A){for(;(M[A]&65535)!=M[A];)M[A+1]+=M[A]>>>16,M[A]&=65535,A++}function Y(M,A){this.g=M,this.h=A}function W(M,A){if(I(A))throw Error("division by zero");if(I(M))return new Y(T,T);if(O(M))return A=W(P(M),A),new Y(P(A.g),P(A.h));if(O(A))return A=W(M,P(A)),new Y(P(A.g),A.h);if(30<M.g.length){if(O(M)||O(A))throw Error("slowDivide_ only works with positive integers.");for(var C=w,N=A;0>=N.l(M);)C=re(C),N=re(N);var L=he(C,1),z=he(N,1);for(N=he(N,2),C=he(C,2);!I(N);){var D=z.add(N);0>=D.l(M)&&(L=L.add(C),z=D),N=he(N,1),C=he(C,1)}return A=B(M,L.j(A)),new Y(L,A)}for(L=T;0<=M.l(A);){for(C=Math.max(1,Math.floor(M.m()/A.m())),N=Math.ceil(Math.log(C)/Math.LN2),N=48>=N?1:Math.pow(2,N-48),z=p(C),D=z.j(A);O(D)||0<D.l(M);)C-=N,z=p(C),D=z.j(A);I(z)&&(z=w),L=L.add(z),M=B(M,D)}return new Y(L,M)}n.A=function(M){return W(this,M).h},n.and=function(M){for(var A=Math.max(this.g.length,M.g.length),C=[],N=0;N<A;N++)C[N]=this.i(N)&M.i(N);return new u(C,this.h&M.h)},n.or=function(M){for(var A=Math.max(this.g.length,M.g.length),C=[],N=0;N<A;N++)C[N]=this.i(N)|M.i(N);return new u(C,this.h|M.h)},n.xor=function(M){for(var A=Math.max(this.g.length,M.g.length),C=[],N=0;N<A;N++)C[N]=this.i(N)^M.i(N);return new u(C,this.h^M.h)};function re(M){for(var A=M.g.length+1,C=[],N=0;N<A;N++)C[N]=M.i(N)<<1|M.i(N-1)>>>31;return new u(C,M.h)}function he(M,A){var C=A>>5;A%=32;for(var N=M.g.length-C,L=[],z=0;z<N;z++)L[z]=0<A?M.i(z+C)>>>A|M.i(z+C+1)<<32-A:M.i(z+C);return new u(L,M.h)}i.prototype.digest=i.prototype.v,i.prototype.reset=i.prototype.s,i.prototype.update=i.prototype.u,QA=i,u.prototype.add=u.prototype.add,u.prototype.multiply=u.prototype.j,u.prototype.modulo=u.prototype.A,u.prototype.compare=u.prototype.l,u.prototype.toNumber=u.prototype.m,u.prototype.toString=u.prototype.toString,u.prototype.getBits=u.prototype.i,u.fromNumber=p,u.fromString=y,xr=u}).apply(typeof kb<"u"?kb:typeof self<"u"?self:typeof window<"u"?window:{});var Cd=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var YA,Yc,WA,Fd,c_,XA,ZA,JA;(function(){var n,e=typeof Object.defineProperties=="function"?Object.defineProperty:function(h,_,E){return h==Array.prototype||h==Object.prototype||(h[_]=E.value),h};function t(h){h=[typeof globalThis=="object"&&globalThis,h,typeof window=="object"&&window,typeof self=="object"&&self,typeof Cd=="object"&&Cd];for(var _=0;_<h.length;++_){var E=h[_];if(E&&E.Math==Math)return E}throw Error("Cannot find global object")}var i=t(this);function a(h,_){if(_)e:{var E=i;h=h.split(".");for(var R=0;R<h.length-1;R++){var q=h[R];if(!(q in E))break e;E=E[q]}h=h[h.length-1],R=E[h],_=_(R),_!=R&&_!=null&&e(E,h,{configurable:!0,writable:!0,value:_})}}function l(h,_){h instanceof String&&(h+="");var E=0,R=!1,q={next:function(){if(!R&&E<h.length){var Q=E++;return{value:_(Q,h[Q]),done:!1}}return R=!0,{done:!0,value:void 0}}};return q[Symbol.iterator]=function(){return q},q}a("Array.prototype.values",function(h){return h||function(){return l(this,function(_,E){return E})}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var u=u||{},d=this||self;function m(h){var _=typeof h;return _=_!="object"?_:h?Array.isArray(h)?"array":_:"null",_=="array"||_=="object"&&typeof h.length=="number"}function p(h){var _=typeof h;return _=="object"&&h!=null||_=="function"}function y(h,_,E){return h.call.apply(h.bind,arguments)}function T(h,_,E){if(!h)throw Error();if(2<arguments.length){var R=Array.prototype.slice.call(arguments,2);return function(){var q=Array.prototype.slice.call(arguments);return Array.prototype.unshift.apply(q,R),h.apply(_,q)}}return function(){return h.apply(_,arguments)}}function w(h,_,E){return w=Function.prototype.bind&&Function.prototype.bind.toString().indexOf("native code")!=-1?y:T,w.apply(null,arguments)}function x(h,_){var E=Array.prototype.slice.call(arguments,1);return function(){var R=E.slice();return R.push.apply(R,arguments),h.apply(this,R)}}function I(h,_){function E(){}E.prototype=_.prototype,h.aa=_.prototype,h.prototype=new E,h.prototype.constructor=h,h.Qb=function(R,q,Q){for(var le=Array(arguments.length-2),Fe=2;Fe<arguments.length;Fe++)le[Fe-2]=arguments[Fe];return _.prototype[q].apply(R,le)}}function O(h){const _=h.length;if(0<_){const E=Array(_);for(let R=0;R<_;R++)E[R]=h[R];return E}return[]}function P(h,_){for(let E=1;E<arguments.length;E++){const R=arguments[E];if(m(R)){const q=h.length||0,Q=R.length||0;h.length=q+Q;for(let le=0;le<Q;le++)h[q+le]=R[le]}else h.push(R)}}class B{constructor(_,E){this.i=_,this.j=E,this.h=0,this.g=null}get(){let _;return 0<this.h?(this.h--,_=this.g,this.g=_.next,_.next=null):_=this.i(),_}}function ee(h){return/^[\s\xa0]*$/.test(h)}function Y(){var h=d.navigator;return h&&(h=h.userAgent)?h:""}function W(h){return W[" "](h),h}W[" "]=function(){};var re=Y().indexOf("Gecko")!=-1&&!(Y().toLowerCase().indexOf("webkit")!=-1&&Y().indexOf("Edge")==-1)&&!(Y().indexOf("Trident")!=-1||Y().indexOf("MSIE")!=-1)&&Y().indexOf("Edge")==-1;function he(h,_,E){for(const R in h)_.call(E,h[R],R,h)}function M(h,_){for(const E in h)_.call(void 0,h[E],E,h)}function A(h){const _={};for(const E in h)_[E]=h[E];return _}const C="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function N(h,_){let E,R;for(let q=1;q<arguments.length;q++){R=arguments[q];for(E in R)h[E]=R[E];for(let Q=0;Q<C.length;Q++)E=C[Q],Object.prototype.hasOwnProperty.call(R,E)&&(h[E]=R[E])}}function L(h){var _=1;h=h.split(":");const E=[];for(;0<_&&h.length;)E.push(h.shift()),_--;return h.length&&E.push(h.join(":")),E}function z(h){d.setTimeout(()=>{throw h},0)}function D(){var h=Ke;let _=null;return h.g&&(_=h.g,h.g=h.g.next,h.g||(h.h=null),_.next=null),_}class tt{constructor(){this.h=this.g=null}add(_,E){const R=ze.get();R.set(_,E),this.h?this.h.next=R:this.g=R,this.h=R}}var ze=new B(()=>new X,h=>h.reset());class X{constructor(){this.next=this.g=this.h=null}set(_,E){this.h=_,this.g=E,this.next=null}reset(){this.next=this.g=this.h=null}}let ce,ge=!1,Ke=new tt,V=()=>{const h=d.Promise.resolve(void 0);ce=()=>{h.then(se)}};var se=()=>{for(var h;h=D();){try{h.h.call(h.g)}catch(E){z(E)}var _=ze;_.j(h),100>_.h&&(_.h++,h.next=_.g,_.g=h)}ge=!1};function ue(){this.s=this.s,this.C=this.C}ue.prototype.s=!1,ue.prototype.ma=function(){this.s||(this.s=!0,this.N())},ue.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function ae(h,_){this.type=h,this.g=this.target=_,this.defaultPrevented=!1}ae.prototype.h=function(){this.defaultPrevented=!0};var ye=function(){if(!d.addEventListener||!Object.defineProperty)return!1;var h=!1,_=Object.defineProperty({},"passive",{get:function(){h=!0}});try{const E=()=>{};d.addEventListener("test",E,_),d.removeEventListener("test",E,_)}catch{}return h}();function ke(h,_){if(ae.call(this,h?h.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,h){var E=this.type=h.type,R=h.changedTouches&&h.changedTouches.length?h.changedTouches[0]:null;if(this.target=h.target||h.srcElement,this.g=_,_=h.relatedTarget){if(re){e:{try{W(_.nodeName);var q=!0;break e}catch{}q=!1}q||(_=null)}}else E=="mouseover"?_=h.fromElement:E=="mouseout"&&(_=h.toElement);this.relatedTarget=_,R?(this.clientX=R.clientX!==void 0?R.clientX:R.pageX,this.clientY=R.clientY!==void 0?R.clientY:R.pageY,this.screenX=R.screenX||0,this.screenY=R.screenY||0):(this.clientX=h.clientX!==void 0?h.clientX:h.pageX,this.clientY=h.clientY!==void 0?h.clientY:h.pageY,this.screenX=h.screenX||0,this.screenY=h.screenY||0),this.button=h.button,this.key=h.key||"",this.ctrlKey=h.ctrlKey,this.altKey=h.altKey,this.shiftKey=h.shiftKey,this.metaKey=h.metaKey,this.pointerId=h.pointerId||0,this.pointerType=typeof h.pointerType=="string"?h.pointerType:Ae[h.pointerType]||"",this.state=h.state,this.i=h,h.defaultPrevented&&ke.aa.h.call(this)}}I(ke,ae);var Ae={2:"touch",3:"pen",4:"mouse"};ke.prototype.h=function(){ke.aa.h.call(this);var h=this.i;h.preventDefault?h.preventDefault():h.returnValue=!1};var qt="closure_listenable_"+(1e6*Math.random()|0),ct=0;function Ai(h,_,E,R,q){this.listener=h,this.proxy=null,this.src=_,this.type=E,this.capture=!!R,this.ha=q,this.key=++ct,this.da=this.fa=!1}function Hs(h){h.da=!0,h.listener=null,h.proxy=null,h.src=null,h.ha=null}function Zi(h){this.src=h,this.g={},this.h=0}Zi.prototype.add=function(h,_,E,R,q){var Q=h.toString();h=this.g[Q],h||(h=this.g[Q]=[],this.h++);var le=Qr(h,_,R,q);return-1<le?(_=h[le],E||(_.fa=!1)):(_=new Ai(_,this.src,Q,!!R,q),_.fa=E,h.push(_)),_};function Kr(h,_){var E=_.type;if(E in h.g){var R=h.g[E],q=Array.prototype.indexOf.call(R,_,void 0),Q;(Q=0<=q)&&Array.prototype.splice.call(R,q,1),Q&&(Hs(_),h.g[E].length==0&&(delete h.g[E],h.h--))}}function Qr(h,_,E,R){for(var q=0;q<h.length;++q){var Q=h[q];if(!Q.da&&Q.listener==_&&Q.capture==!!E&&Q.ha==R)return q}return-1}var Yr="closure_lm_"+(1e6*Math.random()|0),kl={};function th(h,_,E,R,q){if(Array.isArray(_)){for(var Q=0;Q<_.length;Q++)th(h,_[Q],E,R,q);return null}return E=nh(E),h&&h[qt]?h.K(_,E,p(R)?!!R.capture:!1,q):Gn(h,_,E,!1,R,q)}function Gn(h,_,E,R,q,Q){if(!_)throw Error("Invalid event type");var le=p(q)?!!q.capture:!!q,Fe=no(h);if(Fe||(h[Yr]=Fe=new Zi(h)),E=Fe.add(_,E,R,le,Q),E.proxy)return E;if(R=bm(),E.proxy=R,R.src=h,R.listener=E,h.addEventListener)ye||(q=le),q===void 0&&(q=!1),h.addEventListener(_.toString(),R,q);else if(h.attachEvent)h.attachEvent(Wr(_.toString()),R);else if(h.addListener&&h.removeListener)h.addListener(R);else throw Error("addEventListener and attachEvent are unavailable.");return E}function bm(){function h(E){return _.call(h.src,h.listener,E)}const _=wm;return h}function Dl(h,_,E,R,q){if(Array.isArray(_))for(var Q=0;Q<_.length;Q++)Dl(h,_[Q],E,R,q);else R=p(R)?!!R.capture:!!R,E=nh(E),h&&h[qt]?(h=h.i,_=String(_).toString(),_ in h.g&&(Q=h.g[_],E=Qr(Q,E,R,q),-1<E&&(Hs(Q[E]),Array.prototype.splice.call(Q,E,1),Q.length==0&&(delete h.g[_],h.h--)))):h&&(h=no(h))&&(_=h.g[_.toString()],h=-1,_&&(h=Qr(_,E,R,q)),(E=-1<h?_[h]:null)&&to(E))}function to(h){if(typeof h!="number"&&h&&!h.da){var _=h.src;if(_&&_[qt])Kr(_.i,h);else{var E=h.type,R=h.proxy;_.removeEventListener?_.removeEventListener(E,R,h.capture):_.detachEvent?_.detachEvent(Wr(E),R):_.addListener&&_.removeListener&&_.removeListener(R),(E=no(_))?(Kr(E,h),E.h==0&&(E.src=null,_[Yr]=null)):Hs(h)}}}function Wr(h){return h in kl?kl[h]:kl[h]="on"+h}function wm(h,_){if(h.da)h=!0;else{_=new ke(_,this);var E=h.listener,R=h.ha||h.src;h.fa&&to(h),h=E.call(R,_)}return h}function no(h){return h=h[Yr],h instanceof Zi?h:null}var Ol="__closure_events_fn_"+(1e9*Math.random()>>>0);function nh(h){return typeof h=="function"?h:(h[Ol]||(h[Ol]=function(_){return h.handleEvent(_)}),h[Ol])}function vt(){ue.call(this),this.i=new Zi(this),this.M=this,this.F=null}I(vt,ue),vt.prototype[qt]=!0,vt.prototype.removeEventListener=function(h,_,E,R){Dl(this,h,_,E,R)};function Ze(h,_){var E,R=h.F;if(R)for(E=[];R;R=R.F)E.push(R);if(h=h.M,R=_.type||_,typeof _=="string")_=new ae(_,h);else if(_ instanceof ae)_.target=_.target||h;else{var q=_;_=new ae(R,h),N(_,q)}if(q=!0,E)for(var Q=E.length-1;0<=Q;Q--){var le=_.g=E[Q];q=On(le,R,!0,_)&&q}if(le=_.g=h,q=On(le,R,!0,_)&&q,q=On(le,R,!1,_)&&q,E)for(Q=0;Q<E.length;Q++)le=_.g=E[Q],q=On(le,R,!1,_)&&q}vt.prototype.N=function(){if(vt.aa.N.call(this),this.i){var h=this.i,_;for(_ in h.g){for(var E=h.g[_],R=0;R<E.length;R++)Hs(E[R]);delete h.g[_],h.h--}}this.F=null},vt.prototype.K=function(h,_,E,R){return this.i.add(String(h),_,!1,E,R)},vt.prototype.L=function(h,_,E,R){return this.i.add(String(h),_,!0,E,R)};function On(h,_,E,R){if(_=h.i.g[String(_)],!_)return!0;_=_.concat();for(var q=!0,Q=0;Q<_.length;++Q){var le=_[Q];if(le&&!le.da&&le.capture==E){var Fe=le.listener,Lt=le.ha||le.src;le.fa&&Kr(h.i,le),q=Fe.call(Lt,R)!==!1&&q}}return q&&!R.defaultPrevented}function ln(h,_,E){if(typeof h=="function")E&&(h=w(h,E));else if(h&&typeof h.handleEvent=="function")h=w(h.handleEvent,h);else throw Error("Invalid listener argument");return 2147483647<Number(_)?-1:d.setTimeout(h,_||0)}function ih(h){h.g=ln(()=>{h.g=null,h.i&&(h.i=!1,ih(h))},h.l);const _=h.h;h.h=null,h.m.apply(null,_)}class Sm extends ue{constructor(_,E){super(),this.m=_,this.l=E,this.h=null,this.i=!1,this.g=null}j(_){this.h=arguments,this.g?this.i=!0:ih(this)}N(){super.N(),this.g&&(d.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function Xr(h){ue.call(this),this.h=h,this.g={}}I(Xr,ue);var Zr=[];function Jr(h){he(h.g,function(_,E){this.g.hasOwnProperty(E)&&to(_)},h),h.g={}}Xr.prototype.N=function(){Xr.aa.N.call(this),Jr(this)},Xr.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var li=d.JSON.stringify,io=d.JSON.parse,ea=class{stringify(h){return d.JSON.stringify(h,void 0)}parse(h){return d.JSON.parse(h,void 0)}};function Ml(){}Ml.prototype.h=null;function Pl(h){return h.h||(h.h=h.i())}function Ll(){}var Ji={OPEN:"a",kb:"b",Ja:"c",wb:"d"};function es(){ae.call(this,"d")}I(es,ae);function Vl(){ae.call(this,"c")}I(Vl,ae);var Ri={},Ul=null;function Gs(){return Ul=Ul||new vt}Ri.La="serverreachability";function so(h){ae.call(this,Ri.La,h)}I(so,ae);function $s(h){const _=Gs();Ze(_,new so(_))}Ri.STAT_EVENT="statevent";function sh(h,_){ae.call(this,Ri.STAT_EVENT,h),this.stat=_}I(sh,ae);function mt(h){const _=Gs();Ze(_,new sh(_,h))}Ri.Ma="timingevent";function Pt(h,_){ae.call(this,Ri.Ma,h),this.size=_}I(Pt,ae);function Ct(h,_){if(typeof h!="function")throw Error("Fn must not be null and must be a function");return d.setTimeout(function(){h()},_)}function $n(){this.g=!0}$n.prototype.xa=function(){this.g=!1};function jl(h,_,E,R,q,Q){h.info(function(){if(h.g)if(Q)for(var le="",Fe=Q.split("&"),Lt=0;Lt<Fe.length;Lt++){var Be=Fe[Lt].split("=");if(1<Be.length){var Gt=Be[0];Be=Be[1];var Vt=Gt.split("_");le=2<=Vt.length&&Vt[1]=="type"?le+(Gt+"="+Be+"&"):le+(Gt+"=redacted&")}}else le=null;else le=Q;return"XMLHTTP REQ ("+R+") [attempt "+q+"]: "+_+`
`+E+`
`+le})}function Am(h,_,E,R,q,Q,le){h.info(function(){return"XMLHTTP RESP ("+R+") [ attempt "+q+"]: "+_+`
`+E+`
`+Q+" "+le})}function Ks(h,_,E,R){h.info(function(){return"XMLHTTP TEXT ("+_+"): "+ta(h,E)+(R?" "+R:"")})}function rh(h,_){h.info(function(){return"TIMEOUT: "+_})}$n.prototype.info=function(){};function ta(h,_){if(!h.g)return _;if(!_)return null;try{var E=JSON.parse(_);if(E){for(h=0;h<E.length;h++)if(Array.isArray(E[h])){var R=E[h];if(!(2>R.length)){var q=R[1];if(Array.isArray(q)&&!(1>q.length)){var Q=q[0];if(Q!="noop"&&Q!="stop"&&Q!="close")for(var le=1;le<q.length;le++)q[le]=""}}}}return li(E)}catch{return _}}var Qs={NO_ERROR:0,gb:1,tb:2,sb:3,nb:4,rb:5,ub:6,Ia:7,TIMEOUT:8,xb:9},ts={lb:"complete",Hb:"success",Ja:"error",Ia:"abort",zb:"ready",Ab:"readystatechange",TIMEOUT:"timeout",vb:"incrementaldata",yb:"progress",ob:"downloadprogress",Pb:"uploadprogress"},Ci;function xi(){}I(xi,Ml),xi.prototype.g=function(){return new XMLHttpRequest},xi.prototype.i=function(){return{}},Ci=new xi;function _n(h,_,E,R){this.j=h,this.i=_,this.l=E,this.R=R||1,this.U=new Xr(this),this.I=45e3,this.H=null,this.o=!1,this.m=this.A=this.v=this.L=this.F=this.S=this.B=null,this.D=[],this.g=null,this.C=0,this.s=this.u=null,this.X=-1,this.J=!1,this.O=0,this.M=null,this.W=this.K=this.T=this.P=!1,this.h=new bt}function bt(){this.i=null,this.g="",this.h=!1}var zl={},ro={};function ci(h,_,E){h.L=1,h.v=aa(Mn(_)),h.m=E,h.P=!0,ns(h,null)}function ns(h,_){h.F=Date.now(),na(h),h.A=Mn(h.v);var E=h.A,R=h.R;Array.isArray(R)||(R=[String(R)]),$l(E.i,"t",R),h.C=0,E=h.j.J,h.h=new bt,h.g=Th(h.j,E?_:null,!h.m),0<h.O&&(h.M=new Sm(w(h.Y,h,h.g),h.O)),_=h.U,E=h.g,R=h.ca;var q="readystatechange";Array.isArray(q)||(q&&(Zr[0]=q.toString()),q=Zr);for(var Q=0;Q<q.length;Q++){var le=th(E,q[Q],R||_.handleEvent,!1,_.h||_);if(!le)break;_.g[le.key]=le}_=h.H?A(h.H):{},h.m?(h.u||(h.u="POST"),_["Content-Type"]="application/x-www-form-urlencoded",h.g.ea(h.A,h.u,h.m,_)):(h.u="GET",h.g.ea(h.A,h.u,null,_)),$s(),jl(h.i,h.u,h.A,h.l,h.R,h.m)}_n.prototype.ca=function(h){h=h.target;const _=this.M;_&&Wn(h)==3?_.j():this.Y(h)},_n.prototype.Y=function(h){try{if(h==this.g)e:{const Vt=Wn(this.g);var _=this.g.Ba();const us=this.g.Z();if(!(3>Vt)&&(Vt!=3||this.g&&(this.h.h||this.g.oa()||fh(this.g)))){this.J||Vt!=4||_==7||(_==8||0>=us?$s(3):$s(2)),Ys(this);var E=this.g.Z();this.X=E;t:if(ah(this)){var R=fh(this.g);h="";var q=R.length,Q=Wn(this.g)==4;if(!this.h.i){if(typeof TextDecoder>"u"){Jt(this),Ii(this);var le="";break t}this.h.i=new d.TextDecoder}for(_=0;_<q;_++)this.h.h=!0,h+=this.h.i.decode(R[_],{stream:!(Q&&_==q-1)});R.length=0,this.h.g+=h,this.C=0,le=this.h.g}else le=this.g.oa();if(this.o=E==200,Am(this.i,this.u,this.A,this.l,this.R,Vt,E),this.o){if(this.T&&!this.K){t:{if(this.g){var Fe,Lt=this.g;if((Fe=Lt.g?Lt.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!ee(Fe)){var Be=Fe;break t}}Be=null}if(E=Be)Ks(this.i,this.l,E,"Initial handshake response via X-HTTP-Initial-Response"),this.K=!0,ia(this,E);else{this.o=!1,this.s=3,mt(12),Jt(this),Ii(this);break e}}if(this.P){E=!0;let en;for(;!this.J&&this.C<le.length;)if(en=oh(this,le),en==ro){Vt==4&&(this.s=4,mt(14),E=!1),Ks(this.i,this.l,null,"[Incomplete Response]");break}else if(en==zl){this.s=4,mt(15),Ks(this.i,this.l,le,"[Invalid Chunk]"),E=!1;break}else Ks(this.i,this.l,en,null),ia(this,en);if(ah(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),Vt!=4||le.length!=0||this.h.h||(this.s=1,mt(16),E=!1),this.o=this.o&&E,!E)Ks(this.i,this.l,le,"[Invalid Chunked Response]"),Jt(this),Ii(this);else if(0<le.length&&!this.W){this.W=!0;var Gt=this.j;Gt.g==this&&Gt.ba&&!Gt.M&&(Gt.j.info("Great, no buffering proxy detected. Bytes received: "+le.length),ma(Gt),Gt.M=!0,mt(11))}}else Ks(this.i,this.l,le,null),ia(this,le);Vt==4&&Jt(this),this.o&&!this.J&&(Vt==4?yh(this.j,this):(this.o=!1,na(this)))}else Nm(this.g),E==400&&0<le.indexOf("Unknown SID")?(this.s=3,mt(12)):(this.s=0,mt(13)),Jt(this),Ii(this)}}}catch{}finally{}};function ah(h){return h.g?h.u=="GET"&&h.L!=2&&h.j.Ca:!1}function oh(h,_){var E=h.C,R=_.indexOf(`
`,E);return R==-1?ro:(E=Number(_.substring(E,R)),isNaN(E)?zl:(R+=1,R+E>_.length?ro:(_=_.slice(R,R+E),h.C=R+E,_)))}_n.prototype.cancel=function(){this.J=!0,Jt(this)};function na(h){h.S=Date.now()+h.I,lh(h,h.I)}function lh(h,_){if(h.B!=null)throw Error("WatchDog timer not null");h.B=Ct(w(h.ba,h),_)}function Ys(h){h.B&&(d.clearTimeout(h.B),h.B=null)}_n.prototype.ba=function(){this.B=null;const h=Date.now();0<=h-this.S?(rh(this.i,this.A),this.L!=2&&($s(),mt(17)),Jt(this),this.s=2,Ii(this)):lh(this,this.S-h)};function Ii(h){h.j.G==0||h.J||yh(h.j,h)}function Jt(h){Ys(h);var _=h.M;_&&typeof _.ma=="function"&&_.ma(),h.M=null,Jr(h.U),h.g&&(_=h.g,h.g=null,_.abort(),_.ma())}function ia(h,_){try{var E=h.j;if(E.G!=0&&(E.g==h||Fl(E.h,h))){if(!h.K&&Fl(E.h,h)&&E.G==3){try{var R=E.Da.g.parse(_)}catch{R=null}if(Array.isArray(R)&&R.length==3){var q=R;if(q[0]==0){e:if(!E.u){if(E.g)if(E.g.F+3e3<h.F)yo(E),go(E);else break e;Xl(E),mt(18)}}else E.za=q[1],0<E.za-E.T&&37500>q[2]&&E.F&&E.v==0&&!E.C&&(E.C=Ct(w(E.Za,E),6e3));if(1>=oo(E.h)&&E.ca){try{E.ca()}catch{}E.ca=void 0}}else cs(E,11)}else if((h.K||E.g==h)&&yo(E),!ee(_))for(q=E.Da.g.parse(_),_=0;_<q.length;_++){let Be=q[_];if(E.T=Be[0],Be=Be[1],E.G==2)if(Be[0]=="c"){E.K=Be[1],E.ia=Be[2];const Gt=Be[3];Gt!=null&&(E.la=Gt,E.j.info("VER="+E.la));const Vt=Be[4];Vt!=null&&(E.Aa=Vt,E.j.info("SVER="+E.Aa));const us=Be[5];us!=null&&typeof us=="number"&&0<us&&(R=1.5*us,E.L=R,E.j.info("backChannelRequestTimeoutMs_="+R)),R=E;const en=h.g;if(en){const Li=en.g?en.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Li){var Q=R.h;Q.g||Li.indexOf("spdy")==-1&&Li.indexOf("quic")==-1&&Li.indexOf("h2")==-1||(Q.j=Q.l,Q.g=new Set,Q.h&&(lo(Q,Q.h),Q.h=null))}if(R.D){const Jl=en.g?en.g.getResponseHeader("X-HTTP-Session-Id"):null;Jl&&(R.ya=Jl,nt(R.I,R.D,Jl))}}E.G=3,E.l&&E.l.ua(),E.ba&&(E.R=Date.now()-h.F,E.j.info("Handshake RTT: "+E.R+"ms")),R=E;var le=h;if(R.qa=Eh(R,R.J?R.ia:null,R.W),le.K){yn(R.h,le);var Fe=le,Lt=R.L;Lt&&(Fe.I=Lt),Fe.B&&(Ys(Fe),na(Fe)),R.g=le}else gh(R);0<E.i.length&&_o(E)}else Be[0]!="stop"&&Be[0]!="close"||cs(E,7);else E.G==3&&(Be[0]=="stop"||Be[0]=="close"?Be[0]=="stop"?cs(E,7):Yl(E):Be[0]!="noop"&&E.l&&E.l.ta(Be),E.v=0)}}$s(4)}catch{}}var ch=class{constructor(h,_){this.g=h,this.map=_}};function is(h){this.l=h||10,d.PerformanceNavigationTiming?(h=d.performance.getEntriesByType("navigation"),h=0<h.length&&(h[0].nextHopProtocol=="hq"||h[0].nextHopProtocol=="h2")):h=!!(d.chrome&&d.chrome.loadTimes&&d.chrome.loadTimes()&&d.chrome.loadTimes().wasFetchedViaSpdy),this.j=h?this.l:1,this.g=null,1<this.j&&(this.g=new Set),this.h=null,this.i=[]}function ao(h){return h.h?!0:h.g?h.g.size>=h.j:!1}function oo(h){return h.h?1:h.g?h.g.size:0}function Fl(h,_){return h.h?h.h==_:h.g?h.g.has(_):!1}function lo(h,_){h.g?h.g.add(_):h.h=_}function yn(h,_){h.h&&h.h==_?h.h=null:h.g&&h.g.has(_)&&h.g.delete(_)}is.prototype.cancel=function(){if(this.i=Bl(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const h of this.g.values())h.cancel();this.g.clear()}};function Bl(h){if(h.h!=null)return h.i.concat(h.h.D);if(h.g!=null&&h.g.size!==0){let _=h.i;for(const E of h.g.values())_=_.concat(E.D);return _}return O(h.i)}function Rm(h){if(h.V&&typeof h.V=="function")return h.V();if(typeof Map<"u"&&h instanceof Map||typeof Set<"u"&&h instanceof Set)return Array.from(h.values());if(typeof h=="string")return h.split("");if(m(h)){for(var _=[],E=h.length,R=0;R<E;R++)_.push(h[R]);return _}_=[],E=0;for(R in h)_[E++]=h[R];return _}function co(h){if(h.na&&typeof h.na=="function")return h.na();if(!h.V||typeof h.V!="function"){if(typeof Map<"u"&&h instanceof Map)return Array.from(h.keys());if(!(typeof Set<"u"&&h instanceof Set)){if(m(h)||typeof h=="string"){var _=[];h=h.length;for(var E=0;E<h;E++)_.push(E);return _}_=[],E=0;for(const R in h)_[E++]=R;return _}}}function ql(h,_){if(h.forEach&&typeof h.forEach=="function")h.forEach(_,void 0);else if(m(h)||typeof h=="string")Array.prototype.forEach.call(h,_,void 0);else for(var E=co(h),R=Rm(h),q=R.length,Q=0;Q<q;Q++)_.call(void 0,R[Q],E&&E[Q],h)}var sa=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Cm(h,_){if(h){h=h.split("&");for(var E=0;E<h.length;E++){var R=h[E].indexOf("="),q=null;if(0<=R){var Q=h[E].substring(0,R);q=h[E].substring(R+1)}else Q=h[E];_(Q,q?decodeURIComponent(q.replace(/\+/g," ")):"")}}}function xt(h){if(this.g=this.o=this.j="",this.s=null,this.m=this.l="",this.h=!1,h instanceof xt){this.h=h.h,ra(this,h.j),this.o=h.o,this.g=h.g,Ws(this,h.s),this.l=h.l;var _=h.i,E=new rs;E.i=_.i,_.g&&(E.g=new Map(_.g),E.h=_.h),ss(this,E),this.m=h.m}else h&&(_=String(h).match(sa))?(this.h=!1,ra(this,_[1]||"",!0),this.o=Kn(_[2]||""),this.g=Kn(_[3]||"",!0),Ws(this,_[4]),this.l=Kn(_[5]||"",!0),ss(this,_[6]||"",!0),this.m=Kn(_[7]||"")):(this.h=!1,this.i=new rs(null,this.h))}xt.prototype.toString=function(){var h=[],_=this.j;_&&h.push(oa(_,Hl,!0),":");var E=this.g;return(E||_=="file")&&(h.push("//"),(_=this.o)&&h.push(oa(_,Hl,!0),"@"),h.push(encodeURIComponent(String(E)).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),E=this.s,E!=null&&h.push(":",String(E))),(E=this.l)&&(this.g&&E.charAt(0)!="/"&&h.push("/"),h.push(oa(E,E.charAt(0)=="/"?xm:Gl,!0))),(E=this.i.toString())&&h.push("?",E),(E=this.m)&&h.push("#",oa(E,uo)),h.join("")};function Mn(h){return new xt(h)}function ra(h,_,E){h.j=E?Kn(_,!0):_,h.j&&(h.j=h.j.replace(/:$/,""))}function Ws(h,_){if(_){if(_=Number(_),isNaN(_)||0>_)throw Error("Bad port number "+_);h.s=_}else h.s=null}function ss(h,_,E){_ instanceof rs?(h.i=_,hh(h.i,h.h)):(E||(_=oa(_,Im)),h.i=new rs(_,h.h))}function nt(h,_,E){h.i.set(_,E)}function aa(h){return nt(h,"zx",Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)),h}function Kn(h,_){return h?_?decodeURI(h.replace(/%25/g,"%2525")):decodeURIComponent(h):""}function oa(h,_,E){return typeof h=="string"?(h=encodeURI(h).replace(_,uh),E&&(h=h.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),h):null}function uh(h){return h=h.charCodeAt(0),"%"+(h>>4&15).toString(16)+(h&15).toString(16)}var Hl=/[#\/\?@]/g,Gl=/[#\?:]/g,xm=/[#\?]/g,Im=/[#\?@]/g,uo=/#/g;function rs(h,_){this.h=this.g=null,this.i=h||null,this.j=!!_}function Qn(h){h.g||(h.g=new Map,h.h=0,h.i&&Cm(h.i,function(_,E){h.add(decodeURIComponent(_.replace(/\+/g," ")),E)}))}n=rs.prototype,n.add=function(h,_){Qn(this),this.i=null,h=Ni(this,h);var E=this.g.get(h);return E||this.g.set(h,E=[]),E.push(_),this.h+=1,this};function as(h,_){Qn(h),_=Ni(h,_),h.g.has(_)&&(h.i=null,h.h-=h.g.get(_).length,h.g.delete(_))}function os(h,_){return Qn(h),_=Ni(h,_),h.g.has(_)}n.forEach=function(h,_){Qn(this),this.g.forEach(function(E,R){E.forEach(function(q){h.call(_,q,R,this)},this)},this)},n.na=function(){Qn(this);const h=Array.from(this.g.values()),_=Array.from(this.g.keys()),E=[];for(let R=0;R<_.length;R++){const q=h[R];for(let Q=0;Q<q.length;Q++)E.push(_[R])}return E},n.V=function(h){Qn(this);let _=[];if(typeof h=="string")os(this,h)&&(_=_.concat(this.g.get(Ni(this,h))));else{h=Array.from(this.g.values());for(let E=0;E<h.length;E++)_=_.concat(h[E])}return _},n.set=function(h,_){return Qn(this),this.i=null,h=Ni(this,h),os(this,h)&&(this.h-=this.g.get(h).length),this.g.set(h,[_]),this.h+=1,this},n.get=function(h,_){return h?(h=this.V(h),0<h.length?String(h[0]):_):_};function $l(h,_,E){as(h,_),0<E.length&&(h.i=null,h.g.set(Ni(h,_),O(E)),h.h+=E.length)}n.toString=function(){if(this.i)return this.i;if(!this.g)return"";const h=[],_=Array.from(this.g.keys());for(var E=0;E<_.length;E++){var R=_[E];const Q=encodeURIComponent(String(R)),le=this.V(R);for(R=0;R<le.length;R++){var q=Q;le[R]!==""&&(q+="="+encodeURIComponent(String(le[R]))),h.push(q)}}return this.i=h.join("&")};function Ni(h,_){return _=String(_),h.j&&(_=_.toLowerCase()),_}function hh(h,_){_&&!h.j&&(Qn(h),h.i=null,h.g.forEach(function(E,R){var q=R.toLowerCase();R!=q&&(as(this,R),$l(this,q,E))},h)),h.j=_}function la(h,_){const E=new $n;if(d.Image){const R=new Image;R.onload=x(Yn,E,"TestLoadImage: loaded",!0,_,R),R.onerror=x(Yn,E,"TestLoadImage: error",!1,_,R),R.onabort=x(Yn,E,"TestLoadImage: abort",!1,_,R),R.ontimeout=x(Yn,E,"TestLoadImage: timeout",!1,_,R),d.setTimeout(function(){R.ontimeout&&R.ontimeout()},1e4),R.src=h}else _(!1)}function ui(h,_){const E=new $n,R=new AbortController,q=setTimeout(()=>{R.abort(),Yn(E,"TestPingServer: timeout",!1,_)},1e4);fetch(h,{signal:R.signal}).then(Q=>{clearTimeout(q),Q.ok?Yn(E,"TestPingServer: ok",!0,_):Yn(E,"TestPingServer: server error",!1,_)}).catch(()=>{clearTimeout(q),Yn(E,"TestPingServer: error",!1,_)})}function Yn(h,_,E,R,q){try{q&&(q.onload=null,q.onerror=null,q.onabort=null,q.ontimeout=null),R(E)}catch{}}function ca(){this.g=new ea}function ki(h,_,E){const R=E||"";try{ql(h,function(q,Q){let le=q;p(q)&&(le=li(q)),_.push(R+Q+"="+encodeURIComponent(le))})}catch(q){throw _.push(R+"type="+encodeURIComponent("_badmap")),q}}function Xs(h){this.l=h.Ub||null,this.j=h.eb||!1}I(Xs,Ml),Xs.prototype.g=function(){return new ls(this.l,this.j)},Xs.prototype.i=function(h){return function(){return h}}({});function ls(h,_){vt.call(this),this.D=h,this.o=_,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.u=new Headers,this.h=null,this.B="GET",this.A="",this.g=!1,this.v=this.j=this.l=null}I(ls,vt),n=ls.prototype,n.open=function(h,_){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.B=h,this.A=_,this.readyState=1,Oi(this)},n.send=function(h){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");this.g=!0;const _={headers:this.u,method:this.B,credentials:this.m,cache:void 0};h&&(_.body=h),(this.D||d).fetch(new Request(this.A,_)).then(this.Sa.bind(this),this.ga.bind(this))},n.abort=function(){this.response=this.responseText="",this.u=new Headers,this.status=0,this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),1<=this.readyState&&this.g&&this.readyState!=4&&(this.g=!1,Di(this)),this.readyState=0},n.Sa=function(h){if(this.g&&(this.l=h,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=h.headers,this.readyState=2,Oi(this)),this.g&&(this.readyState=3,Oi(this),this.g)))if(this.responseType==="arraybuffer")h.arrayBuffer().then(this.Qa.bind(this),this.ga.bind(this));else if(typeof d.ReadableStream<"u"&&"body"in h){if(this.j=h.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.v=new TextDecoder;Kl(this)}else h.text().then(this.Ra.bind(this),this.ga.bind(this))};function Kl(h){h.j.read().then(h.Pa.bind(h)).catch(h.ga.bind(h))}n.Pa=function(h){if(this.g){if(this.o&&h.value)this.response.push(h.value);else if(!this.o){var _=h.value?h.value:new Uint8Array(0);(_=this.v.decode(_,{stream:!h.done}))&&(this.response=this.responseText+=_)}h.done?Di(this):Oi(this),this.readyState==3&&Kl(this)}},n.Ra=function(h){this.g&&(this.response=this.responseText=h,Di(this))},n.Qa=function(h){this.g&&(this.response=h,Di(this))},n.ga=function(){this.g&&Di(this)};function Di(h){h.readyState=4,h.l=null,h.j=null,h.v=null,Oi(h)}n.setRequestHeader=function(h,_){this.u.append(h,_)},n.getResponseHeader=function(h){return this.h&&this.h.get(h.toLowerCase())||""},n.getAllResponseHeaders=function(){if(!this.h)return"";const h=[],_=this.h.entries();for(var E=_.next();!E.done;)E=E.value,h.push(E[0]+": "+E[1]),E=_.next();return h.join(`\r
`)};function Oi(h){h.onreadystatechange&&h.onreadystatechange.call(h)}Object.defineProperty(ls.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(h){this.m=h?"include":"same-origin"}});function Ql(h){let _="";return he(h,function(E,R){_+=R,_+=":",_+=E,_+=`\r
`}),_}function Ht(h,_,E){e:{for(R in E){var R=!1;break e}R=!0}R||(E=Ql(E),typeof h=="string"?E!=null&&encodeURIComponent(String(E)):nt(h,_,E))}function We(h){vt.call(this),this.headers=new Map,this.o=h||null,this.h=!1,this.v=this.g=null,this.D="",this.m=0,this.l="",this.j=this.B=this.u=this.A=!1,this.I=null,this.H="",this.J=!1}I(We,vt);var ho=/^https?$/i,ua=["POST","PUT"];n=We.prototype,n.Ha=function(h){this.J=h},n.ea=function(h,_,E,R){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+h);_=_?_.toUpperCase():"GET",this.D=h,this.l="",this.m=0,this.A=!1,this.h=!0,this.g=this.o?this.o.g():Ci.g(),this.v=this.o?Pl(this.o):Pl(Ci),this.g.onreadystatechange=w(this.Ea,this);try{this.B=!0,this.g.open(_,String(h),!0),this.B=!1}catch(Q){dh(this,Q);return}if(h=E||"",E=new Map(this.headers),R)if(Object.getPrototypeOf(R)===Object.prototype)for(var q in R)E.set(q,R[q]);else if(typeof R.keys=="function"&&typeof R.get=="function")for(const Q of R.keys())E.set(Q,R.get(Q));else throw Error("Unknown input type for opt_headers: "+String(R));R=Array.from(E.keys()).find(Q=>Q.toLowerCase()=="content-type"),q=d.FormData&&h instanceof d.FormData,!(0<=Array.prototype.indexOf.call(ua,_,void 0))||R||q||E.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[Q,le]of E)this.g.setRequestHeader(Q,le);this.H&&(this.g.responseType=this.H),"withCredentials"in this.g&&this.g.withCredentials!==this.J&&(this.g.withCredentials=this.J);try{ha(this),this.u=!0,this.g.send(h),this.u=!1}catch(Q){dh(this,Q)}};function dh(h,_){h.h=!1,h.g&&(h.j=!0,h.g.abort(),h.j=!1),h.l=_,h.m=5,fo(h),Mi(h)}function fo(h){h.A||(h.A=!0,Ze(h,"complete"),Ze(h,"error"))}n.abort=function(h){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.m=h||7,Ze(this,"complete"),Ze(this,"abort"),Mi(this))},n.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Mi(this,!0)),We.aa.N.call(this)},n.Ea=function(){this.s||(this.B||this.u||this.j?mo(this):this.bb())},n.bb=function(){mo(this)};function mo(h){if(h.h&&typeof u<"u"&&(!h.v[1]||Wn(h)!=4||h.Z()!=2)){if(h.u&&Wn(h)==4)ln(h.Ea,0,h);else if(Ze(h,"readystatechange"),Wn(h)==4){h.h=!1;try{const le=h.Z();e:switch(le){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var _=!0;break e;default:_=!1}var E;if(!(E=_)){var R;if(R=le===0){var q=String(h.D).match(sa)[1]||null;!q&&d.self&&d.self.location&&(q=d.self.location.protocol.slice(0,-1)),R=!ho.test(q?q.toLowerCase():"")}E=R}if(E)Ze(h,"complete"),Ze(h,"success");else{h.m=6;try{var Q=2<Wn(h)?h.g.statusText:""}catch{Q=""}h.l=Q+" ["+h.Z()+"]",fo(h)}}finally{Mi(h)}}}}function Mi(h,_){if(h.g){ha(h);const E=h.g,R=h.v[0]?()=>{}:null;h.g=null,h.v=null,_||Ze(h,"ready");try{E.onreadystatechange=R}catch{}}}function ha(h){h.I&&(d.clearTimeout(h.I),h.I=null)}n.isActive=function(){return!!this.g};function Wn(h){return h.g?h.g.readyState:0}n.Z=function(){try{return 2<Wn(this)?this.g.status:-1}catch{return-1}},n.oa=function(){try{return this.g?this.g.responseText:""}catch{return""}},n.Oa=function(h){if(this.g){var _=this.g.responseText;return h&&_.indexOf(h)==0&&(_=_.substring(h.length)),io(_)}};function fh(h){try{if(!h.g)return null;if("response"in h.g)return h.g.response;switch(h.H){case"":case"text":return h.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in h.g)return h.g.mozResponseArrayBuffer}return null}catch{return null}}function Nm(h){const _={};h=(h.g&&2<=Wn(h)&&h.g.getAllResponseHeaders()||"").split(`\r
`);for(let R=0;R<h.length;R++){if(ee(h[R]))continue;var E=L(h[R]);const q=E[0];if(E=E[1],typeof E!="string")continue;E=E.trim();const Q=_[q]||[];_[q]=Q,Q.push(E)}M(_,function(R){return R.join(", ")})}n.Ba=function(){return this.m},n.Ka=function(){return typeof this.l=="string"?this.l:String(this.l)};function da(h,_,E){return E&&E.internalChannelParams&&E.internalChannelParams[h]||_}function po(h){this.Aa=0,this.i=[],this.j=new $n,this.ia=this.qa=this.I=this.W=this.g=this.ya=this.D=this.H=this.m=this.S=this.o=null,this.Ya=this.U=0,this.Va=da("failFast",!1,h),this.F=this.C=this.u=this.s=this.l=null,this.X=!0,this.za=this.T=-1,this.Y=this.v=this.B=0,this.Ta=da("baseRetryDelayMs",5e3,h),this.cb=da("retryDelaySeedMs",1e4,h),this.Wa=da("forwardChannelMaxRetries",2,h),this.wa=da("forwardChannelRequestTimeoutMs",2e4,h),this.pa=h&&h.xmlHttpFactory||void 0,this.Xa=h&&h.Tb||void 0,this.Ca=h&&h.useFetchStreams||!1,this.L=void 0,this.J=h&&h.supportsCrossDomainXhr||!1,this.K="",this.h=new is(h&&h.concurrentRequestLimit),this.Da=new ca,this.P=h&&h.fastHandshake||!1,this.O=h&&h.encodeInitMessageHeaders||!1,this.P&&this.O&&(this.O=!1),this.Ua=h&&h.Rb||!1,h&&h.xa&&this.j.xa(),h&&h.forceLongPolling&&(this.X=!1),this.ba=!this.P&&this.X&&h&&h.detectBufferingProxy||!1,this.ja=void 0,h&&h.longPollingTimeout&&0<h.longPollingTimeout&&(this.ja=h.longPollingTimeout),this.ca=void 0,this.R=0,this.M=!1,this.ka=this.A=null}n=po.prototype,n.la=8,n.G=1,n.connect=function(h,_,E,R){mt(0),this.W=h,this.H=_||{},E&&R!==void 0&&(this.H.OSID=E,this.H.OAID=R),this.F=this.X,this.I=Eh(this,null,this.W),_o(this)};function Yl(h){if(mh(h),h.G==3){var _=h.U++,E=Mn(h.I);if(nt(E,"SID",h.K),nt(E,"RID",_),nt(E,"TYPE","terminate"),fa(h,E),_=new _n(h,h.j,_),_.L=2,_.v=aa(Mn(E)),E=!1,d.navigator&&d.navigator.sendBeacon)try{E=d.navigator.sendBeacon(_.v.toString(),"")}catch{}!E&&d.Image&&(new Image().src=_.v,E=!0),E||(_.g=Th(_.j,null),_.g.ea(_.v)),_.F=Date.now(),na(_)}vh(h)}function go(h){h.g&&(ma(h),h.g.cancel(),h.g=null)}function mh(h){go(h),h.u&&(d.clearTimeout(h.u),h.u=null),yo(h),h.h.cancel(),h.s&&(typeof h.s=="number"&&d.clearTimeout(h.s),h.s=null)}function _o(h){if(!ao(h.h)&&!h.s){h.s=!0;var _=h.Ga;ce||V(),ge||(ce(),ge=!0),Ke.add(_,h),h.B=0}}function km(h,_){return oo(h.h)>=h.h.j-(h.s?1:0)?!1:h.s?(h.i=_.D.concat(h.i),!0):h.G==1||h.G==2||h.B>=(h.Va?0:h.Wa)?!1:(h.s=Ct(w(h.Ga,h,_),Zl(h,h.B)),h.B++,!0)}n.Ga=function(h){if(this.s)if(this.s=null,this.G==1){if(!h){this.U=Math.floor(1e5*Math.random()),h=this.U++;const q=new _n(this,this.j,h);let Q=this.o;if(this.S&&(Q?(Q=A(Q),N(Q,this.S)):Q=this.S),this.m!==null||this.O||(q.H=Q,Q=null),this.P)e:{for(var _=0,E=0;E<this.i.length;E++){t:{var R=this.i[E];if("__data__"in R.map&&(R=R.map.__data__,typeof R=="string")){R=R.length;break t}R=void 0}if(R===void 0)break;if(_+=R,4096<_){_=E;break e}if(_===4096||E===this.i.length-1){_=E+1;break e}}_=1e3}else _=1e3;_=ph(this,q,_),E=Mn(this.I),nt(E,"RID",h),nt(E,"CVER",22),this.D&&nt(E,"X-HTTP-Session-Id",this.D),fa(this,E),Q&&(this.O?_="headers="+encodeURIComponent(String(Ql(Q)))+"&"+_:this.m&&Ht(E,this.m,Q)),lo(this.h,q),this.Ua&&nt(E,"TYPE","init"),this.P?(nt(E,"$req",_),nt(E,"SID","null"),q.T=!0,ci(q,E,null)):ci(q,E,_),this.G=2}}else this.G==3&&(h?Wl(this,h):this.i.length==0||ao(this.h)||Wl(this))};function Wl(h,_){var E;_?E=_.l:E=h.U++;const R=Mn(h.I);nt(R,"SID",h.K),nt(R,"RID",E),nt(R,"AID",h.T),fa(h,R),h.m&&h.o&&Ht(R,h.m,h.o),E=new _n(h,h.j,E,h.B+1),h.m===null&&(E.H=h.o),_&&(h.i=_.D.concat(h.i)),_=ph(h,E,1e3),E.I=Math.round(.5*h.wa)+Math.round(.5*h.wa*Math.random()),lo(h.h,E),ci(E,R,_)}function fa(h,_){h.H&&he(h.H,function(E,R){nt(_,R,E)}),h.l&&ql({},function(E,R){nt(_,R,E)})}function ph(h,_,E){E=Math.min(h.i.length,E);var R=h.l?w(h.l.Na,h.l,h):null;e:{var q=h.i;let Q=-1;for(;;){const le=["count="+E];Q==-1?0<E?(Q=q[0].g,le.push("ofs="+Q)):Q=0:le.push("ofs="+Q);let Fe=!0;for(let Lt=0;Lt<E;Lt++){let Be=q[Lt].g;const Gt=q[Lt].map;if(Be-=Q,0>Be)Q=Math.max(0,q[Lt].g-100),Fe=!1;else try{ki(Gt,le,"req"+Be+"_")}catch{R&&R(Gt)}}if(Fe){R=le.join("&");break e}}}return h=h.i.splice(0,E),_.D=h,R}function gh(h){if(!h.g&&!h.u){h.Y=1;var _=h.Fa;ce||V(),ge||(ce(),ge=!0),Ke.add(_,h),h.v=0}}function Xl(h){return h.g||h.u||3<=h.v?!1:(h.Y++,h.u=Ct(w(h.Fa,h),Zl(h,h.v)),h.v++,!0)}n.Fa=function(){if(this.u=null,_h(this),this.ba&&!(this.M||this.g==null||0>=this.R)){var h=2*this.R;this.j.info("BP detection timer enabled: "+h),this.A=Ct(w(this.ab,this),h)}},n.ab=function(){this.A&&(this.A=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.M=!0,mt(10),go(this),_h(this))};function ma(h){h.A!=null&&(d.clearTimeout(h.A),h.A=null)}function _h(h){h.g=new _n(h,h.j,"rpc",h.Y),h.m===null&&(h.g.H=h.o),h.g.O=0;var _=Mn(h.qa);nt(_,"RID","rpc"),nt(_,"SID",h.K),nt(_,"AID",h.T),nt(_,"CI",h.F?"0":"1"),!h.F&&h.ja&&nt(_,"TO",h.ja),nt(_,"TYPE","xmlhttp"),fa(h,_),h.m&&h.o&&Ht(_,h.m,h.o),h.L&&(h.g.I=h.L);var E=h.g;h=h.ia,E.L=1,E.v=aa(Mn(_)),E.m=null,E.P=!0,ns(E,h)}n.Za=function(){this.C!=null&&(this.C=null,go(this),Xl(this),mt(19))};function yo(h){h.C!=null&&(d.clearTimeout(h.C),h.C=null)}function yh(h,_){var E=null;if(h.g==_){yo(h),ma(h),h.g=null;var R=2}else if(Fl(h.h,_))E=_.D,yn(h.h,_),R=1;else return;if(h.G!=0){if(_.o)if(R==1){E=_.m?_.m.length:0,_=Date.now()-_.F;var q=h.B;R=Gs(),Ze(R,new Pt(R,E)),_o(h)}else gh(h);else if(q=_.s,q==3||q==0&&0<_.X||!(R==1&&km(h,_)||R==2&&Xl(h)))switch(E&&0<E.length&&(_=h.h,_.i=_.i.concat(E)),q){case 1:cs(h,5);break;case 4:cs(h,10);break;case 3:cs(h,6);break;default:cs(h,2)}}}function Zl(h,_){let E=h.Ta+Math.floor(Math.random()*h.cb);return h.isActive()||(E*=2),E*_}function cs(h,_){if(h.j.info("Error code "+_),_==2){var E=w(h.fb,h),R=h.Xa;const q=!R;R=new xt(R||"//www.google.com/images/cleardot.gif"),d.location&&d.location.protocol=="http"||ra(R,"https"),aa(R),q?la(R.toString(),E):ui(R.toString(),E)}else mt(2);h.G=0,h.l&&h.l.sa(_),vh(h),mh(h)}n.fb=function(h){h?(this.j.info("Successfully pinged google.com"),mt(2)):(this.j.info("Failed to ping google.com"),mt(1))};function vh(h){if(h.G=0,h.ka=[],h.l){const _=Bl(h.h);(_.length!=0||h.i.length!=0)&&(P(h.ka,_),P(h.ka,h.i),h.h.i.length=0,O(h.i),h.i.length=0),h.l.ra()}}function Eh(h,_,E){var R=E instanceof xt?Mn(E):new xt(E);if(R.g!="")_&&(R.g=_+"."+R.g),Ws(R,R.s);else{var q=d.location;R=q.protocol,_=_?_+"."+q.hostname:q.hostname,q=+q.port;var Q=new xt(null);R&&ra(Q,R),_&&(Q.g=_),q&&Ws(Q,q),E&&(Q.l=E),R=Q}return E=h.D,_=h.ya,E&&_&&nt(R,E,_),nt(R,"VER",h.la),fa(h,R),R}function Th(h,_,E){if(_&&!h.J)throw Error("Can't create secondary domain capable XhrIo object.");return _=h.Ca&&!h.pa?new We(new Xs({eb:E})):new We(h.pa),_.Ha(h.J),_}n.isActive=function(){return!!this.l&&this.l.isActive(this)};function bh(){}n=bh.prototype,n.ua=function(){},n.ta=function(){},n.sa=function(){},n.ra=function(){},n.isActive=function(){return!0},n.Na=function(){};function vo(){}vo.prototype.g=function(h,_){return new vn(h,_)};function vn(h,_){vt.call(this),this.g=new po(_),this.l=h,this.h=_&&_.messageUrlParams||null,h=_&&_.messageHeaders||null,_&&_.clientProtocolHeaderRequired&&(h?h["X-Client-Protocol"]="webchannel":h={"X-Client-Protocol":"webchannel"}),this.g.o=h,h=_&&_.initMessageHeaders||null,_&&_.messageContentType&&(h?h["X-WebChannel-Content-Type"]=_.messageContentType:h={"X-WebChannel-Content-Type":_.messageContentType}),_&&_.va&&(h?h["X-WebChannel-Client-Profile"]=_.va:h={"X-WebChannel-Client-Profile":_.va}),this.g.S=h,(h=_&&_.Sb)&&!ee(h)&&(this.g.m=h),this.v=_&&_.supportsCrossDomainXhr||!1,this.u=_&&_.sendRawJson||!1,(_=_&&_.httpSessionIdParam)&&!ee(_)&&(this.g.D=_,h=this.h,h!==null&&_ in h&&(h=this.h,_ in h&&delete h[_])),this.j=new Pi(this)}I(vn,vt),vn.prototype.m=function(){this.g.l=this.j,this.v&&(this.g.J=!0),this.g.connect(this.l,this.h||void 0)},vn.prototype.close=function(){Yl(this.g)},vn.prototype.o=function(h){var _=this.g;if(typeof h=="string"){var E={};E.__data__=h,h=E}else this.u&&(E={},E.__data__=li(h),h=E);_.i.push(new ch(_.Ya++,h)),_.G==3&&_o(_)},vn.prototype.N=function(){this.g.l=null,delete this.j,Yl(this.g),delete this.g,vn.aa.N.call(this)};function wh(h){es.call(this),h.__headers__&&(this.headers=h.__headers__,this.statusCode=h.__status__,delete h.__headers__,delete h.__status__);var _=h.__sm__;if(_){e:{for(const E in _){h=E;break e}h=void 0}(this.i=h)&&(h=this.i,_=_!==null&&h in _?_[h]:void 0),this.data=_}else this.data=h}I(wh,es);function Sh(){Vl.call(this),this.status=1}I(Sh,Vl);function Pi(h){this.g=h}I(Pi,bh),Pi.prototype.ua=function(){Ze(this.g,"a")},Pi.prototype.ta=function(h){Ze(this.g,new wh(h))},Pi.prototype.sa=function(h){Ze(this.g,new Sh)},Pi.prototype.ra=function(){Ze(this.g,"b")},vo.prototype.createWebChannel=vo.prototype.g,vn.prototype.send=vn.prototype.o,vn.prototype.open=vn.prototype.m,vn.prototype.close=vn.prototype.close,JA=function(){return new vo},ZA=function(){return Gs()},XA=Ri,c_={mb:0,pb:1,qb:2,Jb:3,Ob:4,Lb:5,Mb:6,Kb:7,Ib:8,Nb:9,PROXY:10,NOPROXY:11,Gb:12,Cb:13,Db:14,Bb:15,Eb:16,Fb:17,ib:18,hb:19,jb:20},Qs.NO_ERROR=0,Qs.TIMEOUT=8,Qs.HTTP_ERROR=6,Fd=Qs,ts.COMPLETE="complete",WA=ts,Ll.EventType=Ji,Ji.OPEN="a",Ji.CLOSE="b",Ji.ERROR="c",Ji.MESSAGE="d",vt.prototype.listen=vt.prototype.K,Yc=Ll,We.prototype.listenOnce=We.prototype.L,We.prototype.getLastError=We.prototype.Ka,We.prototype.getLastErrorCode=We.prototype.Ba,We.prototype.getStatus=We.prototype.Z,We.prototype.getResponseJson=We.prototype.Oa,We.prototype.getResponseText=We.prototype.oa,We.prototype.send=We.prototype.ea,We.prototype.setWithCredentials=We.prototype.Ha,YA=We}).apply(typeof Cd<"u"?Cd:typeof self<"u"?self:typeof window<"u"?window:{});const Db="@firebase/firestore",Ob="4.7.10";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dn{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}dn.UNAUTHENTICATED=new dn(null),dn.GOOGLE_CREDENTIALS=new dn("google-credentials-uid"),dn.FIRST_PARTY=new dn("first-party-uid"),dn.MOCK_USER=new dn("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let bl="11.5.0";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ja=new Lu("@firebase/firestore");function Yo(){return ja.logLevel}function de(n,...e){if(ja.logLevel<=Ue.DEBUG){const t=e.map(uy);ja.debug(`Firestore (${bl}): ${n}`,...t)}}function Vs(n,...e){if(ja.logLevel<=Ue.ERROR){const t=e.map(uy);ja.error(`Firestore (${bl}): ${n}`,...t)}}function ll(n,...e){if(ja.logLevel<=Ue.WARN){const t=e.map(uy);ja.warn(`Firestore (${bl}): ${n}`,...t)}}function uy(n){if(typeof n=="string")return n;try{/**
* @license
* Copyright 2020 Google LLC
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/return function(t){return JSON.stringify(t)}(n)}catch{return n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Se(n="Unexpected state"){const e=`FIRESTORE (${bl}) INTERNAL ASSERTION FAILED: `+n;throw Vs(e),new Error(e)}function Xe(n,e){n||Se()}function Ce(n,e){return n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ne={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class fe extends oi{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ks{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eR{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class YM{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(dn.UNAUTHENTICATED))}shutdown(){}}class WM{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class XM{constructor(e){this.t=e,this.currentUser=dn.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){Xe(this.o===void 0);let i=this.i;const a=m=>this.i!==i?(i=this.i,t(m)):Promise.resolve();let l=new ks;this.o=()=>{this.i++,this.currentUser=this.u(),l.resolve(),l=new ks,e.enqueueRetryable(()=>a(this.currentUser))};const u=()=>{const m=l;e.enqueueRetryable(async()=>{await m.promise,await a(this.currentUser)})},d=m=>{de("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=m,this.o&&(this.auth.addAuthTokenListener(this.o),u())};this.t.onInit(m=>d(m)),setTimeout(()=>{if(!this.auth){const m=this.t.getImmediate({optional:!0});m?d(m):(de("FirebaseAuthCredentialsProvider","Auth not yet detected"),l.resolve(),l=new ks)}},0),u()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(i=>this.i!==e?(de("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):i?(Xe(typeof i.accessToken=="string"),new eR(i.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return Xe(e===null||typeof e=="string"),new dn(e)}}class ZM{constructor(e,t,i){this.l=e,this.h=t,this.P=i,this.type="FirstParty",this.user=dn.FIRST_PARTY,this.T=new Map}I(){return this.P?this.P():null}get headers(){this.T.set("X-Goog-AuthUser",this.l);const e=this.I();return e&&this.T.set("Authorization",e),this.h&&this.T.set("X-Goog-Iam-Authorization-Token",this.h),this.T}}class JM{constructor(e,t,i){this.l=e,this.h=t,this.P=i}getToken(){return Promise.resolve(new ZM(this.l,this.h,this.P))}start(e,t){e.enqueueRetryable(()=>t(dn.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class Mb{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class eP{constructor(e,t){this.A=t,this.forceRefresh=!1,this.appCheck=null,this.R=null,this.V=null,Rn(e)&&e.settings.appCheckToken&&(this.V=e.settings.appCheckToken)}start(e,t){Xe(this.o===void 0);const i=l=>{l.error!=null&&de("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${l.error.message}`);const u=l.token!==this.R;return this.R=l.token,de("FirebaseAppCheckTokenProvider",`Received ${u?"new":"existing"} token.`),u?t(l.token):Promise.resolve()};this.o=l=>{e.enqueueRetryable(()=>i(l))};const a=l=>{de("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=l,this.o&&this.appCheck.addTokenListener(this.o)};this.A.onInit(l=>a(l)),setTimeout(()=>{if(!this.appCheck){const l=this.A.getImmediate({optional:!0});l?a(l):de("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.V)return Promise.resolve(new Mb(this.V));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(Xe(typeof t.token=="string"),this.R=t.token,new Mb(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tP(n){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(n);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let i=0;i<n;i++)t[i]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tR(){return new TextEncoder}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nR{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let i="";for(;i.length<20;){const a=tP(40);for(let l=0;l<a.length;++l)i.length<20&&a[l]<t&&(i+=e.charAt(a[l]%62))}return i}}function Ne(n,e){return n<e?-1:n>e?1:0}function u_(n,e){let t=0;for(;t<n.length&&t<e.length;){const i=n.codePointAt(t),a=e.codePointAt(t);if(i!==a){if(i<128&&a<128)return Ne(i,a);{const l=tR(),u=nP(l.encode(Pb(n,t)),l.encode(Pb(e,t)));return u!==0?u:Ne(i,a)}}t+=i>65535?2:1}return Ne(n.length,e.length)}function Pb(n,e){return n.codePointAt(e)>65535?n.substring(e,e+2):n.substring(e,e+1)}function nP(n,e){for(let t=0;t<n.length&&t<e.length;++t)if(n[t]!==e[t])return Ne(n[t],e[t]);return Ne(n.length,e.length)}function cl(n,e,t){return n.length===e.length&&n.every((i,a)=>t(i,e[a]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lb=-62135596800,Vb=1e6;class Ft{static now(){return Ft.fromMillis(Date.now())}static fromDate(e){return Ft.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),i=Math.floor((e-1e3*t)*Vb);return new Ft(t,i)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new fe(ne.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new fe(ne.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Lb)throw new fe(ne.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new fe(ne.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Vb}_compareTo(e){return this.seconds===e.seconds?Ne(this.nanoseconds,e.nanoseconds):Ne(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{seconds:this.seconds,nanoseconds:this.nanoseconds}}valueOf(){const e=this.seconds-Lb;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Re{static fromTimestamp(e){return new Re(e)}static min(){return new Re(new Ft(0,0))}static max(){return new Re(new Ft(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ub="__name__";class Bi{constructor(e,t,i){t===void 0?t=0:t>e.length&&Se(),i===void 0?i=e.length-t:i>e.length-t&&Se(),this.segments=e,this.offset=t,this.len=i}get length(){return this.len}isEqual(e){return Bi.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Bi?e.forEach(i=>{t.push(i)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,i=this.limit();t<i;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const i=Math.min(e.length,t.length);for(let a=0;a<i;a++){const l=Bi.compareSegments(e.get(a),t.get(a));if(l!==0)return l}return Ne(e.length,t.length)}static compareSegments(e,t){const i=Bi.isNumericId(e),a=Bi.isNumericId(t);return i&&!a?-1:!i&&a?1:i&&a?Bi.extractNumericId(e).compare(Bi.extractNumericId(t)):u_(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return xr.fromString(e.substring(4,e.length-2))}}class ft extends Bi{construct(e,t,i){return new ft(e,t,i)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const i of e){if(i.indexOf("//")>=0)throw new fe(ne.INVALID_ARGUMENT,`Invalid segment (${i}). Paths must not contain // in them.`);t.push(...i.split("/").filter(a=>a.length>0))}return new ft(t)}static emptyPath(){return new ft([])}}const iP=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class an extends Bi{construct(e,t,i){return new an(e,t,i)}static isValidIdentifier(e){return iP.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),an.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Ub}static keyField(){return new an([Ub])}static fromServerFormat(e){const t=[];let i="",a=0;const l=()=>{if(i.length===0)throw new fe(ne.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(i),i=""};let u=!1;for(;a<e.length;){const d=e[a];if(d==="\\"){if(a+1===e.length)throw new fe(ne.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const m=e[a+1];if(m!=="\\"&&m!=="."&&m!=="`")throw new fe(ne.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);i+=m,a+=2}else d==="`"?(u=!u,a++):d!=="."||u?(i+=d,a++):(l(),a++)}if(l(),u)throw new fe(ne.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new an(t)}static emptyPath(){return new an([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _e{constructor(e){this.path=e}static fromPath(e){return new _e(ft.fromString(e))}static fromName(e){return new _e(ft.fromString(e).popFirst(5))}static empty(){return new _e(ft.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&ft.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return ft.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new _e(new ft(e.slice()))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _u=-1;function sP(n,e){const t=n.toTimestamp().seconds,i=n.toTimestamp().nanoseconds+1,a=Re.fromTimestamp(i===1e9?new Ft(t+1,0):new Ft(t,i));return new Dr(a,_e.empty(),e)}function rP(n){return new Dr(n.readTime,n.key,_u)}class Dr{constructor(e,t,i){this.readTime=e,this.documentKey=t,this.largestBatchId=i}static min(){return new Dr(Re.min(),_e.empty(),_u)}static max(){return new Dr(Re.max(),_e.empty(),_u)}}function aP(n,e){let t=n.readTime.compareTo(e.readTime);return t!==0?t:(t=_e.comparator(n.documentKey,e.documentKey),t!==0?t:Ne(n.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oP="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class lP{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function wl(n){if(n.code!==ne.FAILED_PRECONDITION||n.message!==oP)throw n;de("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ie{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&Se(),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new ie((i,a)=>{this.nextCallback=l=>{this.wrapSuccess(e,l).next(i,a)},this.catchCallback=l=>{this.wrapFailure(t,l).next(i,a)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof ie?t:ie.resolve(t)}catch(t){return ie.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):ie.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):ie.reject(t)}static resolve(e){return new ie((t,i)=>{t(e)})}static reject(e){return new ie((t,i)=>{i(e)})}static waitFor(e){return new ie((t,i)=>{let a=0,l=0,u=!1;e.forEach(d=>{++a,d.next(()=>{++l,u&&l===a&&t()},m=>i(m))}),u=!0,l===a&&t()})}static or(e){let t=ie.resolve(!1);for(const i of e)t=t.next(a=>a?ie.resolve(a):i());return t}static forEach(e,t){const i=[];return e.forEach((a,l)=>{i.push(t.call(this,a,l))}),this.waitFor(i)}static mapArray(e,t){return new ie((i,a)=>{const l=e.length,u=new Array(l);let d=0;for(let m=0;m<l;m++){const p=m;t(e[p]).next(y=>{u[p]=y,++d,d===l&&i(u)},y=>a(y))}})}static doWhile(e,t){return new ie((i,a)=>{const l=()=>{e()===!0?t().next(()=>{l()},a):i()};l()})}}function cP(n){const e=n.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function Sl(n){return n.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kf{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=i=>this.oe(i),this._e=i=>t.writeSequenceNumber(i))}oe(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this._e&&this._e(e),e}}Kf.ae=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hy=-1;function Qf(n){return n==null}function of(n){return n===0&&1/n==-1/0}function uP(n){return typeof n=="number"&&Number.isInteger(n)&&!of(n)&&n<=Number.MAX_SAFE_INTEGER&&n>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iR="";function hP(n){let e="";for(let t=0;t<n.length;t++)e.length>0&&(e=jb(e)),e=dP(n.get(t),e);return jb(e)}function dP(n,e){let t=e;const i=n.length;for(let a=0;a<i;a++){const l=n.charAt(a);switch(l){case"\0":t+="";break;case iR:t+="";break;default:t+=l}}return t}function jb(n){return n+iR+""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zb(n){let e=0;for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e++;return e}function Br(n,e){for(const t in n)Object.prototype.hasOwnProperty.call(n,t)&&e(t,n[t])}function sR(n){for(const e in n)if(Object.prototype.hasOwnProperty.call(n,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Mt=class h_{constructor(e,t){this.comparator=e,this.root=t||Ir.EMPTY}insert(e,t){return new h_(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,Ir.BLACK,null,null))}remove(e){return new h_(this.comparator,this.root.remove(e,this.comparator).copy(null,null,Ir.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const i=this.comparator(e,t.key);if(i===0)return t.value;i<0?t=t.left:i>0&&(t=t.right)}return null}indexOf(e){let t=0,i=this.root;for(;!i.isEmpty();){const a=this.comparator(e,i.key);if(a===0)return t+i.left.size;a<0?i=i.left:(t+=i.left.size+1,i=i.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,i)=>(e(t,i),!1))}toString(){const e=[];return this.inorderTraversal((t,i)=>(e.push(`${t}:${i}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new xd(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new xd(this.root,e,this.comparator,!1)}getReverseIterator(){return new xd(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new xd(this.root,e,this.comparator,!0)}},xd=class{constructor(e,t,i,a){this.isReverse=a,this.nodeStack=[];let l=1;for(;!e.isEmpty();)if(l=t?i(e.key,t):1,t&&a&&(l*=-1),l<0)e=this.isReverse?e.left:e.right;else{if(l===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}},Ir=class Ss{constructor(e,t,i,a,l){this.key=e,this.value=t,this.color=i??Ss.RED,this.left=a??Ss.EMPTY,this.right=l??Ss.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,i,a,l){return new Ss(e??this.key,t??this.value,i??this.color,a??this.left,l??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,i){let a=this;const l=i(e,a.key);return a=l<0?a.copy(null,null,null,a.left.insert(e,t,i),null):l===0?a.copy(null,t,null,null,null):a.copy(null,null,null,null,a.right.insert(e,t,i)),a.fixUp()}removeMin(){if(this.left.isEmpty())return Ss.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let i,a=this;if(t(e,a.key)<0)a.left.isEmpty()||a.left.isRed()||a.left.left.isRed()||(a=a.moveRedLeft()),a=a.copy(null,null,null,a.left.remove(e,t),null);else{if(a.left.isRed()&&(a=a.rotateRight()),a.right.isEmpty()||a.right.isRed()||a.right.left.isRed()||(a=a.moveRedRight()),t(e,a.key)===0){if(a.right.isEmpty())return Ss.EMPTY;i=a.right.min(),a=a.copy(i.key,i.value,null,null,a.right.removeMin())}a=a.copy(null,null,null,null,a.right.remove(e,t))}return a.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,Ss.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,Ss.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed()||this.right.isRed())throw Se();const e=this.left.check();if(e!==this.right.check())throw Se();return e+(this.isRed()?0:1)}};Ir.EMPTY=null,Ir.RED=!0,Ir.BLACK=!1;Ir.EMPTY=new class{constructor(){this.size=0}get key(){throw Se()}get value(){throw Se()}get color(){throw Se()}get left(){throw Se()}get right(){throw Se()}copy(e,t,i,a,l){return this}insert(e,t,i){return new Ir(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bt{constructor(e){this.comparator=e,this.data=new Mt(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,i)=>(e(t),!1))}forEachInRange(e,t){const i=this.data.getIteratorFrom(e[0]);for(;i.hasNext();){const a=i.getNext();if(this.comparator(a.key,e[1])>=0)return;t(a.key)}}forEachWhile(e,t){let i;for(i=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();i.hasNext();)if(!e(i.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Fb(this.data.getIterator())}getIteratorFrom(e){return new Fb(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(i=>{t=t.add(i)}),t}isEqual(e){if(!(e instanceof Bt)||this.size!==e.size)return!1;const t=this.data.getIterator(),i=e.data.getIterator();for(;t.hasNext();){const a=t.getNext().key,l=i.getNext().key;if(this.comparator(a,l)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new Bt(this.comparator);return t.data=e,t}}class Fb{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bn{constructor(e){this.fields=e,e.sort(an.comparator)}static empty(){return new Bn([])}unionWith(e){let t=new Bt(an.comparator);for(const i of this.fields)t=t.add(i);for(const i of e)t=t.add(i);return new Bn(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return cl(this.fields,e.fields,(t,i)=>t.isEqual(i))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class rR extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class on{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(a){try{return atob(a)}catch(l){throw typeof DOMException<"u"&&l instanceof DOMException?new rR("Invalid base64 string: "+l):l}}(e);return new on(t)}static fromUint8Array(e){const t=function(a){let l="";for(let u=0;u<a.length;++u)l+=String.fromCharCode(a[u]);return l}(e);return new on(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const i=new Uint8Array(t.length);for(let a=0;a<t.length;a++)i[a]=t.charCodeAt(a);return i}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return Ne(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}on.EMPTY_BYTE_STRING=new on("");const fP=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function Or(n){if(Xe(!!n),typeof n=="string"){let e=0;const t=fP.exec(n);if(Xe(!!t),t[1]){let a=t[1];a=(a+"000000000").substr(0,9),e=Number(a)}const i=new Date(n);return{seconds:Math.floor(i.getTime()/1e3),nanos:e}}return{seconds:Rt(n.seconds),nanos:Rt(n.nanos)}}function Rt(n){return typeof n=="number"?n:typeof n=="string"?Number(n):0}function Mr(n){return typeof n=="string"?on.fromBase64String(n):on.fromUint8Array(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const aR="server_timestamp",oR="__type__",lR="__previous_value__",cR="__local_write_time__";function dy(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{})[oR])===null||t===void 0?void 0:t.stringValue)===aR}function Yf(n){const e=n.mapValue.fields[lR];return dy(e)?Yf(e):e}function yu(n){const e=Or(n.mapValue.fields[cR].timestampValue);return new Ft(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mP{constructor(e,t,i,a,l,u,d,m,p){this.databaseId=e,this.appId=t,this.persistenceKey=i,this.host=a,this.ssl=l,this.forceLongPolling=u,this.autoDetectLongPolling=d,this.longPollingOptions=m,this.useFetchStreams=p}}const lf="(default)";class vu{constructor(e,t){this.projectId=e,this.database=t||lf}static empty(){return new vu("","")}get isDefaultDatabase(){return this.database===lf}isEqual(e){return e instanceof vu&&e.projectId===this.projectId&&e.database===this.database}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uR="__type__",pP="__max__",Id={mapValue:{}},hR="__vector__",cf="value";function Pr(n){return"nullValue"in n?0:"booleanValue"in n?1:"integerValue"in n||"doubleValue"in n?2:"timestampValue"in n?3:"stringValue"in n?5:"bytesValue"in n?6:"referenceValue"in n?7:"geoPointValue"in n?8:"arrayValue"in n?9:"mapValue"in n?dy(n)?4:_P(n)?9007199254740991:gP(n)?10:11:Se()}function Ki(n,e){if(n===e)return!0;const t=Pr(n);if(t!==Pr(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return n.booleanValue===e.booleanValue;case 4:return yu(n).isEqual(yu(e));case 3:return function(a,l){if(typeof a.timestampValue=="string"&&typeof l.timestampValue=="string"&&a.timestampValue.length===l.timestampValue.length)return a.timestampValue===l.timestampValue;const u=Or(a.timestampValue),d=Or(l.timestampValue);return u.seconds===d.seconds&&u.nanos===d.nanos}(n,e);case 5:return n.stringValue===e.stringValue;case 6:return function(a,l){return Mr(a.bytesValue).isEqual(Mr(l.bytesValue))}(n,e);case 7:return n.referenceValue===e.referenceValue;case 8:return function(a,l){return Rt(a.geoPointValue.latitude)===Rt(l.geoPointValue.latitude)&&Rt(a.geoPointValue.longitude)===Rt(l.geoPointValue.longitude)}(n,e);case 2:return function(a,l){if("integerValue"in a&&"integerValue"in l)return Rt(a.integerValue)===Rt(l.integerValue);if("doubleValue"in a&&"doubleValue"in l){const u=Rt(a.doubleValue),d=Rt(l.doubleValue);return u===d?of(u)===of(d):isNaN(u)&&isNaN(d)}return!1}(n,e);case 9:return cl(n.arrayValue.values||[],e.arrayValue.values||[],Ki);case 10:case 11:return function(a,l){const u=a.mapValue.fields||{},d=l.mapValue.fields||{};if(zb(u)!==zb(d))return!1;for(const m in u)if(u.hasOwnProperty(m)&&(d[m]===void 0||!Ki(u[m],d[m])))return!1;return!0}(n,e);default:return Se()}}function Eu(n,e){return(n.values||[]).find(t=>Ki(t,e))!==void 0}function ul(n,e){if(n===e)return 0;const t=Pr(n),i=Pr(e);if(t!==i)return Ne(t,i);switch(t){case 0:case 9007199254740991:return 0;case 1:return Ne(n.booleanValue,e.booleanValue);case 2:return function(l,u){const d=Rt(l.integerValue||l.doubleValue),m=Rt(u.integerValue||u.doubleValue);return d<m?-1:d>m?1:d===m?0:isNaN(d)?isNaN(m)?0:-1:1}(n,e);case 3:return Bb(n.timestampValue,e.timestampValue);case 4:return Bb(yu(n),yu(e));case 5:return u_(n.stringValue,e.stringValue);case 6:return function(l,u){const d=Mr(l),m=Mr(u);return d.compareTo(m)}(n.bytesValue,e.bytesValue);case 7:return function(l,u){const d=l.split("/"),m=u.split("/");for(let p=0;p<d.length&&p<m.length;p++){const y=Ne(d[p],m[p]);if(y!==0)return y}return Ne(d.length,m.length)}(n.referenceValue,e.referenceValue);case 8:return function(l,u){const d=Ne(Rt(l.latitude),Rt(u.latitude));return d!==0?d:Ne(Rt(l.longitude),Rt(u.longitude))}(n.geoPointValue,e.geoPointValue);case 9:return qb(n.arrayValue,e.arrayValue);case 10:return function(l,u){var d,m,p,y;const T=l.fields||{},w=u.fields||{},x=(d=T[cf])===null||d===void 0?void 0:d.arrayValue,I=(m=w[cf])===null||m===void 0?void 0:m.arrayValue,O=Ne(((p=x==null?void 0:x.values)===null||p===void 0?void 0:p.length)||0,((y=I==null?void 0:I.values)===null||y===void 0?void 0:y.length)||0);return O!==0?O:qb(x,I)}(n.mapValue,e.mapValue);case 11:return function(l,u){if(l===Id.mapValue&&u===Id.mapValue)return 0;if(l===Id.mapValue)return 1;if(u===Id.mapValue)return-1;const d=l.fields||{},m=Object.keys(d),p=u.fields||{},y=Object.keys(p);m.sort(),y.sort();for(let T=0;T<m.length&&T<y.length;++T){const w=u_(m[T],y[T]);if(w!==0)return w;const x=ul(d[m[T]],p[y[T]]);if(x!==0)return x}return Ne(m.length,y.length)}(n.mapValue,e.mapValue);default:throw Se()}}function Bb(n,e){if(typeof n=="string"&&typeof e=="string"&&n.length===e.length)return Ne(n,e);const t=Or(n),i=Or(e),a=Ne(t.seconds,i.seconds);return a!==0?a:Ne(t.nanos,i.nanos)}function qb(n,e){const t=n.values||[],i=e.values||[];for(let a=0;a<t.length&&a<i.length;++a){const l=ul(t[a],i[a]);if(l)return l}return Ne(t.length,i.length)}function hl(n){return d_(n)}function d_(n){return"nullValue"in n?"null":"booleanValue"in n?""+n.booleanValue:"integerValue"in n?""+n.integerValue:"doubleValue"in n?""+n.doubleValue:"timestampValue"in n?function(t){const i=Or(t);return`time(${i.seconds},${i.nanos})`}(n.timestampValue):"stringValue"in n?n.stringValue:"bytesValue"in n?function(t){return Mr(t).toBase64()}(n.bytesValue):"referenceValue"in n?function(t){return _e.fromName(t).toString()}(n.referenceValue):"geoPointValue"in n?function(t){return`geo(${t.latitude},${t.longitude})`}(n.geoPointValue):"arrayValue"in n?function(t){let i="[",a=!0;for(const l of t.values||[])a?a=!1:i+=",",i+=d_(l);return i+"]"}(n.arrayValue):"mapValue"in n?function(t){const i=Object.keys(t.fields||{}).sort();let a="{",l=!0;for(const u of i)l?l=!1:a+=",",a+=`${u}:${d_(t.fields[u])}`;return a+"}"}(n.mapValue):Se()}function Bd(n){switch(Pr(n)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=Yf(n);return e?16+Bd(e):16;case 5:return 2*n.stringValue.length;case 6:return Mr(n.bytesValue).approximateByteSize();case 7:return n.referenceValue.length;case 9:return function(i){return(i.values||[]).reduce((a,l)=>a+Bd(l),0)}(n.arrayValue);case 10:case 11:return function(i){let a=0;return Br(i.fields,(l,u)=>{a+=l.length+Bd(u)}),a}(n.mapValue);default:throw Se()}}function Hb(n,e){return{referenceValue:`projects/${n.projectId}/databases/${n.database}/documents/${e.path.canonicalString()}`}}function f_(n){return!!n&&"integerValue"in n}function fy(n){return!!n&&"arrayValue"in n}function Gb(n){return!!n&&"nullValue"in n}function $b(n){return!!n&&"doubleValue"in n&&isNaN(Number(n.doubleValue))}function qd(n){return!!n&&"mapValue"in n}function gP(n){var e,t;return((t=(((e=n==null?void 0:n.mapValue)===null||e===void 0?void 0:e.fields)||{})[uR])===null||t===void 0?void 0:t.stringValue)===hR}function tu(n){if(n.geoPointValue)return{geoPointValue:Object.assign({},n.geoPointValue)};if(n.timestampValue&&typeof n.timestampValue=="object")return{timestampValue:Object.assign({},n.timestampValue)};if(n.mapValue){const e={mapValue:{fields:{}}};return Br(n.mapValue.fields,(t,i)=>e.mapValue.fields[t]=tu(i)),e}if(n.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(n.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=tu(n.arrayValue.values[t]);return e}return Object.assign({},n)}function _P(n){return(((n.mapValue||{}).fields||{}).__type__||{}).stringValue===pP}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cn{constructor(e){this.value=e}static empty(){return new Cn({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let i=0;i<e.length-1;++i)if(t=(t.mapValue.fields||{})[e.get(i)],!qd(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=tu(t)}setAll(e){let t=an.emptyPath(),i={},a=[];e.forEach((u,d)=>{if(!t.isImmediateParentOf(d)){const m=this.getFieldsMap(t);this.applyChanges(m,i,a),i={},a=[],t=d.popLast()}u?i[d.lastSegment()]=tu(u):a.push(d.lastSegment())});const l=this.getFieldsMap(t);this.applyChanges(l,i,a)}delete(e){const t=this.field(e.popLast());qd(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Ki(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let i=0;i<e.length;++i){let a=t.mapValue.fields[e.get(i)];qd(a)&&a.mapValue.fields||(a={mapValue:{fields:{}}},t.mapValue.fields[e.get(i)]=a),t=a}return t.mapValue.fields}applyChanges(e,t,i){Br(t,(a,l)=>e[a]=l);for(const a of i)delete e[a]}clone(){return new Cn(tu(this.value))}}function dR(n){const e=[];return Br(n.fields,(t,i)=>{const a=new an([t]);if(qd(i)){const l=dR(i.mapValue).fields;if(l.length===0)e.push(a);else for(const u of l)e.push(a.child(u))}else e.push(a)}),new Bn(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fn{constructor(e,t,i,a,l,u,d){this.key=e,this.documentType=t,this.version=i,this.readTime=a,this.createTime=l,this.data=u,this.documentState=d}static newInvalidDocument(e){return new fn(e,0,Re.min(),Re.min(),Re.min(),Cn.empty(),0)}static newFoundDocument(e,t,i,a){return new fn(e,1,t,Re.min(),i,a,0)}static newNoDocument(e,t){return new fn(e,2,t,Re.min(),Re.min(),Cn.empty(),0)}static newUnknownDocument(e,t){return new fn(e,3,t,Re.min(),Re.min(),Cn.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(Re.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=Cn.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=Cn.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=Re.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof fn&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new fn(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uf{constructor(e,t){this.position=e,this.inclusive=t}}function Kb(n,e,t){let i=0;for(let a=0;a<n.position.length;a++){const l=e[a],u=n.position[a];if(l.field.isKeyField()?i=_e.comparator(_e.fromName(u.referenceValue),t.key):i=ul(u,t.data.field(l.field)),l.dir==="desc"&&(i*=-1),i!==0)break}return i}function Qb(n,e){if(n===null)return e===null;if(e===null||n.inclusive!==e.inclusive||n.position.length!==e.position.length)return!1;for(let t=0;t<n.position.length;t++)if(!Ki(n.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tu{constructor(e,t="asc"){this.field=e,this.dir=t}}function yP(n,e){return n.dir===e.dir&&n.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fR{}class Ot extends fR{constructor(e,t,i){super(),this.field=e,this.op=t,this.value=i}static create(e,t,i){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,i):new EP(e,t,i):t==="array-contains"?new wP(e,i):t==="in"?new SP(e,i):t==="not-in"?new AP(e,i):t==="array-contains-any"?new RP(e,i):new Ot(e,t,i)}static createKeyFieldInFilter(e,t,i){return t==="in"?new TP(e,i):new bP(e,i)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&this.matchesComparison(ul(t,this.value)):t!==null&&Pr(this.value)===Pr(t)&&this.matchesComparison(ul(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return Se()}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class Ti extends fR{constructor(e,t){super(),this.filters=e,this.op=t,this.ce=null}static create(e,t){return new Ti(e,t)}matches(e){return mR(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.ce!==null||(this.ce=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.ce}getFilters(){return Object.assign([],this.filters)}}function mR(n){return n.op==="and"}function pR(n){return vP(n)&&mR(n)}function vP(n){for(const e of n.filters)if(e instanceof Ti)return!1;return!0}function m_(n){if(n instanceof Ot)return n.field.canonicalString()+n.op.toString()+hl(n.value);if(pR(n))return n.filters.map(e=>m_(e)).join(",");{const e=n.filters.map(t=>m_(t)).join(",");return`${n.op}(${e})`}}function gR(n,e){return n instanceof Ot?function(i,a){return a instanceof Ot&&i.op===a.op&&i.field.isEqual(a.field)&&Ki(i.value,a.value)}(n,e):n instanceof Ti?function(i,a){return a instanceof Ti&&i.op===a.op&&i.filters.length===a.filters.length?i.filters.reduce((l,u,d)=>l&&gR(u,a.filters[d]),!0):!1}(n,e):void Se()}function _R(n){return n instanceof Ot?function(t){return`${t.field.canonicalString()} ${t.op} ${hl(t.value)}`}(n):n instanceof Ti?function(t){return t.op.toString()+" {"+t.getFilters().map(_R).join(" ,")+"}"}(n):"Filter"}class EP extends Ot{constructor(e,t,i){super(e,t,i),this.key=_e.fromName(i.referenceValue)}matches(e){const t=_e.comparator(e.key,this.key);return this.matchesComparison(t)}}class TP extends Ot{constructor(e,t){super(e,"in",t),this.keys=yR("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class bP extends Ot{constructor(e,t){super(e,"not-in",t),this.keys=yR("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function yR(n,e){var t;return(((t=e.arrayValue)===null||t===void 0?void 0:t.values)||[]).map(i=>_e.fromName(i.referenceValue))}class wP extends Ot{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return fy(t)&&Eu(t.arrayValue,this.value)}}class SP extends Ot{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Eu(this.value.arrayValue,t)}}class AP extends Ot{constructor(e,t){super(e,"not-in",t)}matches(e){if(Eu(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&!Eu(this.value.arrayValue,t)}}class RP extends Ot{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!fy(t)||!t.arrayValue.values)&&t.arrayValue.values.some(i=>Eu(this.value.arrayValue,i))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CP{constructor(e,t=null,i=[],a=[],l=null,u=null,d=null){this.path=e,this.collectionGroup=t,this.orderBy=i,this.filters=a,this.limit=l,this.startAt=u,this.endAt=d,this.le=null}}function Yb(n,e=null,t=[],i=[],a=null,l=null,u=null){return new CP(n,e,t,i,a,l,u)}function my(n){const e=Ce(n);if(e.le===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(i=>m_(i)).join(","),t+="|ob:",t+=e.orderBy.map(i=>function(l){return l.field.canonicalString()+l.dir}(i)).join(","),Qf(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(i=>hl(i)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(i=>hl(i)).join(",")),e.le=t}return e.le}function py(n,e){if(n.limit!==e.limit||n.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<n.orderBy.length;t++)if(!yP(n.orderBy[t],e.orderBy[t]))return!1;if(n.filters.length!==e.filters.length)return!1;for(let t=0;t<n.filters.length;t++)if(!gR(n.filters[t],e.filters[t]))return!1;return n.collectionGroup===e.collectionGroup&&!!n.path.isEqual(e.path)&&!!Qb(n.startAt,e.startAt)&&Qb(n.endAt,e.endAt)}function p_(n){return _e.isDocumentKey(n.path)&&n.collectionGroup===null&&n.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Al{constructor(e,t=null,i=[],a=[],l=null,u="F",d=null,m=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=i,this.filters=a,this.limit=l,this.limitType=u,this.startAt=d,this.endAt=m,this.he=null,this.Pe=null,this.Te=null,this.startAt,this.endAt}}function xP(n,e,t,i,a,l,u,d){return new Al(n,e,t,i,a,l,u,d)}function gy(n){return new Al(n)}function Wb(n){return n.filters.length===0&&n.limit===null&&n.startAt==null&&n.endAt==null&&(n.explicitOrderBy.length===0||n.explicitOrderBy.length===1&&n.explicitOrderBy[0].field.isKeyField())}function vR(n){return n.collectionGroup!==null}function nu(n){const e=Ce(n);if(e.he===null){e.he=[];const t=new Set;for(const l of e.explicitOrderBy)e.he.push(l),t.add(l.field.canonicalString());const i=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(u){let d=new Bt(an.comparator);return u.filters.forEach(m=>{m.getFlattenedFilters().forEach(p=>{p.isInequality()&&(d=d.add(p.field))})}),d})(e).forEach(l=>{t.has(l.canonicalString())||l.isKeyField()||e.he.push(new Tu(l,i))}),t.has(an.keyField().canonicalString())||e.he.push(new Tu(an.keyField(),i))}return e.he}function qi(n){const e=Ce(n);return e.Pe||(e.Pe=IP(e,nu(n))),e.Pe}function IP(n,e){if(n.limitType==="F")return Yb(n.path,n.collectionGroup,e,n.filters,n.limit,n.startAt,n.endAt);{e=e.map(a=>{const l=a.dir==="desc"?"asc":"desc";return new Tu(a.field,l)});const t=n.endAt?new uf(n.endAt.position,n.endAt.inclusive):null,i=n.startAt?new uf(n.startAt.position,n.startAt.inclusive):null;return Yb(n.path,n.collectionGroup,e,n.filters,n.limit,t,i)}}function g_(n,e){const t=n.filters.concat([e]);return new Al(n.path,n.collectionGroup,n.explicitOrderBy.slice(),t,n.limit,n.limitType,n.startAt,n.endAt)}function __(n,e,t){return new Al(n.path,n.collectionGroup,n.explicitOrderBy.slice(),n.filters.slice(),e,t,n.startAt,n.endAt)}function Wf(n,e){return py(qi(n),qi(e))&&n.limitType===e.limitType}function ER(n){return`${my(qi(n))}|lt:${n.limitType}`}function Wo(n){return`Query(target=${function(t){let i=t.path.canonicalString();return t.collectionGroup!==null&&(i+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(i+=`, filters: [${t.filters.map(a=>_R(a)).join(", ")}]`),Qf(t.limit)||(i+=", limit: "+t.limit),t.orderBy.length>0&&(i+=`, orderBy: [${t.orderBy.map(a=>function(u){return`${u.field.canonicalString()} (${u.dir})`}(a)).join(", ")}]`),t.startAt&&(i+=", startAt: ",i+=t.startAt.inclusive?"b:":"a:",i+=t.startAt.position.map(a=>hl(a)).join(",")),t.endAt&&(i+=", endAt: ",i+=t.endAt.inclusive?"a:":"b:",i+=t.endAt.position.map(a=>hl(a)).join(",")),`Target(${i})`}(qi(n))}; limitType=${n.limitType})`}function Xf(n,e){return e.isFoundDocument()&&function(i,a){const l=a.key.path;return i.collectionGroup!==null?a.key.hasCollectionId(i.collectionGroup)&&i.path.isPrefixOf(l):_e.isDocumentKey(i.path)?i.path.isEqual(l):i.path.isImmediateParentOf(l)}(n,e)&&function(i,a){for(const l of nu(i))if(!l.field.isKeyField()&&a.data.field(l.field)===null)return!1;return!0}(n,e)&&function(i,a){for(const l of i.filters)if(!l.matches(a))return!1;return!0}(n,e)&&function(i,a){return!(i.startAt&&!function(u,d,m){const p=Kb(u,d,m);return u.inclusive?p<=0:p<0}(i.startAt,nu(i),a)||i.endAt&&!function(u,d,m){const p=Kb(u,d,m);return u.inclusive?p>=0:p>0}(i.endAt,nu(i),a))}(n,e)}function NP(n){return n.collectionGroup||(n.path.length%2==1?n.path.lastSegment():n.path.get(n.path.length-2))}function TR(n){return(e,t)=>{let i=!1;for(const a of nu(n)){const l=kP(a,e,t);if(l!==0)return l;i=i||a.field.isKeyField()}return 0}}function kP(n,e,t){const i=n.field.isKeyField()?_e.comparator(e.key,t.key):function(l,u,d){const m=u.data.field(l),p=d.data.field(l);return m!==null&&p!==null?ul(m,p):Se()}(n.field,e,t);switch(n.dir){case"asc":return i;case"desc":return-1*i;default:return Se()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ya{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),i=this.inner[t];if(i!==void 0){for(const[a,l]of i)if(this.equalsFn(a,e))return l}}has(e){return this.get(e)!==void 0}set(e,t){const i=this.mapKeyFn(e),a=this.inner[i];if(a===void 0)return this.inner[i]=[[e,t]],void this.innerSize++;for(let l=0;l<a.length;l++)if(this.equalsFn(a[l][0],e))return void(a[l]=[e,t]);a.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),i=this.inner[t];if(i===void 0)return!1;for(let a=0;a<i.length;a++)if(this.equalsFn(i[a][0],e))return i.length===1?delete this.inner[t]:i.splice(a,1),this.innerSize--,!0;return!1}forEach(e){Br(this.inner,(t,i)=>{for(const[a,l]of i)e(a,l)})}isEmpty(){return sR(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const DP=new Mt(_e.comparator);function Us(){return DP}const bR=new Mt(_e.comparator);function Wc(...n){let e=bR;for(const t of n)e=e.insert(t.key,t);return e}function wR(n){let e=bR;return n.forEach((t,i)=>e=e.insert(t,i.overlayedDocument)),e}function Oa(){return iu()}function SR(){return iu()}function iu(){return new Ya(n=>n.toString(),(n,e)=>n.isEqual(e))}const OP=new Mt(_e.comparator),MP=new Bt(_e.comparator);function je(...n){let e=MP;for(const t of n)e=e.add(t);return e}const PP=new Bt(Ne);function LP(){return PP}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _y(n,e){if(n.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:of(e)?"-0":e}}function AR(n){return{integerValue:""+n}}function VP(n,e){return uP(e)?AR(e):_y(n,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zf{constructor(){this._=void 0}}function UP(n,e,t){return n instanceof bu?function(a,l){const u={fields:{[oR]:{stringValue:aR},[cR]:{timestampValue:{seconds:a.seconds,nanos:a.nanoseconds}}}};return l&&dy(l)&&(l=Yf(l)),l&&(u.fields[lR]=l),{mapValue:u}}(t,e):n instanceof wu?CR(n,e):n instanceof Su?xR(n,e):function(a,l){const u=RR(a,l),d=Xb(u)+Xb(a.Ie);return f_(u)&&f_(a.Ie)?AR(d):_y(a.serializer,d)}(n,e)}function jP(n,e,t){return n instanceof wu?CR(n,e):n instanceof Su?xR(n,e):t}function RR(n,e){return n instanceof hf?function(i){return f_(i)||function(l){return!!l&&"doubleValue"in l}(i)}(e)?e:{integerValue:0}:null}class bu extends Zf{}class wu extends Zf{constructor(e){super(),this.elements=e}}function CR(n,e){const t=IR(e);for(const i of n.elements)t.some(a=>Ki(a,i))||t.push(i);return{arrayValue:{values:t}}}class Su extends Zf{constructor(e){super(),this.elements=e}}function xR(n,e){let t=IR(e);for(const i of n.elements)t=t.filter(a=>!Ki(a,i));return{arrayValue:{values:t}}}class hf extends Zf{constructor(e,t){super(),this.serializer=e,this.Ie=t}}function Xb(n){return Rt(n.integerValue||n.doubleValue)}function IR(n){return fy(n)&&n.arrayValue.values?n.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zP{constructor(e,t){this.field=e,this.transform=t}}function FP(n,e){return n.field.isEqual(e.field)&&function(i,a){return i instanceof wu&&a instanceof wu||i instanceof Su&&a instanceof Su?cl(i.elements,a.elements,Ki):i instanceof hf&&a instanceof hf?Ki(i.Ie,a.Ie):i instanceof bu&&a instanceof bu}(n.transform,e.transform)}class BP{constructor(e,t){this.version=e,this.transformResults=t}}class si{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new si}static exists(e){return new si(void 0,e)}static updateTime(e){return new si(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Hd(n,e){return n.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(n.updateTime):n.exists===void 0||n.exists===e.isFoundDocument()}class Jf{}function NR(n,e){if(!n.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return n.isNoDocument()?new yy(n.key,si.none()):new Uu(n.key,n.data,si.none());{const t=n.data,i=Cn.empty();let a=new Bt(an.comparator);for(let l of e.fields)if(!a.has(l)){let u=t.field(l);u===null&&l.length>1&&(l=l.popLast(),u=t.field(l)),u===null?i.delete(l):i.set(l,u),a=a.add(l)}return new qr(n.key,i,new Bn(a.toArray()),si.none())}}function qP(n,e,t){n instanceof Uu?function(a,l,u){const d=a.value.clone(),m=Jb(a.fieldTransforms,l,u.transformResults);d.setAll(m),l.convertToFoundDocument(u.version,d).setHasCommittedMutations()}(n,e,t):n instanceof qr?function(a,l,u){if(!Hd(a.precondition,l))return void l.convertToUnknownDocument(u.version);const d=Jb(a.fieldTransforms,l,u.transformResults),m=l.data;m.setAll(kR(a)),m.setAll(d),l.convertToFoundDocument(u.version,m).setHasCommittedMutations()}(n,e,t):function(a,l,u){l.convertToNoDocument(u.version).setHasCommittedMutations()}(0,e,t)}function su(n,e,t,i){return n instanceof Uu?function(l,u,d,m){if(!Hd(l.precondition,u))return d;const p=l.value.clone(),y=ew(l.fieldTransforms,m,u);return p.setAll(y),u.convertToFoundDocument(u.version,p).setHasLocalMutations(),null}(n,e,t,i):n instanceof qr?function(l,u,d,m){if(!Hd(l.precondition,u))return d;const p=ew(l.fieldTransforms,m,u),y=u.data;return y.setAll(kR(l)),y.setAll(p),u.convertToFoundDocument(u.version,y).setHasLocalMutations(),d===null?null:d.unionWith(l.fieldMask.fields).unionWith(l.fieldTransforms.map(T=>T.field))}(n,e,t,i):function(l,u,d){return Hd(l.precondition,u)?(u.convertToNoDocument(u.version).setHasLocalMutations(),null):d}(n,e,t)}function HP(n,e){let t=null;for(const i of n.fieldTransforms){const a=e.data.field(i.field),l=RR(i.transform,a||null);l!=null&&(t===null&&(t=Cn.empty()),t.set(i.field,l))}return t||null}function Zb(n,e){return n.type===e.type&&!!n.key.isEqual(e.key)&&!!n.precondition.isEqual(e.precondition)&&!!function(i,a){return i===void 0&&a===void 0||!(!i||!a)&&cl(i,a,(l,u)=>FP(l,u))}(n.fieldTransforms,e.fieldTransforms)&&(n.type===0?n.value.isEqual(e.value):n.type!==1||n.data.isEqual(e.data)&&n.fieldMask.isEqual(e.fieldMask))}class Uu extends Jf{constructor(e,t,i,a=[]){super(),this.key=e,this.value=t,this.precondition=i,this.fieldTransforms=a,this.type=0}getFieldMask(){return null}}class qr extends Jf{constructor(e,t,i,a,l=[]){super(),this.key=e,this.data=t,this.fieldMask=i,this.precondition=a,this.fieldTransforms=l,this.type=1}getFieldMask(){return this.fieldMask}}function kR(n){const e=new Map;return n.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const i=n.data.field(t);e.set(t,i)}}),e}function Jb(n,e,t){const i=new Map;Xe(n.length===t.length);for(let a=0;a<t.length;a++){const l=n[a],u=l.transform,d=e.data.field(l.field);i.set(l.field,jP(u,d,t[a]))}return i}function ew(n,e,t){const i=new Map;for(const a of n){const l=a.transform,u=t.data.field(a.field);i.set(a.field,UP(l,u,e))}return i}class yy extends Jf{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class GP extends Jf{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $P{constructor(e,t,i,a){this.batchId=e,this.localWriteTime=t,this.baseMutations=i,this.mutations=a}applyToRemoteDocument(e,t){const i=t.mutationResults;for(let a=0;a<this.mutations.length;a++){const l=this.mutations[a];l.key.isEqual(e.key)&&qP(l,e,i[a])}}applyToLocalView(e,t){for(const i of this.baseMutations)i.key.isEqual(e.key)&&(t=su(i,e,t,this.localWriteTime));for(const i of this.mutations)i.key.isEqual(e.key)&&(t=su(i,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const i=SR();return this.mutations.forEach(a=>{const l=e.get(a.key),u=l.overlayedDocument;let d=this.applyToLocalView(u,l.mutatedFields);d=t.has(a.key)?null:d;const m=NR(u,d);m!==null&&i.set(a.key,m),u.isValidDocument()||u.convertToNoDocument(Re.min())}),i}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),je())}isEqual(e){return this.batchId===e.batchId&&cl(this.mutations,e.mutations,(t,i)=>Zb(t,i))&&cl(this.baseMutations,e.baseMutations,(t,i)=>Zb(t,i))}}class vy{constructor(e,t,i,a){this.batch=e,this.commitVersion=t,this.mutationResults=i,this.docVersions=a}static from(e,t,i){Xe(e.mutations.length===i.length);let a=function(){return OP}();const l=e.mutations;for(let u=0;u<l.length;u++)a=a.insert(l[u].key,i[u].version);return new vy(e,t,i,a)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KP{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class QP{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var kt,He;function YP(n){switch(n){case ne.OK:return Se();case ne.CANCELLED:case ne.UNKNOWN:case ne.DEADLINE_EXCEEDED:case ne.RESOURCE_EXHAUSTED:case ne.INTERNAL:case ne.UNAVAILABLE:case ne.UNAUTHENTICATED:return!1;case ne.INVALID_ARGUMENT:case ne.NOT_FOUND:case ne.ALREADY_EXISTS:case ne.PERMISSION_DENIED:case ne.FAILED_PRECONDITION:case ne.ABORTED:case ne.OUT_OF_RANGE:case ne.UNIMPLEMENTED:case ne.DATA_LOSS:return!0;default:return Se()}}function DR(n){if(n===void 0)return Vs("GRPC error has no .code"),ne.UNKNOWN;switch(n){case kt.OK:return ne.OK;case kt.CANCELLED:return ne.CANCELLED;case kt.UNKNOWN:return ne.UNKNOWN;case kt.DEADLINE_EXCEEDED:return ne.DEADLINE_EXCEEDED;case kt.RESOURCE_EXHAUSTED:return ne.RESOURCE_EXHAUSTED;case kt.INTERNAL:return ne.INTERNAL;case kt.UNAVAILABLE:return ne.UNAVAILABLE;case kt.UNAUTHENTICATED:return ne.UNAUTHENTICATED;case kt.INVALID_ARGUMENT:return ne.INVALID_ARGUMENT;case kt.NOT_FOUND:return ne.NOT_FOUND;case kt.ALREADY_EXISTS:return ne.ALREADY_EXISTS;case kt.PERMISSION_DENIED:return ne.PERMISSION_DENIED;case kt.FAILED_PRECONDITION:return ne.FAILED_PRECONDITION;case kt.ABORTED:return ne.ABORTED;case kt.OUT_OF_RANGE:return ne.OUT_OF_RANGE;case kt.UNIMPLEMENTED:return ne.UNIMPLEMENTED;case kt.DATA_LOSS:return ne.DATA_LOSS;default:return Se()}}(He=kt||(kt={}))[He.OK=0]="OK",He[He.CANCELLED=1]="CANCELLED",He[He.UNKNOWN=2]="UNKNOWN",He[He.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",He[He.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",He[He.NOT_FOUND=5]="NOT_FOUND",He[He.ALREADY_EXISTS=6]="ALREADY_EXISTS",He[He.PERMISSION_DENIED=7]="PERMISSION_DENIED",He[He.UNAUTHENTICATED=16]="UNAUTHENTICATED",He[He.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",He[He.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",He[He.ABORTED=10]="ABORTED",He[He.OUT_OF_RANGE=11]="OUT_OF_RANGE",He[He.UNIMPLEMENTED=12]="UNIMPLEMENTED",He[He.INTERNAL=13]="INTERNAL",He[He.UNAVAILABLE=14]="UNAVAILABLE",He[He.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const WP=new xr([4294967295,4294967295],0);function tw(n){const e=tR().encode(n),t=new QA;return t.update(e),new Uint8Array(t.digest())}function nw(n){const e=new DataView(n.buffer),t=e.getUint32(0,!0),i=e.getUint32(4,!0),a=e.getUint32(8,!0),l=e.getUint32(12,!0);return[new xr([t,i],0),new xr([a,l],0)]}class Ey{constructor(e,t,i){if(this.bitmap=e,this.padding=t,this.hashCount=i,t<0||t>=8)throw new Xc(`Invalid padding: ${t}`);if(i<0)throw new Xc(`Invalid hash count: ${i}`);if(e.length>0&&this.hashCount===0)throw new Xc(`Invalid hash count: ${i}`);if(e.length===0&&t!==0)throw new Xc(`Invalid padding when bitmap length is 0: ${t}`);this.Ee=8*e.length-t,this.de=xr.fromNumber(this.Ee)}Ae(e,t,i){let a=e.add(t.multiply(xr.fromNumber(i)));return a.compare(WP)===1&&(a=new xr([a.getBits(0),a.getBits(1)],0)),a.modulo(this.de).toNumber()}Re(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.Ee===0)return!1;const t=tw(e),[i,a]=nw(t);for(let l=0;l<this.hashCount;l++){const u=this.Ae(i,a,l);if(!this.Re(u))return!1}return!0}static create(e,t,i){const a=e%8==0?0:8-e%8,l=new Uint8Array(Math.ceil(e/8)),u=new Ey(l,a,t);return i.forEach(d=>u.insert(d)),u}insert(e){if(this.Ee===0)return;const t=tw(e),[i,a]=nw(t);for(let l=0;l<this.hashCount;l++){const u=this.Ae(i,a,l);this.Ve(u)}}Ve(e){const t=Math.floor(e/8),i=e%8;this.bitmap[t]|=1<<i}}class Xc extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class em{constructor(e,t,i,a,l){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=i,this.documentUpdates=a,this.resolvedLimboDocuments=l}static createSynthesizedRemoteEventForCurrentChange(e,t,i){const a=new Map;return a.set(e,ju.createSynthesizedTargetChangeForCurrentChange(e,t,i)),new em(Re.min(),a,new Mt(Ne),Us(),je())}}class ju{constructor(e,t,i,a,l){this.resumeToken=e,this.current=t,this.addedDocuments=i,this.modifiedDocuments=a,this.removedDocuments=l}static createSynthesizedTargetChangeForCurrentChange(e,t,i){return new ju(i,t,je(),je(),je())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gd{constructor(e,t,i,a){this.me=e,this.removedTargetIds=t,this.key=i,this.fe=a}}class OR{constructor(e,t){this.targetId=e,this.ge=t}}class MR{constructor(e,t,i=on.EMPTY_BYTE_STRING,a=null){this.state=e,this.targetIds=t,this.resumeToken=i,this.cause=a}}class iw{constructor(){this.pe=0,this.ye=sw(),this.we=on.EMPTY_BYTE_STRING,this.Se=!1,this.be=!0}get current(){return this.Se}get resumeToken(){return this.we}get De(){return this.pe!==0}get ve(){return this.be}Ce(e){e.approximateByteSize()>0&&(this.be=!0,this.we=e)}Fe(){let e=je(),t=je(),i=je();return this.ye.forEach((a,l)=>{switch(l){case 0:e=e.add(a);break;case 2:t=t.add(a);break;case 1:i=i.add(a);break;default:Se()}}),new ju(this.we,this.Se,e,t,i)}Me(){this.be=!1,this.ye=sw()}xe(e,t){this.be=!0,this.ye=this.ye.insert(e,t)}Oe(e){this.be=!0,this.ye=this.ye.remove(e)}Ne(){this.pe+=1}Be(){this.pe-=1,Xe(this.pe>=0)}Le(){this.be=!0,this.Se=!0}}class XP{constructor(e){this.ke=e,this.qe=new Map,this.Qe=Us(),this.$e=Nd(),this.Ue=Nd(),this.Ke=new Mt(Ne)}We(e){for(const t of e.me)e.fe&&e.fe.isFoundDocument()?this.Ge(t,e.fe):this.ze(t,e.key,e.fe);for(const t of e.removedTargetIds)this.ze(t,e.key,e.fe)}je(e){this.forEachTarget(e,t=>{const i=this.He(t);switch(e.state){case 0:this.Je(t)&&i.Ce(e.resumeToken);break;case 1:i.Be(),i.De||i.Me(),i.Ce(e.resumeToken);break;case 2:i.Be(),i.De||this.removeTarget(t);break;case 3:this.Je(t)&&(i.Le(),i.Ce(e.resumeToken));break;case 4:this.Je(t)&&(this.Ye(t),i.Ce(e.resumeToken));break;default:Se()}})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.qe.forEach((i,a)=>{this.Je(a)&&t(a)})}Ze(e){const t=e.targetId,i=e.ge.count,a=this.Xe(t);if(a){const l=a.target;if(p_(l))if(i===0){const u=new _e(l.path);this.ze(t,u,fn.newNoDocument(u,Re.min()))}else Xe(i===1);else{const u=this.et(t);if(u!==i){const d=this.tt(e),m=d?this.nt(d,e,u):1;if(m!==0){this.Ye(t);const p=m===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ke=this.Ke.insert(t,p)}}}}}tt(e){const t=e.ge.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:i="",padding:a=0},hashCount:l=0}=t;let u,d;try{u=Mr(i).toUint8Array()}catch(m){if(m instanceof rR)return ll("Decoding the base64 bloom filter in existence filter failed ("+m.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw m}try{d=new Ey(u,a,l)}catch(m){return ll(m instanceof Xc?"BloomFilter error: ":"Applying bloom filter failed: ",m),null}return d.Ee===0?null:d}nt(e,t,i){return t.ge.count===i-this.st(e,t.targetId)?0:2}st(e,t){const i=this.ke.getRemoteKeysForTarget(t);let a=0;return i.forEach(l=>{const u=this.ke.it(),d=`projects/${u.projectId}/databases/${u.database}/documents/${l.path.canonicalString()}`;e.mightContain(d)||(this.ze(t,l,null),a++)}),a}ot(e){const t=new Map;this.qe.forEach((l,u)=>{const d=this.Xe(u);if(d){if(l.current&&p_(d.target)){const m=new _e(d.target.path);this._t(m).has(u)||this.ut(u,m)||this.ze(u,m,fn.newNoDocument(m,e))}l.ve&&(t.set(u,l.Fe()),l.Me())}});let i=je();this.Ue.forEach((l,u)=>{let d=!0;u.forEachWhile(m=>{const p=this.Xe(m);return!p||p.purpose==="TargetPurposeLimboResolution"||(d=!1,!1)}),d&&(i=i.add(l))}),this.Qe.forEach((l,u)=>u.setReadTime(e));const a=new em(e,t,this.Ke,this.Qe,i);return this.Qe=Us(),this.$e=Nd(),this.Ue=Nd(),this.Ke=new Mt(Ne),a}Ge(e,t){if(!this.Je(e))return;const i=this.ut(e,t.key)?2:0;this.He(e).xe(t.key,i),this.Qe=this.Qe.insert(t.key,t),this.$e=this.$e.insert(t.key,this._t(t.key).add(e)),this.Ue=this.Ue.insert(t.key,this.ct(t.key).add(e))}ze(e,t,i){if(!this.Je(e))return;const a=this.He(e);this.ut(e,t)?a.xe(t,1):a.Oe(t),this.Ue=this.Ue.insert(t,this.ct(t).delete(e)),this.Ue=this.Ue.insert(t,this.ct(t).add(e)),i&&(this.Qe=this.Qe.insert(t,i))}removeTarget(e){this.qe.delete(e)}et(e){const t=this.He(e).Fe();return this.ke.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}Ne(e){this.He(e).Ne()}He(e){let t=this.qe.get(e);return t||(t=new iw,this.qe.set(e,t)),t}ct(e){let t=this.Ue.get(e);return t||(t=new Bt(Ne),this.Ue=this.Ue.insert(e,t)),t}_t(e){let t=this.$e.get(e);return t||(t=new Bt(Ne),this.$e=this.$e.insert(e,t)),t}Je(e){const t=this.Xe(e)!==null;return t||de("WatchChangeAggregator","Detected inactive target",e),t}Xe(e){const t=this.qe.get(e);return t&&t.De?null:this.ke.lt(e)}Ye(e){this.qe.set(e,new iw),this.ke.getRemoteKeysForTarget(e).forEach(t=>{this.ze(e,t,null)})}ut(e,t){return this.ke.getRemoteKeysForTarget(e).has(t)}}function Nd(){return new Mt(_e.comparator)}function sw(){return new Mt(_e.comparator)}const ZP={asc:"ASCENDING",desc:"DESCENDING"},JP={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},eL={and:"AND",or:"OR"};class tL{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function y_(n,e){return n.useProto3Json||Qf(e)?e:{value:e}}function df(n,e){return n.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function PR(n,e){return n.useProto3Json?e.toBase64():e.toUint8Array()}function nL(n,e){return df(n,e.toTimestamp())}function Hi(n){return Xe(!!n),Re.fromTimestamp(function(t){const i=Or(t);return new Ft(i.seconds,i.nanos)}(n))}function Ty(n,e){return v_(n,e).canonicalString()}function v_(n,e){const t=function(a){return new ft(["projects",a.projectId,"databases",a.database])}(n).child("documents");return e===void 0?t:t.child(e)}function LR(n){const e=ft.fromString(n);return Xe(FR(e)),e}function E_(n,e){return Ty(n.databaseId,e.path)}function Ug(n,e){const t=LR(e);if(t.get(1)!==n.databaseId.projectId)throw new fe(ne.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+n.databaseId.projectId);if(t.get(3)!==n.databaseId.database)throw new fe(ne.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+n.databaseId.database);return new _e(UR(t))}function VR(n,e){return Ty(n.databaseId,e)}function iL(n){const e=LR(n);return e.length===4?ft.emptyPath():UR(e)}function T_(n){return new ft(["projects",n.databaseId.projectId,"databases",n.databaseId.database]).canonicalString()}function UR(n){return Xe(n.length>4&&n.get(4)==="documents"),n.popFirst(5)}function rw(n,e,t){return{name:E_(n,e),fields:t.value.mapValue.fields}}function sL(n,e){let t;if("targetChange"in e){e.targetChange;const i=function(p){return p==="NO_CHANGE"?0:p==="ADD"?1:p==="REMOVE"?2:p==="CURRENT"?3:p==="RESET"?4:Se()}(e.targetChange.targetChangeType||"NO_CHANGE"),a=e.targetChange.targetIds||[],l=function(p,y){return p.useProto3Json?(Xe(y===void 0||typeof y=="string"),on.fromBase64String(y||"")):(Xe(y===void 0||y instanceof Buffer||y instanceof Uint8Array),on.fromUint8Array(y||new Uint8Array))}(n,e.targetChange.resumeToken),u=e.targetChange.cause,d=u&&function(p){const y=p.code===void 0?ne.UNKNOWN:DR(p.code);return new fe(y,p.message||"")}(u);t=new MR(i,a,l,d||null)}else if("documentChange"in e){e.documentChange;const i=e.documentChange;i.document,i.document.name,i.document.updateTime;const a=Ug(n,i.document.name),l=Hi(i.document.updateTime),u=i.document.createTime?Hi(i.document.createTime):Re.min(),d=new Cn({mapValue:{fields:i.document.fields}}),m=fn.newFoundDocument(a,l,u,d),p=i.targetIds||[],y=i.removedTargetIds||[];t=new Gd(p,y,m.key,m)}else if("documentDelete"in e){e.documentDelete;const i=e.documentDelete;i.document;const a=Ug(n,i.document),l=i.readTime?Hi(i.readTime):Re.min(),u=fn.newNoDocument(a,l),d=i.removedTargetIds||[];t=new Gd([],d,u.key,u)}else if("documentRemove"in e){e.documentRemove;const i=e.documentRemove;i.document;const a=Ug(n,i.document),l=i.removedTargetIds||[];t=new Gd([],l,a,null)}else{if(!("filter"in e))return Se();{e.filter;const i=e.filter;i.targetId;const{count:a=0,unchangedNames:l}=i,u=new QP(a,l),d=i.targetId;t=new OR(d,u)}}return t}function rL(n,e){let t;if(e instanceof Uu)t={update:rw(n,e.key,e.value)};else if(e instanceof yy)t={delete:E_(n,e.key)};else if(e instanceof qr)t={update:rw(n,e.key,e.data),updateMask:mL(e.fieldMask)};else{if(!(e instanceof GP))return Se();t={verify:E_(n,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(i=>function(l,u){const d=u.transform;if(d instanceof bu)return{fieldPath:u.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(d instanceof wu)return{fieldPath:u.field.canonicalString(),appendMissingElements:{values:d.elements}};if(d instanceof Su)return{fieldPath:u.field.canonicalString(),removeAllFromArray:{values:d.elements}};if(d instanceof hf)return{fieldPath:u.field.canonicalString(),increment:d.Ie};throw Se()}(0,i))),e.precondition.isNone||(t.currentDocument=function(a,l){return l.updateTime!==void 0?{updateTime:nL(a,l.updateTime)}:l.exists!==void 0?{exists:l.exists}:Se()}(n,e.precondition)),t}function aL(n,e){return n&&n.length>0?(Xe(e!==void 0),n.map(t=>function(a,l){let u=a.updateTime?Hi(a.updateTime):Hi(l);return u.isEqual(Re.min())&&(u=Hi(l)),new BP(u,a.transformResults||[])}(t,e))):[]}function oL(n,e){return{documents:[VR(n,e.path)]}}function lL(n,e){const t={structuredQuery:{}},i=e.path;let a;e.collectionGroup!==null?(a=i,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(a=i.popLast(),t.structuredQuery.from=[{collectionId:i.lastSegment()}]),t.parent=VR(n,a);const l=function(p){if(p.length!==0)return zR(Ti.create(p,"and"))}(e.filters);l&&(t.structuredQuery.where=l);const u=function(p){if(p.length!==0)return p.map(y=>function(w){return{field:Xo(w.field),direction:hL(w.dir)}}(y))}(e.orderBy);u&&(t.structuredQuery.orderBy=u);const d=y_(n,e.limit);return d!==null&&(t.structuredQuery.limit=d),e.startAt&&(t.structuredQuery.startAt=function(p){return{before:p.inclusive,values:p.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(p){return{before:!p.inclusive,values:p.position}}(e.endAt)),{ht:t,parent:a}}function cL(n){let e=iL(n.parent);const t=n.structuredQuery,i=t.from?t.from.length:0;let a=null;if(i>0){Xe(i===1);const y=t.from[0];y.allDescendants?a=y.collectionId:e=e.child(y.collectionId)}let l=[];t.where&&(l=function(T){const w=jR(T);return w instanceof Ti&&pR(w)?w.getFilters():[w]}(t.where));let u=[];t.orderBy&&(u=function(T){return T.map(w=>function(I){return new Tu(Zo(I.field),function(P){switch(P){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(I.direction))}(w))}(t.orderBy));let d=null;t.limit&&(d=function(T){let w;return w=typeof T=="object"?T.value:T,Qf(w)?null:w}(t.limit));let m=null;t.startAt&&(m=function(T){const w=!!T.before,x=T.values||[];return new uf(x,w)}(t.startAt));let p=null;return t.endAt&&(p=function(T){const w=!T.before,x=T.values||[];return new uf(x,w)}(t.endAt)),xP(e,a,u,l,d,"F",m,p)}function uL(n,e){const t=function(a){switch(a){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return Se()}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function jR(n){return n.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const i=Zo(t.unaryFilter.field);return Ot.create(i,"==",{doubleValue:NaN});case"IS_NULL":const a=Zo(t.unaryFilter.field);return Ot.create(a,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const l=Zo(t.unaryFilter.field);return Ot.create(l,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const u=Zo(t.unaryFilter.field);return Ot.create(u,"!=",{nullValue:"NULL_VALUE"});default:return Se()}}(n):n.fieldFilter!==void 0?function(t){return Ot.create(Zo(t.fieldFilter.field),function(a){switch(a){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";default:return Se()}}(t.fieldFilter.op),t.fieldFilter.value)}(n):n.compositeFilter!==void 0?function(t){return Ti.create(t.compositeFilter.filters.map(i=>jR(i)),function(a){switch(a){case"AND":return"and";case"OR":return"or";default:return Se()}}(t.compositeFilter.op))}(n):Se()}function hL(n){return ZP[n]}function dL(n){return JP[n]}function fL(n){return eL[n]}function Xo(n){return{fieldPath:n.canonicalString()}}function Zo(n){return an.fromServerFormat(n.fieldPath)}function zR(n){return n instanceof Ot?function(t){if(t.op==="=="){if($b(t.value))return{unaryFilter:{field:Xo(t.field),op:"IS_NAN"}};if(Gb(t.value))return{unaryFilter:{field:Xo(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if($b(t.value))return{unaryFilter:{field:Xo(t.field),op:"IS_NOT_NAN"}};if(Gb(t.value))return{unaryFilter:{field:Xo(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Xo(t.field),op:dL(t.op),value:t.value}}}(n):n instanceof Ti?function(t){const i=t.getFilters().map(a=>zR(a));return i.length===1?i[0]:{compositeFilter:{op:fL(t.op),filters:i}}}(n):Se()}function mL(n){const e=[];return n.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function FR(n){return n.length>=4&&n.get(0)==="projects"&&n.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ar{constructor(e,t,i,a,l=Re.min(),u=Re.min(),d=on.EMPTY_BYTE_STRING,m=null){this.target=e,this.targetId=t,this.purpose=i,this.sequenceNumber=a,this.snapshotVersion=l,this.lastLimboFreeSnapshotVersion=u,this.resumeToken=d,this.expectedCount=m}withSequenceNumber(e){return new Ar(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new Ar(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new Ar(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new Ar(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pL{constructor(e){this.Tt=e}}function gL(n){const e=cL({parent:n.parent,structuredQuery:n.structuredQuery});return n.limitType==="LAST"?__(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _L{constructor(){this.Tn=new yL}addToCollectionParentIndex(e,t){return this.Tn.add(t),ie.resolve()}getCollectionParents(e,t){return ie.resolve(this.Tn.getEntries(t))}addFieldIndex(e,t){return ie.resolve()}deleteFieldIndex(e,t){return ie.resolve()}deleteAllFieldIndexes(e){return ie.resolve()}createTargetIndexes(e,t){return ie.resolve()}getDocumentsMatchingTarget(e,t){return ie.resolve(null)}getIndexType(e,t){return ie.resolve(0)}getFieldIndexes(e,t){return ie.resolve([])}getNextCollectionGroupToUpdate(e){return ie.resolve(null)}getMinOffset(e,t){return ie.resolve(Dr.min())}getMinOffsetFromCollectionGroup(e,t){return ie.resolve(Dr.min())}updateCollectionGroup(e,t,i){return ie.resolve()}updateIndexEntries(e,t){return ie.resolve()}}class yL{constructor(){this.index={}}add(e){const t=e.lastSegment(),i=e.popLast(),a=this.index[t]||new Bt(ft.comparator),l=!a.has(i);return this.index[t]=a.add(i),l}has(e){const t=e.lastSegment(),i=e.popLast(),a=this.index[t];return a&&a.has(i)}getEntries(e){return(this.index[e]||new Bt(ft.comparator)).toArray()}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const aw={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},BR=41943040;class An{static withCacheSize(e){return new An(e,An.DEFAULT_COLLECTION_PERCENTILE,An.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,i){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */An.DEFAULT_COLLECTION_PERCENTILE=10,An.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,An.DEFAULT=new An(BR,An.DEFAULT_COLLECTION_PERCENTILE,An.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),An.DISABLED=new An(-1,0,0);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dl{constructor(e){this.$n=e}next(){return this.$n+=2,this.$n}static Un(){return new dl(0)}static Kn(){return new dl(-1)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ow="LruGarbageCollector",vL=1048576;function lw([n,e],[t,i]){const a=Ne(n,t);return a===0?Ne(e,i):a}class EL{constructor(e){this.Hn=e,this.buffer=new Bt(lw),this.Jn=0}Yn(){return++this.Jn}Zn(e){const t=[e,this.Yn()];if(this.buffer.size<this.Hn)this.buffer=this.buffer.add(t);else{const i=this.buffer.last();lw(t,i)<0&&(this.buffer=this.buffer.delete(i).add(t))}}get maxValue(){return this.buffer.last()[0]}}class TL{constructor(e,t,i){this.garbageCollector=e,this.asyncQueue=t,this.localStore=i,this.Xn=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.er(6e4)}stop(){this.Xn&&(this.Xn.cancel(),this.Xn=null)}get started(){return this.Xn!==null}er(e){de(ow,`Garbage collection scheduled in ${e}ms`),this.Xn=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.Xn=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Sl(t)?de(ow,"Ignoring IndexedDB error during garbage collection: ",t):await wl(t)}await this.er(3e5)})}}class bL{constructor(e,t){this.tr=e,this.params=t}calculateTargetCount(e,t){return this.tr.nr(e).next(i=>Math.floor(t/100*i))}nthSequenceNumber(e,t){if(t===0)return ie.resolve(Kf.ae);const i=new EL(t);return this.tr.forEachTarget(e,a=>i.Zn(a.sequenceNumber)).next(()=>this.tr.rr(e,a=>i.Zn(a))).next(()=>i.maxValue)}removeTargets(e,t,i){return this.tr.removeTargets(e,t,i)}removeOrphanedDocuments(e,t){return this.tr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(de("LruGarbageCollector","Garbage collection skipped; disabled"),ie.resolve(aw)):this.getCacheSize(e).next(i=>i<this.params.cacheSizeCollectionThreshold?(de("LruGarbageCollector",`Garbage collection skipped; Cache size ${i} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),aw):this.ir(e,t))}getCacheSize(e){return this.tr.getCacheSize(e)}ir(e,t){let i,a,l,u,d,m,p;const y=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(T=>(T>this.params.maximumSequenceNumbersToCollect?(de("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${T}`),a=this.params.maximumSequenceNumbersToCollect):a=T,u=Date.now(),this.nthSequenceNumber(e,a))).next(T=>(i=T,d=Date.now(),this.removeTargets(e,i,t))).next(T=>(l=T,m=Date.now(),this.removeOrphanedDocuments(e,i))).next(T=>(p=Date.now(),Yo()<=Ue.DEBUG&&de("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${u-y}ms
	Determined least recently used ${a} in `+(d-u)+`ms
	Removed ${l} targets in `+(m-d)+`ms
	Removed ${T} documents in `+(p-m)+`ms
Total Duration: ${p-y}ms`),ie.resolve({didRun:!0,sequenceNumbersCollected:a,targetsRemoved:l,documentsRemoved:T})))}}function wL(n,e){return new bL(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SL{constructor(){this.changes=new Ya(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,fn.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const i=this.changes.get(t);return i!==void 0?ie.resolve(i):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class AL{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RL{constructor(e,t,i,a){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=i,this.indexManager=a}getDocument(e,t){let i=null;return this.documentOverlayCache.getOverlay(e,t).next(a=>(i=a,this.remoteDocumentCache.getEntry(e,t))).next(a=>(i!==null&&su(i.mutation,a,Bn.empty(),Ft.now()),a))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(i=>this.getLocalViewOfDocuments(e,i,je()).next(()=>i))}getLocalViewOfDocuments(e,t,i=je()){const a=Oa();return this.populateOverlays(e,a,t).next(()=>this.computeViews(e,t,a,i).next(l=>{let u=Wc();return l.forEach((d,m)=>{u=u.insert(d,m.overlayedDocument)}),u}))}getOverlayedDocuments(e,t){const i=Oa();return this.populateOverlays(e,i,t).next(()=>this.computeViews(e,t,i,je()))}populateOverlays(e,t,i){const a=[];return i.forEach(l=>{t.has(l)||a.push(l)}),this.documentOverlayCache.getOverlays(e,a).next(l=>{l.forEach((u,d)=>{t.set(u,d)})})}computeViews(e,t,i,a){let l=Us();const u=iu(),d=function(){return iu()}();return t.forEach((m,p)=>{const y=i.get(p.key);a.has(p.key)&&(y===void 0||y.mutation instanceof qr)?l=l.insert(p.key,p):y!==void 0?(u.set(p.key,y.mutation.getFieldMask()),su(y.mutation,p,y.mutation.getFieldMask(),Ft.now())):u.set(p.key,Bn.empty())}),this.recalculateAndSaveOverlays(e,l).next(m=>(m.forEach((p,y)=>u.set(p,y)),t.forEach((p,y)=>{var T;return d.set(p,new AL(y,(T=u.get(p))!==null&&T!==void 0?T:null))}),d))}recalculateAndSaveOverlays(e,t){const i=iu();let a=new Mt((u,d)=>u-d),l=je();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(u=>{for(const d of u)d.keys().forEach(m=>{const p=t.get(m);if(p===null)return;let y=i.get(m)||Bn.empty();y=d.applyToLocalView(p,y),i.set(m,y);const T=(a.get(d.batchId)||je()).add(m);a=a.insert(d.batchId,T)})}).next(()=>{const u=[],d=a.getReverseIterator();for(;d.hasNext();){const m=d.getNext(),p=m.key,y=m.value,T=SR();y.forEach(w=>{if(!l.has(w)){const x=NR(t.get(w),i.get(w));x!==null&&T.set(w,x),l=l.add(w)}}),u.push(this.documentOverlayCache.saveOverlays(e,p,T))}return ie.waitFor(u)}).next(()=>i)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(i=>this.recalculateAndSaveOverlays(e,i))}getDocumentsMatchingQuery(e,t,i,a){return function(u){return _e.isDocumentKey(u.path)&&u.collectionGroup===null&&u.filters.length===0}(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):vR(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,i,a):this.getDocumentsMatchingCollectionQuery(e,t,i,a)}getNextDocuments(e,t,i,a){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,i,a).next(l=>{const u=a-l.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,i.largestBatchId,a-l.size):ie.resolve(Oa());let d=_u,m=l;return u.next(p=>ie.forEach(p,(y,T)=>(d<T.largestBatchId&&(d=T.largestBatchId),l.get(y)?ie.resolve():this.remoteDocumentCache.getEntry(e,y).next(w=>{m=m.insert(y,w)}))).next(()=>this.populateOverlays(e,p,l)).next(()=>this.computeViews(e,m,p,je())).next(y=>({batchId:d,changes:wR(y)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new _e(t)).next(i=>{let a=Wc();return i.isFoundDocument()&&(a=a.insert(i.key,i)),a})}getDocumentsMatchingCollectionGroupQuery(e,t,i,a){const l=t.collectionGroup;let u=Wc();return this.indexManager.getCollectionParents(e,l).next(d=>ie.forEach(d,m=>{const p=function(T,w){return new Al(w,null,T.explicitOrderBy.slice(),T.filters.slice(),T.limit,T.limitType,T.startAt,T.endAt)}(t,m.child(l));return this.getDocumentsMatchingCollectionQuery(e,p,i,a).next(y=>{y.forEach((T,w)=>{u=u.insert(T,w)})})}).next(()=>u))}getDocumentsMatchingCollectionQuery(e,t,i,a){let l;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,i.largestBatchId).next(u=>(l=u,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,i,l,a))).next(u=>{l.forEach((m,p)=>{const y=p.getKey();u.get(y)===null&&(u=u.insert(y,fn.newInvalidDocument(y)))});let d=Wc();return u.forEach((m,p)=>{const y=l.get(m);y!==void 0&&su(y.mutation,p,Bn.empty(),Ft.now()),Xf(t,p)&&(d=d.insert(m,p))}),d})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CL{constructor(e){this.serializer=e,this.dr=new Map,this.Ar=new Map}getBundleMetadata(e,t){return ie.resolve(this.dr.get(t))}saveBundleMetadata(e,t){return this.dr.set(t.id,function(a){return{id:a.id,version:a.version,createTime:Hi(a.createTime)}}(t)),ie.resolve()}getNamedQuery(e,t){return ie.resolve(this.Ar.get(t))}saveNamedQuery(e,t){return this.Ar.set(t.name,function(a){return{name:a.name,query:gL(a.bundledQuery),readTime:Hi(a.readTime)}}(t)),ie.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xL{constructor(){this.overlays=new Mt(_e.comparator),this.Rr=new Map}getOverlay(e,t){return ie.resolve(this.overlays.get(t))}getOverlays(e,t){const i=Oa();return ie.forEach(t,a=>this.getOverlay(e,a).next(l=>{l!==null&&i.set(a,l)})).next(()=>i)}saveOverlays(e,t,i){return i.forEach((a,l)=>{this.Et(e,t,l)}),ie.resolve()}removeOverlaysForBatchId(e,t,i){const a=this.Rr.get(i);return a!==void 0&&(a.forEach(l=>this.overlays=this.overlays.remove(l)),this.Rr.delete(i)),ie.resolve()}getOverlaysForCollection(e,t,i){const a=Oa(),l=t.length+1,u=new _e(t.child("")),d=this.overlays.getIteratorFrom(u);for(;d.hasNext();){const m=d.getNext().value,p=m.getKey();if(!t.isPrefixOf(p.path))break;p.path.length===l&&m.largestBatchId>i&&a.set(m.getKey(),m)}return ie.resolve(a)}getOverlaysForCollectionGroup(e,t,i,a){let l=new Mt((p,y)=>p-y);const u=this.overlays.getIterator();for(;u.hasNext();){const p=u.getNext().value;if(p.getKey().getCollectionGroup()===t&&p.largestBatchId>i){let y=l.get(p.largestBatchId);y===null&&(y=Oa(),l=l.insert(p.largestBatchId,y)),y.set(p.getKey(),p)}}const d=Oa(),m=l.getIterator();for(;m.hasNext()&&(m.getNext().value.forEach((p,y)=>d.set(p,y)),!(d.size()>=a)););return ie.resolve(d)}Et(e,t,i){const a=this.overlays.get(i.key);if(a!==null){const u=this.Rr.get(a.largestBatchId).delete(i.key);this.Rr.set(a.largestBatchId,u)}this.overlays=this.overlays.insert(i.key,new KP(t,i));let l=this.Rr.get(t);l===void 0&&(l=je(),this.Rr.set(t,l)),this.Rr.set(t,l.add(i.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IL{constructor(){this.sessionToken=on.EMPTY_BYTE_STRING}getSessionToken(e){return ie.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,ie.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class by{constructor(){this.Vr=new Bt(Wt.mr),this.gr=new Bt(Wt.pr)}isEmpty(){return this.Vr.isEmpty()}addReference(e,t){const i=new Wt(e,t);this.Vr=this.Vr.add(i),this.gr=this.gr.add(i)}yr(e,t){e.forEach(i=>this.addReference(i,t))}removeReference(e,t){this.wr(new Wt(e,t))}Sr(e,t){e.forEach(i=>this.removeReference(i,t))}br(e){const t=new _e(new ft([])),i=new Wt(t,e),a=new Wt(t,e+1),l=[];return this.gr.forEachInRange([i,a],u=>{this.wr(u),l.push(u.key)}),l}Dr(){this.Vr.forEach(e=>this.wr(e))}wr(e){this.Vr=this.Vr.delete(e),this.gr=this.gr.delete(e)}vr(e){const t=new _e(new ft([])),i=new Wt(t,e),a=new Wt(t,e+1);let l=je();return this.gr.forEachInRange([i,a],u=>{l=l.add(u.key)}),l}containsKey(e){const t=new Wt(e,0),i=this.Vr.firstAfterOrEqual(t);return i!==null&&e.isEqual(i.key)}}class Wt{constructor(e,t){this.key=e,this.Cr=t}static mr(e,t){return _e.comparator(e.key,t.key)||Ne(e.Cr,t.Cr)}static pr(e,t){return Ne(e.Cr,t.Cr)||_e.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NL{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Fr=1,this.Mr=new Bt(Wt.mr)}checkEmpty(e){return ie.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,i,a){const l=this.Fr;this.Fr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const u=new $P(l,t,i,a);this.mutationQueue.push(u);for(const d of a)this.Mr=this.Mr.add(new Wt(d.key,l)),this.indexManager.addToCollectionParentIndex(e,d.key.path.popLast());return ie.resolve(u)}lookupMutationBatch(e,t){return ie.resolve(this.Or(t))}getNextMutationBatchAfterBatchId(e,t){const i=t+1,a=this.Nr(i),l=a<0?0:a;return ie.resolve(this.mutationQueue.length>l?this.mutationQueue[l]:null)}getHighestUnacknowledgedBatchId(){return ie.resolve(this.mutationQueue.length===0?hy:this.Fr-1)}getAllMutationBatches(e){return ie.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const i=new Wt(t,0),a=new Wt(t,Number.POSITIVE_INFINITY),l=[];return this.Mr.forEachInRange([i,a],u=>{const d=this.Or(u.Cr);l.push(d)}),ie.resolve(l)}getAllMutationBatchesAffectingDocumentKeys(e,t){let i=new Bt(Ne);return t.forEach(a=>{const l=new Wt(a,0),u=new Wt(a,Number.POSITIVE_INFINITY);this.Mr.forEachInRange([l,u],d=>{i=i.add(d.Cr)})}),ie.resolve(this.Br(i))}getAllMutationBatchesAffectingQuery(e,t){const i=t.path,a=i.length+1;let l=i;_e.isDocumentKey(l)||(l=l.child(""));const u=new Wt(new _e(l),0);let d=new Bt(Ne);return this.Mr.forEachWhile(m=>{const p=m.key.path;return!!i.isPrefixOf(p)&&(p.length===a&&(d=d.add(m.Cr)),!0)},u),ie.resolve(this.Br(d))}Br(e){const t=[];return e.forEach(i=>{const a=this.Or(i);a!==null&&t.push(a)}),t}removeMutationBatch(e,t){Xe(this.Lr(t.batchId,"removed")===0),this.mutationQueue.shift();let i=this.Mr;return ie.forEach(t.mutations,a=>{const l=new Wt(a.key,t.batchId);return i=i.delete(l),this.referenceDelegate.markPotentiallyOrphaned(e,a.key)}).next(()=>{this.Mr=i})}qn(e){}containsKey(e,t){const i=new Wt(t,0),a=this.Mr.firstAfterOrEqual(i);return ie.resolve(t.isEqual(a&&a.key))}performConsistencyCheck(e){return this.mutationQueue.length,ie.resolve()}Lr(e,t){return this.Nr(e)}Nr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Or(e){const t=this.Nr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kL{constructor(e){this.kr=e,this.docs=function(){return new Mt(_e.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const i=t.key,a=this.docs.get(i),l=a?a.size:0,u=this.kr(t);return this.docs=this.docs.insert(i,{document:t.mutableCopy(),size:u}),this.size+=u-l,this.indexManager.addToCollectionParentIndex(e,i.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const i=this.docs.get(t);return ie.resolve(i?i.document.mutableCopy():fn.newInvalidDocument(t))}getEntries(e,t){let i=Us();return t.forEach(a=>{const l=this.docs.get(a);i=i.insert(a,l?l.document.mutableCopy():fn.newInvalidDocument(a))}),ie.resolve(i)}getDocumentsMatchingQuery(e,t,i,a){let l=Us();const u=t.path,d=new _e(u.child("__id-9223372036854775808__")),m=this.docs.getIteratorFrom(d);for(;m.hasNext();){const{key:p,value:{document:y}}=m.getNext();if(!u.isPrefixOf(p.path))break;p.path.length>u.length+1||aP(rP(y),i)<=0||(a.has(y.key)||Xf(t,y))&&(l=l.insert(y.key,y.mutableCopy()))}return ie.resolve(l)}getAllFromCollectionGroup(e,t,i,a){Se()}qr(e,t){return ie.forEach(this.docs,i=>t(i))}newChangeBuffer(e){return new DL(this)}getSize(e){return ie.resolve(this.size)}}class DL extends SL{constructor(e){super(),this.Ir=e}applyChanges(e){const t=[];return this.changes.forEach((i,a)=>{a.isValidDocument()?t.push(this.Ir.addEntry(e,a)):this.Ir.removeEntry(i)}),ie.waitFor(t)}getFromCache(e,t){return this.Ir.getEntry(e,t)}getAllFromCache(e,t){return this.Ir.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class OL{constructor(e){this.persistence=e,this.Qr=new Ya(t=>my(t),py),this.lastRemoteSnapshotVersion=Re.min(),this.highestTargetId=0,this.$r=0,this.Ur=new by,this.targetCount=0,this.Kr=dl.Un()}forEachTarget(e,t){return this.Qr.forEach((i,a)=>t(a)),ie.resolve()}getLastRemoteSnapshotVersion(e){return ie.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return ie.resolve(this.$r)}allocateTargetId(e){return this.highestTargetId=this.Kr.next(),ie.resolve(this.highestTargetId)}setTargetsMetadata(e,t,i){return i&&(this.lastRemoteSnapshotVersion=i),t>this.$r&&(this.$r=t),ie.resolve()}zn(e){this.Qr.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Kr=new dl(t),this.highestTargetId=t),e.sequenceNumber>this.$r&&(this.$r=e.sequenceNumber)}addTargetData(e,t){return this.zn(t),this.targetCount+=1,ie.resolve()}updateTargetData(e,t){return this.zn(t),ie.resolve()}removeTargetData(e,t){return this.Qr.delete(t.target),this.Ur.br(t.targetId),this.targetCount-=1,ie.resolve()}removeTargets(e,t,i){let a=0;const l=[];return this.Qr.forEach((u,d)=>{d.sequenceNumber<=t&&i.get(d.targetId)===null&&(this.Qr.delete(u),l.push(this.removeMatchingKeysForTargetId(e,d.targetId)),a++)}),ie.waitFor(l).next(()=>a)}getTargetCount(e){return ie.resolve(this.targetCount)}getTargetData(e,t){const i=this.Qr.get(t)||null;return ie.resolve(i)}addMatchingKeys(e,t,i){return this.Ur.yr(t,i),ie.resolve()}removeMatchingKeys(e,t,i){this.Ur.Sr(t,i);const a=this.persistence.referenceDelegate,l=[];return a&&t.forEach(u=>{l.push(a.markPotentiallyOrphaned(e,u))}),ie.waitFor(l)}removeMatchingKeysForTargetId(e,t){return this.Ur.br(t),ie.resolve()}getMatchingKeysForTargetId(e,t){const i=this.Ur.vr(t);return ie.resolve(i)}containsKey(e,t){return ie.resolve(this.Ur.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qR{constructor(e,t){this.Wr={},this.overlays={},this.Gr=new Kf(0),this.zr=!1,this.zr=!0,this.jr=new IL,this.referenceDelegate=e(this),this.Hr=new OL(this),this.indexManager=new _L,this.remoteDocumentCache=function(a){return new kL(a)}(i=>this.referenceDelegate.Jr(i)),this.serializer=new pL(t),this.Yr=new CL(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.zr=!1,Promise.resolve()}get started(){return this.zr}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new xL,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let i=this.Wr[e.toKey()];return i||(i=new NL(t,this.referenceDelegate),this.Wr[e.toKey()]=i),i}getGlobalsCache(){return this.jr}getTargetCache(){return this.Hr}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Yr}runTransaction(e,t,i){de("MemoryPersistence","Starting transaction:",e);const a=new ML(this.Gr.next());return this.referenceDelegate.Zr(),i(a).next(l=>this.referenceDelegate.Xr(a).next(()=>l)).toPromise().then(l=>(a.raiseOnCommittedEvent(),l))}ei(e,t){return ie.or(Object.values(this.Wr).map(i=>()=>i.containsKey(e,t)))}}class ML extends lP{constructor(e){super(),this.currentSequenceNumber=e}}class wy{constructor(e){this.persistence=e,this.ti=new by,this.ni=null}static ri(e){return new wy(e)}get ii(){if(this.ni)return this.ni;throw Se()}addReference(e,t,i){return this.ti.addReference(i,t),this.ii.delete(i.toString()),ie.resolve()}removeReference(e,t,i){return this.ti.removeReference(i,t),this.ii.add(i.toString()),ie.resolve()}markPotentiallyOrphaned(e,t){return this.ii.add(t.toString()),ie.resolve()}removeTarget(e,t){this.ti.br(t.targetId).forEach(a=>this.ii.add(a.toString()));const i=this.persistence.getTargetCache();return i.getMatchingKeysForTargetId(e,t.targetId).next(a=>{a.forEach(l=>this.ii.add(l.toString()))}).next(()=>i.removeTargetData(e,t))}Zr(){this.ni=new Set}Xr(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return ie.forEach(this.ii,i=>{const a=_e.fromPath(i);return this.si(e,a).next(l=>{l||t.removeEntry(a,Re.min())})}).next(()=>(this.ni=null,t.apply(e)))}updateLimboDocument(e,t){return this.si(e,t).next(i=>{i?this.ii.delete(t.toString()):this.ii.add(t.toString())})}Jr(e){return 0}si(e,t){return ie.or([()=>ie.resolve(this.ti.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.ei(e,t)])}}class ff{constructor(e,t){this.persistence=e,this.oi=new Ya(i=>hP(i.path),(i,a)=>i.isEqual(a)),this.garbageCollector=wL(this,t)}static ri(e,t){return new ff(e,t)}Zr(){}Xr(e){return ie.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}nr(e){const t=this.sr(e);return this.persistence.getTargetCache().getTargetCount(e).next(i=>t.next(a=>i+a))}sr(e){let t=0;return this.rr(e,i=>{t++}).next(()=>t)}rr(e,t){return ie.forEach(this.oi,(i,a)=>this.ar(e,i,a).next(l=>l?ie.resolve():t(a)))}removeTargets(e,t,i){return this.persistence.getTargetCache().removeTargets(e,t,i)}removeOrphanedDocuments(e,t){let i=0;const a=this.persistence.getRemoteDocumentCache(),l=a.newChangeBuffer();return a.qr(e,u=>this.ar(e,u,t).next(d=>{d||(i++,l.removeEntry(u,Re.min()))})).next(()=>l.apply(e)).next(()=>i)}markPotentiallyOrphaned(e,t){return this.oi.set(t,e.currentSequenceNumber),ie.resolve()}removeTarget(e,t){const i=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,i)}addReference(e,t,i){return this.oi.set(i,e.currentSequenceNumber),ie.resolve()}removeReference(e,t,i){return this.oi.set(i,e.currentSequenceNumber),ie.resolve()}updateLimboDocument(e,t){return this.oi.set(t,e.currentSequenceNumber),ie.resolve()}Jr(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=Bd(e.data.value)),t}ar(e,t,i){return ie.or([()=>this.persistence.ei(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const a=this.oi.get(t);return ie.resolve(a!==void 0&&a>i)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sy{constructor(e,t,i,a){this.targetId=e,this.fromCache=t,this.Hi=i,this.Ji=a}static Yi(e,t){let i=je(),a=je();for(const l of t.docChanges)switch(l.type){case 0:i=i.add(l.doc.key);break;case 1:a=a.add(l.doc.key)}return new Sy(e,t.fromCache,i,a)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PL{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class LL{constructor(){this.Zi=!1,this.Xi=!1,this.es=100,this.ts=function(){return rD()?8:cP(gn())>0?6:4}()}initialize(e,t){this.ns=e,this.indexManager=t,this.Zi=!0}getDocumentsMatchingQuery(e,t,i,a){const l={result:null};return this.rs(e,t).next(u=>{l.result=u}).next(()=>{if(!l.result)return this.ss(e,t,a,i).next(u=>{l.result=u})}).next(()=>{if(l.result)return;const u=new PL;return this._s(e,t,u).next(d=>{if(l.result=d,this.Xi)return this.us(e,t,u,d.size)})}).next(()=>l.result)}us(e,t,i,a){return i.documentReadCount<this.es?(Yo()<=Ue.DEBUG&&de("QueryEngine","SDK will not create cache indexes for query:",Wo(t),"since it only creates cache indexes for collection contains","more than or equal to",this.es,"documents"),ie.resolve()):(Yo()<=Ue.DEBUG&&de("QueryEngine","Query:",Wo(t),"scans",i.documentReadCount,"local documents and returns",a,"documents as results."),i.documentReadCount>this.ts*a?(Yo()<=Ue.DEBUG&&de("QueryEngine","The SDK decides to create cache indexes for query:",Wo(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,qi(t))):ie.resolve())}rs(e,t){if(Wb(t))return ie.resolve(null);let i=qi(t);return this.indexManager.getIndexType(e,i).next(a=>a===0?null:(t.limit!==null&&a===1&&(t=__(t,null,"F"),i=qi(t)),this.indexManager.getDocumentsMatchingTarget(e,i).next(l=>{const u=je(...l);return this.ns.getDocuments(e,u).next(d=>this.indexManager.getMinOffset(e,i).next(m=>{const p=this.cs(t,d);return this.ls(t,p,u,m.readTime)?this.rs(e,__(t,null,"F")):this.hs(e,p,t,m)}))})))}ss(e,t,i,a){return Wb(t)||a.isEqual(Re.min())?ie.resolve(null):this.ns.getDocuments(e,i).next(l=>{const u=this.cs(t,l);return this.ls(t,u,i,a)?ie.resolve(null):(Yo()<=Ue.DEBUG&&de("QueryEngine","Re-using previous result from %s to execute query: %s",a.toString(),Wo(t)),this.hs(e,u,t,sP(a,_u)).next(d=>d))})}cs(e,t){let i=new Bt(TR(e));return t.forEach((a,l)=>{Xf(e,l)&&(i=i.add(l))}),i}ls(e,t,i,a){if(e.limit===null)return!1;if(i.size!==t.size)return!0;const l=e.limitType==="F"?t.last():t.first();return!!l&&(l.hasPendingWrites||l.version.compareTo(a)>0)}_s(e,t,i){return Yo()<=Ue.DEBUG&&de("QueryEngine","Using full collection scan to execute query:",Wo(t)),this.ns.getDocumentsMatchingQuery(e,t,Dr.min(),i)}hs(e,t,i,a){return this.ns.getDocumentsMatchingQuery(e,i,a).next(l=>(t.forEach(u=>{l=l.insert(u.key,u)}),l))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ay="LocalStore",VL=3e8;class UL{constructor(e,t,i,a){this.persistence=e,this.Ps=t,this.serializer=a,this.Ts=new Mt(Ne),this.Is=new Ya(l=>my(l),py),this.Es=new Map,this.ds=e.getRemoteDocumentCache(),this.Hr=e.getTargetCache(),this.Yr=e.getBundleCache(),this.As(i)}As(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new RL(this.ds,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.ds.setIndexManager(this.indexManager),this.Ps.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.Ts))}}function jL(n,e,t,i){return new UL(n,e,t,i)}async function HR(n,e){const t=Ce(n);return await t.persistence.runTransaction("Handle user change","readonly",i=>{let a;return t.mutationQueue.getAllMutationBatches(i).next(l=>(a=l,t.As(e),t.mutationQueue.getAllMutationBatches(i))).next(l=>{const u=[],d=[];let m=je();for(const p of a){u.push(p.batchId);for(const y of p.mutations)m=m.add(y.key)}for(const p of l){d.push(p.batchId);for(const y of p.mutations)m=m.add(y.key)}return t.localDocuments.getDocuments(i,m).next(p=>({Rs:p,removedBatchIds:u,addedBatchIds:d}))})})}function zL(n,e){const t=Ce(n);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",i=>{const a=e.batch.keys(),l=t.ds.newChangeBuffer({trackRemovals:!0});return function(d,m,p,y){const T=p.batch,w=T.keys();let x=ie.resolve();return w.forEach(I=>{x=x.next(()=>y.getEntry(m,I)).next(O=>{const P=p.docVersions.get(I);Xe(P!==null),O.version.compareTo(P)<0&&(T.applyToRemoteDocument(O,p),O.isValidDocument()&&(O.setReadTime(p.commitVersion),y.addEntry(O)))})}),x.next(()=>d.mutationQueue.removeMutationBatch(m,T))}(t,i,e,l).next(()=>l.apply(i)).next(()=>t.mutationQueue.performConsistencyCheck(i)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(i,a,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(i,function(d){let m=je();for(let p=0;p<d.mutationResults.length;++p)d.mutationResults[p].transformResults.length>0&&(m=m.add(d.batch.mutations[p].key));return m}(e))).next(()=>t.localDocuments.getDocuments(i,a))})}function GR(n){const e=Ce(n);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.Hr.getLastRemoteSnapshotVersion(t))}function FL(n,e){const t=Ce(n),i=e.snapshotVersion;let a=t.Ts;return t.persistence.runTransaction("Apply remote event","readwrite-primary",l=>{const u=t.ds.newChangeBuffer({trackRemovals:!0});a=t.Ts;const d=[];e.targetChanges.forEach((y,T)=>{const w=a.get(T);if(!w)return;d.push(t.Hr.removeMatchingKeys(l,y.removedDocuments,T).next(()=>t.Hr.addMatchingKeys(l,y.addedDocuments,T)));let x=w.withSequenceNumber(l.currentSequenceNumber);e.targetMismatches.get(T)!==null?x=x.withResumeToken(on.EMPTY_BYTE_STRING,Re.min()).withLastLimboFreeSnapshotVersion(Re.min()):y.resumeToken.approximateByteSize()>0&&(x=x.withResumeToken(y.resumeToken,i)),a=a.insert(T,x),function(O,P,B){return O.resumeToken.approximateByteSize()===0||P.snapshotVersion.toMicroseconds()-O.snapshotVersion.toMicroseconds()>=VL?!0:B.addedDocuments.size+B.modifiedDocuments.size+B.removedDocuments.size>0}(w,x,y)&&d.push(t.Hr.updateTargetData(l,x))});let m=Us(),p=je();if(e.documentUpdates.forEach(y=>{e.resolvedLimboDocuments.has(y)&&d.push(t.persistence.referenceDelegate.updateLimboDocument(l,y))}),d.push(BL(l,u,e.documentUpdates).next(y=>{m=y.Vs,p=y.fs})),!i.isEqual(Re.min())){const y=t.Hr.getLastRemoteSnapshotVersion(l).next(T=>t.Hr.setTargetsMetadata(l,l.currentSequenceNumber,i));d.push(y)}return ie.waitFor(d).next(()=>u.apply(l)).next(()=>t.localDocuments.getLocalViewOfDocuments(l,m,p)).next(()=>m)}).then(l=>(t.Ts=a,l))}function BL(n,e,t){let i=je(),a=je();return t.forEach(l=>i=i.add(l)),e.getEntries(n,i).next(l=>{let u=Us();return t.forEach((d,m)=>{const p=l.get(d);m.isFoundDocument()!==p.isFoundDocument()&&(a=a.add(d)),m.isNoDocument()&&m.version.isEqual(Re.min())?(e.removeEntry(d,m.readTime),u=u.insert(d,m)):!p.isValidDocument()||m.version.compareTo(p.version)>0||m.version.compareTo(p.version)===0&&p.hasPendingWrites?(e.addEntry(m),u=u.insert(d,m)):de(Ay,"Ignoring outdated watch update for ",d,". Current version:",p.version," Watch version:",m.version)}),{Vs:u,fs:a}})}function qL(n,e){const t=Ce(n);return t.persistence.runTransaction("Get next mutation batch","readonly",i=>(e===void 0&&(e=hy),t.mutationQueue.getNextMutationBatchAfterBatchId(i,e)))}function HL(n,e){const t=Ce(n);return t.persistence.runTransaction("Allocate target","readwrite",i=>{let a;return t.Hr.getTargetData(i,e).next(l=>l?(a=l,ie.resolve(a)):t.Hr.allocateTargetId(i).next(u=>(a=new Ar(e,u,"TargetPurposeListen",i.currentSequenceNumber),t.Hr.addTargetData(i,a).next(()=>a))))}).then(i=>{const a=t.Ts.get(i.targetId);return(a===null||i.snapshotVersion.compareTo(a.snapshotVersion)>0)&&(t.Ts=t.Ts.insert(i.targetId,i),t.Is.set(e,i.targetId)),i})}async function b_(n,e,t){const i=Ce(n),a=i.Ts.get(e),l=t?"readwrite":"readwrite-primary";try{t||await i.persistence.runTransaction("Release target",l,u=>i.persistence.referenceDelegate.removeTarget(u,a))}catch(u){if(!Sl(u))throw u;de(Ay,`Failed to update sequence numbers for target ${e}: ${u}`)}i.Ts=i.Ts.remove(e),i.Is.delete(a.target)}function cw(n,e,t){const i=Ce(n);let a=Re.min(),l=je();return i.persistence.runTransaction("Execute query","readwrite",u=>function(m,p,y){const T=Ce(m),w=T.Is.get(y);return w!==void 0?ie.resolve(T.Ts.get(w)):T.Hr.getTargetData(p,y)}(i,u,qi(e)).next(d=>{if(d)return a=d.lastLimboFreeSnapshotVersion,i.Hr.getMatchingKeysForTargetId(u,d.targetId).next(m=>{l=m})}).next(()=>i.Ps.getDocumentsMatchingQuery(u,e,t?a:Re.min(),t?l:je())).next(d=>(GL(i,NP(e),d),{documents:d,gs:l})))}function GL(n,e,t){let i=n.Es.get(e)||Re.min();t.forEach((a,l)=>{l.readTime.compareTo(i)>0&&(i=l.readTime)}),n.Es.set(e,i)}class uw{constructor(){this.activeTargetIds=LP()}Ds(e){this.activeTargetIds=this.activeTargetIds.add(e)}vs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}bs(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class $L{constructor(){this.ho=new uw,this.Po={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,i){}addLocalQueryTarget(e,t=!0){return t&&this.ho.Ds(e),this.Po[e]||"not-current"}updateQueryState(e,t,i){this.Po[e]=t}removeLocalQueryTarget(e){this.ho.vs(e)}isLocalQueryTarget(e){return this.ho.activeTargetIds.has(e)}clearQueryState(e){delete this.Po[e]}getAllActiveQueryTargets(){return this.ho.activeTargetIds}isActiveQueryTarget(e){return this.ho.activeTargetIds.has(e)}start(){return this.ho=new uw,Promise.resolve()}handleUserChange(e,t,i){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class KL{To(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hw="ConnectivityMonitor";class dw{constructor(){this.Io=()=>this.Eo(),this.Ao=()=>this.Ro(),this.Vo=[],this.mo()}To(e){this.Vo.push(e)}shutdown(){window.removeEventListener("online",this.Io),window.removeEventListener("offline",this.Ao)}mo(){window.addEventListener("online",this.Io),window.addEventListener("offline",this.Ao)}Eo(){de(hw,"Network connectivity changed: AVAILABLE");for(const e of this.Vo)e(0)}Ro(){de(hw,"Network connectivity changed: UNAVAILABLE");for(const e of this.Vo)e(1)}static D(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let kd=null;function w_(){return kd===null?kd=function(){return 268435456+Math.round(2147483648*Math.random())}():kd++,"0x"+kd.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jg="RestConnection",QL={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery"};class YL{get fo(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",i=encodeURIComponent(this.databaseId.projectId),a=encodeURIComponent(this.databaseId.database);this.po=t+"://"+e.host,this.yo=`projects/${i}/databases/${a}`,this.wo=this.databaseId.database===lf?`project_id=${i}`:`project_id=${i}&database_id=${a}`}So(e,t,i,a,l){const u=w_(),d=this.bo(e,t.toUriEncodedString());de(jg,`Sending RPC '${e}' ${u}:`,d,i);const m={"google-cloud-resource-prefix":this.yo,"x-goog-request-params":this.wo};return this.Do(m,a,l),this.vo(e,d,m,i).then(p=>(de(jg,`Received RPC '${e}' ${u}: `,p),p),p=>{throw ll(jg,`RPC '${e}' ${u} failed with error: `,p,"url: ",d,"request:",i),p})}Co(e,t,i,a,l,u){return this.So(e,t,i,a,l)}Do(e,t,i){e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+bl}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((a,l)=>e[l]=a),i&&i.headers.forEach((a,l)=>e[l]=a)}bo(e,t){const i=QL[e];return`${this.po}/v1/${t}:${i}`}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WL{constructor(e){this.Fo=e.Fo,this.Mo=e.Mo}xo(e){this.Oo=e}No(e){this.Bo=e}Lo(e){this.ko=e}onMessage(e){this.qo=e}close(){this.Mo()}send(e){this.Fo(e)}Qo(){this.Oo()}$o(){this.Bo()}Uo(e){this.ko(e)}Ko(e){this.qo(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hn="WebChannelConnection";class XL extends YL{constructor(e){super(e),this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}vo(e,t,i,a){const l=w_();return new Promise((u,d)=>{const m=new YA;m.setWithCredentials(!0),m.listenOnce(WA.COMPLETE,()=>{try{switch(m.getLastErrorCode()){case Fd.NO_ERROR:const y=m.getResponseJson();de(hn,`XHR for RPC '${e}' ${l} received:`,JSON.stringify(y)),u(y);break;case Fd.TIMEOUT:de(hn,`RPC '${e}' ${l} timed out`),d(new fe(ne.DEADLINE_EXCEEDED,"Request time out"));break;case Fd.HTTP_ERROR:const T=m.getStatus();if(de(hn,`RPC '${e}' ${l} failed with status:`,T,"response text:",m.getResponseText()),T>0){let w=m.getResponseJson();Array.isArray(w)&&(w=w[0]);const x=w==null?void 0:w.error;if(x&&x.status&&x.message){const I=function(P){const B=P.toLowerCase().replace(/_/g,"-");return Object.values(ne).indexOf(B)>=0?B:ne.UNKNOWN}(x.status);d(new fe(I,x.message))}else d(new fe(ne.UNKNOWN,"Server responded with status "+m.getStatus()))}else d(new fe(ne.UNAVAILABLE,"Connection failed."));break;default:Se()}}finally{de(hn,`RPC '${e}' ${l} completed.`)}});const p=JSON.stringify(a);de(hn,`RPC '${e}' ${l} sending request:`,a),m.send(t,"POST",p,i,15)})}Wo(e,t,i){const a=w_(),l=[this.po,"/","google.firestore.v1.Firestore","/",e,"/channel"],u=JA(),d=ZA(),m={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},p=this.longPollingOptions.timeoutSeconds;p!==void 0&&(m.longPollingTimeout=Math.round(1e3*p)),this.useFetchStreams&&(m.useFetchStreams=!0),this.Do(m.initMessageHeaders,t,i),m.encodeInitMessageHeaders=!0;const y=l.join("");de(hn,`Creating RPC '${e}' stream ${a}: ${y}`,m);const T=u.createWebChannel(y,m);let w=!1,x=!1;const I=new WL({Fo:P=>{x?de(hn,`Not sending because RPC '${e}' stream ${a} is closed:`,P):(w||(de(hn,`Opening RPC '${e}' stream ${a} transport.`),T.open(),w=!0),de(hn,`RPC '${e}' stream ${a} sending:`,P),T.send(P))},Mo:()=>T.close()}),O=(P,B,ee)=>{P.listen(B,Y=>{try{ee(Y)}catch(W){setTimeout(()=>{throw W},0)}})};return O(T,Yc.EventType.OPEN,()=>{x||(de(hn,`RPC '${e}' stream ${a} transport opened.`),I.Qo())}),O(T,Yc.EventType.CLOSE,()=>{x||(x=!0,de(hn,`RPC '${e}' stream ${a} transport closed`),I.Uo())}),O(T,Yc.EventType.ERROR,P=>{x||(x=!0,ll(hn,`RPC '${e}' stream ${a} transport errored:`,P),I.Uo(new fe(ne.UNAVAILABLE,"The operation could not be completed")))}),O(T,Yc.EventType.MESSAGE,P=>{var B;if(!x){const ee=P.data[0];Xe(!!ee);const Y=ee,W=(Y==null?void 0:Y.error)||((B=Y[0])===null||B===void 0?void 0:B.error);if(W){de(hn,`RPC '${e}' stream ${a} received error:`,W);const re=W.status;let he=function(C){const N=kt[C];if(N!==void 0)return DR(N)}(re),M=W.message;he===void 0&&(he=ne.INTERNAL,M="Unknown error status: "+re+" with message "+W.message),x=!0,I.Uo(new fe(he,M)),T.close()}else de(hn,`RPC '${e}' stream ${a} received:`,ee),I.Ko(ee)}}),O(d,XA.STAT_EVENT,P=>{P.stat===c_.PROXY?de(hn,`RPC '${e}' stream ${a} detected buffering proxy`):P.stat===c_.NOPROXY&&de(hn,`RPC '${e}' stream ${a} detected no buffering proxy`)}),setTimeout(()=>{I.$o()},0),I}}function zg(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tm(n){return new tL(n,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $R{constructor(e,t,i=1e3,a=1.5,l=6e4){this.Ti=e,this.timerId=t,this.Go=i,this.zo=a,this.jo=l,this.Ho=0,this.Jo=null,this.Yo=Date.now(),this.reset()}reset(){this.Ho=0}Zo(){this.Ho=this.jo}Xo(e){this.cancel();const t=Math.floor(this.Ho+this.e_()),i=Math.max(0,Date.now()-this.Yo),a=Math.max(0,t-i);a>0&&de("ExponentialBackoff",`Backing off for ${a} ms (base delay: ${this.Ho} ms, delay with jitter: ${t} ms, last attempt: ${i} ms ago)`),this.Jo=this.Ti.enqueueAfterDelay(this.timerId,a,()=>(this.Yo=Date.now(),e())),this.Ho*=this.zo,this.Ho<this.Go&&(this.Ho=this.Go),this.Ho>this.jo&&(this.Ho=this.jo)}t_(){this.Jo!==null&&(this.Jo.skipDelay(),this.Jo=null)}cancel(){this.Jo!==null&&(this.Jo.cancel(),this.Jo=null)}e_(){return(Math.random()-.5)*this.Ho}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fw="PersistentStream";class KR{constructor(e,t,i,a,l,u,d,m){this.Ti=e,this.n_=i,this.r_=a,this.connection=l,this.authCredentialsProvider=u,this.appCheckCredentialsProvider=d,this.listener=m,this.state=0,this.i_=0,this.s_=null,this.o_=null,this.stream=null,this.__=0,this.a_=new $R(e,t)}u_(){return this.state===1||this.state===5||this.c_()}c_(){return this.state===2||this.state===3}start(){this.__=0,this.state!==4?this.auth():this.l_()}async stop(){this.u_()&&await this.close(0)}h_(){this.state=0,this.a_.reset()}P_(){this.c_()&&this.s_===null&&(this.s_=this.Ti.enqueueAfterDelay(this.n_,6e4,()=>this.T_()))}I_(e){this.E_(),this.stream.send(e)}async T_(){if(this.c_())return this.close(0)}E_(){this.s_&&(this.s_.cancel(),this.s_=null)}d_(){this.o_&&(this.o_.cancel(),this.o_=null)}async close(e,t){this.E_(),this.d_(),this.a_.cancel(),this.i_++,e!==4?this.a_.reset():t&&t.code===ne.RESOURCE_EXHAUSTED?(Vs(t.toString()),Vs("Using maximum backoff delay to prevent overloading the backend."),this.a_.Zo()):t&&t.code===ne.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.A_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Lo(t)}A_(){}auth(){this.state=1;const e=this.R_(this.i_),t=this.i_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([i,a])=>{this.i_===t&&this.V_(i,a)},i=>{e(()=>{const a=new fe(ne.UNKNOWN,"Fetching auth token failed: "+i.message);return this.m_(a)})})}V_(e,t){const i=this.R_(this.i_);this.stream=this.f_(e,t),this.stream.xo(()=>{i(()=>this.listener.xo())}),this.stream.No(()=>{i(()=>(this.state=2,this.o_=this.Ti.enqueueAfterDelay(this.r_,1e4,()=>(this.c_()&&(this.state=3),Promise.resolve())),this.listener.No()))}),this.stream.Lo(a=>{i(()=>this.m_(a))}),this.stream.onMessage(a=>{i(()=>++this.__==1?this.g_(a):this.onNext(a))})}l_(){this.state=5,this.a_.Xo(async()=>{this.state=0,this.start()})}m_(e){return de(fw,`close with error: ${e}`),this.stream=null,this.close(4,e)}R_(e){return t=>{this.Ti.enqueueAndForget(()=>this.i_===e?t():(de(fw,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class ZL extends KR{constructor(e,t,i,a,l,u){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,i,a,u),this.serializer=l}f_(e,t){return this.connection.Wo("Listen",e,t)}g_(e){return this.onNext(e)}onNext(e){this.a_.reset();const t=sL(this.serializer,e),i=function(l){if(!("targetChange"in l))return Re.min();const u=l.targetChange;return u.targetIds&&u.targetIds.length?Re.min():u.readTime?Hi(u.readTime):Re.min()}(e);return this.listener.p_(t,i)}y_(e){const t={};t.database=T_(this.serializer),t.addTarget=function(l,u){let d;const m=u.target;if(d=p_(m)?{documents:oL(l,m)}:{query:lL(l,m).ht},d.targetId=u.targetId,u.resumeToken.approximateByteSize()>0){d.resumeToken=PR(l,u.resumeToken);const p=y_(l,u.expectedCount);p!==null&&(d.expectedCount=p)}else if(u.snapshotVersion.compareTo(Re.min())>0){d.readTime=df(l,u.snapshotVersion.toTimestamp());const p=y_(l,u.expectedCount);p!==null&&(d.expectedCount=p)}return d}(this.serializer,e);const i=uL(this.serializer,e);i&&(t.labels=i),this.I_(t)}w_(e){const t={};t.database=T_(this.serializer),t.removeTarget=e,this.I_(t)}}class JL extends KR{constructor(e,t,i,a,l,u){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,i,a,u),this.serializer=l}get S_(){return this.__>0}start(){this.lastStreamToken=void 0,super.start()}A_(){this.S_&&this.b_([])}f_(e,t){return this.connection.Wo("Write",e,t)}g_(e){return Xe(!!e.streamToken),this.lastStreamToken=e.streamToken,Xe(!e.writeResults||e.writeResults.length===0),this.listener.D_()}onNext(e){Xe(!!e.streamToken),this.lastStreamToken=e.streamToken,this.a_.reset();const t=aL(e.writeResults,e.commitTime),i=Hi(e.commitTime);return this.listener.v_(i,t)}C_(){const e={};e.database=T_(this.serializer),this.I_(e)}b_(e){const t={streamToken:this.lastStreamToken,writes:e.map(i=>rL(this.serializer,i))};this.I_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class e4{}class t4 extends e4{constructor(e,t,i,a){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=i,this.serializer=a,this.F_=!1}M_(){if(this.F_)throw new fe(ne.FAILED_PRECONDITION,"The client has already been terminated.")}So(e,t,i,a){return this.M_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([l,u])=>this.connection.So(e,v_(t,i),a,l,u)).catch(l=>{throw l.name==="FirebaseError"?(l.code===ne.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),l):new fe(ne.UNKNOWN,l.toString())})}Co(e,t,i,a,l){return this.M_(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([u,d])=>this.connection.Co(e,v_(t,i),a,u,d,l)).catch(u=>{throw u.name==="FirebaseError"?(u.code===ne.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),u):new fe(ne.UNKNOWN,u.toString())})}terminate(){this.F_=!0,this.connection.terminate()}}class n4{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.x_=0,this.O_=null,this.N_=!0}B_(){this.x_===0&&(this.L_("Unknown"),this.O_=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.O_=null,this.k_("Backend didn't respond within 10 seconds."),this.L_("Offline"),Promise.resolve())))}q_(e){this.state==="Online"?this.L_("Unknown"):(this.x_++,this.x_>=1&&(this.Q_(),this.k_(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.L_("Offline")))}set(e){this.Q_(),this.x_=0,e==="Online"&&(this.N_=!1),this.L_(e)}L_(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}k_(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.N_?(Vs(t),this.N_=!1):de("OnlineStateTracker",t)}Q_(){this.O_!==null&&(this.O_.cancel(),this.O_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const za="RemoteStore";class i4{constructor(e,t,i,a,l){this.localStore=e,this.datastore=t,this.asyncQueue=i,this.remoteSyncer={},this.U_=[],this.K_=new Map,this.W_=new Set,this.G_=[],this.z_=l,this.z_.To(u=>{i.enqueueAndForget(async()=>{Wa(this)&&(de(za,"Restarting streams for network reachability change."),await async function(m){const p=Ce(m);p.W_.add(4),await zu(p),p.j_.set("Unknown"),p.W_.delete(4),await nm(p)}(this))})}),this.j_=new n4(i,a)}}async function nm(n){if(Wa(n))for(const e of n.G_)await e(!0)}async function zu(n){for(const e of n.G_)await e(!1)}function QR(n,e){const t=Ce(n);t.K_.has(e.targetId)||(t.K_.set(e.targetId,e),Iy(t)?xy(t):Rl(t).c_()&&Cy(t,e))}function Ry(n,e){const t=Ce(n),i=Rl(t);t.K_.delete(e),i.c_()&&YR(t,e),t.K_.size===0&&(i.c_()?i.P_():Wa(t)&&t.j_.set("Unknown"))}function Cy(n,e){if(n.H_.Ne(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(Re.min())>0){const t=n.remoteSyncer.getRemoteKeysForTarget(e.targetId).size;e=e.withExpectedCount(t)}Rl(n).y_(e)}function YR(n,e){n.H_.Ne(e),Rl(n).w_(e)}function xy(n){n.H_=new XP({getRemoteKeysForTarget:e=>n.remoteSyncer.getRemoteKeysForTarget(e),lt:e=>n.K_.get(e)||null,it:()=>n.datastore.serializer.databaseId}),Rl(n).start(),n.j_.B_()}function Iy(n){return Wa(n)&&!Rl(n).u_()&&n.K_.size>0}function Wa(n){return Ce(n).W_.size===0}function WR(n){n.H_=void 0}async function s4(n){n.j_.set("Online")}async function r4(n){n.K_.forEach((e,t)=>{Cy(n,e)})}async function a4(n,e){WR(n),Iy(n)?(n.j_.q_(e),xy(n)):n.j_.set("Unknown")}async function o4(n,e,t){if(n.j_.set("Online"),e instanceof MR&&e.state===2&&e.cause)try{await async function(a,l){const u=l.cause;for(const d of l.targetIds)a.K_.has(d)&&(await a.remoteSyncer.rejectListen(d,u),a.K_.delete(d),a.H_.removeTarget(d))}(n,e)}catch(i){de(za,"Failed to remove targets %s: %s ",e.targetIds.join(","),i),await mf(n,i)}else if(e instanceof Gd?n.H_.We(e):e instanceof OR?n.H_.Ze(e):n.H_.je(e),!t.isEqual(Re.min()))try{const i=await GR(n.localStore);t.compareTo(i)>=0&&await function(l,u){const d=l.H_.ot(u);return d.targetChanges.forEach((m,p)=>{if(m.resumeToken.approximateByteSize()>0){const y=l.K_.get(p);y&&l.K_.set(p,y.withResumeToken(m.resumeToken,u))}}),d.targetMismatches.forEach((m,p)=>{const y=l.K_.get(m);if(!y)return;l.K_.set(m,y.withResumeToken(on.EMPTY_BYTE_STRING,y.snapshotVersion)),YR(l,m);const T=new Ar(y.target,m,p,y.sequenceNumber);Cy(l,T)}),l.remoteSyncer.applyRemoteEvent(d)}(n,t)}catch(i){de(za,"Failed to raise snapshot:",i),await mf(n,i)}}async function mf(n,e,t){if(!Sl(e))throw e;n.W_.add(1),await zu(n),n.j_.set("Offline"),t||(t=()=>GR(n.localStore)),n.asyncQueue.enqueueRetryable(async()=>{de(za,"Retrying IndexedDB access"),await t(),n.W_.delete(1),await nm(n)})}function XR(n,e){return e().catch(t=>mf(n,t,e))}async function im(n){const e=Ce(n),t=Lr(e);let i=e.U_.length>0?e.U_[e.U_.length-1].batchId:hy;for(;l4(e);)try{const a=await qL(e.localStore,i);if(a===null){e.U_.length===0&&t.P_();break}i=a.batchId,c4(e,a)}catch(a){await mf(e,a)}ZR(e)&&JR(e)}function l4(n){return Wa(n)&&n.U_.length<10}function c4(n,e){n.U_.push(e);const t=Lr(n);t.c_()&&t.S_&&t.b_(e.mutations)}function ZR(n){return Wa(n)&&!Lr(n).u_()&&n.U_.length>0}function JR(n){Lr(n).start()}async function u4(n){Lr(n).C_()}async function h4(n){const e=Lr(n);for(const t of n.U_)e.b_(t.mutations)}async function d4(n,e,t){const i=n.U_.shift(),a=vy.from(i,e,t);await XR(n,()=>n.remoteSyncer.applySuccessfulWrite(a)),await im(n)}async function f4(n,e){e&&Lr(n).S_&&await async function(i,a){if(function(u){return YP(u)&&u!==ne.ABORTED}(a.code)){const l=i.U_.shift();Lr(i).h_(),await XR(i,()=>i.remoteSyncer.rejectFailedWrite(l.batchId,a)),await im(i)}}(n,e),ZR(n)&&JR(n)}async function mw(n,e){const t=Ce(n);t.asyncQueue.verifyOperationInProgress(),de(za,"RemoteStore received new credentials");const i=Wa(t);t.W_.add(3),await zu(t),i&&t.j_.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.W_.delete(3),await nm(t)}async function m4(n,e){const t=Ce(n);e?(t.W_.delete(2),await nm(t)):e||(t.W_.add(2),await zu(t),t.j_.set("Unknown"))}function Rl(n){return n.J_||(n.J_=function(t,i,a){const l=Ce(t);return l.M_(),new ZL(i,l.connection,l.authCredentials,l.appCheckCredentials,l.serializer,a)}(n.datastore,n.asyncQueue,{xo:s4.bind(null,n),No:r4.bind(null,n),Lo:a4.bind(null,n),p_:o4.bind(null,n)}),n.G_.push(async e=>{e?(n.J_.h_(),Iy(n)?xy(n):n.j_.set("Unknown")):(await n.J_.stop(),WR(n))})),n.J_}function Lr(n){return n.Y_||(n.Y_=function(t,i,a){const l=Ce(t);return l.M_(),new JL(i,l.connection,l.authCredentials,l.appCheckCredentials,l.serializer,a)}(n.datastore,n.asyncQueue,{xo:()=>Promise.resolve(),No:u4.bind(null,n),Lo:f4.bind(null,n),D_:h4.bind(null,n),v_:d4.bind(null,n)}),n.G_.push(async e=>{e?(n.Y_.h_(),await im(n)):(await n.Y_.stop(),n.U_.length>0&&(de(za,`Stopping write stream with ${n.U_.length} pending writes`),n.U_=[]))})),n.Y_}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ny{constructor(e,t,i,a,l){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=i,this.op=a,this.removalCallback=l,this.deferred=new ks,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(u=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,i,a,l){const u=Date.now()+i,d=new Ny(e,t,u,a,l);return d.start(i),d}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new fe(ne.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function ky(n,e){if(Vs("AsyncQueue",`${e}: ${n}`),Sl(n))return new fe(ne.UNAVAILABLE,`${e}: ${n}`);throw n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tl{static emptySet(e){return new tl(e.comparator)}constructor(e){this.comparator=e?(t,i)=>e(t,i)||_e.comparator(t.key,i.key):(t,i)=>_e.comparator(t.key,i.key),this.keyedMap=Wc(),this.sortedSet=new Mt(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,i)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof tl)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),i=e.sortedSet.getIterator();for(;t.hasNext();){const a=t.getNext().key,l=i.getNext().key;if(!a.isEqual(l))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const i=new tl;return i.comparator=this.comparator,i.keyedMap=e,i.sortedSet=t,i}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pw{constructor(){this.Z_=new Mt(_e.comparator)}track(e){const t=e.doc.key,i=this.Z_.get(t);i?e.type!==0&&i.type===3?this.Z_=this.Z_.insert(t,e):e.type===3&&i.type!==1?this.Z_=this.Z_.insert(t,{type:i.type,doc:e.doc}):e.type===2&&i.type===2?this.Z_=this.Z_.insert(t,{type:2,doc:e.doc}):e.type===2&&i.type===0?this.Z_=this.Z_.insert(t,{type:0,doc:e.doc}):e.type===1&&i.type===0?this.Z_=this.Z_.remove(t):e.type===1&&i.type===2?this.Z_=this.Z_.insert(t,{type:1,doc:i.doc}):e.type===0&&i.type===1?this.Z_=this.Z_.insert(t,{type:2,doc:e.doc}):Se():this.Z_=this.Z_.insert(t,e)}X_(){const e=[];return this.Z_.inorderTraversal((t,i)=>{e.push(i)}),e}}class fl{constructor(e,t,i,a,l,u,d,m,p){this.query=e,this.docs=t,this.oldDocs=i,this.docChanges=a,this.mutatedKeys=l,this.fromCache=u,this.syncStateChanged=d,this.excludesMetadataChanges=m,this.hasCachedResults=p}static fromInitialDocuments(e,t,i,a,l){const u=[];return t.forEach(d=>{u.push({type:0,doc:d})}),new fl(e,t,tl.emptySet(t),u,i,a,!0,!1,l)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&Wf(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,i=e.docChanges;if(t.length!==i.length)return!1;for(let a=0;a<t.length;a++)if(t[a].type!==i[a].type||!t[a].doc.isEqual(i[a].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p4{constructor(){this.ea=void 0,this.ta=[]}na(){return this.ta.some(e=>e.ra())}}class g4{constructor(){this.queries=gw(),this.onlineState="Unknown",this.ia=new Set}terminate(){(function(t,i){const a=Ce(t),l=a.queries;a.queries=gw(),l.forEach((u,d)=>{for(const m of d.ta)m.onError(i)})})(this,new fe(ne.ABORTED,"Firestore shutting down"))}}function gw(){return new Ya(n=>ER(n),Wf)}async function eC(n,e){const t=Ce(n);let i=3;const a=e.query;let l=t.queries.get(a);l?!l.na()&&e.ra()&&(i=2):(l=new p4,i=e.ra()?0:1);try{switch(i){case 0:l.ea=await t.onListen(a,!0);break;case 1:l.ea=await t.onListen(a,!1);break;case 2:await t.onFirstRemoteStoreListen(a)}}catch(u){const d=ky(u,`Initialization of query '${Wo(e.query)}' failed`);return void e.onError(d)}t.queries.set(a,l),l.ta.push(e),e.sa(t.onlineState),l.ea&&e.oa(l.ea)&&Dy(t)}async function tC(n,e){const t=Ce(n),i=e.query;let a=3;const l=t.queries.get(i);if(l){const u=l.ta.indexOf(e);u>=0&&(l.ta.splice(u,1),l.ta.length===0?a=e.ra()?0:1:!l.na()&&e.ra()&&(a=2))}switch(a){case 0:return t.queries.delete(i),t.onUnlisten(i,!0);case 1:return t.queries.delete(i),t.onUnlisten(i,!1);case 2:return t.onLastRemoteStoreUnlisten(i);default:return}}function _4(n,e){const t=Ce(n);let i=!1;for(const a of e){const l=a.query,u=t.queries.get(l);if(u){for(const d of u.ta)d.oa(a)&&(i=!0);u.ea=a}}i&&Dy(t)}function y4(n,e,t){const i=Ce(n),a=i.queries.get(e);if(a)for(const l of a.ta)l.onError(t);i.queries.delete(e)}function Dy(n){n.ia.forEach(e=>{e.next()})}var S_,_w;(_w=S_||(S_={}))._a="default",_w.Cache="cache";class nC{constructor(e,t,i){this.query=e,this.aa=t,this.ua=!1,this.ca=null,this.onlineState="Unknown",this.options=i||{}}oa(e){if(!this.options.includeMetadataChanges){const i=[];for(const a of e.docChanges)a.type!==3&&i.push(a);e=new fl(e.query,e.docs,e.oldDocs,i,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.ua?this.la(e)&&(this.aa.next(e),t=!0):this.ha(e,this.onlineState)&&(this.Pa(e),t=!0),this.ca=e,t}onError(e){this.aa.error(e)}sa(e){this.onlineState=e;let t=!1;return this.ca&&!this.ua&&this.ha(this.ca,e)&&(this.Pa(this.ca),t=!0),t}ha(e,t){if(!e.fromCache||!this.ra())return!0;const i=t!=="Offline";return(!this.options.Ta||!i)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}la(e){if(e.docChanges.length>0)return!0;const t=this.ca&&this.ca.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}Pa(e){e=fl.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.ua=!0,this.aa.next(e)}ra(){return this.options.source!==S_.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iC{constructor(e){this.key=e}}class sC{constructor(e){this.key=e}}class v4{constructor(e,t){this.query=e,this.fa=t,this.ga=null,this.hasCachedResults=!1,this.current=!1,this.pa=je(),this.mutatedKeys=je(),this.ya=TR(e),this.wa=new tl(this.ya)}get Sa(){return this.fa}ba(e,t){const i=t?t.Da:new pw,a=t?t.wa:this.wa;let l=t?t.mutatedKeys:this.mutatedKeys,u=a,d=!1;const m=this.query.limitType==="F"&&a.size===this.query.limit?a.last():null,p=this.query.limitType==="L"&&a.size===this.query.limit?a.first():null;if(e.inorderTraversal((y,T)=>{const w=a.get(y),x=Xf(this.query,T)?T:null,I=!!w&&this.mutatedKeys.has(w.key),O=!!x&&(x.hasLocalMutations||this.mutatedKeys.has(x.key)&&x.hasCommittedMutations);let P=!1;w&&x?w.data.isEqual(x.data)?I!==O&&(i.track({type:3,doc:x}),P=!0):this.va(w,x)||(i.track({type:2,doc:x}),P=!0,(m&&this.ya(x,m)>0||p&&this.ya(x,p)<0)&&(d=!0)):!w&&x?(i.track({type:0,doc:x}),P=!0):w&&!x&&(i.track({type:1,doc:w}),P=!0,(m||p)&&(d=!0)),P&&(x?(u=u.add(x),l=O?l.add(y):l.delete(y)):(u=u.delete(y),l=l.delete(y)))}),this.query.limit!==null)for(;u.size>this.query.limit;){const y=this.query.limitType==="F"?u.last():u.first();u=u.delete(y.key),l=l.delete(y.key),i.track({type:1,doc:y})}return{wa:u,Da:i,ls:d,mutatedKeys:l}}va(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,i,a){const l=this.wa;this.wa=e.wa,this.mutatedKeys=e.mutatedKeys;const u=e.Da.X_();u.sort((y,T)=>function(x,I){const O=P=>{switch(P){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return Se()}};return O(x)-O(I)}(y.type,T.type)||this.ya(y.doc,T.doc)),this.Ca(i),a=a!=null&&a;const d=t&&!a?this.Fa():[],m=this.pa.size===0&&this.current&&!a?1:0,p=m!==this.ga;return this.ga=m,u.length!==0||p?{snapshot:new fl(this.query,e.wa,l,u,e.mutatedKeys,m===0,p,!1,!!i&&i.resumeToken.approximateByteSize()>0),Ma:d}:{Ma:d}}sa(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({wa:this.wa,Da:new pw,mutatedKeys:this.mutatedKeys,ls:!1},!1)):{Ma:[]}}xa(e){return!this.fa.has(e)&&!!this.wa.has(e)&&!this.wa.get(e).hasLocalMutations}Ca(e){e&&(e.addedDocuments.forEach(t=>this.fa=this.fa.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.fa=this.fa.delete(t)),this.current=e.current)}Fa(){if(!this.current)return[];const e=this.pa;this.pa=je(),this.wa.forEach(i=>{this.xa(i.key)&&(this.pa=this.pa.add(i.key))});const t=[];return e.forEach(i=>{this.pa.has(i)||t.push(new sC(i))}),this.pa.forEach(i=>{e.has(i)||t.push(new iC(i))}),t}Oa(e){this.fa=e.gs,this.pa=je();const t=this.ba(e.documents);return this.applyChanges(t,!0)}Na(){return fl.fromInitialDocuments(this.query,this.wa,this.mutatedKeys,this.ga===0,this.hasCachedResults)}}const Oy="SyncEngine";class E4{constructor(e,t,i){this.query=e,this.targetId=t,this.view=i}}class T4{constructor(e){this.key=e,this.Ba=!1}}class b4{constructor(e,t,i,a,l,u){this.localStore=e,this.remoteStore=t,this.eventManager=i,this.sharedClientState=a,this.currentUser=l,this.maxConcurrentLimboResolutions=u,this.La={},this.ka=new Ya(d=>ER(d),Wf),this.qa=new Map,this.Qa=new Set,this.$a=new Mt(_e.comparator),this.Ua=new Map,this.Ka=new by,this.Wa={},this.Ga=new Map,this.za=dl.Kn(),this.onlineState="Unknown",this.ja=void 0}get isPrimaryClient(){return this.ja===!0}}async function w4(n,e,t=!0){const i=uC(n);let a;const l=i.ka.get(e);return l?(i.sharedClientState.addLocalQueryTarget(l.targetId),a=l.view.Na()):a=await rC(i,e,t,!0),a}async function S4(n,e){const t=uC(n);await rC(t,e,!0,!1)}async function rC(n,e,t,i){const a=await HL(n.localStore,qi(e)),l=a.targetId,u=n.sharedClientState.addLocalQueryTarget(l,t);let d;return i&&(d=await A4(n,e,l,u==="current",a.resumeToken)),n.isPrimaryClient&&t&&QR(n.remoteStore,a),d}async function A4(n,e,t,i,a){n.Ha=(T,w,x)=>async function(O,P,B,ee){let Y=P.view.ba(B);Y.ls&&(Y=await cw(O.localStore,P.query,!1).then(({documents:M})=>P.view.ba(M,Y)));const W=ee&&ee.targetChanges.get(P.targetId),re=ee&&ee.targetMismatches.get(P.targetId)!=null,he=P.view.applyChanges(Y,O.isPrimaryClient,W,re);return vw(O,P.targetId,he.Ma),he.snapshot}(n,T,w,x);const l=await cw(n.localStore,e,!0),u=new v4(e,l.gs),d=u.ba(l.documents),m=ju.createSynthesizedTargetChangeForCurrentChange(t,i&&n.onlineState!=="Offline",a),p=u.applyChanges(d,n.isPrimaryClient,m);vw(n,t,p.Ma);const y=new E4(e,t,u);return n.ka.set(e,y),n.qa.has(t)?n.qa.get(t).push(e):n.qa.set(t,[e]),p.snapshot}async function R4(n,e,t){const i=Ce(n),a=i.ka.get(e),l=i.qa.get(a.targetId);if(l.length>1)return i.qa.set(a.targetId,l.filter(u=>!Wf(u,e))),void i.ka.delete(e);i.isPrimaryClient?(i.sharedClientState.removeLocalQueryTarget(a.targetId),i.sharedClientState.isActiveQueryTarget(a.targetId)||await b_(i.localStore,a.targetId,!1).then(()=>{i.sharedClientState.clearQueryState(a.targetId),t&&Ry(i.remoteStore,a.targetId),A_(i,a.targetId)}).catch(wl)):(A_(i,a.targetId),await b_(i.localStore,a.targetId,!0))}async function C4(n,e){const t=Ce(n),i=t.ka.get(e),a=t.qa.get(i.targetId);t.isPrimaryClient&&a.length===1&&(t.sharedClientState.removeLocalQueryTarget(i.targetId),Ry(t.remoteStore,i.targetId))}async function x4(n,e,t){const i=P4(n);try{const a=await function(u,d){const m=Ce(u),p=Ft.now(),y=d.reduce((x,I)=>x.add(I.key),je());let T,w;return m.persistence.runTransaction("Locally write mutations","readwrite",x=>{let I=Us(),O=je();return m.ds.getEntries(x,y).next(P=>{I=P,I.forEach((B,ee)=>{ee.isValidDocument()||(O=O.add(B))})}).next(()=>m.localDocuments.getOverlayedDocuments(x,I)).next(P=>{T=P;const B=[];for(const ee of d){const Y=HP(ee,T.get(ee.key).overlayedDocument);Y!=null&&B.push(new qr(ee.key,Y,dR(Y.value.mapValue),si.exists(!0)))}return m.mutationQueue.addMutationBatch(x,p,B,d)}).next(P=>{w=P;const B=P.applyToLocalDocumentSet(T,O);return m.documentOverlayCache.saveOverlays(x,P.batchId,B)})}).then(()=>({batchId:w.batchId,changes:wR(T)}))}(i.localStore,e);i.sharedClientState.addPendingMutation(a.batchId),function(u,d,m){let p=u.Wa[u.currentUser.toKey()];p||(p=new Mt(Ne)),p=p.insert(d,m),u.Wa[u.currentUser.toKey()]=p}(i,a.batchId,t),await Fu(i,a.changes),await im(i.remoteStore)}catch(a){const l=ky(a,"Failed to persist write");t.reject(l)}}async function aC(n,e){const t=Ce(n);try{const i=await FL(t.localStore,e);e.targetChanges.forEach((a,l)=>{const u=t.Ua.get(l);u&&(Xe(a.addedDocuments.size+a.modifiedDocuments.size+a.removedDocuments.size<=1),a.addedDocuments.size>0?u.Ba=!0:a.modifiedDocuments.size>0?Xe(u.Ba):a.removedDocuments.size>0&&(Xe(u.Ba),u.Ba=!1))}),await Fu(t,i,e)}catch(i){await wl(i)}}function yw(n,e,t){const i=Ce(n);if(i.isPrimaryClient&&t===0||!i.isPrimaryClient&&t===1){const a=[];i.ka.forEach((l,u)=>{const d=u.view.sa(e);d.snapshot&&a.push(d.snapshot)}),function(u,d){const m=Ce(u);m.onlineState=d;let p=!1;m.queries.forEach((y,T)=>{for(const w of T.ta)w.sa(d)&&(p=!0)}),p&&Dy(m)}(i.eventManager,e),a.length&&i.La.p_(a),i.onlineState=e,i.isPrimaryClient&&i.sharedClientState.setOnlineState(e)}}async function I4(n,e,t){const i=Ce(n);i.sharedClientState.updateQueryState(e,"rejected",t);const a=i.Ua.get(e),l=a&&a.key;if(l){let u=new Mt(_e.comparator);u=u.insert(l,fn.newNoDocument(l,Re.min()));const d=je().add(l),m=new em(Re.min(),new Map,new Mt(Ne),u,d);await aC(i,m),i.$a=i.$a.remove(l),i.Ua.delete(e),My(i)}else await b_(i.localStore,e,!1).then(()=>A_(i,e,t)).catch(wl)}async function N4(n,e){const t=Ce(n),i=e.batch.batchId;try{const a=await zL(t.localStore,e);lC(t,i,null),oC(t,i),t.sharedClientState.updateMutationState(i,"acknowledged"),await Fu(t,a)}catch(a){await wl(a)}}async function k4(n,e,t){const i=Ce(n);try{const a=await function(u,d){const m=Ce(u);return m.persistence.runTransaction("Reject batch","readwrite-primary",p=>{let y;return m.mutationQueue.lookupMutationBatch(p,d).next(T=>(Xe(T!==null),y=T.keys(),m.mutationQueue.removeMutationBatch(p,T))).next(()=>m.mutationQueue.performConsistencyCheck(p)).next(()=>m.documentOverlayCache.removeOverlaysForBatchId(p,y,d)).next(()=>m.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(p,y)).next(()=>m.localDocuments.getDocuments(p,y))})}(i.localStore,e);lC(i,e,t),oC(i,e),i.sharedClientState.updateMutationState(e,"rejected",t),await Fu(i,a)}catch(a){await wl(a)}}function oC(n,e){(n.Ga.get(e)||[]).forEach(t=>{t.resolve()}),n.Ga.delete(e)}function lC(n,e,t){const i=Ce(n);let a=i.Wa[i.currentUser.toKey()];if(a){const l=a.get(e);l&&(t?l.reject(t):l.resolve(),a=a.remove(e)),i.Wa[i.currentUser.toKey()]=a}}function A_(n,e,t=null){n.sharedClientState.removeLocalQueryTarget(e);for(const i of n.qa.get(e))n.ka.delete(i),t&&n.La.Ja(i,t);n.qa.delete(e),n.isPrimaryClient&&n.Ka.br(e).forEach(i=>{n.Ka.containsKey(i)||cC(n,i)})}function cC(n,e){n.Qa.delete(e.path.canonicalString());const t=n.$a.get(e);t!==null&&(Ry(n.remoteStore,t),n.$a=n.$a.remove(e),n.Ua.delete(t),My(n))}function vw(n,e,t){for(const i of t)i instanceof iC?(n.Ka.addReference(i.key,e),D4(n,i)):i instanceof sC?(de(Oy,"Document no longer in limbo: "+i.key),n.Ka.removeReference(i.key,e),n.Ka.containsKey(i.key)||cC(n,i.key)):Se()}function D4(n,e){const t=e.key,i=t.path.canonicalString();n.$a.get(t)||n.Qa.has(i)||(de(Oy,"New document in limbo: "+t),n.Qa.add(i),My(n))}function My(n){for(;n.Qa.size>0&&n.$a.size<n.maxConcurrentLimboResolutions;){const e=n.Qa.values().next().value;n.Qa.delete(e);const t=new _e(ft.fromString(e)),i=n.za.next();n.Ua.set(i,new T4(t)),n.$a=n.$a.insert(t,i),QR(n.remoteStore,new Ar(qi(gy(t.path)),i,"TargetPurposeLimboResolution",Kf.ae))}}async function Fu(n,e,t){const i=Ce(n),a=[],l=[],u=[];i.ka.isEmpty()||(i.ka.forEach((d,m)=>{u.push(i.Ha(m,e,t).then(p=>{var y;if((p||t)&&i.isPrimaryClient){const T=p?!p.fromCache:(y=t==null?void 0:t.targetChanges.get(m.targetId))===null||y===void 0?void 0:y.current;i.sharedClientState.updateQueryState(m.targetId,T?"current":"not-current")}if(p){a.push(p);const T=Sy.Yi(m.targetId,p);l.push(T)}}))}),await Promise.all(u),i.La.p_(a),await async function(m,p){const y=Ce(m);try{await y.persistence.runTransaction("notifyLocalViewChanges","readwrite",T=>ie.forEach(p,w=>ie.forEach(w.Hi,x=>y.persistence.referenceDelegate.addReference(T,w.targetId,x)).next(()=>ie.forEach(w.Ji,x=>y.persistence.referenceDelegate.removeReference(T,w.targetId,x)))))}catch(T){if(!Sl(T))throw T;de(Ay,"Failed to update sequence numbers: "+T)}for(const T of p){const w=T.targetId;if(!T.fromCache){const x=y.Ts.get(w),I=x.snapshotVersion,O=x.withLastLimboFreeSnapshotVersion(I);y.Ts=y.Ts.insert(w,O)}}}(i.localStore,l))}async function O4(n,e){const t=Ce(n);if(!t.currentUser.isEqual(e)){de(Oy,"User change. New user:",e.toKey());const i=await HR(t.localStore,e);t.currentUser=e,function(l,u){l.Ga.forEach(d=>{d.forEach(m=>{m.reject(new fe(ne.CANCELLED,u))})}),l.Ga.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,i.removedBatchIds,i.addedBatchIds),await Fu(t,i.Rs)}}function M4(n,e){const t=Ce(n),i=t.Ua.get(e);if(i&&i.Ba)return je().add(i.key);{let a=je();const l=t.qa.get(e);if(!l)return a;for(const u of l){const d=t.ka.get(u);a=a.unionWith(d.view.Sa)}return a}}function uC(n){const e=Ce(n);return e.remoteStore.remoteSyncer.applyRemoteEvent=aC.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=M4.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=I4.bind(null,e),e.La.p_=_4.bind(null,e.eventManager),e.La.Ja=y4.bind(null,e.eventManager),e}function P4(n){const e=Ce(n);return e.remoteStore.remoteSyncer.applySuccessfulWrite=N4.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=k4.bind(null,e),e}class pf{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=tm(e.databaseInfo.databaseId),this.sharedClientState=this.Za(e),this.persistence=this.Xa(e),await this.persistence.start(),this.localStore=this.eu(e),this.gcScheduler=this.tu(e,this.localStore),this.indexBackfillerScheduler=this.nu(e,this.localStore)}tu(e,t){return null}nu(e,t){return null}eu(e){return jL(this.persistence,new LL,e.initialUser,this.serializer)}Xa(e){return new qR(wy.ri,this.serializer)}Za(e){return new $L}async terminate(){var e,t;(e=this.gcScheduler)===null||e===void 0||e.stop(),(t=this.indexBackfillerScheduler)===null||t===void 0||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}pf.provider={build:()=>new pf};class L4 extends pf{constructor(e){super(),this.cacheSizeBytes=e}tu(e,t){Xe(this.persistence.referenceDelegate instanceof ff);const i=this.persistence.referenceDelegate.garbageCollector;return new TL(i,e.asyncQueue,t)}Xa(e){const t=this.cacheSizeBytes!==void 0?An.withCacheSize(this.cacheSizeBytes):An.DEFAULT;return new qR(i=>ff.ri(i,t),this.serializer)}}class R_{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=i=>yw(this.syncEngine,i,1),this.remoteStore.remoteSyncer.handleCredentialChange=O4.bind(null,this.syncEngine),await m4(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new g4}()}createDatastore(e){const t=tm(e.databaseInfo.databaseId),i=function(l){return new XL(l)}(e.databaseInfo);return function(l,u,d,m){return new t4(l,u,d,m)}(e.authCredentials,e.appCheckCredentials,i,t)}createRemoteStore(e){return function(i,a,l,u,d){return new i4(i,a,l,u,d)}(this.localStore,this.datastore,e.asyncQueue,t=>yw(this.syncEngine,t,0),function(){return dw.D()?new dw:new KL}())}createSyncEngine(e,t){return function(a,l,u,d,m,p,y){const T=new b4(a,l,u,d,m,p);return y&&(T.ja=!0),T}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(a){const l=Ce(a);de(za,"RemoteStore shutting down."),l.W_.add(5),await zu(l),l.z_.shutdown(),l.j_.set("Unknown")}(this.remoteStore),(e=this.datastore)===null||e===void 0||e.terminate(),(t=this.eventManager)===null||t===void 0||t.terminate()}}R_.provider={build:()=>new R_};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hC{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.iu(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.iu(this.observer.error,e):Vs("Uncaught Error in snapshot listener:",e.toString()))}su(){this.muted=!0}iu(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vr="FirestoreClient";class V4{constructor(e,t,i,a,l){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=i,this.databaseInfo=a,this.user=dn.UNAUTHENTICATED,this.clientId=nR.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=l,this.authCredentials.start(i,async u=>{de(Vr,"Received user=",u.uid),await this.authCredentialListener(u),this.user=u}),this.appCheckCredentials.start(i,u=>(de(Vr,"Received new app check token=",u),this.appCheckCredentialListener(u,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this.databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new ks;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const i=ky(t,"Failed to shutdown persistence");e.reject(i)}}),e.promise}}async function Fg(n,e){n.asyncQueue.verifyOperationInProgress(),de(Vr,"Initializing OfflineComponentProvider");const t=n.configuration;await e.initialize(t);let i=t.initialUser;n.setCredentialChangeListener(async a=>{i.isEqual(a)||(await HR(e.localStore,a),i=a)}),e.persistence.setDatabaseDeletedListener(()=>n.terminate()),n._offlineComponents=e}async function Ew(n,e){n.asyncQueue.verifyOperationInProgress();const t=await U4(n);de(Vr,"Initializing OnlineComponentProvider"),await e.initialize(t,n.configuration),n.setCredentialChangeListener(i=>mw(e.remoteStore,i)),n.setAppCheckTokenChangeListener((i,a)=>mw(e.remoteStore,a)),n._onlineComponents=e}async function U4(n){if(!n._offlineComponents)if(n._uninitializedComponentsProvider){de(Vr,"Using user provided OfflineComponentProvider");try{await Fg(n,n._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(a){return a.name==="FirebaseError"?a.code===ne.FAILED_PRECONDITION||a.code===ne.UNIMPLEMENTED:!(typeof DOMException<"u"&&a instanceof DOMException)||a.code===22||a.code===20||a.code===11}(t))throw t;ll("Error using user provided cache. Falling back to memory cache: "+t),await Fg(n,new pf)}}else de(Vr,"Using default OfflineComponentProvider"),await Fg(n,new L4(void 0));return n._offlineComponents}async function dC(n){return n._onlineComponents||(n._uninitializedComponentsProvider?(de(Vr,"Using user provided OnlineComponentProvider"),await Ew(n,n._uninitializedComponentsProvider._online)):(de(Vr,"Using default OnlineComponentProvider"),await Ew(n,new R_))),n._onlineComponents}function j4(n){return dC(n).then(e=>e.syncEngine)}async function fC(n){const e=await dC(n),t=e.eventManager;return t.onListen=w4.bind(null,e.syncEngine),t.onUnlisten=R4.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=S4.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=C4.bind(null,e.syncEngine),t}function z4(n,e,t={}){const i=new ks;return n.asyncQueue.enqueueAndForget(async()=>function(l,u,d,m,p){const y=new hC({next:w=>{y.su(),u.enqueueAndForget(()=>tC(l,T));const x=w.docs.has(d);!x&&w.fromCache?p.reject(new fe(ne.UNAVAILABLE,"Failed to get document because the client is offline.")):x&&w.fromCache&&m&&m.source==="server"?p.reject(new fe(ne.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):p.resolve(w)},error:w=>p.reject(w)}),T=new nC(gy(d.path),y,{includeMetadataChanges:!0,Ta:!0});return eC(l,T)}(await fC(n),n.asyncQueue,e,t,i)),i.promise}function F4(n,e,t={}){const i=new ks;return n.asyncQueue.enqueueAndForget(async()=>function(l,u,d,m,p){const y=new hC({next:w=>{y.su(),u.enqueueAndForget(()=>tC(l,T)),w.fromCache&&m.source==="server"?p.reject(new fe(ne.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):p.resolve(w)},error:w=>p.reject(w)}),T=new nC(d,y,{includeMetadataChanges:!0,Ta:!0});return eC(l,T)}(await fC(n),n.asyncQueue,e,t,i)),i.promise}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mC(n){const e={};return n.timeoutSeconds!==void 0&&(e.timeoutSeconds=n.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tw=new Map;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pC(n,e,t){if(!t)throw new fe(ne.INVALID_ARGUMENT,`Function ${n}() cannot be called with an empty ${e}.`)}function B4(n,e,t,i){if(e===!0&&i===!0)throw new fe(ne.INVALID_ARGUMENT,`${n} and ${t} cannot be used together.`)}function bw(n){if(!_e.isDocumentKey(n))throw new fe(ne.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${n} has ${n.length}.`)}function ww(n){if(_e.isDocumentKey(n))throw new fe(ne.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${n} has ${n.length}.`)}function sm(n){if(n===void 0)return"undefined";if(n===null)return"null";if(typeof n=="string")return n.length>20&&(n=`${n.substring(0,20)}...`),JSON.stringify(n);if(typeof n=="number"||typeof n=="boolean")return""+n;if(typeof n=="object"){if(n instanceof Array)return"an array";{const e=function(i){return i.constructor?i.constructor.name:null}(n);return e?`a custom ${e} object`:"an object"}}return typeof n=="function"?"a function":Se()}function bi(n,e){if("_delegate"in n&&(n=n._delegate),!(n instanceof e)){if(e.name===n.constructor.name)throw new fe(ne.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=sm(n);throw new fe(ne.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gC="firestore.googleapis.com",Sw=!0;class Aw{constructor(e){var t,i;if(e.host===void 0){if(e.ssl!==void 0)throw new fe(ne.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=gC,this.ssl=Sw}else this.host=e.host,this.ssl=(t=e.ssl)!==null&&t!==void 0?t:Sw;if(this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=BR;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<vL)throw new fe(ne.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}B4("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=mC((i=e.experimentalLongPollingOptions)!==null&&i!==void 0?i:{}),function(l){if(l.timeoutSeconds!==void 0){if(isNaN(l.timeoutSeconds))throw new fe(ne.INVALID_ARGUMENT,`invalid long polling timeout: ${l.timeoutSeconds} (must not be NaN)`);if(l.timeoutSeconds<5)throw new fe(ne.INVALID_ARGUMENT,`invalid long polling timeout: ${l.timeoutSeconds} (minimum allowed value is 5)`);if(l.timeoutSeconds>30)throw new fe(ne.INVALID_ARGUMENT,`invalid long polling timeout: ${l.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(i,a){return i.timeoutSeconds===a.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class rm{constructor(e,t,i,a){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=i,this._app=a,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new Aw({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new fe(ne.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new fe(ne.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new Aw(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(i){if(!i)return new YM;switch(i.type){case"firstParty":return new JM(i.sessionIndex||"0",i.iamToken||null,i.authTokenFactory||null);case"provider":return i.client;default:throw new fe(ne.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const i=Tw.get(t);i&&(de("ComponentProvider","Removing Datastore"),Tw.delete(t),i.terminate())}(this),Promise.resolve()}}function q4(n,e,t,i={}){var a;const l=(n=bi(n,rm))._getSettings(),u=Object.assign(Object.assign({},l),{emulatorOptions:n._getEmulatorOptions()}),d=`${e}:${t}`;l.host!==gC&&l.host!==d&&ll("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const m=Object.assign(Object.assign({},l),{host:d,ssl:!1,emulatorOptions:i});if(!Ps(m,u)&&(n._setSettings(m),i.mockUserToken)){let p,y;if(typeof i.mockUserToken=="string")p=i.mockUserToken,y=dn.MOCK_USER;else{p=ty(i.mockUserToken,(a=n._app)===null||a===void 0?void 0:a.options.projectId);const T=i.mockUserToken.sub||i.mockUserToken.user_id;if(!T)throw new fe(ne.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");y=new dn(T)}n._authCredentials=new WM(new eR(p,y))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xa{constructor(e,t,i){this.converter=t,this._query=i,this.type="query",this.firestore=e}withConverter(e){return new Xa(this.firestore,e,this._query)}}class Tn{constructor(e,t,i){this.converter=t,this._key=i,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Nr(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Tn(this.firestore,e,this._key)}}class Nr extends Xa{constructor(e,t,i){super(e,t,gy(i)),this._path=i,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Tn(this.firestore,null,new _e(e))}withConverter(e){return new Nr(this.firestore,e,this._path)}}function C_(n,e,...t){if(n=at(n),pC("collection","path",e),n instanceof rm){const i=ft.fromString(e,...t);return ww(i),new Nr(n,null,i)}{if(!(n instanceof Tn||n instanceof Nr))throw new fe(ne.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const i=n._path.child(ft.fromString(e,...t));return ww(i),new Nr(n.firestore,null,i)}}function Fa(n,e,...t){if(n=at(n),arguments.length===1&&(e=nR.newId()),pC("doc","path",e),n instanceof rm){const i=ft.fromString(e,...t);return bw(i),new Tn(n,null,new _e(i))}{if(!(n instanceof Tn||n instanceof Nr))throw new fe(ne.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const i=n._path.child(ft.fromString(e,...t));return bw(i),new Tn(n.firestore,n instanceof Nr?n.converter:null,new _e(i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rw="AsyncQueue";class Cw{constructor(e=Promise.resolve()){this.Vu=[],this.mu=!1,this.fu=[],this.gu=null,this.pu=!1,this.yu=!1,this.wu=[],this.a_=new $R(this,"async_queue_retry"),this.Su=()=>{const i=zg();i&&de(Rw,"Visibility state changed to "+i.visibilityState),this.a_.t_()},this.bu=e;const t=zg();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.Su)}get isShuttingDown(){return this.mu}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Du(),this.vu(e)}enterRestrictedMode(e){if(!this.mu){this.mu=!0,this.yu=e||!1;const t=zg();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.Su)}}enqueue(e){if(this.Du(),this.mu)return new Promise(()=>{});const t=new ks;return this.vu(()=>this.mu&&this.yu?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.Vu.push(e),this.Cu()))}async Cu(){if(this.Vu.length!==0){try{await this.Vu[0](),this.Vu.shift(),this.a_.reset()}catch(e){if(!Sl(e))throw e;de(Rw,"Operation failed with retryable error: "+e)}this.Vu.length>0&&this.a_.Xo(()=>this.Cu())}}vu(e){const t=this.bu.then(()=>(this.pu=!0,e().catch(i=>{this.gu=i,this.pu=!1;const a=function(u){let d=u.message||"";return u.stack&&(d=u.stack.includes(u.message)?u.stack:u.message+`
`+u.stack),d}(i);throw Vs("INTERNAL UNHANDLED ERROR: ",a),i}).then(i=>(this.pu=!1,i))));return this.bu=t,t}enqueueAfterDelay(e,t,i){this.Du(),this.wu.indexOf(e)>-1&&(t=0);const a=Ny.createAndSchedule(this,e,t,i,l=>this.Fu(l));return this.fu.push(a),a}Du(){this.gu&&Se()}verifyOperationInProgress(){}async Mu(){let e;do e=this.bu,await e;while(e!==this.bu)}xu(e){for(const t of this.fu)if(t.timerId===e)return!0;return!1}Ou(e){return this.Mu().then(()=>{this.fu.sort((t,i)=>t.targetTimeMs-i.targetTimeMs);for(const t of this.fu)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Mu()})}Nu(e){this.wu.push(e)}Fu(e){const t=this.fu.indexOf(e);this.fu.splice(t,1)}}class Za extends rm{constructor(e,t,i,a){super(e,t,i,a),this.type="firestore",this._queue=new Cw,this._persistenceKey=(a==null?void 0:a.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new Cw(e),this._firestoreClient=void 0,await e}}}function H4(n,e){const t=typeof n=="object"?n:Vu(),i=typeof n=="string"?n:lf,a=qs(t,"firestore").getImmediate({identifier:i});if(!a._initialized){const l=ey("firestore");l&&q4(a,...l)}return a}function Py(n){if(n._terminated)throw new fe(ne.FAILED_PRECONDITION,"The client has already been terminated.");return n._firestoreClient||G4(n),n._firestoreClient}function G4(n){var e,t,i;const a=n._freezeSettings(),l=function(d,m,p,y){return new mP(d,m,p,y.host,y.ssl,y.experimentalForceLongPolling,y.experimentalAutoDetectLongPolling,mC(y.experimentalLongPollingOptions),y.useFetchStreams)}(n._databaseId,((e=n._app)===null||e===void 0?void 0:e.options.appId)||"",n._persistenceKey,a);n._componentsProvider||!((t=a.localCache)===null||t===void 0)&&t._offlineComponentProvider&&(!((i=a.localCache)===null||i===void 0)&&i._onlineComponentProvider)&&(n._componentsProvider={_offline:a.localCache._offlineComponentProvider,_online:a.localCache._onlineComponentProvider}),n._firestoreClient=new V4(n._authCredentials,n._appCheckCredentials,n._queue,l,n._componentsProvider&&function(d){const m=d==null?void 0:d._online.build();return{_offline:d==null?void 0:d._offline.build(m),_online:m}}(n._componentsProvider))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ml{constructor(e){this._byteString=e}static fromBase64String(e){try{return new ml(on.fromBase64String(e))}catch(t){throw new fe(ne.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new ml(on.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class am{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new fe(ne.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new an(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class om{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ly{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new fe(ne.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new fe(ne.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}toJSON(){return{latitude:this._lat,longitude:this._long}}_compareTo(e){return Ne(this._lat,e._lat)||Ne(this._long,e._long)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vy{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(i,a){if(i.length!==a.length)return!1;for(let l=0;l<i.length;++l)if(i[l]!==a[l])return!1;return!0}(this._values,e._values)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $4=/^__.*__$/;class K4{constructor(e,t,i){this.data=e,this.fieldMask=t,this.fieldTransforms=i}toMutation(e,t){return this.fieldMask!==null?new qr(e,this.data,this.fieldMask,t,this.fieldTransforms):new Uu(e,this.data,t,this.fieldTransforms)}}class _C{constructor(e,t,i){this.data=e,this.fieldMask=t,this.fieldTransforms=i}toMutation(e,t){return new qr(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function yC(n){switch(n){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw Se()}}class Uy{constructor(e,t,i,a,l,u){this.settings=e,this.databaseId=t,this.serializer=i,this.ignoreUndefinedProperties=a,l===void 0&&this.Bu(),this.fieldTransforms=l||[],this.fieldMask=u||[]}get path(){return this.settings.path}get Lu(){return this.settings.Lu}ku(e){return new Uy(Object.assign(Object.assign({},this.settings),e),this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}qu(e){var t;const i=(t=this.path)===null||t===void 0?void 0:t.child(e),a=this.ku({path:i,Qu:!1});return a.$u(e),a}Uu(e){var t;const i=(t=this.path)===null||t===void 0?void 0:t.child(e),a=this.ku({path:i,Qu:!1});return a.Bu(),a}Ku(e){return this.ku({path:void 0,Qu:!0})}Wu(e){return gf(e,this.settings.methodName,this.settings.Gu||!1,this.path,this.settings.zu)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}Bu(){if(this.path)for(let e=0;e<this.path.length;e++)this.$u(this.path.get(e))}$u(e){if(e.length===0)throw this.Wu("Document fields must not be empty");if(yC(this.Lu)&&$4.test(e))throw this.Wu('Document fields cannot begin and end with "__"')}}class Q4{constructor(e,t,i){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=i||tm(e)}ju(e,t,i,a=!1){return new Uy({Lu:e,methodName:t,zu:i,path:an.emptyPath(),Qu:!1,Gu:a},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function lm(n){const e=n._freezeSettings(),t=tm(n._databaseId);return new Q4(n._databaseId,!!e.ignoreUndefinedProperties,t)}function vC(n,e,t,i,a,l={}){const u=n.ju(l.merge||l.mergeFields?2:0,e,t,a);zy("Data must be an object, but it was:",u,i);const d=EC(i,u);let m,p;if(l.merge)m=new Bn(u.fieldMask),p=u.fieldTransforms;else if(l.mergeFields){const y=[];for(const T of l.mergeFields){const w=x_(e,T,t);if(!u.contains(w))throw new fe(ne.INVALID_ARGUMENT,`Field '${w}' is specified in your field mask but missing from your input data.`);bC(y,w)||y.push(w)}m=new Bn(y),p=u.fieldTransforms.filter(T=>m.covers(T.field))}else m=null,p=u.fieldTransforms;return new K4(new Cn(d),m,p)}class cm extends om{_toFieldTransform(e){if(e.Lu!==2)throw e.Lu===1?e.Wu(`${this._methodName}() can only appear at the top level of your update data`):e.Wu(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof cm}}class jy extends om{_toFieldTransform(e){return new zP(e.path,new bu)}isEqual(e){return e instanceof jy}}function Y4(n,e,t,i){const a=n.ju(1,e,t);zy("Data must be an object, but it was:",a,i);const l=[],u=Cn.empty();Br(i,(m,p)=>{const y=Fy(e,m,t);p=at(p);const T=a.Uu(y);if(p instanceof cm)l.push(y);else{const w=Bu(p,T);w!=null&&(l.push(y),u.set(y,w))}});const d=new Bn(l);return new _C(u,d,a.fieldTransforms)}function W4(n,e,t,i,a,l){const u=n.ju(1,e,t),d=[x_(e,i,t)],m=[a];if(l.length%2!=0)throw new fe(ne.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let w=0;w<l.length;w+=2)d.push(x_(e,l[w])),m.push(l[w+1]);const p=[],y=Cn.empty();for(let w=d.length-1;w>=0;--w)if(!bC(p,d[w])){const x=d[w];let I=m[w];I=at(I);const O=u.Uu(x);if(I instanceof cm)p.push(x);else{const P=Bu(I,O);P!=null&&(p.push(x),y.set(x,P))}}const T=new Bn(p);return new _C(y,T,u.fieldTransforms)}function X4(n,e,t,i=!1){return Bu(t,n.ju(i?4:3,e))}function Bu(n,e){if(TC(n=at(n)))return zy("Unsupported field value:",e,n),EC(n,e);if(n instanceof om)return function(i,a){if(!yC(a.Lu))throw a.Wu(`${i._methodName}() can only be used with update() and set()`);if(!a.path)throw a.Wu(`${i._methodName}() is not currently supported inside arrays`);const l=i._toFieldTransform(a);l&&a.fieldTransforms.push(l)}(n,e),null;if(n===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),n instanceof Array){if(e.settings.Qu&&e.Lu!==4)throw e.Wu("Nested arrays are not supported");return function(i,a){const l=[];let u=0;for(const d of i){let m=Bu(d,a.Ku(u));m==null&&(m={nullValue:"NULL_VALUE"}),l.push(m),u++}return{arrayValue:{values:l}}}(n,e)}return function(i,a){if((i=at(i))===null)return{nullValue:"NULL_VALUE"};if(typeof i=="number")return VP(a.serializer,i);if(typeof i=="boolean")return{booleanValue:i};if(typeof i=="string")return{stringValue:i};if(i instanceof Date){const l=Ft.fromDate(i);return{timestampValue:df(a.serializer,l)}}if(i instanceof Ft){const l=new Ft(i.seconds,1e3*Math.floor(i.nanoseconds/1e3));return{timestampValue:df(a.serializer,l)}}if(i instanceof Ly)return{geoPointValue:{latitude:i.latitude,longitude:i.longitude}};if(i instanceof ml)return{bytesValue:PR(a.serializer,i._byteString)};if(i instanceof Tn){const l=a.databaseId,u=i.firestore._databaseId;if(!u.isEqual(l))throw a.Wu(`Document reference is for database ${u.projectId}/${u.database} but should be for database ${l.projectId}/${l.database}`);return{referenceValue:Ty(i.firestore._databaseId||a.databaseId,i._key.path)}}if(i instanceof Vy)return function(u,d){return{mapValue:{fields:{[uR]:{stringValue:hR},[cf]:{arrayValue:{values:u.toArray().map(p=>{if(typeof p!="number")throw d.Wu("VectorValues must only contain numeric values.");return _y(d.serializer,p)})}}}}}}(i,a);throw a.Wu(`Unsupported field value: ${sm(i)}`)}(n,e)}function EC(n,e){const t={};return sR(n)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Br(n,(i,a)=>{const l=Bu(a,e.qu(i));l!=null&&(t[i]=l)}),{mapValue:{fields:t}}}function TC(n){return!(typeof n!="object"||n===null||n instanceof Array||n instanceof Date||n instanceof Ft||n instanceof Ly||n instanceof ml||n instanceof Tn||n instanceof om||n instanceof Vy)}function zy(n,e,t){if(!TC(t)||!function(a){return typeof a=="object"&&a!==null&&(Object.getPrototypeOf(a)===Object.prototype||Object.getPrototypeOf(a)===null)}(t)){const i=sm(t);throw i==="an object"?e.Wu(n+" a custom object"):e.Wu(n+" "+i)}}function x_(n,e,t){if((e=at(e))instanceof am)return e._internalPath;if(typeof e=="string")return Fy(n,e);throw gf("Field path arguments must be of type string or ",n,!1,void 0,t)}const Z4=new RegExp("[~\\*/\\[\\]]");function Fy(n,e,t){if(e.search(Z4)>=0)throw gf(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,n,!1,void 0,t);try{return new am(...e.split("."))._internalPath}catch{throw gf(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,n,!1,void 0,t)}}function gf(n,e,t,i,a){const l=i&&!i.isEmpty(),u=a!==void 0;let d=`Function ${e}() called with invalid data`;t&&(d+=" (via `toFirestore()`)"),d+=". ";let m="";return(l||u)&&(m+=" (found",l&&(m+=` in field ${i}`),u&&(m+=` in document ${a}`),m+=")"),new fe(ne.INVALID_ARGUMENT,d+n+m)}function bC(n,e){return n.some(t=>t.isEqual(e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wC{constructor(e,t,i,a,l){this._firestore=e,this._userDataWriter=t,this._key=i,this._document=a,this._converter=l}get id(){return this._key.path.lastSegment()}get ref(){return new Tn(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new J4(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}get(e){if(this._document){const t=this._document.data.field(By("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class J4 extends wC{data(){return super.data()}}function By(n,e){return typeof e=="string"?Fy(n,e):e instanceof am?e._internalPath:e._delegate._internalPath}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eV(n){if(n.limitType==="L"&&n.explicitOrderBy.length===0)throw new fe(ne.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class qy{}let SC=class extends qy{};function AC(n,e,...t){let i=[];e instanceof qy&&i.push(e),i=i.concat(t),function(l){const u=l.filter(m=>m instanceof Gy).length,d=l.filter(m=>m instanceof Hy).length;if(u>1||u>0&&d>0)throw new fe(ne.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(i);for(const a of i)n=a._apply(n);return n}class Hy extends SC{constructor(e,t,i){super(),this._field=e,this._op=t,this._value=i,this.type="where"}static _create(e,t,i){return new Hy(e,t,i)}_apply(e){const t=this._parse(e);return CC(e._query,t),new Xa(e.firestore,e.converter,g_(e._query,t))}_parse(e){const t=lm(e.firestore);return function(l,u,d,m,p,y,T){let w;if(p.isKeyField()){if(y==="array-contains"||y==="array-contains-any")throw new fe(ne.INVALID_ARGUMENT,`Invalid Query. You can't perform '${y}' queries on documentId().`);if(y==="in"||y==="not-in"){Iw(T,y);const I=[];for(const O of T)I.push(xw(m,l,O));w={arrayValue:{values:I}}}else w=xw(m,l,T)}else y!=="in"&&y!=="not-in"&&y!=="array-contains-any"||Iw(T,y),w=X4(d,u,T,y==="in"||y==="not-in");return Ot.create(p,y,w)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class Gy extends qy{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Gy(e,t)}_parse(e){const t=this._queryConstraints.map(i=>i._parse(e)).filter(i=>i.getFilters().length>0);return t.length===1?t[0]:Ti.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(a,l){let u=a;const d=l.getFlattenedFilters();for(const m of d)CC(u,m),u=g_(u,m)}(e._query,t),new Xa(e.firestore,e.converter,g_(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class $y extends SC{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new $y(e,t)}_apply(e){const t=function(a,l,u){if(a.startAt!==null)throw new fe(ne.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(a.endAt!==null)throw new fe(ne.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new Tu(l,u)}(e._query,this._field,this._direction);return new Xa(e.firestore,e.converter,function(a,l){const u=a.explicitOrderBy.concat([l]);return new Al(a.path,a.collectionGroup,u,a.filters.slice(),a.limit,a.limitType,a.startAt,a.endAt)}(e._query,t))}}function RC(n,e="asc"){const t=e,i=By("orderBy",n);return $y._create(i,t)}function xw(n,e,t){if(typeof(t=at(t))=="string"){if(t==="")throw new fe(ne.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!vR(e)&&t.indexOf("/")!==-1)throw new fe(ne.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const i=e.path.child(ft.fromString(t));if(!_e.isDocumentKey(i))throw new fe(ne.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${i}' is not because it has an odd number of segments (${i.length}).`);return Hb(n,new _e(i))}if(t instanceof Tn)return Hb(n,t._key);throw new fe(ne.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${sm(t)}.`)}function Iw(n,e){if(!Array.isArray(n)||n.length===0)throw new fe(ne.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function CC(n,e){const t=function(a,l){for(const u of a)for(const d of u.getFlattenedFilters())if(l.indexOf(d.op)>=0)return d.op;return null}(n.filters,function(a){switch(a){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new fe(ne.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new fe(ne.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}class tV{convertValue(e,t="none"){switch(Pr(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Rt(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(Mr(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw Se()}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const i={};return Br(e,(a,l)=>{i[a]=this.convertValue(l,t)}),i}convertVectorValue(e){var t,i,a;const l=(a=(i=(t=e.fields)===null||t===void 0?void 0:t[cf].arrayValue)===null||i===void 0?void 0:i.values)===null||a===void 0?void 0:a.map(u=>Rt(u.doubleValue));return new Vy(l)}convertGeoPoint(e){return new Ly(Rt(e.latitude),Rt(e.longitude))}convertArray(e,t){return(e.values||[]).map(i=>this.convertValue(i,t))}convertServerTimestamp(e,t){switch(t){case"previous":const i=Yf(e);return i==null?null:this.convertValue(i,t);case"estimate":return this.convertTimestamp(yu(e));default:return null}}convertTimestamp(e){const t=Or(e);return new Ft(t.seconds,t.nanos)}convertDocumentKey(e,t){const i=ft.fromString(e);Xe(FR(i));const a=new vu(i.get(1),i.get(3)),l=new _e(i.popFirst(5));return a.isEqual(t)||Vs(`Document ${l} contains a document reference within a different database (${a.projectId}/${a.database}) which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xC(n,e,t){let i;return i=n?n.toFirestore(e):e,i}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zc{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class IC extends wC{constructor(e,t,i,a,l,u){super(e,t,i,a,u),this._firestore=e,this._firestoreImpl=e,this.metadata=l}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new $d(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const i=this._document.data.field(By("DocumentSnapshot.get",e));if(i!==null)return this._userDataWriter.convertValue(i,t.serverTimestamps)}}}class $d extends IC{data(e={}){return super.data(e)}}class nV{constructor(e,t,i,a){this._firestore=e,this._userDataWriter=t,this._snapshot=a,this.metadata=new Zc(a.hasPendingWrites,a.fromCache),this.query=i}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(i=>{e.call(t,new $d(this._firestore,this._userDataWriter,i.key,i,new Zc(this._snapshot.mutatedKeys.has(i.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new fe(ne.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(a,l){if(a._snapshot.oldDocs.isEmpty()){let u=0;return a._snapshot.docChanges.map(d=>{const m=new $d(a._firestore,a._userDataWriter,d.doc.key,d.doc,new Zc(a._snapshot.mutatedKeys.has(d.doc.key),a._snapshot.fromCache),a.query.converter);return d.doc,{type:"added",doc:m,oldIndex:-1,newIndex:u++}})}{let u=a._snapshot.oldDocs;return a._snapshot.docChanges.filter(d=>l||d.type!==3).map(d=>{const m=new $d(a._firestore,a._userDataWriter,d.doc.key,d.doc,new Zc(a._snapshot.mutatedKeys.has(d.doc.key),a._snapshot.fromCache),a.query.converter);let p=-1,y=-1;return d.type!==0&&(p=u.indexOf(d.doc.key),u=u.delete(d.doc.key)),d.type!==1&&(u=u.add(d.doc),y=u.indexOf(d.doc.key)),{type:iV(d.type),doc:m,oldIndex:p,newIndex:y}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}}function iV(n){switch(n){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return Se()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ky(n){n=bi(n,Tn);const e=bi(n.firestore,Za);return z4(Py(e),n._key).then(t=>lV(e,n,t))}class NC extends tV{constructor(e){super(),this.firestore=e}convertBytes(e){return new ml(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Tn(this.firestore,null,t)}}function kC(n){n=bi(n,Xa);const e=bi(n.firestore,Za),t=Py(e),i=new NC(e);return eV(n._query),F4(t,n._query).then(a=>new nV(e,i,n,a))}function sV(n,e,t){n=bi(n,Tn);const i=bi(n.firestore,Za),a=xC(n.converter,e);return um(i,[vC(lm(i),"setDoc",n._key,a,n.converter!==null,t).toMutation(n._key,si.none())])}function rV(n,e,t,...i){n=bi(n,Tn);const a=bi(n.firestore,Za),l=lm(a);let u;return u=typeof(e=at(e))=="string"||e instanceof am?W4(l,"updateDoc",n._key,e,t,i):Y4(l,"updateDoc",n._key,e),um(a,[u.toMutation(n._key,si.exists(!0))])}function aV(n){return um(bi(n.firestore,Za),[new yy(n._key,si.none())])}function oV(n,e){const t=bi(n.firestore,Za),i=Fa(n),a=xC(n.converter,e);return um(t,[vC(lm(n.firestore),"addDoc",i._key,a,n.converter!==null,{}).toMutation(i._key,si.exists(!1))]).then(()=>i)}function um(n,e){return function(i,a){const l=new ks;return i.asyncQueue.enqueueAndForget(async()=>x4(await j4(i),a,l)),l.promise}(Py(n),e)}function lV(n,e,t){const i=t.docs.get(e._key),a=new NC(n);return new IC(n,a,e._key,i,new Zc(t.hasPendingWrites,t.fromCache),e.converter)}function ru(){return new jy("serverTimestamp")}(function(e,t=!0){(function(a){bl=a})(Fr),ri(new Hn("firestore",(i,{instanceIdentifier:a,options:l})=>{const u=i.getProvider("app").getImmediate(),d=new Za(new XM(i.getProvider("auth-internal")),new eP(u,i.getProvider("app-check-internal")),function(p,y){if(!Object.prototype.hasOwnProperty.apply(p.options,["projectId"]))throw new fe(ne.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new vu(p.options.projectId,y)}(u,a),u);return l=Object.assign({useFetchStreams:t},l),d._setSettings(l),d},"PUBLIC").setMultipleInstances(!0)),pn(Db,Ob,e),pn(Db,Ob,"esm2017")})();function Qy(n,e){var t={};for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&e.indexOf(i)<0&&(t[i]=n[i]);if(n!=null&&typeof Object.getOwnPropertySymbols=="function")for(var a=0,i=Object.getOwnPropertySymbols(n);a<i.length;a++)e.indexOf(i[a])<0&&Object.prototype.propertyIsEnumerable.call(n,i[a])&&(t[i[a]]=n[i[a]]);return t}function DC(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const cV=DC,OC=new Qa("auth","Firebase",DC());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _f=new Lu("@firebase/auth");function uV(n,...e){_f.logLevel<=Ue.WARN&&_f.warn(`Auth (${Fr}): ${n}`,...e)}function Kd(n,...e){_f.logLevel<=Ue.ERROR&&_f.error(`Auth (${Fr}): ${n}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wi(n,...e){throw Yy(n,...e)}function Gi(n,...e){return Yy(n,...e)}function MC(n,e,t){const i=Object.assign(Object.assign({},cV()),{[e]:t});return new Qa("auth","Firebase",i).create(e,{appName:n.name})}function Ds(n){return MC(n,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function Yy(n,...e){if(typeof n!="string"){const t=e[0],i=[...e.slice(1)];return i[0]&&(i[0].appName=n.name),n._errorFactory.create(t,...i)}return OC.create(n,...e)}function Te(n,e,...t){if(!n)throw Yy(e,...t)}function Rs(n){const e="INTERNAL ASSERTION FAILED: "+n;throw Kd(e),new Error(e)}function js(n,e){n||Rs(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function I_(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.href)||""}function hV(){return Nw()==="http:"||Nw()==="https:"}function Nw(){var n;return typeof self<"u"&&((n=self.location)===null||n===void 0?void 0:n.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dV(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(hV()||pA()||"connection"in navigator)?navigator.onLine:!0}function fV(){if(typeof navigator>"u")return null;const n=navigator;return n.languages&&n.languages[0]||n.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qu{constructor(e,t){this.shortDelay=e,this.longDelay=t,js(t>e,"Short delay should be less than long delay!"),this.isMobile=ny()||gA()}get(){return dV()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wy(n,e){js(n.emulator,"Emulator should always be set here");const{url:t}=n.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PC{static initialize(e,t,i){this.fetchImpl=e,t&&(this.headersImpl=t),i&&(this.responseImpl=i)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;Rs("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;Rs("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;Rs("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mV={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pV=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],gV=new qu(3e4,6e4);function Hr(n,e){return n.tenantId&&!e.tenantId?Object.assign(Object.assign({},e),{tenantId:n.tenantId}):e}async function Gr(n,e,t,i,a={}){return LC(n,a,async()=>{let l={},u={};i&&(e==="GET"?u=i:l={body:JSON.stringify(i)});const d=Tl(Object.assign({key:n.config.apiKey},u)).slice(1),m=await n._getAdditionalHeaders();m["Content-Type"]="application/json",n.languageCode&&(m["X-Firebase-Locale"]=n.languageCode);const p=Object.assign({method:e,headers:m},l);return nD()||(p.referrerPolicy="no-referrer"),PC.fetch()(await VC(n,n.config.apiHost,t,d),p)})}async function LC(n,e,t){n._canInitEmulator=!1;const i=Object.assign(Object.assign({},mV),e);try{const a=new yV(n),l=await Promise.race([t(),a.promise]);a.clearNetworkTimeout();const u=await l.json();if("needConfirmation"in u)throw Dd(n,"account-exists-with-different-credential",u);if(l.ok&&!("errorMessage"in u))return u;{const d=l.ok?u.errorMessage:u.error.message,[m,p]=d.split(" : ");if(m==="FEDERATED_USER_ID_ALREADY_LINKED")throw Dd(n,"credential-already-in-use",u);if(m==="EMAIL_EXISTS")throw Dd(n,"email-already-in-use",u);if(m==="USER_DISABLED")throw Dd(n,"user-disabled",u);const y=i[m]||m.toLowerCase().replace(/[_\s]+/g,"-");if(p)throw MC(n,y,p);wi(n,y)}}catch(a){if(a instanceof oi)throw a;wi(n,"network-request-failed",{message:String(a)})}}async function Hu(n,e,t,i,a={}){const l=await Gr(n,e,t,i,a);return"mfaPendingCredential"in l&&wi(n,"multi-factor-auth-required",{_serverResponse:l}),l}async function VC(n,e,t,i){const a=`${e}${t}?${i}`,l=n,u=l.config.emulator?Wy(n.config,a):`${n.config.apiScheme}://${a}`;return pV.includes(t)&&(await l._persistenceManagerAvailable,l._getPersistenceType()==="COOKIE")?l._getPersistence()._getFinalTarget(u).toString():u}function _V(n){switch(n){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class yV{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,i)=>{this.timer=setTimeout(()=>i(Gi(this.auth,"network-request-failed")),gV.get())})}}function Dd(n,e,t){const i={appName:n.name};t.email&&(i.email=t.email),t.phoneNumber&&(i.phoneNumber=t.phoneNumber);const a=Gi(n,e,i);return a.customData._tokenResponse=t,a}function kw(n){return n!==void 0&&n.enterprise!==void 0}class vV{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return _V(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}async function EV(n,e){return Gr(n,"GET","/v2/recaptchaConfig",Hr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function TV(n,e){return Gr(n,"POST","/v1/accounts:delete",e)}async function yf(n,e){return Gr(n,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function au(n){if(n)try{const e=new Date(Number(n));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function bV(n,e=!1){const t=at(n),i=await t.getIdToken(e),a=Xy(i);Te(a&&a.exp&&a.auth_time&&a.iat,t.auth,"internal-error");const l=typeof a.firebase=="object"?a.firebase:void 0,u=l==null?void 0:l.sign_in_provider;return{claims:a,token:i,authTime:au(Bg(a.auth_time)),issuedAtTime:au(Bg(a.iat)),expirationTime:au(Bg(a.exp)),signInProvider:u||null,signInSecondFactor:(l==null?void 0:l.sign_in_second_factor)||null}}function Bg(n){return Number(n)*1e3}function Xy(n){const[e,t,i]=n.split(".");if(e===void 0||t===void 0||i===void 0)return Kd("JWT malformed, contained fewer than 3 sections"),null;try{const a=tf(t);return a?JSON.parse(a):(Kd("Failed to decode base64 JWT payload"),null)}catch(a){return Kd("Caught error parsing JWT payload as JSON",a==null?void 0:a.toString()),null}}function Dw(n){const e=Xy(n);return Te(e,"internal-error"),Te(typeof e.exp<"u","internal-error"),Te(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Au(n,e,t=!1){if(t)return e;try{return await e}catch(i){throw i instanceof oi&&wV(i)&&n.auth.currentUser===n&&await n.auth.signOut(),i}}function wV({code:n}){return n==="auth/user-disabled"||n==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SV{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){var t;if(e){const i=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),i}else{this.errorBackoff=3e4;const a=((t=this.user.stsTokenManager.expirationTime)!==null&&t!==void 0?t:0)-Date.now()-3e5;return Math.max(0,a)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class N_{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=au(this.lastLoginAt),this.creationTime=au(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function vf(n){var e;const t=n.auth,i=await n.getIdToken(),a=await Au(n,yf(t,{idToken:i}));Te(a==null?void 0:a.users.length,t,"internal-error");const l=a.users[0];n._notifyReloadListener(l);const u=!((e=l.providerUserInfo)===null||e===void 0)&&e.length?UC(l.providerUserInfo):[],d=RV(n.providerData,u),m=n.isAnonymous,p=!(n.email&&l.passwordHash)&&!(d!=null&&d.length),y=m?p:!1,T={uid:l.localId,displayName:l.displayName||null,photoURL:l.photoUrl||null,email:l.email||null,emailVerified:l.emailVerified||!1,phoneNumber:l.phoneNumber||null,tenantId:l.tenantId||null,providerData:d,metadata:new N_(l.createdAt,l.lastLoginAt),isAnonymous:y};Object.assign(n,T)}async function AV(n){const e=at(n);await vf(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function RV(n,e){return[...n.filter(i=>!e.some(a=>a.providerId===i.providerId)),...e]}function UC(n){return n.map(e=>{var{providerId:t}=e,i=Qy(e,["providerId"]);return{providerId:t,uid:i.rawId||"",displayName:i.displayName||null,email:i.email||null,phoneNumber:i.phoneNumber||null,photoURL:i.photoUrl||null}})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function CV(n,e){const t=await LC(n,{},async()=>{const i=Tl({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:a,apiKey:l}=n.config,u=await VC(n,a,"/v1/token",`key=${l}`),d=await n._getAdditionalHeaders();return d["Content-Type"]="application/x-www-form-urlencoded",PC.fetch()(u,{method:"POST",headers:d,body:i})});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function xV(n,e){return Gr(n,"POST","/v2/accounts:revokeToken",Hr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nl{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){Te(e.idToken,"internal-error"),Te(typeof e.idToken<"u","internal-error"),Te(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):Dw(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){Te(e.length!==0,"internal-error");const t=Dw(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(Te(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:i,refreshToken:a,expiresIn:l}=await CV(e,t);this.updateTokensAndExpiration(i,a,Number(l))}updateTokensAndExpiration(e,t,i){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+i*1e3}static fromJSON(e,t){const{refreshToken:i,accessToken:a,expirationTime:l}=t,u=new nl;return i&&(Te(typeof i=="string","internal-error",{appName:e}),u.refreshToken=i),a&&(Te(typeof a=="string","internal-error",{appName:e}),u.accessToken=a),l&&(Te(typeof l=="number","internal-error",{appName:e}),u.expirationTime=l),u}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new nl,this.toJSON())}_performRefresh(){return Rs("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vr(n,e){Te(typeof n=="string"||typeof n>"u","internal-error",{appName:e})}class pi{constructor(e){var{uid:t,auth:i,stsTokenManager:a}=e,l=Qy(e,["uid","auth","stsTokenManager"]);this.providerId="firebase",this.proactiveRefresh=new SV(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=t,this.auth=i,this.stsTokenManager=a,this.accessToken=a.accessToken,this.displayName=l.displayName||null,this.email=l.email||null,this.emailVerified=l.emailVerified||!1,this.phoneNumber=l.phoneNumber||null,this.photoURL=l.photoURL||null,this.isAnonymous=l.isAnonymous||!1,this.tenantId=l.tenantId||null,this.providerData=l.providerData?[...l.providerData]:[],this.metadata=new N_(l.createdAt||void 0,l.lastLoginAt||void 0)}async getIdToken(e){const t=await Au(this,this.stsTokenManager.getToken(this.auth,e));return Te(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return bV(this,e)}reload(){return AV(this)}_assign(e){this!==e&&(Te(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>Object.assign({},t)),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new pi(Object.assign(Object.assign({},this),{auth:e,stsTokenManager:this.stsTokenManager._clone()}));return t.metadata._copy(this.metadata),t}_onReload(e){Te(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let i=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),i=!0),t&&await vf(this),await this.auth._persistUserIfCurrent(this),i&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Rn(this.auth.app))return Promise.reject(Ds(this.auth));const e=await this.getIdToken();return await Au(this,TV(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return Object.assign(Object.assign({uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>Object.assign({},e)),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId},this.metadata.toJSON()),{apiKey:this.auth.config.apiKey,appName:this.auth.name})}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){var i,a,l,u,d,m,p,y;const T=(i=t.displayName)!==null&&i!==void 0?i:void 0,w=(a=t.email)!==null&&a!==void 0?a:void 0,x=(l=t.phoneNumber)!==null&&l!==void 0?l:void 0,I=(u=t.photoURL)!==null&&u!==void 0?u:void 0,O=(d=t.tenantId)!==null&&d!==void 0?d:void 0,P=(m=t._redirectEventId)!==null&&m!==void 0?m:void 0,B=(p=t.createdAt)!==null&&p!==void 0?p:void 0,ee=(y=t.lastLoginAt)!==null&&y!==void 0?y:void 0,{uid:Y,emailVerified:W,isAnonymous:re,providerData:he,stsTokenManager:M}=t;Te(Y&&M,e,"internal-error");const A=nl.fromJSON(this.name,M);Te(typeof Y=="string",e,"internal-error"),vr(T,e.name),vr(w,e.name),Te(typeof W=="boolean",e,"internal-error"),Te(typeof re=="boolean",e,"internal-error"),vr(x,e.name),vr(I,e.name),vr(O,e.name),vr(P,e.name),vr(B,e.name),vr(ee,e.name);const C=new pi({uid:Y,auth:e,email:w,emailVerified:W,displayName:T,isAnonymous:re,photoURL:I,phoneNumber:x,tenantId:O,stsTokenManager:A,createdAt:B,lastLoginAt:ee});return he&&Array.isArray(he)&&(C.providerData=he.map(N=>Object.assign({},N))),P&&(C._redirectEventId=P),C}static async _fromIdTokenResponse(e,t,i=!1){const a=new nl;a.updateFromServerResponse(t);const l=new pi({uid:t.localId,auth:e,stsTokenManager:a,isAnonymous:i});return await vf(l),l}static async _fromGetAccountInfoResponse(e,t,i){const a=t.users[0];Te(a.localId!==void 0,"internal-error");const l=a.providerUserInfo!==void 0?UC(a.providerUserInfo):[],u=!(a.email&&a.passwordHash)&&!(l!=null&&l.length),d=new nl;d.updateFromIdToken(i);const m=new pi({uid:a.localId,auth:e,stsTokenManager:d,isAnonymous:u}),p={uid:a.localId,displayName:a.displayName||null,photoURL:a.photoUrl||null,email:a.email||null,emailVerified:a.emailVerified||!1,phoneNumber:a.phoneNumber||null,tenantId:a.tenantId||null,providerData:l,metadata:new N_(a.createdAt,a.lastLoginAt),isAnonymous:!(a.email&&a.passwordHash)&&!(l!=null&&l.length)};return Object.assign(m,p),m}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ow=new Map;function Cs(n){js(n instanceof Function,"Expected a class definition");let e=Ow.get(n);return e?(js(e instanceof n,"Instance stored in cache mismatched with class"),e):(e=new n,Ow.set(n,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jC{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}jC.type="NONE";const Mw=jC;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qd(n,e,t){return`firebase:${n}:${e}:${t}`}class il{constructor(e,t,i){this.persistence=e,this.auth=t,this.userKey=i;const{config:a,name:l}=this.auth;this.fullUserKey=Qd(this.userKey,a.apiKey,l),this.fullPersistenceKey=Qd("persistence",a.apiKey,l),this.boundEventHandler=t._onStorageEvent.bind(t),this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await yf(this.auth,{idToken:e}).catch(()=>{});return t?pi._fromGetAccountInfoResponse(this.auth,t,e):null}return pi._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}static async create(e,t,i="authUser"){if(!t.length)return new il(Cs(Mw),e,i);const a=(await Promise.all(t.map(async p=>{if(await p._isAvailable())return p}))).filter(p=>p);let l=a[0]||Cs(Mw);const u=Qd(i,e.config.apiKey,e.name);let d=null;for(const p of t)try{const y=await p._get(u);if(y){let T;if(typeof y=="string"){const w=await yf(e,{idToken:y}).catch(()=>{});if(!w)break;T=await pi._fromGetAccountInfoResponse(e,w,y)}else T=pi._fromJSON(e,y);p!==l&&(d=T),l=p;break}}catch{}const m=a.filter(p=>p._shouldAllowMigration);return!l._shouldAllowMigration||!m.length?new il(l,e,i):(l=m[0],d&&await l._set(u,d.toJSON()),await Promise.all(t.map(async p=>{if(p!==l)try{await p._remove(u)}catch{}})),new il(l,e,i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pw(n){const e=n.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(qC(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(zC(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(GC(e))return"Blackberry";if($C(e))return"Webos";if(FC(e))return"Safari";if((e.includes("chrome/")||BC(e))&&!e.includes("edge/"))return"Chrome";if(HC(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,i=n.match(t);if((i==null?void 0:i.length)===2)return i[1]}return"Other"}function zC(n=gn()){return/firefox\//i.test(n)}function FC(n=gn()){const e=n.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function BC(n=gn()){return/crios\//i.test(n)}function qC(n=gn()){return/iemobile/i.test(n)}function HC(n=gn()){return/android/i.test(n)}function GC(n=gn()){return/blackberry/i.test(n)}function $C(n=gn()){return/webos/i.test(n)}function Zy(n=gn()){return/iphone|ipad|ipod/i.test(n)||/macintosh/i.test(n)&&/mobile/i.test(n)}function IV(n=gn()){var e;return Zy(n)&&!!(!((e=window.navigator)===null||e===void 0)&&e.standalone)}function NV(){return iD()&&document.documentMode===10}function KC(n=gn()){return Zy(n)||HC(n)||$C(n)||GC(n)||/windows phone/i.test(n)||qC(n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function QC(n,e=[]){let t;switch(n){case"Browser":t=Pw(gn());break;case"Worker":t=`${Pw(gn())}-${n}`;break;default:t=n}const i=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${Fr}/${i}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kV{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const i=l=>new Promise((u,d)=>{try{const m=e(l);u(m)}catch(m){d(m)}});i.onAbort=t,this.queue.push(i);const a=this.queue.length-1;return()=>{this.queue[a]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const i of this.queue)await i(e),i.onAbort&&t.push(i.onAbort)}catch(i){t.reverse();for(const a of t)try{a()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:i==null?void 0:i.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function DV(n,e={}){return Gr(n,"GET","/v2/passwordPolicy",Hr(n,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const OV=6;class MV{constructor(e){var t,i,a,l;const u=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=(t=u.minPasswordLength)!==null&&t!==void 0?t:OV,u.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=u.maxPasswordLength),u.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=u.containsLowercaseCharacter),u.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=u.containsUppercaseCharacter),u.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=u.containsNumericCharacter),u.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=u.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=(a=(i=e.allowedNonAlphanumericCharacters)===null||i===void 0?void 0:i.join(""))!==null&&a!==void 0?a:"",this.forceUpgradeOnSignin=(l=e.forceUpgradeOnSignin)!==null&&l!==void 0?l:!1,this.schemaVersion=e.schemaVersion}validatePassword(e){var t,i,a,l,u,d;const m={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,m),this.validatePasswordCharacterOptions(e,m),m.isValid&&(m.isValid=(t=m.meetsMinPasswordLength)!==null&&t!==void 0?t:!0),m.isValid&&(m.isValid=(i=m.meetsMaxPasswordLength)!==null&&i!==void 0?i:!0),m.isValid&&(m.isValid=(a=m.containsLowercaseLetter)!==null&&a!==void 0?a:!0),m.isValid&&(m.isValid=(l=m.containsUppercaseLetter)!==null&&l!==void 0?l:!0),m.isValid&&(m.isValid=(u=m.containsNumericCharacter)!==null&&u!==void 0?u:!0),m.isValid&&(m.isValid=(d=m.containsNonAlphanumericCharacter)!==null&&d!==void 0?d:!0),m}validatePasswordLengthOptions(e,t){const i=this.customStrengthOptions.minPasswordLength,a=this.customStrengthOptions.maxPasswordLength;i&&(t.meetsMinPasswordLength=e.length>=i),a&&(t.meetsMaxPasswordLength=e.length<=a)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let i;for(let a=0;a<e.length;a++)i=e.charAt(a),this.updatePasswordCharacterOptionsStatuses(t,i>="a"&&i<="z",i>="A"&&i<="Z",i>="0"&&i<="9",this.allowedNonAlphanumericCharacters.includes(i))}updatePasswordCharacterOptionsStatuses(e,t,i,a,l){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=i)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=a)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=l))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PV{constructor(e,t,i,a){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=i,this.config=a,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new Lw(this),this.idTokenSubscription=new Lw(this),this.beforeStateQueue=new kV(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=OC,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=a.sdkClientVersion,this._persistenceManagerAvailable=new Promise(l=>this._resolvePersistenceManagerAvailable=l)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Cs(t)),this._initializationPromise=this.queue(async()=>{var i,a,l;if(!this._deleted&&(this.persistenceManager=await il.create(this,e),(i=this._resolvePersistenceManagerAvailable)===null||i===void 0||i.call(this),!this._deleted)){if(!((a=this._popupRedirectResolver)===null||a===void 0)&&a._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}await this.initializeCurrentUser(t),this.lastNotifiedUid=((l=this.currentUser)===null||l===void 0?void 0:l.uid)||null,!this._deleted&&(this._isInitialized=!0)}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await yf(this,{idToken:e}),i=await pi._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(i)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var t;if(Rn(this.app)){const u=this.app.settings.authIdToken;return u?new Promise(d=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(u).then(d,d))}):this.directlySetCurrentUser(null)}const i=await this.assertedPersistence.getCurrentUser();let a=i,l=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const u=(t=this.redirectUser)===null||t===void 0?void 0:t._redirectEventId,d=a==null?void 0:a._redirectEventId,m=await this.tryRedirectSignIn(e);(!u||u===d)&&(m!=null&&m.user)&&(a=m.user,l=!0)}if(!a)return this.directlySetCurrentUser(null);if(!a._redirectEventId){if(l)try{await this.beforeStateQueue.runMiddleware(a)}catch(u){a=i,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(u))}return a?this.reloadAndSetCurrentUserOrClear(a):this.directlySetCurrentUser(null)}return Te(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===a._redirectEventId?this.directlySetCurrentUser(a):this.reloadAndSetCurrentUserOrClear(a)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await vf(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=fV()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Rn(this.app))return Promise.reject(Ds(this));const t=e?at(e):null;return t&&Te(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&Te(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Rn(this.app)?Promise.reject(Ds(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Rn(this.app)?Promise.reject(Ds(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Cs(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await DV(this),t=new MV(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new Qa("auth","Firebase",e())}onAuthStateChanged(e,t,i){return this.registerStateListener(this.authStateSubscription,e,t,i)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,i){return this.registerStateListener(this.idTokenSubscription,e,t,i)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const i=this.onAuthStateChanged(()=>{i(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),i={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(i.tenantId=this.tenantId),await xV(this,i)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)===null||e===void 0?void 0:e.toJSON()}}async _setRedirectUser(e,t){const i=await this.getOrInitRedirectPersistenceManager(t);return e===null?i.removeCurrentUser():i.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Cs(e)||this._popupRedirectResolver;Te(t,this,"argument-error"),this.redirectPersistenceManager=await il.create(this,[Cs(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,i;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)===null||t===void 0?void 0:t._redirectEventId)===e?this._currentUser:((i=this.redirectUser)===null||i===void 0?void 0:i._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var e,t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const i=(t=(e=this.currentUser)===null||e===void 0?void 0:e.uid)!==null&&t!==void 0?t:null;this.lastNotifiedUid!==i&&(this.lastNotifiedUid=i,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,i,a){if(this._deleted)return()=>{};const l=typeof t=="function"?t:t.next.bind(t);let u=!1;const d=this._isInitialized?Promise.resolve():this._initializationPromise;if(Te(d,this,"internal-error"),d.then(()=>{u||l(this.currentUser)}),typeof t=="function"){const m=e.addObserver(t,i,a);return()=>{u=!0,m()}}else{const m=e.addObserver(t);return()=>{u=!0,m()}}}async directlySetCurrentUser(e){this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,e?await this.assertedPersistence.setCurrentUser(e):await this.assertedPersistence.removeCurrentUser()}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return Te(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=QC(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var e;const t={"X-Client-Version":this.clientVersion};this.app.options.appId&&(t["X-Firebase-gmpid"]=this.app.options.appId);const i=await((e=this.heartbeatServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getHeartbeatsHeader());i&&(t["X-Firebase-Client"]=i);const a=await this._getAppCheckToken();return a&&(t["X-Firebase-AppCheck"]=a),t}async _getAppCheckToken(){var e;if(Rn(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const t=await((e=this.appCheckServiceProvider.getImmediate({optional:!0}))===null||e===void 0?void 0:e.getToken());return t!=null&&t.error&&uV(`Error while retrieving App Check token: ${t.error}`),t==null?void 0:t.token}}function Ja(n){return at(n)}class Lw{constructor(e){this.auth=e,this.observer=null,this.addObserver=fD(t=>this.observer=t)}get next(){return Te(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let hm={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function LV(n){hm=n}function YC(n){return hm.loadJS(n)}function VV(){return hm.recaptchaEnterpriseScript}function UV(){return hm.gapiScript}function jV(n){return`__${n}${Math.floor(Math.random()*1e6)}`}class zV{constructor(){this.enterprise=new FV}ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}class FV{ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}const BV="recaptcha-enterprise",WC="NO_RECAPTCHA";class qV{constructor(e){this.type=BV,this.auth=Ja(e)}async verify(e="verify",t=!1){async function i(l){if(!t){if(l.tenantId==null&&l._agentRecaptchaConfig!=null)return l._agentRecaptchaConfig.siteKey;if(l.tenantId!=null&&l._tenantRecaptchaConfigs[l.tenantId]!==void 0)return l._tenantRecaptchaConfigs[l.tenantId].siteKey}return new Promise(async(u,d)=>{EV(l,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(m=>{if(m.recaptchaKey===void 0)d(new Error("recaptcha Enterprise site key undefined"));else{const p=new vV(m);return l.tenantId==null?l._agentRecaptchaConfig=p:l._tenantRecaptchaConfigs[l.tenantId]=p,u(p.siteKey)}}).catch(m=>{d(m)})})}function a(l,u,d){const m=window.grecaptcha;kw(m)?m.enterprise.ready(()=>{m.enterprise.execute(l,{action:e}).then(p=>{u(p)}).catch(()=>{u(WC)})}):d(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new zV().execute("siteKey",{action:"verify"}):new Promise((l,u)=>{i(this.auth).then(d=>{if(!t&&kw(window.grecaptcha))a(d,l,u);else{if(typeof window>"u"){u(new Error("RecaptchaVerifier is only supported in browser"));return}let m=VV();m.length!==0&&(m+=d),YC(m).then(()=>{a(d,l,u)}).catch(p=>{u(p)})}}).catch(d=>{u(d)})})}}async function Vw(n,e,t,i=!1,a=!1){const l=new qV(n);let u;if(a)u=WC;else try{u=await l.verify(t)}catch{u=await l.verify(t,!0)}const d=Object.assign({},e);if(t==="mfaSmsEnrollment"||t==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in d){const m=d.phoneEnrollmentInfo.phoneNumber,p=d.phoneEnrollmentInfo.recaptchaToken;Object.assign(d,{phoneEnrollmentInfo:{phoneNumber:m,recaptchaToken:p,captchaResponse:u,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in d){const m=d.phoneSignInInfo.recaptchaToken;Object.assign(d,{phoneSignInInfo:{recaptchaToken:m,captchaResponse:u,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return d}return i?Object.assign(d,{captchaResp:u}):Object.assign(d,{captchaResponse:u}),Object.assign(d,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(d,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),d}async function k_(n,e,t,i,a){var l;if(!((l=n._getRecaptchaConfig())===null||l===void 0)&&l.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const u=await Vw(n,e,t,t==="getOobCode");return i(n,u)}else return i(n,e).catch(async u=>{if(u.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const d=await Vw(n,e,t,t==="getOobCode");return i(n,d)}else return Promise.reject(u)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function HV(n,e){const t=qs(n,"auth");if(t.isInitialized()){const a=t.getImmediate(),l=t.getOptions();if(Ps(l,e??{}))return a;wi(a,"already-initialized")}return t.initialize({options:e})}function GV(n,e){const t=(e==null?void 0:e.persistence)||[],i=(Array.isArray(t)?t:[t]).map(Cs);e!=null&&e.errorMap&&n._updateErrorMap(e.errorMap),n._initializeWithPersistence(i,e==null?void 0:e.popupRedirectResolver)}function $V(n,e,t){const i=Ja(n);Te(/^https?:\/\//.test(e),i,"invalid-emulator-scheme");const a=!1,l=XC(e),{host:u,port:d}=KV(e),m=d===null?"":`:${d}`,p={url:`${l}//${u}${m}/`},y=Object.freeze({host:u,port:d,protocol:l.replace(":",""),options:Object.freeze({disableWarnings:a})});if(!i._canInitEmulator){Te(i.config.emulator&&i.emulatorConfig,i,"emulator-config-failed"),Te(Ps(p,i.config.emulator)&&Ps(y,i.emulatorConfig),i,"emulator-config-failed");return}i.config.emulator=p,i.emulatorConfig=y,i.settings.appVerificationDisabledForTesting=!0,QV()}function XC(n){const e=n.indexOf(":");return e<0?"":n.substr(0,e+1)}function KV(n){const e=XC(n),t=/(\/\/)?([^?#/]+)/.exec(n.substr(e.length));if(!t)return{host:"",port:null};const i=t[2].split("@").pop()||"",a=/^(\[[^\]]+\])(:|$)/.exec(i);if(a){const l=a[1];return{host:l,port:Uw(i.substr(l.length+1))}}else{const[l,u]=i.split(":");return{host:l,port:Uw(u)}}}function Uw(n){if(!n)return null;const e=Number(n);return isNaN(e)?null:e}function QV(){function n(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",n):n())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jy{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return Rs("not implemented")}_getIdTokenResponse(e){return Rs("not implemented")}_linkToIdToken(e,t){return Rs("not implemented")}_getReauthenticationResolver(e){return Rs("not implemented")}}async function YV(n,e){return Gr(n,"POST","/v1/accounts:signUp",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function WV(n,e){return Hu(n,"POST","/v1/accounts:signInWithPassword",Hr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function XV(n,e){return Hu(n,"POST","/v1/accounts:signInWithEmailLink",Hr(n,e))}async function ZV(n,e){return Hu(n,"POST","/v1/accounts:signInWithEmailLink",Hr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ru extends Jy{constructor(e,t,i,a=null){super("password",i),this._email=e,this._password=t,this._tenantId=a}static _fromEmailAndPassword(e,t){return new Ru(e,t,"password")}static _fromEmailAndCode(e,t,i=null){return new Ru(e,t,"emailLink",i)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return k_(e,t,"signInWithPassword",WV);case"emailLink":return XV(e,{email:this._email,oobCode:this._password});default:wi(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const i={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return k_(e,i,"signUpPassword",YV);case"emailLink":return ZV(e,{idToken:t,email:this._email,oobCode:this._password});default:wi(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sl(n,e){return Hu(n,"POST","/v1/accounts:signInWithIdp",Hr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const JV="http://localhost";class Ba extends Jy{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Ba(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):wi("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:i,signInMethod:a}=t,l=Qy(t,["providerId","signInMethod"]);if(!i||!a)return null;const u=new Ba(i,a);return u.idToken=l.idToken||void 0,u.accessToken=l.accessToken||void 0,u.secret=l.secret,u.nonce=l.nonce,u.pendingToken=l.pendingToken||null,u}_getIdTokenResponse(e){const t=this.buildRequest();return sl(e,t)}_linkToIdToken(e,t){const i=this.buildRequest();return i.idToken=t,sl(e,i)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,sl(e,t)}buildRequest(){const e={requestUri:JV,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=Tl(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eU(n){switch(n){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function tU(n){const e=Kc(Qc(n)).link,t=e?Kc(Qc(e)).deep_link_id:null,i=Kc(Qc(n)).deep_link_id;return(i?Kc(Qc(i)).link:null)||i||t||e||n}class ev{constructor(e){var t,i,a,l,u,d;const m=Kc(Qc(e)),p=(t=m.apiKey)!==null&&t!==void 0?t:null,y=(i=m.oobCode)!==null&&i!==void 0?i:null,T=eU((a=m.mode)!==null&&a!==void 0?a:null);Te(p&&y&&T,"argument-error"),this.apiKey=p,this.operation=T,this.code=y,this.continueUrl=(l=m.continueUrl)!==null&&l!==void 0?l:null,this.languageCode=(u=m.languageCode)!==null&&u!==void 0?u:null,this.tenantId=(d=m.tenantId)!==null&&d!==void 0?d:null}static parseLink(e){const t=tU(e);try{return new ev(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cl{constructor(){this.providerId=Cl.PROVIDER_ID}static credential(e,t){return Ru._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const i=ev.parseLink(t);return Te(i,"argument-error"),Ru._fromEmailAndCode(e,i.code,i.tenantId)}}Cl.PROVIDER_ID="password";Cl.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Cl.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ZC{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gu extends ZC{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tr extends Gu{constructor(){super("facebook.com")}static credential(e){return Ba._fromParams({providerId:Tr.PROVIDER_ID,signInMethod:Tr.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return Tr.credentialFromTaggedObject(e)}static credentialFromError(e){return Tr.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return Tr.credential(e.oauthAccessToken)}catch{return null}}}Tr.FACEBOOK_SIGN_IN_METHOD="facebook.com";Tr.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class br extends Gu{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Ba._fromParams({providerId:br.PROVIDER_ID,signInMethod:br.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return br.credentialFromTaggedObject(e)}static credentialFromError(e){return br.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:i}=e;if(!t&&!i)return null;try{return br.credential(t,i)}catch{return null}}}br.GOOGLE_SIGN_IN_METHOD="google.com";br.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wr extends Gu{constructor(){super("github.com")}static credential(e){return Ba._fromParams({providerId:wr.PROVIDER_ID,signInMethod:wr.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return wr.credentialFromTaggedObject(e)}static credentialFromError(e){return wr.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return wr.credential(e.oauthAccessToken)}catch{return null}}}wr.GITHUB_SIGN_IN_METHOD="github.com";wr.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sr extends Gu{constructor(){super("twitter.com")}static credential(e,t){return Ba._fromParams({providerId:Sr.PROVIDER_ID,signInMethod:Sr.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return Sr.credentialFromTaggedObject(e)}static credentialFromError(e){return Sr.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:i}=e;if(!t||!i)return null;try{return Sr.credential(t,i)}catch{return null}}}Sr.TWITTER_SIGN_IN_METHOD="twitter.com";Sr.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function nU(n,e){return Hu(n,"POST","/v1/accounts:signUp",Hr(n,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qa{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,i,a=!1){const l=await pi._fromIdTokenResponse(e,i,a),u=jw(i);return new qa({user:l,providerId:u,_tokenResponse:i,operationType:t})}static async _forOperation(e,t,i){await e._updateTokensIfNecessary(i,!0);const a=jw(i);return new qa({user:e,providerId:a,_tokenResponse:i,operationType:t})}}function jw(n){return n.providerId?n.providerId:"phoneNumber"in n?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ef extends oi{constructor(e,t,i,a){var l;super(t.code,t.message),this.operationType=i,this.user=a,Object.setPrototypeOf(this,Ef.prototype),this.customData={appName:e.name,tenantId:(l=e.tenantId)!==null&&l!==void 0?l:void 0,_serverResponse:t.customData._serverResponse,operationType:i}}static _fromErrorAndOperation(e,t,i,a){return new Ef(e,t,i,a)}}function JC(n,e,t,i){return(e==="reauthenticate"?t._getReauthenticationResolver(n):t._getIdTokenResponse(n)).catch(l=>{throw l.code==="auth/multi-factor-auth-required"?Ef._fromErrorAndOperation(n,l,e,i):l})}async function iU(n,e,t=!1){const i=await Au(n,e._linkToIdToken(n.auth,await n.getIdToken()),t);return qa._forOperation(n,"link",i)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sU(n,e,t=!1){const{auth:i}=n;if(Rn(i.app))return Promise.reject(Ds(i));const a="reauthenticate";try{const l=await Au(n,JC(i,a,e,n),t);Te(l.idToken,i,"internal-error");const u=Xy(l.idToken);Te(u,i,"internal-error");const{sub:d}=u;return Te(n.uid===d,i,"user-mismatch"),qa._forOperation(n,a,l)}catch(l){throw(l==null?void 0:l.code)==="auth/user-not-found"&&wi(i,"user-mismatch"),l}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ex(n,e,t=!1){if(Rn(n.app))return Promise.reject(Ds(n));const i="signIn",a=await JC(n,i,e),l=await qa._fromIdTokenResponse(n,i,a);return t||await n._updateCurrentUser(l.user),l}async function rU(n,e){return ex(Ja(n),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function tx(n){const e=Ja(n);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function aU(n,e,t){if(Rn(n.app))return Promise.reject(Ds(n));const i=Ja(n),u=await k_(i,{returnSecureToken:!0,email:e,password:t,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",nU).catch(m=>{throw m.code==="auth/password-does-not-meet-requirements"&&tx(n),m}),d=await qa._fromIdTokenResponse(i,"signIn",u);return await i._updateCurrentUser(d.user),d}function oU(n,e,t){return Rn(n.app)?Promise.reject(Ds(n)):rU(at(n),Cl.credential(e,t)).catch(async i=>{throw i.code==="auth/password-does-not-meet-requirements"&&tx(n),i})}function lU(n,e,t,i){return at(n).onIdTokenChanged(e,t,i)}function cU(n,e,t){return at(n).beforeAuthStateChanged(e,t)}function uU(n,e,t,i){return at(n).onAuthStateChanged(e,t,i)}function hU(n){return at(n).signOut()}const Tf="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nx{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Tf,"1"),this.storage.removeItem(Tf),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dU=1e3,fU=10;class ix extends nx{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=KC(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const i=this.storage.getItem(t),a=this.localCache[t];i!==a&&e(t,a,i)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((u,d,m)=>{this.notifyListeners(u,m)});return}const i=e.key;t?this.detachListener():this.stopPolling();const a=()=>{const u=this.storage.getItem(i);!t&&this.localCache[i]===u||this.notifyListeners(i,u)},l=this.storage.getItem(i);NV()&&l!==e.newValue&&e.newValue!==e.oldValue?setTimeout(a,fU):a()}notifyListeners(e,t){this.localCache[e]=t;const i=this.listeners[e];if(i)for(const a of Array.from(i))a(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,i)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:i}),!0)})},dU)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}ix.type="LOCAL";const mU=ix;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sx extends nx{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}sx.type="SESSION";const rx=sx;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pU(n){return Promise.all(n.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dm{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(a=>a.isListeningto(e));if(t)return t;const i=new dm(e);return this.receivers.push(i),i}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:i,eventType:a,data:l}=t.data,u=this.handlersMap[a];if(!(u!=null&&u.size))return;t.ports[0].postMessage({status:"ack",eventId:i,eventType:a});const d=Array.from(u).map(async p=>p(t.origin,l)),m=await pU(d);t.ports[0].postMessage({status:"done",eventId:i,eventType:a,response:m})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}dm.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tv(n="",e=10){let t="";for(let i=0;i<e;i++)t+=Math.floor(Math.random()*10);return n+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gU{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,i=50){const a=typeof MessageChannel<"u"?new MessageChannel:null;if(!a)throw new Error("connection_unavailable");let l,u;return new Promise((d,m)=>{const p=tv("",20);a.port1.start();const y=setTimeout(()=>{m(new Error("unsupported_event"))},i);u={messageChannel:a,onMessage(T){const w=T;if(w.data.eventId===p)switch(w.data.status){case"ack":clearTimeout(y),l=setTimeout(()=>{m(new Error("timeout"))},3e3);break;case"done":clearTimeout(l),d(w.data.response);break;default:clearTimeout(y),clearTimeout(l),m(new Error("invalid_response"));break}}},this.handlers.add(u),a.port1.addEventListener("message",u.onMessage),this.target.postMessage({eventType:e,eventId:p,data:t},[a.port2])}).finally(()=>{u&&this.removeMessageHandler(u)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $i(){return window}function _U(n){$i().location.href=n}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ax(){return typeof $i().WorkerGlobalScope<"u"&&typeof $i().importScripts=="function"}async function yU(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function vU(){var n;return((n=navigator==null?void 0:navigator.serviceWorker)===null||n===void 0?void 0:n.controller)||null}function EU(){return ax()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ox="firebaseLocalStorageDb",TU=1,bf="firebaseLocalStorage",lx="fbase_key";class $u{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function fm(n,e){return n.transaction([bf],e?"readwrite":"readonly").objectStore(bf)}function bU(){const n=indexedDB.deleteDatabase(ox);return new $u(n).toPromise()}function D_(){const n=indexedDB.open(ox,TU);return new Promise((e,t)=>{n.addEventListener("error",()=>{t(n.error)}),n.addEventListener("upgradeneeded",()=>{const i=n.result;try{i.createObjectStore(bf,{keyPath:lx})}catch(a){t(a)}}),n.addEventListener("success",async()=>{const i=n.result;i.objectStoreNames.contains(bf)?e(i):(i.close(),await bU(),e(await D_()))})})}async function zw(n,e,t){const i=fm(n,!0).put({[lx]:e,value:t});return new $u(i).toPromise()}async function wU(n,e){const t=fm(n,!1).get(e),i=await new $u(t).toPromise();return i===void 0?null:i.value}function Fw(n,e){const t=fm(n,!0).delete(e);return new $u(t).toPromise()}const SU=800,AU=3;class cx{constructor(){this.type="LOCAL",this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.db?this.db:(this.db=await D_(),this.db)}async _withRetries(e){let t=0;for(;;)try{const i=await this._openDb();return await e(i)}catch(i){if(t++>AU)throw i;this.db&&(this.db.close(),this.db=void 0)}}async initializeServiceWorkerMessaging(){return ax()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=dm._getInstance(EU()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var e,t;if(this.activeServiceWorker=await yU(),!this.activeServiceWorker)return;this.sender=new gU(this.activeServiceWorker);const i=await this.sender._send("ping",{},800);i&&!((e=i[0])===null||e===void 0)&&e.fulfilled&&!((t=i[0])===null||t===void 0)&&t.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||vU()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{if(!indexedDB)return!1;const e=await D_();return await zw(e,Tf,"1"),await Fw(e,Tf),!0}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(i=>zw(i,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(i=>wU(i,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Fw(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){const e=await this._withRetries(a=>{const l=fm(a,!1).getAll();return new $u(l).toPromise()});if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],i=new Set;if(e.length!==0)for(const{fbase_key:a,value:l}of e)i.add(a),JSON.stringify(this.localCache[a])!==JSON.stringify(l)&&(this.notifyListeners(a,l),t.push(a));for(const a of Object.keys(this.localCache))this.localCache[a]&&!i.has(a)&&(this.notifyListeners(a,null),t.push(a));return t}notifyListeners(e,t){this.localCache[e]=t;const i=this.listeners[e];if(i)for(const a of Array.from(i))a(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),SU)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&this.startPolling(),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&this.stopPolling()}}cx.type="LOCAL";const RU=cx;new qu(3e4,6e4);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function CU(n,e){return e?Cs(e):(Te(n._popupRedirectResolver,n,"argument-error"),n._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nv extends Jy{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return sl(e,this._buildIdpRequest())}_linkToIdToken(e,t){return sl(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return sl(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function xU(n){return ex(n.auth,new nv(n),n.bypassAuthState)}function IU(n){const{auth:e,user:t}=n;return Te(t,e,"internal-error"),sU(t,new nv(n),n.bypassAuthState)}async function NU(n){const{auth:e,user:t}=n;return Te(t,e,"internal-error"),iU(t,new nv(n),n.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ux{constructor(e,t,i,a,l=!1){this.auth=e,this.resolver=i,this.user=a,this.bypassAuthState=l,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(i){this.reject(i)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:i,postBody:a,tenantId:l,error:u,type:d}=e;if(u){this.reject(u);return}const m={auth:this.auth,requestUri:t,sessionId:i,tenantId:l||void 0,postBody:a||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(d)(m))}catch(p){this.reject(p)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return xU;case"linkViaPopup":case"linkViaRedirect":return NU;case"reauthViaPopup":case"reauthViaRedirect":return IU;default:wi(this.auth,"internal-error")}}resolve(e){js(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){js(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const kU=new qu(2e3,1e4);class Jo extends ux{constructor(e,t,i,a,l){super(e,t,a,l),this.provider=i,this.authWindow=null,this.pollId=null,Jo.currentPopupAction&&Jo.currentPopupAction.cancel(),Jo.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return Te(e,this.auth,"internal-error"),e}async onExecution(){js(this.filter.length===1,"Popup operations only handle one event");const e=tv();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(Gi(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)===null||e===void 0?void 0:e.associatedEvent)||null}cancel(){this.reject(Gi(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,Jo.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,i;if(!((i=(t=this.authWindow)===null||t===void 0?void 0:t.window)===null||i===void 0)&&i.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(Gi(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,kU.get())};e()}}Jo.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const DU="pendingRedirect",Yd=new Map;class OU extends ux{constructor(e,t,i=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,i),this.eventId=null}async execute(){let e=Yd.get(this.auth._key());if(!e){try{const i=await MU(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(i)}catch(t){e=()=>Promise.reject(t)}Yd.set(this.auth._key(),e)}return this.bypassAuthState||Yd.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function MU(n,e){const t=VU(e),i=LU(n);if(!await i._isAvailable())return!1;const a=await i._get(t)==="true";return await i._remove(t),a}function PU(n,e){Yd.set(n._key(),e)}function LU(n){return Cs(n._redirectPersistence)}function VU(n){return Qd(DU,n.config.apiKey,n.name)}async function UU(n,e,t=!1){if(Rn(n.app))return Promise.reject(Ds(n));const i=Ja(n),a=CU(i,e),u=await new OU(i,a,t).execute();return u&&!t&&(delete u.user._redirectEventId,await i._persistUserIfCurrent(u.user),await i._setRedirectUser(null,e)),u}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jU=10*60*1e3;class zU{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(i=>{this.isEventForConsumer(e,i)&&(t=!0,this.sendToConsumer(e,i),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!FU(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var i;if(e.error&&!hx(e)){const a=((i=e.error.code)===null||i===void 0?void 0:i.split("auth/")[1])||"internal-error";t.onError(Gi(this.auth,a))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const i=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&i}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=jU&&this.cachedEventUids.clear(),this.cachedEventUids.has(Bw(e))}saveEventToCache(e){this.cachedEventUids.add(Bw(e)),this.lastProcessedEventTime=Date.now()}}function Bw(n){return[n.type,n.eventId,n.sessionId,n.tenantId].filter(e=>e).join("-")}function hx({type:n,error:e}){return n==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function FU(n){switch(n.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return hx(n);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function BU(n,e={}){return Gr(n,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qU=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,HU=/^https?/;async function GU(n){if(n.config.emulator)return;const{authorizedDomains:e}=await BU(n);for(const t of e)try{if($U(t))return}catch{}wi(n,"unauthorized-domain")}function $U(n){const e=I_(),{protocol:t,hostname:i}=new URL(e);if(n.startsWith("chrome-extension://")){const u=new URL(n);return u.hostname===""&&i===""?t==="chrome-extension:"&&n.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&u.hostname===i}if(!HU.test(t))return!1;if(qU.test(n))return i===n;const a=n.replace(/\./g,"\\.");return new RegExp("^(.+\\."+a+"|"+a+")$","i").test(i)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const KU=new qu(3e4,6e4);function qw(){const n=$i().___jsl;if(n!=null&&n.H){for(const e of Object.keys(n.H))if(n.H[e].r=n.H[e].r||[],n.H[e].L=n.H[e].L||[],n.H[e].r=[...n.H[e].L],n.CP)for(let t=0;t<n.CP.length;t++)n.CP[t]=null}}function QU(n){return new Promise((e,t)=>{var i,a,l;function u(){qw(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{qw(),t(Gi(n,"network-request-failed"))},timeout:KU.get()})}if(!((a=(i=$i().gapi)===null||i===void 0?void 0:i.iframes)===null||a===void 0)&&a.Iframe)e(gapi.iframes.getContext());else if(!((l=$i().gapi)===null||l===void 0)&&l.load)u();else{const d=jV("iframefcb");return $i()[d]=()=>{gapi.load?u():t(Gi(n,"network-request-failed"))},YC(`${UV()}?onload=${d}`).catch(m=>t(m))}}).catch(e=>{throw Wd=null,e})}let Wd=null;function YU(n){return Wd=Wd||QU(n),Wd}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const WU=new qu(5e3,15e3),XU="__/auth/iframe",ZU="emulator/auth/iframe",JU={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},ej=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function tj(n){const e=n.config;Te(e.authDomain,n,"auth-domain-config-required");const t=e.emulator?Wy(e,ZU):`https://${n.config.authDomain}/${XU}`,i={apiKey:e.apiKey,appName:n.name,v:Fr},a=ej.get(n.config.apiHost);a&&(i.eid=a);const l=n._getFrameworks();return l.length&&(i.fw=l.join(",")),`${t}?${Tl(i).slice(1)}`}async function nj(n){const e=await YU(n),t=$i().gapi;return Te(t,n,"internal-error"),e.open({where:document.body,url:tj(n),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:JU,dontclear:!0},i=>new Promise(async(a,l)=>{await i.restyle({setHideOnLeave:!1});const u=Gi(n,"network-request-failed"),d=$i().setTimeout(()=>{l(u)},WU.get());function m(){$i().clearTimeout(d),a(i)}i.ping(m).then(m,()=>{l(u)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ij={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},sj=500,rj=600,aj="_blank",oj="http://localhost";class Hw{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function lj(n,e,t,i=sj,a=rj){const l=Math.max((window.screen.availHeight-a)/2,0).toString(),u=Math.max((window.screen.availWidth-i)/2,0).toString();let d="";const m=Object.assign(Object.assign({},ij),{width:i.toString(),height:a.toString(),top:l,left:u}),p=gn().toLowerCase();t&&(d=BC(p)?aj:t),zC(p)&&(e=e||oj,m.scrollbars="yes");const y=Object.entries(m).reduce((w,[x,I])=>`${w}${x}=${I},`,"");if(IV(p)&&d!=="_self")return cj(e||"",d),new Hw(null);const T=window.open(e||"",d,y);Te(T,n,"popup-blocked");try{T.focus()}catch{}return new Hw(T)}function cj(n,e){const t=document.createElement("a");t.href=n,t.target=e;const i=document.createEvent("MouseEvent");i.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(i)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uj="__/auth/handler",hj="emulator/auth/handler",dj=encodeURIComponent("fac");async function Gw(n,e,t,i,a,l){Te(n.config.authDomain,n,"auth-domain-config-required"),Te(n.config.apiKey,n,"invalid-api-key");const u={apiKey:n.config.apiKey,appName:n.name,authType:t,redirectUrl:i,v:Fr,eventId:a};if(e instanceof ZC){e.setDefaultLanguage(n.languageCode),u.providerId=e.providerId||"",n_(e.getCustomParameters())||(u.customParameters=JSON.stringify(e.getCustomParameters()));for(const[y,T]of Object.entries({}))u[y]=T}if(e instanceof Gu){const y=e.getScopes().filter(T=>T!=="");y.length>0&&(u.scopes=y.join(","))}n.tenantId&&(u.tid=n.tenantId);const d=u;for(const y of Object.keys(d))d[y]===void 0&&delete d[y];const m=await n._getAppCheckToken(),p=m?`#${dj}=${encodeURIComponent(m)}`:"";return`${fj(n)}?${Tl(d).slice(1)}${p}`}function fj({config:n}){return n.emulator?Wy(n,hj):`https://${n.authDomain}/${uj}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qg="webStorageSupport";class mj{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=rx,this._completeRedirectFn=UU,this._overrideRedirectResult=PU}async _openPopup(e,t,i,a){var l;js((l=this.eventManagers[e._key()])===null||l===void 0?void 0:l.manager,"_initialize() not called before _openPopup()");const u=await Gw(e,t,i,I_(),a);return lj(e,u,tv())}async _openRedirect(e,t,i,a){await this._originValidation(e);const l=await Gw(e,t,i,I_(),a);return _U(l),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:a,promise:l}=this.eventManagers[t];return a?Promise.resolve(a):(js(l,"If manager is not set, promise should be"),l)}const i=this.initAndGetManager(e);return this.eventManagers[t]={promise:i},i.catch(()=>{delete this.eventManagers[t]}),i}async initAndGetManager(e){const t=await nj(e),i=new zU(e);return t.register("authEvent",a=>(Te(a==null?void 0:a.authEvent,e,"invalid-auth-event"),{status:i.onEvent(a.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:i},this.iframes[e._key()]=t,i}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(qg,{type:qg},a=>{var l;const u=(l=a==null?void 0:a[0])===null||l===void 0?void 0:l[qg];u!==void 0&&t(!!u),wi(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=GU(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return KC()||FC()||Zy()}}const pj=mj;var $w="@firebase/auth",Kw="1.10.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gj{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)===null||e===void 0?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(i=>{e((i==null?void 0:i.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){Te(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _j(n){switch(n){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function yj(n){ri(new Hn("auth",(e,{options:t})=>{const i=e.getProvider("app").getImmediate(),a=e.getProvider("heartbeat"),l=e.getProvider("app-check-internal"),{apiKey:u,authDomain:d}=i.options;Te(u&&!u.includes(":"),"invalid-api-key",{appName:i.name});const m={apiKey:u,authDomain:d,clientPlatform:n,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:QC(n)},p=new PV(i,a,l,m);return GV(p,t),p},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,i)=>{e.getProvider("auth-internal").initialize()})),ri(new Hn("auth-internal",e=>{const t=Ja(e.getProvider("auth").getImmediate());return(i=>new gj(i))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),pn($w,Kw,_j(n)),pn($w,Kw,"esm2017")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vj=5*60,Ej=mA("authIdTokenMaxAge")||vj;let Qw=null;const Tj=n=>async e=>{const t=e&&await e.getIdTokenResult(),i=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(i&&i>Ej)return;const a=t==null?void 0:t.token;Qw!==a&&(Qw=a,await fetch(n,{method:a?"POST":"DELETE",headers:a?{Authorization:`Bearer ${a}`}:{}}))};function bj(n=Vu()){const e=qs(n,"auth");if(e.isInitialized())return e.getImmediate();const t=HV(n,{popupRedirectResolver:pj,persistence:[RU,mU,rx]}),i=mA("authTokenSyncURL");if(i&&typeof isSecureContext=="boolean"&&isSecureContext){const l=new URL(i,location.origin);if(location.origin===l.origin){const u=Tj(l.toString());cU(t,u,()=>u(t.currentUser)),lU(t,d=>u(d))}}const a=dA("auth");return a&&$V(t,`http://${a}`),t}function wj(){var n,e;return(e=(n=document.getElementsByTagName("head"))===null||n===void 0?void 0:n[0])!==null&&e!==void 0?e:document}LV({loadJS(n){return new Promise((e,t)=>{const i=document.createElement("script");i.setAttribute("src",n),i.onload=e,i.onerror=a=>{const l=Gi("internal-error");l.customData=a,t(l)},i.type="text/javascript",i.charset="UTF-8",wj().appendChild(i)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});yj("Browser");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dx="firebasestorage.googleapis.com",Sj="storageBucket",Aj=2*60*1e3,Rj=10*60*1e3;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xi extends oi{constructor(e,t,i=0){super(Hg(e),`Firebase Storage: ${t} (${Hg(e)})`),this.status_=i,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,Xi.prototype)}get status(){return this.status_}set status(e){this.status_=e}_codeEquals(e){return Hg(e)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=`${this._baseMessage}
${this.customData.serverResponse}`:this.message=this._baseMessage}}var Qi;(function(n){n.UNKNOWN="unknown",n.OBJECT_NOT_FOUND="object-not-found",n.BUCKET_NOT_FOUND="bucket-not-found",n.PROJECT_NOT_FOUND="project-not-found",n.QUOTA_EXCEEDED="quota-exceeded",n.UNAUTHENTICATED="unauthenticated",n.UNAUTHORIZED="unauthorized",n.UNAUTHORIZED_APP="unauthorized-app",n.RETRY_LIMIT_EXCEEDED="retry-limit-exceeded",n.INVALID_CHECKSUM="invalid-checksum",n.CANCELED="canceled",n.INVALID_EVENT_NAME="invalid-event-name",n.INVALID_URL="invalid-url",n.INVALID_DEFAULT_BUCKET="invalid-default-bucket",n.NO_DEFAULT_BUCKET="no-default-bucket",n.CANNOT_SLICE_BLOB="cannot-slice-blob",n.SERVER_FILE_WRONG_SIZE="server-file-wrong-size",n.NO_DOWNLOAD_URL="no-download-url",n.INVALID_ARGUMENT="invalid-argument",n.INVALID_ARGUMENT_COUNT="invalid-argument-count",n.APP_DELETED="app-deleted",n.INVALID_ROOT_OPERATION="invalid-root-operation",n.INVALID_FORMAT="invalid-format",n.INTERNAL_ERROR="internal-error",n.UNSUPPORTED_ENVIRONMENT="unsupported-environment"})(Qi||(Qi={}));function Hg(n){return"storage/"+n}function Cj(){const n="An unknown error occurred, please check the error payload for server response.";return new Xi(Qi.UNKNOWN,n)}function xj(){return new Xi(Qi.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.")}function Ij(){return new Xi(Qi.CANCELED,"User canceled the upload/download.")}function Nj(n){return new Xi(Qi.INVALID_URL,"Invalid URL '"+n+"'.")}function kj(n){return new Xi(Qi.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+n+"'.")}function Yw(n){return new Xi(Qi.INVALID_ARGUMENT,n)}function fx(){return new Xi(Qi.APP_DELETED,"The Firebase app was deleted.")}function Dj(n){return new Xi(Qi.INVALID_ROOT_OPERATION,"The operation '"+n+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gi{constructor(e,t){this.bucket=e,this.path_=t}get path(){return this.path_}get isRoot(){return this.path.length===0}fullServerUrl(){const e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)}bucketOnlyServerUrl(){return"/b/"+encodeURIComponent(this.bucket)+"/o"}static makeFromBucketSpec(e,t){let i;try{i=gi.makeFromUrl(e,t)}catch{return new gi(e,"")}if(i.path==="")return i;throw kj(e)}static makeFromUrl(e,t){let i=null;const a="([A-Za-z0-9.\\-_]+)";function l(W){W.path.charAt(W.path.length-1)==="/"&&(W.path_=W.path_.slice(0,-1))}const u="(/(.*))?$",d=new RegExp("^gs://"+a+u,"i"),m={bucket:1,path:3};function p(W){W.path_=decodeURIComponent(W.path)}const y="v[A-Za-z0-9_]+",T=t.replace(/[.]/g,"\\."),w="(/([^?#]*).*)?$",x=new RegExp(`^https?://${T}/${y}/b/${a}/o${w}`,"i"),I={bucket:1,path:3},O=t===dx?"(?:storage.googleapis.com|storage.cloud.google.com)":t,P="([^?#]*)",B=new RegExp(`^https?://${O}/${a}/${P}`,"i"),Y=[{regex:d,indices:m,postModify:l},{regex:x,indices:I,postModify:p},{regex:B,indices:{bucket:1,path:2},postModify:p}];for(let W=0;W<Y.length;W++){const re=Y[W],he=re.regex.exec(e);if(he){const M=he[re.indices.bucket];let A=he[re.indices.path];A||(A=""),i=new gi(M,A),re.postModify(i);break}}if(i==null)throw Nj(e);return i}}class Oj{constructor(e){this.promise_=Promise.reject(e)}getPromise(){return this.promise_}cancel(e=!1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Mj(n,e,t){let i=1,a=null,l=null,u=!1,d=0;function m(){return d===2}let p=!1;function y(...P){p||(p=!0,e.apply(null,P))}function T(P){a=setTimeout(()=>{a=null,n(x,m())},P)}function w(){l&&clearTimeout(l)}function x(P,...B){if(p){w();return}if(P){w(),y.call(null,P,...B);return}if(m()||u){w(),y.call(null,P,...B);return}i<64&&(i*=2);let Y;d===1?(d=2,Y=0):Y=(i+Math.random())*1e3,T(Y)}let I=!1;function O(P){I||(I=!0,w(),!p&&(a!==null?(P||(d=2),clearTimeout(a),T(0)):P||(d=1)))}return T(0),l=setTimeout(()=>{u=!0,O(!0)},t),O}function Pj(n){n(!1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Lj(n){return n!==void 0}function Ww(n,e,t,i){if(i<e)throw Yw(`Invalid value for '${n}'. Expected ${e} or greater.`);if(i>t)throw Yw(`Invalid value for '${n}'. Expected ${t} or less.`)}function Vj(n){const e=encodeURIComponent;let t="?";for(const i in n)if(n.hasOwnProperty(i)){const a=e(i)+"="+e(n[i]);t=t+a+"&"}return t=t.slice(0,-1),t}var wf;(function(n){n[n.NO_ERROR=0]="NO_ERROR",n[n.NETWORK_ERROR=1]="NETWORK_ERROR",n[n.ABORT=2]="ABORT"})(wf||(wf={}));/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uj(n,e){const t=n>=500&&n<600,a=[408,429].indexOf(n)!==-1,l=e.indexOf(n)!==-1;return t||a||l}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jj{constructor(e,t,i,a,l,u,d,m,p,y,T,w=!0){this.url_=e,this.method_=t,this.headers_=i,this.body_=a,this.successCodes_=l,this.additionalRetryCodes_=u,this.callback_=d,this.errorCallback_=m,this.timeout_=p,this.progressCallback_=y,this.connectionFactory_=T,this.retry=w,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise((x,I)=>{this.resolve_=x,this.reject_=I,this.start_()})}start_(){const e=(i,a)=>{if(a){i(!1,new Od(!1,null,!0));return}const l=this.connectionFactory_();this.pendingConnection_=l;const u=d=>{const m=d.loaded,p=d.lengthComputable?d.total:-1;this.progressCallback_!==null&&this.progressCallback_(m,p)};this.progressCallback_!==null&&l.addUploadProgressListener(u),l.send(this.url_,this.method_,this.body_,this.headers_).then(()=>{this.progressCallback_!==null&&l.removeUploadProgressListener(u),this.pendingConnection_=null;const d=l.getErrorCode()===wf.NO_ERROR,m=l.getStatus();if(!d||Uj(m,this.additionalRetryCodes_)&&this.retry){const y=l.getErrorCode()===wf.ABORT;i(!1,new Od(!1,null,y));return}const p=this.successCodes_.indexOf(m)!==-1;i(!0,new Od(p,l))})},t=(i,a)=>{const l=this.resolve_,u=this.reject_,d=a.connection;if(a.wasSuccessCode)try{const m=this.callback_(d,d.getResponse());Lj(m)?l(m):l()}catch(m){u(m)}else if(d!==null){const m=Cj();m.serverResponse=d.getErrorText(),this.errorCallback_?u(this.errorCallback_(d,m)):u(m)}else if(a.canceled){const m=this.appDelete_?fx():Ij();u(m)}else{const m=xj();u(m)}};this.canceled_?t(!1,new Od(!1,null,!0)):this.backoffId_=Mj(e,t,this.timeout_)}getPromise(){return this.promise_}cancel(e){this.canceled_=!0,this.appDelete_=e||!1,this.backoffId_!==null&&Pj(this.backoffId_),this.pendingConnection_!==null&&this.pendingConnection_.abort()}}class Od{constructor(e,t,i){this.wasSuccessCode=e,this.connection=t,this.canceled=!!i}}function zj(n,e){e!==null&&e.length>0&&(n.Authorization="Firebase "+e)}function Fj(n,e){n["X-Firebase-Storage-Version"]="webjs/"+(e??"AppManager")}function Bj(n,e){e&&(n["X-Firebase-GMPID"]=e)}function qj(n,e){e!==null&&(n["X-Firebase-AppCheck"]=e)}function Hj(n,e,t,i,a,l,u=!0){const d=Vj(n.urlParams),m=n.url+d,p=Object.assign({},n.headers);return Bj(p,e),zj(p,t),Fj(p,l),qj(p,i),new jj(m,n.method,p,n.body,n.successCodes,n.additionalRetryCodes,n.handler,n.errorHandler,n.timeout,n.progressCallback,a,u)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gj(n){if(n.length===0)return null;const e=n.lastIndexOf("/");return e===-1?"":n.slice(0,e)}function $j(n){const e=n.lastIndexOf("/",n.length-2);return e===-1?n:n.slice(e+1)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sf{constructor(e,t){this._service=e,t instanceof gi?this._location=t:this._location=gi.makeFromUrl(t,e.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(e,t){return new Sf(e,t)}get root(){const e=new gi(this._location.bucket,"");return this._newRef(this._service,e)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return $j(this._location.path)}get storage(){return this._service}get parent(){const e=Gj(this._location.path);if(e===null)return null;const t=new gi(this._location.bucket,e);return new Sf(this._service,t)}_throwIfRoot(e){if(this._location.path==="")throw Dj(e)}}function Xw(n,e){const t=e==null?void 0:e[Sj];return t==null?null:gi.makeFromBucketSpec(t,n)}function Kj(n,e,t,i={}){n.host=`${e}:${t}`,n._protocol="http";const{mockUserToken:a}=i;a&&(n._overrideAuthToken=typeof a=="string"?a:ty(a,n.app.options.projectId))}class Qj{constructor(e,t,i,a,l){this.app=e,this._authProvider=t,this._appCheckProvider=i,this._url=a,this._firebaseVersion=l,this._bucket=null,this._host=dx,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=Aj,this._maxUploadRetryTime=Rj,this._requests=new Set,a!=null?this._bucket=gi.makeFromBucketSpec(a,this._host):this._bucket=Xw(this._host,this.app.options)}get host(){return this._host}set host(e){this._host=e,this._url!=null?this._bucket=gi.makeFromBucketSpec(this._url,e):this._bucket=Xw(e,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(e){Ww("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(e){Ww("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;const e=this._authProvider.getImmediate({optional:!0});if(e){const t=await e.getToken();if(t!==null)return t.accessToken}return null}async _getAppCheckToken(){if(Rn(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=this._appCheckProvider.getImmediate({optional:!0});return e?(await e.getToken()).token:null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach(e=>e.cancel()),this._requests.clear()),Promise.resolve()}_makeStorageReference(e){return new Sf(this,e)}_makeRequest(e,t,i,a,l=!0){if(this._deleted)return new Oj(fx());{const u=Hj(e,this._appId,i,a,t,this._firebaseVersion,l);return this._requests.add(u),u.getPromise().then(()=>this._requests.delete(u),()=>this._requests.delete(u)),u}}async makeRequestWithTokens(e,t){const[i,a]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(e,t,i,a).getPromise()}}const Zw="@firebase/storage",Jw="0.13.7";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mx="storage";function Yj(n=Vu(),e){n=at(n);const i=qs(n,mx).getImmediate({identifier:e}),a=ey("storage");return a&&Wj(i,...a),i}function Wj(n,e,t,i={}){Kj(n,e,t,i)}function Xj(n,{instanceIdentifier:e}){const t=n.getProvider("app").getImmediate(),i=n.getProvider("auth-internal"),a=n.getProvider("app-check-internal");return new Qj(t,i,a,e,Fr)}function Zj(){ri(new Hn(mx,Xj,"PUBLIC").setMultipleInstances(!0)),pn(Zw,Jw,""),pn(Zw,Jw,"esm2017")}Zj();var eS={};const tS="@firebase/database",nS="1.0.14";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let px="";function Jj(n){px=n}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class e3{constructor(e){this.domStorage_=e,this.prefix_="firebase:"}set(e,t){t==null?this.domStorage_.removeItem(this.prefixedName_(e)):this.domStorage_.setItem(this.prefixedName_(e),Zt(t))}get(e){const t=this.domStorage_.getItem(this.prefixedName_(e));return t==null?null:pu(t)}remove(e){this.domStorage_.removeItem(this.prefixedName_(e))}prefixedName_(e){return this.prefix_+e}toString(){return this.domStorage_.toString()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class t3{constructor(){this.cache_={},this.isInMemoryStorage=!0}set(e,t){t==null?delete this.cache_[e]:this.cache_[e]=t}get(e){return Wi(this.cache_,e)?this.cache_[e]:null}remove(e){delete this.cache_[e]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const gx=function(n){try{if(typeof window<"u"&&typeof window[n]<"u"){const e=window[n];return e.setItem("firebase:sentinel","cache"),e.removeItem("firebase:sentinel"),new e3(e)}}catch{}return new t3},Ma=gx("localStorage"),n3=gx("sessionStorage");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rl=new Lu("@firebase/database"),i3=function(){let n=1;return function(){return n++}}(),_x=function(n){const e=gD(n),t=new dD;t.update(e);const i=t.digest();return J_.encodeByteArray(i)},Ku=function(...n){let e="";for(let t=0;t<n.length;t++){const i=n[t];Array.isArray(i)||i&&typeof i=="object"&&typeof i.length=="number"?e+=Ku.apply(null,i):typeof i=="object"?e+=Zt(i):e+=i,e+=" "}return e};let ou=null,iS=!0;const s3=function(n,e){oe(!0,"Can't turn on custom loggers persistently."),rl.logLevel=Ue.VERBOSE,ou=rl.log.bind(rl)},mn=function(...n){if(iS===!0&&(iS=!1,ou===null&&n3.get("logging_enabled")===!0&&s3()),ou){const e=Ku.apply(null,n);ou(e)}},Qu=function(n){return function(...e){mn(n,...e)}},O_=function(...n){const e="FIREBASE INTERNAL ERROR: "+Ku(...n);rl.error(e)},zs=function(...n){const e=`FIREBASE FATAL ERROR: ${Ku(...n)}`;throw rl.error(e),new Error(e)},kn=function(...n){const e="FIREBASE WARNING: "+Ku(...n);rl.warn(e)},r3=function(){typeof window<"u"&&window.location&&window.location.protocol&&window.location.protocol.indexOf("https:")!==-1&&kn("Insecure Firebase access from a secure page. Please use https in calls to new Firebase().")},iv=function(n){return typeof n=="number"&&(n!==n||n===Number.POSITIVE_INFINITY||n===Number.NEGATIVE_INFINITY)},a3=function(n){if(document.readyState==="complete")n();else{let e=!1;const t=function(){if(!document.body){setTimeout(t,Math.floor(10));return}e||(e=!0,n())};document.addEventListener?(document.addEventListener("DOMContentLoaded",t,!1),window.addEventListener("load",t,!1)):document.attachEvent&&(document.attachEvent("onreadystatechange",()=>{document.readyState==="complete"&&t()}),window.attachEvent("onload",t))}},Ha="[MIN_NAME]",Ur="[MAX_NAME]",xl=function(n,e){if(n===e)return 0;if(n===Ha||e===Ur)return-1;if(e===Ha||n===Ur)return 1;{const t=sS(n),i=sS(e);return t!==null?i!==null?t-i===0?n.length-e.length:t-i:-1:i!==null?1:n<e?-1:1}},o3=function(n,e){return n===e?0:n<e?-1:1},qc=function(n,e){if(e&&n in e)return e[n];throw new Error("Missing required key ("+n+") in object: "+Zt(e))},sv=function(n){if(typeof n!="object"||n===null)return Zt(n);const e=[];for(const i in n)e.push(i);e.sort();let t="{";for(let i=0;i<e.length;i++)i!==0&&(t+=","),t+=Zt(e[i]),t+=":",t+=sv(n[e[i]]);return t+="}",t},yx=function(n,e){const t=n.length;if(t<=e)return[n];const i=[];for(let a=0;a<t;a+=e)a+e>t?i.push(n.substring(a,t)):i.push(n.substring(a,a+e));return i};function Dn(n,e){for(const t in n)n.hasOwnProperty(t)&&e(t,n[t])}const vx=function(n){oe(!iv(n),"Invalid JSON number");const e=11,t=52,i=(1<<e-1)-1;let a,l,u,d,m;n===0?(l=0,u=0,a=1/n===-1/0?1:0):(a=n<0,n=Math.abs(n),n>=Math.pow(2,1-i)?(d=Math.min(Math.floor(Math.log(n)/Math.LN2),i),l=d+i,u=Math.round(n*Math.pow(2,t-d)-Math.pow(2,t))):(l=0,u=Math.round(n/Math.pow(2,1-i-t))));const p=[];for(m=t;m;m-=1)p.push(u%2?1:0),u=Math.floor(u/2);for(m=e;m;m-=1)p.push(l%2?1:0),l=Math.floor(l/2);p.push(a?1:0),p.reverse();const y=p.join("");let T="";for(m=0;m<64;m+=8){let w=parseInt(y.substr(m,8),2).toString(16);w.length===1&&(w="0"+w),T=T+w}return T.toLowerCase()},l3=function(){return!!(typeof window=="object"&&window.chrome&&window.chrome.extension&&!/^chrome/.test(window.location.href))},c3=function(){return typeof Windows=="object"&&typeof Windows.UI=="object"};function u3(n,e){let t="Unknown Error";n==="too_big"?t="The data requested exceeds the maximum size that can be accessed with a single request.":n==="permission_denied"?t="Client doesn't have permission to access the desired data.":n==="unavailable"&&(t="The service is unavailable");const i=new Error(n+" at "+e._path.toString()+": "+t);return i.code=n.toUpperCase(),i}const h3=new RegExp("^-?(0*)\\d{1,10}$"),d3=-2147483648,f3=2147483647,sS=function(n){if(h3.test(n)){const e=Number(n);if(e>=d3&&e<=f3)return e}return null},Il=function(n){try{n()}catch(e){setTimeout(()=>{const t=e.stack||"";throw kn("Exception was thrown by user callback.",t),e},Math.floor(0))}},m3=function(){return(typeof window=="object"&&window.navigator&&window.navigator.userAgent||"").search(/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0},lu=function(n,e){const t=setTimeout(n,e);return typeof t=="number"&&typeof Deno<"u"&&Deno.unrefTimer?Deno.unrefTimer(t):typeof t=="object"&&t.unref&&t.unref(),t};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p3{constructor(e,t){this.appCheckProvider=t,this.appName=e.name,Rn(e)&&e.settings.appCheckToken&&(this.serverAppAppCheckToken=e.settings.appCheckToken),this.appCheck=t==null?void 0:t.getImmediate({optional:!0}),this.appCheck||t==null||t.get().then(i=>this.appCheck=i)}getToken(e){if(this.serverAppAppCheckToken){if(e)throw new Error("Attempted reuse of `FirebaseServerApp.appCheckToken` after previous usage failed.");return Promise.resolve({token:this.serverAppAppCheckToken})}return this.appCheck?this.appCheck.getToken(e):new Promise((t,i)=>{setTimeout(()=>{this.appCheck?this.getToken(e).then(t,i):t(null)},0)})}addTokenChangeListener(e){var t;(t=this.appCheckProvider)===null||t===void 0||t.get().then(i=>i.addTokenListener(e))}notifyForInvalidToken(){kn(`Provided AppCheck credentials for the app named "${this.appName}" are invalid. This usually indicates your app was not initialized correctly.`)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class g3{constructor(e,t,i){this.appName_=e,this.firebaseOptions_=t,this.authProvider_=i,this.auth_=null,this.auth_=i.getImmediate({optional:!0}),this.auth_||i.onInit(a=>this.auth_=a)}getToken(e){return this.auth_?this.auth_.getToken(e).catch(t=>t&&t.code==="auth/token-not-initialized"?(mn("Got auth/token-not-initialized error.  Treating as null token."),null):Promise.reject(t)):new Promise((t,i)=>{setTimeout(()=>{this.auth_?this.getToken(e).then(t,i):t(null)},0)})}addTokenChangeListener(e){this.auth_?this.auth_.addAuthTokenListener(e):this.authProvider_.get().then(t=>t.addAuthTokenListener(e))}removeTokenChangeListener(e){this.authProvider_.get().then(t=>t.removeAuthTokenListener(e))}notifyForInvalidToken(){let e='Provided authentication credentials for the app named "'+this.appName_+'" are invalid. This usually indicates your app was not initialized correctly. ';"credential"in this.firebaseOptions_?e+='Make sure the "credential" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':"serviceAccount"in this.firebaseOptions_?e+='Make sure the "serviceAccount" property provided to initializeApp() is authorized to access the specified "databaseURL" and is from the correct project.':e+='Make sure the "apiKey" and "databaseURL" properties provided to initializeApp() match the values provided for your app at https://console.firebase.google.com/.',kn(e)}}class Xd{constructor(e){this.accessToken=e}getToken(e){return Promise.resolve({accessToken:this.accessToken})}addTokenChangeListener(e){e(this.accessToken)}removeTokenChangeListener(e){}notifyForInvalidToken(){}}Xd.OWNER="owner";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rv="5",Ex="v",Tx="s",bx="r",wx="f",Sx=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,Ax="ls",Rx="p",M_="ac",Cx="websocket",xx="long_polling";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ix{constructor(e,t,i,a,l=!1,u="",d=!1,m=!1,p=null){this.secure=t,this.namespace=i,this.webSocketOnly=a,this.nodeAdmin=l,this.persistenceKey=u,this.includeNamespaceInQueryParams=d,this.isUsingEmulator=m,this.emulatorOptions=p,this._host=e.toLowerCase(),this._domain=this._host.substr(this._host.indexOf(".")+1),this.internalHost=Ma.get("host:"+e)||this._host}isCacheableHost(){return this.internalHost.substr(0,2)==="s-"}isCustomHost(){return this._domain!=="firebaseio.com"&&this._domain!=="firebaseio-demo.com"}get host(){return this._host}set host(e){e!==this.internalHost&&(this.internalHost=e,this.isCacheableHost()&&Ma.set("host:"+this._host,this.internalHost))}toString(){let e=this.toURLString();return this.persistenceKey&&(e+="<"+this.persistenceKey+">"),e}toURLString(){const e=this.secure?"https://":"http://",t=this.includeNamespaceInQueryParams?`?ns=${this.namespace}`:"";return`${e}${this.host}/${t}`}}function _3(n){return n.host!==n.internalHost||n.isCustomHost()||n.includeNamespaceInQueryParams}function Nx(n,e,t){oe(typeof e=="string","typeof type must == string"),oe(typeof t=="object","typeof params must == object");let i;if(e===Cx)i=(n.secure?"wss://":"ws://")+n.internalHost+"/.ws?";else if(e===xx)i=(n.secure?"https://":"http://")+n.internalHost+"/.lp?";else throw new Error("Unknown connection type: "+e);_3(n)&&(t.ns=n.namespace);const a=[];return Dn(t,(l,u)=>{a.push(l+"="+u)}),i+a.join("&")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y3{constructor(){this.counters_={}}incrementCounter(e,t=1){Wi(this.counters_,e)||(this.counters_[e]=0),this.counters_[e]+=t}get(){return Yk(this.counters_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Gg={},$g={};function av(n){const e=n.toString();return Gg[e]||(Gg[e]=new y3),Gg[e]}function v3(n,e){const t=n.toString();return $g[t]||($g[t]=e()),$g[t]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class E3{constructor(e){this.onMessage_=e,this.pendingResponses=[],this.currentResponseNum=0,this.closeAfterResponse=-1,this.onClose=null}closeAfter(e,t){this.closeAfterResponse=e,this.onClose=t,this.closeAfterResponse<this.currentResponseNum&&(this.onClose(),this.onClose=null)}handleResponse(e,t){for(this.pendingResponses[e]=t;this.pendingResponses[this.currentResponseNum];){const i=this.pendingResponses[this.currentResponseNum];delete this.pendingResponses[this.currentResponseNum];for(let a=0;a<i.length;++a)i[a]&&Il(()=>{this.onMessage_(i[a])});if(this.currentResponseNum===this.closeAfterResponse){this.onClose&&(this.onClose(),this.onClose=null);break}this.currentResponseNum++}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rS="start",T3="close",b3="pLPCommand",w3="pRTLPCB",kx="id",Dx="pw",Ox="ser",S3="cb",A3="seg",R3="ts",C3="d",x3="dframe",Mx=1870,Px=30,I3=Mx-Px,N3=25e3,k3=3e4;class el{constructor(e,t,i,a,l,u,d){this.connId=e,this.repoInfo=t,this.applicationId=i,this.appCheckToken=a,this.authToken=l,this.transportSessionId=u,this.lastSessionId=d,this.bytesSent=0,this.bytesReceived=0,this.everConnected_=!1,this.log_=Qu(e),this.stats_=av(t),this.urlFn=m=>(this.appCheckToken&&(m[M_]=this.appCheckToken),Nx(t,xx,m))}open(e,t){this.curSegmentNum=0,this.onDisconnect_=t,this.myPacketOrderer=new E3(e),this.isClosed_=!1,this.connectTimeoutTimer_=setTimeout(()=>{this.log_("Timed out trying to connect."),this.onClosed_(),this.connectTimeoutTimer_=null},Math.floor(k3)),a3(()=>{if(this.isClosed_)return;this.scriptTagHolder=new ov((...l)=>{const[u,d,m,p,y]=l;if(this.incrementIncomingBytes_(l),!!this.scriptTagHolder)if(this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null),this.everConnected_=!0,u===rS)this.id=d,this.password=m;else if(u===T3)d?(this.scriptTagHolder.sendNewPolls=!1,this.myPacketOrderer.closeAfter(d,()=>{this.onClosed_()})):this.onClosed_();else throw new Error("Unrecognized command received: "+u)},(...l)=>{const[u,d]=l;this.incrementIncomingBytes_(l),this.myPacketOrderer.handleResponse(u,d)},()=>{this.onClosed_()},this.urlFn);const i={};i[rS]="t",i[Ox]=Math.floor(Math.random()*1e8),this.scriptTagHolder.uniqueCallbackIdentifier&&(i[S3]=this.scriptTagHolder.uniqueCallbackIdentifier),i[Ex]=rv,this.transportSessionId&&(i[Tx]=this.transportSessionId),this.lastSessionId&&(i[Ax]=this.lastSessionId),this.applicationId&&(i[Rx]=this.applicationId),this.appCheckToken&&(i[M_]=this.appCheckToken),typeof location<"u"&&location.hostname&&Sx.test(location.hostname)&&(i[bx]=wx);const a=this.urlFn(i);this.log_("Connecting via long-poll to "+a),this.scriptTagHolder.addTag(a,()=>{})})}start(){this.scriptTagHolder.startLongPoll(this.id,this.password),this.addDisconnectPingFrame(this.id,this.password)}static forceAllow(){el.forceAllow_=!0}static forceDisallow(){el.forceDisallow_=!0}static isAvailable(){return el.forceAllow_?!0:!el.forceDisallow_&&typeof document<"u"&&document.createElement!=null&&!l3()&&!c3()}markConnectionHealthy(){}shutdown_(){this.isClosed_=!0,this.scriptTagHolder&&(this.scriptTagHolder.close(),this.scriptTagHolder=null),this.myDisconnFrame&&(document.body.removeChild(this.myDisconnFrame),this.myDisconnFrame=null),this.connectTimeoutTimer_&&(clearTimeout(this.connectTimeoutTimer_),this.connectTimeoutTimer_=null)}onClosed_(){this.isClosed_||(this.log_("Longpoll is closing itself"),this.shutdown_(),this.onDisconnect_&&(this.onDisconnect_(this.everConnected_),this.onDisconnect_=null))}close(){this.isClosed_||(this.log_("Longpoll is being closed."),this.shutdown_())}send(e){const t=Zt(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const i=uA(t),a=yx(i,I3);for(let l=0;l<a.length;l++)this.scriptTagHolder.enqueueSegment(this.curSegmentNum,a.length,a[l]),this.curSegmentNum++}addDisconnectPingFrame(e,t){this.myDisconnFrame=document.createElement("iframe");const i={};i[x3]="t",i[kx]=e,i[Dx]=t,this.myDisconnFrame.src=this.urlFn(i),this.myDisconnFrame.style.display="none",document.body.appendChild(this.myDisconnFrame)}incrementIncomingBytes_(e){const t=Zt(e).length;this.bytesReceived+=t,this.stats_.incrementCounter("bytes_received",t)}}class ov{constructor(e,t,i,a){this.onDisconnect=i,this.urlFn=a,this.outstandingRequests=new Set,this.pendingSegs=[],this.currentSerial=Math.floor(Math.random()*1e8),this.sendNewPolls=!0;{this.uniqueCallbackIdentifier=i3(),window[b3+this.uniqueCallbackIdentifier]=e,window[w3+this.uniqueCallbackIdentifier]=t,this.myIFrame=ov.createIFrame_();let l="";this.myIFrame.src&&this.myIFrame.src.substr(0,11)==="javascript:"&&(l='<script>document.domain="'+document.domain+'";<\/script>');const u="<html><body>"+l+"</body></html>";try{this.myIFrame.doc.open(),this.myIFrame.doc.write(u),this.myIFrame.doc.close()}catch(d){mn("frame writing exception"),d.stack&&mn(d.stack),mn(d)}}}static createIFrame_(){const e=document.createElement("iframe");if(e.style.display="none",document.body){document.body.appendChild(e);try{e.contentWindow.document||mn("No IE domain setting required")}catch{const i=document.domain;e.src="javascript:void((function(){document.open();document.domain='"+i+"';document.close();})())"}}else throw"Document body has not initialized. Wait to initialize Firebase until after the document is ready.";return e.contentDocument?e.doc=e.contentDocument:e.contentWindow?e.doc=e.contentWindow.document:e.document&&(e.doc=e.document),e}close(){this.alive=!1,this.myIFrame&&(this.myIFrame.doc.body.textContent="",setTimeout(()=>{this.myIFrame!==null&&(document.body.removeChild(this.myIFrame),this.myIFrame=null)},Math.floor(0)));const e=this.onDisconnect;e&&(this.onDisconnect=null,e())}startLongPoll(e,t){for(this.myID=e,this.myPW=t,this.alive=!0;this.newRequest_(););}newRequest_(){if(this.alive&&this.sendNewPolls&&this.outstandingRequests.size<(this.pendingSegs.length>0?2:1)){this.currentSerial++;const e={};e[kx]=this.myID,e[Dx]=this.myPW,e[Ox]=this.currentSerial;let t=this.urlFn(e),i="",a=0;for(;this.pendingSegs.length>0&&this.pendingSegs[0].d.length+Px+i.length<=Mx;){const u=this.pendingSegs.shift();i=i+"&"+A3+a+"="+u.seg+"&"+R3+a+"="+u.ts+"&"+C3+a+"="+u.d,a++}return t=t+i,this.addLongPollTag_(t,this.currentSerial),!0}else return!1}enqueueSegment(e,t,i){this.pendingSegs.push({seg:e,ts:t,d:i}),this.alive&&this.newRequest_()}addLongPollTag_(e,t){this.outstandingRequests.add(t);const i=()=>{this.outstandingRequests.delete(t),this.newRequest_()},a=setTimeout(i,Math.floor(N3)),l=()=>{clearTimeout(a),i()};this.addTag(e,l)}addTag(e,t){setTimeout(()=>{try{if(!this.sendNewPolls)return;const i=this.myIFrame.doc.createElement("script");i.type="text/javascript",i.async=!0,i.src=e,i.onload=i.onreadystatechange=function(){const a=i.readyState;(!a||a==="loaded"||a==="complete")&&(i.onload=i.onreadystatechange=null,i.parentNode&&i.parentNode.removeChild(i),t())},i.onerror=()=>{mn("Long-poll script failed to load: "+e),this.sendNewPolls=!1,this.close()},this.myIFrame.doc.body.appendChild(i)}catch{}},Math.floor(1))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const D3=16384,O3=45e3;let Af=null;typeof MozWebSocket<"u"?Af=MozWebSocket:typeof WebSocket<"u"&&(Af=WebSocket);class mi{constructor(e,t,i,a,l,u,d){this.connId=e,this.applicationId=i,this.appCheckToken=a,this.authToken=l,this.keepaliveTimer=null,this.frames=null,this.totalFrames=0,this.bytesSent=0,this.bytesReceived=0,this.log_=Qu(this.connId),this.stats_=av(t),this.connURL=mi.connectionURL_(t,u,d,a,i),this.nodeAdmin=t.nodeAdmin}static connectionURL_(e,t,i,a,l){const u={};return u[Ex]=rv,typeof location<"u"&&location.hostname&&Sx.test(location.hostname)&&(u[bx]=wx),t&&(u[Tx]=t),i&&(u[Ax]=i),a&&(u[M_]=a),l&&(u[Rx]=l),Nx(e,Cx,u)}open(e,t){this.onDisconnect=t,this.onMessage=e,this.log_("Websocket connecting to "+this.connURL),this.everConnected_=!1,Ma.set("previous_websocket_failure",!0);try{let i;sD(),this.mySock=new Af(this.connURL,[],i)}catch(i){this.log_("Error instantiating WebSocket.");const a=i.message||i.data;a&&this.log_(a),this.onClosed_();return}this.mySock.onopen=()=>{this.log_("Websocket connected."),this.everConnected_=!0},this.mySock.onclose=()=>{this.log_("Websocket connection was disconnected."),this.mySock=null,this.onClosed_()},this.mySock.onmessage=i=>{this.handleIncomingFrame(i)},this.mySock.onerror=i=>{this.log_("WebSocket error.  Closing connection.");const a=i.message||i.data;a&&this.log_(a),this.onClosed_()}}start(){}static forceDisallow(){mi.forceDisallow_=!0}static isAvailable(){let e=!1;if(typeof navigator<"u"&&navigator.userAgent){const t=/Android ([0-9]{0,}\.[0-9]{0,})/,i=navigator.userAgent.match(t);i&&i.length>1&&parseFloat(i[1])<4.4&&(e=!0)}return!e&&Af!==null&&!mi.forceDisallow_}static previouslyFailed(){return Ma.isInMemoryStorage||Ma.get("previous_websocket_failure")===!0}markConnectionHealthy(){Ma.remove("previous_websocket_failure")}appendFrame_(e){if(this.frames.push(e),this.frames.length===this.totalFrames){const t=this.frames.join("");this.frames=null;const i=pu(t);this.onMessage(i)}}handleNewFrameCount_(e){this.totalFrames=e,this.frames=[]}extractFrameCount_(e){if(oe(this.frames===null,"We already have a frame buffer"),e.length<=6){const t=Number(e);if(!isNaN(t))return this.handleNewFrameCount_(t),null}return this.handleNewFrameCount_(1),e}handleIncomingFrame(e){if(this.mySock===null)return;const t=e.data;if(this.bytesReceived+=t.length,this.stats_.incrementCounter("bytes_received",t.length),this.resetKeepAlive(),this.frames!==null)this.appendFrame_(t);else{const i=this.extractFrameCount_(t);i!==null&&this.appendFrame_(i)}}send(e){this.resetKeepAlive();const t=Zt(e);this.bytesSent+=t.length,this.stats_.incrementCounter("bytes_sent",t.length);const i=yx(t,D3);i.length>1&&this.sendString_(String(i.length));for(let a=0;a<i.length;a++)this.sendString_(i[a])}shutdown_(){this.isClosed_=!0,this.keepaliveTimer&&(clearInterval(this.keepaliveTimer),this.keepaliveTimer=null),this.mySock&&(this.mySock.close(),this.mySock=null)}onClosed_(){this.isClosed_||(this.log_("WebSocket is closing itself"),this.shutdown_(),this.onDisconnect&&(this.onDisconnect(this.everConnected_),this.onDisconnect=null))}close(){this.isClosed_||(this.log_("WebSocket is being closed"),this.shutdown_())}resetKeepAlive(){clearInterval(this.keepaliveTimer),this.keepaliveTimer=setInterval(()=>{this.mySock&&this.sendString_("0"),this.resetKeepAlive()},Math.floor(O3))}sendString_(e){try{this.mySock.send(e)}catch(t){this.log_("Exception thrown from WebSocket.send():",t.message||t.data,"Closing connection."),setTimeout(this.onClosed_.bind(this),0)}}}mi.responsesRequiredToBeHealthy=2;mi.healthyTimeout=3e4;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cu{static get ALL_TRANSPORTS(){return[el,mi]}static get IS_TRANSPORT_INITIALIZED(){return this.globalTransportInitialized_}constructor(e){this.initTransports_(e)}initTransports_(e){const t=mi&&mi.isAvailable();let i=t&&!mi.previouslyFailed();if(e.webSocketOnly&&(t||kn("wss:// URL used, but browser isn't known to support websockets.  Trying anyway."),i=!0),i)this.transports_=[mi];else{const a=this.transports_=[];for(const l of Cu.ALL_TRANSPORTS)l&&l.isAvailable()&&a.push(l);Cu.globalTransportInitialized_=!0}}initialTransport(){if(this.transports_.length>0)return this.transports_[0];throw new Error("No transports available")}upgradeTransport(){return this.transports_.length>1?this.transports_[1]:null}}Cu.globalTransportInitialized_=!1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const M3=6e4,P3=5e3,L3=10*1024,V3=100*1024,Kg="t",aS="d",U3="s",oS="r",j3="e",lS="o",cS="a",uS="n",hS="p",z3="h";class F3{constructor(e,t,i,a,l,u,d,m,p,y){this.id=e,this.repoInfo_=t,this.applicationId_=i,this.appCheckToken_=a,this.authToken_=l,this.onMessage_=u,this.onReady_=d,this.onDisconnect_=m,this.onKill_=p,this.lastSessionId=y,this.connectionCount=0,this.pendingDataMessages=[],this.state_=0,this.log_=Qu("c:"+this.id+":"),this.transportManager_=new Cu(t),this.log_("Connection created"),this.start_()}start_(){const e=this.transportManager_.initialTransport();this.conn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,null,this.lastSessionId),this.primaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.conn_),i=this.disconnReceiver_(this.conn_);this.tx_=this.conn_,this.rx_=this.conn_,this.secondaryConn_=null,this.isHealthy_=!1,setTimeout(()=>{this.conn_&&this.conn_.open(t,i)},Math.floor(0));const a=e.healthyTimeout||0;a>0&&(this.healthyTimeout_=lu(()=>{this.healthyTimeout_=null,this.isHealthy_||(this.conn_&&this.conn_.bytesReceived>V3?(this.log_("Connection exceeded healthy timeout but has received "+this.conn_.bytesReceived+" bytes.  Marking connection healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()):this.conn_&&this.conn_.bytesSent>L3?this.log_("Connection exceeded healthy timeout but has sent "+this.conn_.bytesSent+" bytes.  Leaving connection alive."):(this.log_("Closing unhealthy connection after timeout."),this.close()))},Math.floor(a)))}nextTransportId_(){return"c:"+this.id+":"+this.connectionCount++}disconnReceiver_(e){return t=>{e===this.conn_?this.onConnectionLost_(t):e===this.secondaryConn_?(this.log_("Secondary connection lost."),this.onSecondaryConnectionLost_()):this.log_("closing an old connection")}}connReceiver_(e){return t=>{this.state_!==2&&(e===this.rx_?this.onPrimaryMessageReceived_(t):e===this.secondaryConn_?this.onSecondaryMessageReceived_(t):this.log_("message on old connection"))}}sendRequest(e){const t={t:"d",d:e};this.sendData_(t)}tryCleanupConnection(){this.tx_===this.secondaryConn_&&this.rx_===this.secondaryConn_&&(this.log_("cleaning up and promoting a connection: "+this.secondaryConn_.connId),this.conn_=this.secondaryConn_,this.secondaryConn_=null)}onSecondaryControl_(e){if(Kg in e){const t=e[Kg];t===cS?this.upgradeIfSecondaryHealthy_():t===oS?(this.log_("Got a reset on secondary, closing it"),this.secondaryConn_.close(),(this.tx_===this.secondaryConn_||this.rx_===this.secondaryConn_)&&this.close()):t===lS&&(this.log_("got pong on secondary."),this.secondaryResponsesRequired_--,this.upgradeIfSecondaryHealthy_())}}onSecondaryMessageReceived_(e){const t=qc("t",e),i=qc("d",e);if(t==="c")this.onSecondaryControl_(i);else if(t==="d")this.pendingDataMessages.push(i);else throw new Error("Unknown protocol layer: "+t)}upgradeIfSecondaryHealthy_(){this.secondaryResponsesRequired_<=0?(this.log_("Secondary connection is healthy."),this.isHealthy_=!0,this.secondaryConn_.markConnectionHealthy(),this.proceedWithUpgrade_()):(this.log_("sending ping on secondary."),this.secondaryConn_.send({t:"c",d:{t:hS,d:{}}}))}proceedWithUpgrade_(){this.secondaryConn_.start(),this.log_("sending client ack on secondary"),this.secondaryConn_.send({t:"c",d:{t:cS,d:{}}}),this.log_("Ending transmission on primary"),this.conn_.send({t:"c",d:{t:uS,d:{}}}),this.tx_=this.secondaryConn_,this.tryCleanupConnection()}onPrimaryMessageReceived_(e){const t=qc("t",e),i=qc("d",e);t==="c"?this.onControl_(i):t==="d"&&this.onDataMessage_(i)}onDataMessage_(e){this.onPrimaryResponse_(),this.onMessage_(e)}onPrimaryResponse_(){this.isHealthy_||(this.primaryResponsesRequired_--,this.primaryResponsesRequired_<=0&&(this.log_("Primary connection is healthy."),this.isHealthy_=!0,this.conn_.markConnectionHealthy()))}onControl_(e){const t=qc(Kg,e);if(aS in e){const i=e[aS];if(t===z3){const a=Object.assign({},i);this.repoInfo_.isUsingEmulator&&(a.h=this.repoInfo_.host),this.onHandshake_(a)}else if(t===uS){this.log_("recvd end transmission on primary"),this.rx_=this.secondaryConn_;for(let a=0;a<this.pendingDataMessages.length;++a)this.onDataMessage_(this.pendingDataMessages[a]);this.pendingDataMessages=[],this.tryCleanupConnection()}else t===U3?this.onConnectionShutdown_(i):t===oS?this.onReset_(i):t===j3?O_("Server Error: "+i):t===lS?(this.log_("got pong on primary."),this.onPrimaryResponse_(),this.sendPingOnPrimaryIfNecessary_()):O_("Unknown control packet command: "+t)}}onHandshake_(e){const t=e.ts,i=e.v,a=e.h;this.sessionId=e.s,this.repoInfo_.host=a,this.state_===0&&(this.conn_.start(),this.onConnectionEstablished_(this.conn_,t),rv!==i&&kn("Protocol version mismatch detected"),this.tryStartUpgrade_())}tryStartUpgrade_(){const e=this.transportManager_.upgradeTransport();e&&this.startUpgrade_(e)}startUpgrade_(e){this.secondaryConn_=new e(this.nextTransportId_(),this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,this.sessionId),this.secondaryResponsesRequired_=e.responsesRequiredToBeHealthy||0;const t=this.connReceiver_(this.secondaryConn_),i=this.disconnReceiver_(this.secondaryConn_);this.secondaryConn_.open(t,i),lu(()=>{this.secondaryConn_&&(this.log_("Timed out trying to upgrade."),this.secondaryConn_.close())},Math.floor(M3))}onReset_(e){this.log_("Reset packet received.  New host: "+e),this.repoInfo_.host=e,this.state_===1?this.close():(this.closeConnections_(),this.start_())}onConnectionEstablished_(e,t){this.log_("Realtime connection established."),this.conn_=e,this.state_=1,this.onReady_&&(this.onReady_(t,this.sessionId),this.onReady_=null),this.primaryResponsesRequired_===0?(this.log_("Primary connection is healthy."),this.isHealthy_=!0):lu(()=>{this.sendPingOnPrimaryIfNecessary_()},Math.floor(P3))}sendPingOnPrimaryIfNecessary_(){!this.isHealthy_&&this.state_===1&&(this.log_("sending ping on primary."),this.sendData_({t:"c",d:{t:hS,d:{}}}))}onSecondaryConnectionLost_(){const e=this.secondaryConn_;this.secondaryConn_=null,(this.tx_===e||this.rx_===e)&&this.close()}onConnectionLost_(e){this.conn_=null,!e&&this.state_===0?(this.log_("Realtime connection failed."),this.repoInfo_.isCacheableHost()&&(Ma.remove("host:"+this.repoInfo_.host),this.repoInfo_.internalHost=this.repoInfo_.host)):this.state_===1&&this.log_("Realtime connection lost."),this.close()}onConnectionShutdown_(e){this.log_("Connection shutdown command received. Shutting down..."),this.onKill_&&(this.onKill_(e),this.onKill_=null),this.onDisconnect_=null,this.close()}sendData_(e){if(this.state_!==1)throw"Connection is not connected";this.tx_.send(e)}close(){this.state_!==2&&(this.log_("Closing realtime connection."),this.state_=2,this.closeConnections_(),this.onDisconnect_&&(this.onDisconnect_(),this.onDisconnect_=null))}closeConnections_(){this.log_("Shutting down all connections"),this.conn_&&(this.conn_.close(),this.conn_=null),this.secondaryConn_&&(this.secondaryConn_.close(),this.secondaryConn_=null),this.healthyTimeout_&&(clearTimeout(this.healthyTimeout_),this.healthyTimeout_=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lx{put(e,t,i,a){}merge(e,t,i,a){}refreshAuthToken(e){}refreshAppCheckToken(e){}onDisconnectPut(e,t,i){}onDisconnectMerge(e,t,i){}onDisconnectCancel(e,t){}reportStats(e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vx{constructor(e){this.allowedEvents_=e,this.listeners_={},oe(Array.isArray(e)&&e.length>0,"Requires a non-empty array")}trigger(e,...t){if(Array.isArray(this.listeners_[e])){const i=[...this.listeners_[e]];for(let a=0;a<i.length;a++)i[a].callback.apply(i[a].context,t)}}on(e,t,i){this.validateEventType_(e),this.listeners_[e]=this.listeners_[e]||[],this.listeners_[e].push({callback:t,context:i});const a=this.getInitialEvent(e);a&&t.apply(i,a)}off(e,t,i){this.validateEventType_(e);const a=this.listeners_[e]||[];for(let l=0;l<a.length;l++)if(a[l].callback===t&&(!i||i===a[l].context)){a.splice(l,1);return}}validateEventType_(e){oe(this.allowedEvents_.find(t=>t===e),"Unknown event: "+e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rf extends Vx{static getInstance(){return new Rf}constructor(){super(["online"]),this.online_=!0,typeof window<"u"&&typeof window.addEventListener<"u"&&!ny()&&(window.addEventListener("online",()=>{this.online_||(this.online_=!0,this.trigger("online",!0))},!1),window.addEventListener("offline",()=>{this.online_&&(this.online_=!1,this.trigger("online",!1))},!1))}getInitialEvent(e){return oe(e==="online","Unknown event type: "+e),[this.online_]}currentlyOnline(){return this.online_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dS=32,fS=768;class ot{constructor(e,t){if(t===void 0){this.pieces_=e.split("/");let i=0;for(let a=0;a<this.pieces_.length;a++)this.pieces_[a].length>0&&(this.pieces_[i]=this.pieces_[a],i++);this.pieces_.length=i,this.pieceNum_=0}else this.pieces_=e,this.pieceNum_=t}toString(){let e="";for(let t=this.pieceNum_;t<this.pieces_.length;t++)this.pieces_[t]!==""&&(e+="/"+this.pieces_[t]);return e||"/"}}function Ye(){return new ot("")}function Oe(n){return n.pieceNum_>=n.pieces_.length?null:n.pieces_[n.pieceNum_]}function jr(n){return n.pieces_.length-n.pieceNum_}function ht(n){let e=n.pieceNum_;return e<n.pieces_.length&&e++,new ot(n.pieces_,e)}function Ux(n){return n.pieceNum_<n.pieces_.length?n.pieces_[n.pieces_.length-1]:null}function B3(n){let e="";for(let t=n.pieceNum_;t<n.pieces_.length;t++)n.pieces_[t]!==""&&(e+="/"+encodeURIComponent(String(n.pieces_[t])));return e||"/"}function jx(n,e=0){return n.pieces_.slice(n.pieceNum_+e)}function zx(n){if(n.pieceNum_>=n.pieces_.length)return null;const e=[];for(let t=n.pieceNum_;t<n.pieces_.length-1;t++)e.push(n.pieces_[t]);return new ot(e,0)}function zt(n,e){const t=[];for(let i=n.pieceNum_;i<n.pieces_.length;i++)t.push(n.pieces_[i]);if(e instanceof ot)for(let i=e.pieceNum_;i<e.pieces_.length;i++)t.push(e.pieces_[i]);else{const i=e.split("/");for(let a=0;a<i.length;a++)i[a].length>0&&t.push(i[a])}return new ot(t,0)}function Me(n){return n.pieceNum_>=n.pieces_.length}function xn(n,e){const t=Oe(n),i=Oe(e);if(t===null)return e;if(t===i)return xn(ht(n),ht(e));throw new Error("INTERNAL ERROR: innerPath ("+e+") is not within outerPath ("+n+")")}function lv(n,e){if(jr(n)!==jr(e))return!1;for(let t=n.pieceNum_,i=e.pieceNum_;t<=n.pieces_.length;t++,i++)if(n.pieces_[t]!==e.pieces_[i])return!1;return!0}function _i(n,e){let t=n.pieceNum_,i=e.pieceNum_;if(jr(n)>jr(e))return!1;for(;t<n.pieces_.length;){if(n.pieces_[t]!==e.pieces_[i])return!1;++t,++i}return!0}class q3{constructor(e,t){this.errorPrefix_=t,this.parts_=jx(e,0),this.byteLength_=Math.max(1,this.parts_.length);for(let i=0;i<this.parts_.length;i++)this.byteLength_+=Hf(this.parts_[i]);Fx(this)}}function H3(n,e){n.parts_.length>0&&(n.byteLength_+=1),n.parts_.push(e),n.byteLength_+=Hf(e),Fx(n)}function G3(n){const e=n.parts_.pop();n.byteLength_-=Hf(e),n.parts_.length>0&&(n.byteLength_-=1)}function Fx(n){if(n.byteLength_>fS)throw new Error(n.errorPrefix_+"has a key path longer than "+fS+" bytes ("+n.byteLength_+").");if(n.parts_.length>dS)throw new Error(n.errorPrefix_+"path specified exceeds the maximum depth that can be written ("+dS+") or object contains a cycle "+ka(n))}function ka(n){return n.parts_.length===0?"":"in property '"+n.parts_.join(".")+"'"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cv extends Vx{static getInstance(){return new cv}constructor(){super(["visible"]);let e,t;typeof document<"u"&&typeof document.addEventListener<"u"&&(typeof document.hidden<"u"?(t="visibilitychange",e="hidden"):typeof document.mozHidden<"u"?(t="mozvisibilitychange",e="mozHidden"):typeof document.msHidden<"u"?(t="msvisibilitychange",e="msHidden"):typeof document.webkitHidden<"u"&&(t="webkitvisibilitychange",e="webkitHidden")),this.visible_=!0,t&&document.addEventListener(t,()=>{const i=!document[e];i!==this.visible_&&(this.visible_=i,this.trigger("visible",i))},!1)}getInitialEvent(e){return oe(e==="visible","Unknown event type: "+e),[this.visible_]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hc=1e3,$3=60*5*1e3,mS=30*1e3,K3=1.3,Q3=3e4,Y3="server_kill",pS=3;class Os extends Lx{constructor(e,t,i,a,l,u,d,m){if(super(),this.repoInfo_=e,this.applicationId_=t,this.onDataUpdate_=i,this.onConnectStatus_=a,this.onServerInfoUpdate_=l,this.authTokenProvider_=u,this.appCheckTokenProvider_=d,this.authOverride_=m,this.id=Os.nextPersistentConnectionId_++,this.log_=Qu("p:"+this.id+":"),this.interruptReasons_={},this.listens=new Map,this.outstandingPuts_=[],this.outstandingGets_=[],this.outstandingPutCount_=0,this.outstandingGetCount_=0,this.onDisconnectRequestQueue_=[],this.connected_=!1,this.reconnectDelay_=Hc,this.maxReconnectDelay_=$3,this.securityDebugCallback_=null,this.lastSessionId=null,this.establishConnectionTimer_=null,this.visible_=!1,this.requestCBHash_={},this.requestNumber_=0,this.realtime_=null,this.authToken_=null,this.appCheckToken_=null,this.forceTokenRefresh_=!1,this.invalidAuthTokenCount_=0,this.invalidAppCheckTokenCount_=0,this.firstConnection_=!0,this.lastConnectionAttemptTime_=null,this.lastConnectionEstablishedTime_=null,m)throw new Error("Auth override specified in options, but not supported on non Node.js platforms");cv.getInstance().on("visible",this.onVisible_,this),e.host.indexOf("fblocal")===-1&&Rf.getInstance().on("online",this.onOnline_,this)}sendRequest(e,t,i){const a=++this.requestNumber_,l={r:a,a:e,b:t};this.log_(Zt(l)),oe(this.connected_,"sendRequest call when we're not connected not allowed."),this.realtime_.sendRequest(l),i&&(this.requestCBHash_[a]=i)}get(e){this.initConnection_();const t=new qf,a={action:"g",request:{p:e._path.toString(),q:e._queryObject},onComplete:u=>{const d=u.d;u.s==="ok"?t.resolve(d):t.reject(d)}};this.outstandingGets_.push(a),this.outstandingGetCount_++;const l=this.outstandingGets_.length-1;return this.connected_&&this.sendGet_(l),t.promise}listen(e,t,i,a){this.initConnection_();const l=e._queryIdentifier,u=e._path.toString();this.log_("Listen called for "+u+" "+l),this.listens.has(u)||this.listens.set(u,new Map),oe(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"listen() called for non-default but complete query"),oe(!this.listens.get(u).has(l),"listen() called twice for same path/queryId.");const d={onComplete:a,hashFn:t,query:e,tag:i};this.listens.get(u).set(l,d),this.connected_&&this.sendListen_(d)}sendGet_(e){const t=this.outstandingGets_[e];this.sendRequest("g",t.request,i=>{delete this.outstandingGets_[e],this.outstandingGetCount_--,this.outstandingGetCount_===0&&(this.outstandingGets_=[]),t.onComplete&&t.onComplete(i)})}sendListen_(e){const t=e.query,i=t._path.toString(),a=t._queryIdentifier;this.log_("Listen on "+i+" for "+a);const l={p:i},u="q";e.tag&&(l.q=t._queryObject,l.t=e.tag),l.h=e.hashFn(),this.sendRequest(u,l,d=>{const m=d.d,p=d.s;Os.warnOnListenWarnings_(m,t),(this.listens.get(i)&&this.listens.get(i).get(a))===e&&(this.log_("listen response",d),p!=="ok"&&this.removeListen_(i,a),e.onComplete&&e.onComplete(p,m))})}static warnOnListenWarnings_(e,t){if(e&&typeof e=="object"&&Wi(e,"w")){const i=ol(e,"w");if(Array.isArray(i)&&~i.indexOf("no_index")){const a='".indexOn": "'+t._queryParams.getIndex().toString()+'"',l=t._path.toString();kn(`Using an unspecified index. Your data will be downloaded and filtered on the client. Consider adding ${a} at ${l} to your security rules for better performance.`)}}}refreshAuthToken(e){this.authToken_=e,this.log_("Auth token refreshed"),this.authToken_?this.tryAuth():this.connected_&&this.sendRequest("unauth",{},()=>{}),this.reduceReconnectDelayIfAdminCredential_(e)}reduceReconnectDelayIfAdminCredential_(e){(e&&e.length===40||hD(e))&&(this.log_("Admin auth credential detected.  Reducing max reconnect time."),this.maxReconnectDelay_=mS)}refreshAppCheckToken(e){this.appCheckToken_=e,this.log_("App check token refreshed"),this.appCheckToken_?this.tryAppCheck():this.connected_&&this.sendRequest("unappeck",{},()=>{})}tryAuth(){if(this.connected_&&this.authToken_){const e=this.authToken_,t=uD(e)?"auth":"gauth",i={cred:e};this.authOverride_===null?i.noauth=!0:typeof this.authOverride_=="object"&&(i.authvar=this.authOverride_),this.sendRequest(t,i,a=>{const l=a.s,u=a.d||"error";this.authToken_===e&&(l==="ok"?this.invalidAuthTokenCount_=0:this.onAuthRevoked_(l,u))})}}tryAppCheck(){this.connected_&&this.appCheckToken_&&this.sendRequest("appcheck",{token:this.appCheckToken_},e=>{const t=e.s,i=e.d||"error";t==="ok"?this.invalidAppCheckTokenCount_=0:this.onAppCheckRevoked_(t,i)})}unlisten(e,t){const i=e._path.toString(),a=e._queryIdentifier;this.log_("Unlisten called for "+i+" "+a),oe(e._queryParams.isDefault()||!e._queryParams.loadsAllData(),"unlisten() called for non-default but complete query"),this.removeListen_(i,a)&&this.connected_&&this.sendUnlisten_(i,a,e._queryObject,t)}sendUnlisten_(e,t,i,a){this.log_("Unlisten on "+e+" for "+t);const l={p:e},u="n";a&&(l.q=i,l.t=a),this.sendRequest(u,l)}onDisconnectPut(e,t,i){this.initConnection_(),this.connected_?this.sendOnDisconnect_("o",e,t,i):this.onDisconnectRequestQueue_.push({pathString:e,action:"o",data:t,onComplete:i})}onDisconnectMerge(e,t,i){this.initConnection_(),this.connected_?this.sendOnDisconnect_("om",e,t,i):this.onDisconnectRequestQueue_.push({pathString:e,action:"om",data:t,onComplete:i})}onDisconnectCancel(e,t){this.initConnection_(),this.connected_?this.sendOnDisconnect_("oc",e,null,t):this.onDisconnectRequestQueue_.push({pathString:e,action:"oc",data:null,onComplete:t})}sendOnDisconnect_(e,t,i,a){const l={p:t,d:i};this.log_("onDisconnect "+e,l),this.sendRequest(e,l,u=>{a&&setTimeout(()=>{a(u.s,u.d)},Math.floor(0))})}put(e,t,i,a){this.putInternal("p",e,t,i,a)}merge(e,t,i,a){this.putInternal("m",e,t,i,a)}putInternal(e,t,i,a,l){this.initConnection_();const u={p:t,d:i};l!==void 0&&(u.h=l),this.outstandingPuts_.push({action:e,request:u,onComplete:a}),this.outstandingPutCount_++;const d=this.outstandingPuts_.length-1;this.connected_?this.sendPut_(d):this.log_("Buffering put: "+t)}sendPut_(e){const t=this.outstandingPuts_[e].action,i=this.outstandingPuts_[e].request,a=this.outstandingPuts_[e].onComplete;this.outstandingPuts_[e].queued=this.connected_,this.sendRequest(t,i,l=>{this.log_(t+" response",l),delete this.outstandingPuts_[e],this.outstandingPutCount_--,this.outstandingPutCount_===0&&(this.outstandingPuts_=[]),a&&a(l.s,l.d)})}reportStats(e){if(this.connected_){const t={c:e};this.log_("reportStats",t),this.sendRequest("s",t,i=>{if(i.s!=="ok"){const l=i.d;this.log_("reportStats","Error sending stats: "+l)}})}}onDataMessage_(e){if("r"in e){this.log_("from server: "+Zt(e));const t=e.r,i=this.requestCBHash_[t];i&&(delete this.requestCBHash_[t],i(e.b))}else{if("error"in e)throw"A server-side error has occurred: "+e.error;"a"in e&&this.onDataPush_(e.a,e.b)}}onDataPush_(e,t){this.log_("handleServerMessage",e,t),e==="d"?this.onDataUpdate_(t.p,t.d,!1,t.t):e==="m"?this.onDataUpdate_(t.p,t.d,!0,t.t):e==="c"?this.onListenRevoked_(t.p,t.q):e==="ac"?this.onAuthRevoked_(t.s,t.d):e==="apc"?this.onAppCheckRevoked_(t.s,t.d):e==="sd"?this.onSecurityDebugPacket_(t):O_("Unrecognized action received from server: "+Zt(e)+`
Are you using the latest client?`)}onReady_(e,t){this.log_("connection ready"),this.connected_=!0,this.lastConnectionEstablishedTime_=new Date().getTime(),this.handleTimestamp_(e),this.lastSessionId=t,this.firstConnection_&&this.sendConnectStats_(),this.restoreState_(),this.firstConnection_=!1,this.onConnectStatus_(!0)}scheduleConnect_(e){oe(!this.realtime_,"Scheduling a connect when we're already connected/ing?"),this.establishConnectionTimer_&&clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=setTimeout(()=>{this.establishConnectionTimer_=null,this.establishConnection_()},Math.floor(e))}initConnection_(){!this.realtime_&&this.firstConnection_&&this.scheduleConnect_(0)}onVisible_(e){e&&!this.visible_&&this.reconnectDelay_===this.maxReconnectDelay_&&(this.log_("Window became visible.  Reducing delay."),this.reconnectDelay_=Hc,this.realtime_||this.scheduleConnect_(0)),this.visible_=e}onOnline_(e){e?(this.log_("Browser went online."),this.reconnectDelay_=Hc,this.realtime_||this.scheduleConnect_(0)):(this.log_("Browser went offline.  Killing connection."),this.realtime_&&this.realtime_.close())}onRealtimeDisconnect_(){if(this.log_("data client disconnected"),this.connected_=!1,this.realtime_=null,this.cancelSentTransactions_(),this.requestCBHash_={},this.shouldReconnect_()){this.visible_?this.lastConnectionEstablishedTime_&&(new Date().getTime()-this.lastConnectionEstablishedTime_>Q3&&(this.reconnectDelay_=Hc),this.lastConnectionEstablishedTime_=null):(this.log_("Window isn't visible.  Delaying reconnect."),this.reconnectDelay_=this.maxReconnectDelay_,this.lastConnectionAttemptTime_=new Date().getTime());const e=Math.max(0,new Date().getTime()-this.lastConnectionAttemptTime_);let t=Math.max(0,this.reconnectDelay_-e);t=Math.random()*t,this.log_("Trying to reconnect in "+t+"ms"),this.scheduleConnect_(t),this.reconnectDelay_=Math.min(this.maxReconnectDelay_,this.reconnectDelay_*K3)}this.onConnectStatus_(!1)}async establishConnection_(){if(this.shouldReconnect_()){this.log_("Making a connection attempt"),this.lastConnectionAttemptTime_=new Date().getTime(),this.lastConnectionEstablishedTime_=null;const e=this.onDataMessage_.bind(this),t=this.onReady_.bind(this),i=this.onRealtimeDisconnect_.bind(this),a=this.id+":"+Os.nextConnectionId_++,l=this.lastSessionId;let u=!1,d=null;const m=function(){d?d.close():(u=!0,i())},p=function(T){oe(d,"sendRequest call when we're not connected not allowed."),d.sendRequest(T)};this.realtime_={close:m,sendRequest:p};const y=this.forceTokenRefresh_;this.forceTokenRefresh_=!1;try{const[T,w]=await Promise.all([this.authTokenProvider_.getToken(y),this.appCheckTokenProvider_.getToken(y)]);u?mn("getToken() completed but was canceled"):(mn("getToken() completed. Creating connection."),this.authToken_=T&&T.accessToken,this.appCheckToken_=w&&w.token,d=new F3(a,this.repoInfo_,this.applicationId_,this.appCheckToken_,this.authToken_,e,t,i,x=>{kn(x+" ("+this.repoInfo_.toString()+")"),this.interrupt(Y3)},l))}catch(T){this.log_("Failed to get token: "+T),u||(this.repoInfo_.nodeAdmin&&kn(T),m())}}}interrupt(e){mn("Interrupting connection for reason: "+e),this.interruptReasons_[e]=!0,this.realtime_?this.realtime_.close():(this.establishConnectionTimer_&&(clearTimeout(this.establishConnectionTimer_),this.establishConnectionTimer_=null),this.connected_&&this.onRealtimeDisconnect_())}resume(e){mn("Resuming connection for reason: "+e),delete this.interruptReasons_[e],n_(this.interruptReasons_)&&(this.reconnectDelay_=Hc,this.realtime_||this.scheduleConnect_(0))}handleTimestamp_(e){const t=e-new Date().getTime();this.onServerInfoUpdate_({serverTimeOffset:t})}cancelSentTransactions_(){for(let e=0;e<this.outstandingPuts_.length;e++){const t=this.outstandingPuts_[e];t&&"h"in t.request&&t.queued&&(t.onComplete&&t.onComplete("disconnect"),delete this.outstandingPuts_[e],this.outstandingPutCount_--)}this.outstandingPutCount_===0&&(this.outstandingPuts_=[])}onListenRevoked_(e,t){let i;t?i=t.map(l=>sv(l)).join("$"):i="default";const a=this.removeListen_(e,i);a&&a.onComplete&&a.onComplete("permission_denied")}removeListen_(e,t){const i=new ot(e).toString();let a;if(this.listens.has(i)){const l=this.listens.get(i);a=l.get(t),l.delete(t),l.size===0&&this.listens.delete(i)}else a=void 0;return a}onAuthRevoked_(e,t){mn("Auth token revoked: "+e+"/"+t),this.authToken_=null,this.forceTokenRefresh_=!0,this.realtime_.close(),(e==="invalid_token"||e==="permission_denied")&&(this.invalidAuthTokenCount_++,this.invalidAuthTokenCount_>=pS&&(this.reconnectDelay_=mS,this.authTokenProvider_.notifyForInvalidToken()))}onAppCheckRevoked_(e,t){mn("App check token revoked: "+e+"/"+t),this.appCheckToken_=null,this.forceTokenRefresh_=!0,(e==="invalid_token"||e==="permission_denied")&&(this.invalidAppCheckTokenCount_++,this.invalidAppCheckTokenCount_>=pS&&this.appCheckTokenProvider_.notifyForInvalidToken())}onSecurityDebugPacket_(e){this.securityDebugCallback_?this.securityDebugCallback_(e):"msg"in e&&console.log("FIREBASE: "+e.msg.replace(`
`,`
FIREBASE: `))}restoreState_(){this.tryAuth(),this.tryAppCheck();for(const e of this.listens.values())for(const t of e.values())this.sendListen_(t);for(let e=0;e<this.outstandingPuts_.length;e++)this.outstandingPuts_[e]&&this.sendPut_(e);for(;this.onDisconnectRequestQueue_.length;){const e=this.onDisconnectRequestQueue_.shift();this.sendOnDisconnect_(e.action,e.pathString,e.data,e.onComplete)}for(let e=0;e<this.outstandingGets_.length;e++)this.outstandingGets_[e]&&this.sendGet_(e)}sendConnectStats_(){const e={};let t="js";e["sdk."+t+"."+px.replace(/\./g,"-")]=1,ny()?e["framework.cordova"]=1:gA()&&(e["framework.reactnative"]=1),this.reportStats(e)}shouldReconnect_(){const e=Rf.getInstance().currentlyOnline();return n_(this.interruptReasons_)&&e}}Os.nextPersistentConnectionId_=0;Os.nextConnectionId_=0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pe{constructor(e,t){this.name=e,this.node=t}static Wrap(e,t){return new Pe(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mm{getCompare(){return this.compare.bind(this)}indexedValueChanged(e,t){const i=new Pe(Ha,e),a=new Pe(Ha,t);return this.compare(i,a)!==0}minPost(){return Pe.MIN}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Md;class Bx extends mm{static get __EMPTY_NODE(){return Md}static set __EMPTY_NODE(e){Md=e}compare(e,t){return xl(e.name,t.name)}isDefinedOn(e){throw El("KeyIndex.isDefinedOn not expected to be called.")}indexedValueChanged(e,t){return!1}minPost(){return Pe.MIN}maxPost(){return new Pe(Ur,Md)}makePost(e,t){return oe(typeof e=="string","KeyIndex indexValue must always be a string."),new Pe(e,Md)}toString(){return".key"}}const La=new Bx;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pd{constructor(e,t,i,a,l=null){this.isReverse_=a,this.resultGenerator_=l,this.nodeStack_=[];let u=1;for(;!e.isEmpty();)if(e=e,u=t?i(e.key,t):1,a&&(u*=-1),u<0)this.isReverse_?e=e.left:e=e.right;else if(u===0){this.nodeStack_.push(e);break}else this.nodeStack_.push(e),this.isReverse_?e=e.right:e=e.left}getNext(){if(this.nodeStack_.length===0)return null;let e=this.nodeStack_.pop(),t;if(this.resultGenerator_?t=this.resultGenerator_(e.key,e.value):t={key:e.key,value:e.value},this.isReverse_)for(e=e.left;!e.isEmpty();)this.nodeStack_.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack_.push(e),e=e.left;return t}hasNext(){return this.nodeStack_.length>0}peek(){if(this.nodeStack_.length===0)return null;const e=this.nodeStack_[this.nodeStack_.length-1];return this.resultGenerator_?this.resultGenerator_(e.key,e.value):{key:e.key,value:e.value}}}class Xt{constructor(e,t,i,a,l){this.key=e,this.value=t,this.color=i??Xt.RED,this.left=a??In.EMPTY_NODE,this.right=l??In.EMPTY_NODE}copy(e,t,i,a,l){return new Xt(e??this.key,t??this.value,i??this.color,a??this.left,l??this.right)}count(){return this.left.count()+1+this.right.count()}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||!!e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min_(){return this.left.isEmpty()?this:this.left.min_()}minKey(){return this.min_().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,i){let a=this;const l=i(e,a.key);return l<0?a=a.copy(null,null,null,a.left.insert(e,t,i),null):l===0?a=a.copy(null,t,null,null,null):a=a.copy(null,null,null,null,a.right.insert(e,t,i)),a.fixUp_()}removeMin_(){if(this.left.isEmpty())return In.EMPTY_NODE;let e=this;return!e.left.isRed_()&&!e.left.left.isRed_()&&(e=e.moveRedLeft_()),e=e.copy(null,null,null,e.left.removeMin_(),null),e.fixUp_()}remove(e,t){let i,a;if(i=this,t(e,i.key)<0)!i.left.isEmpty()&&!i.left.isRed_()&&!i.left.left.isRed_()&&(i=i.moveRedLeft_()),i=i.copy(null,null,null,i.left.remove(e,t),null);else{if(i.left.isRed_()&&(i=i.rotateRight_()),!i.right.isEmpty()&&!i.right.isRed_()&&!i.right.left.isRed_()&&(i=i.moveRedRight_()),t(e,i.key)===0){if(i.right.isEmpty())return In.EMPTY_NODE;a=i.right.min_(),i=i.copy(a.key,a.value,null,null,i.right.removeMin_())}i=i.copy(null,null,null,null,i.right.remove(e,t))}return i.fixUp_()}isRed_(){return this.color}fixUp_(){let e=this;return e.right.isRed_()&&!e.left.isRed_()&&(e=e.rotateLeft_()),e.left.isRed_()&&e.left.left.isRed_()&&(e=e.rotateRight_()),e.left.isRed_()&&e.right.isRed_()&&(e=e.colorFlip_()),e}moveRedLeft_(){let e=this.colorFlip_();return e.right.left.isRed_()&&(e=e.copy(null,null,null,null,e.right.rotateRight_()),e=e.rotateLeft_(),e=e.colorFlip_()),e}moveRedRight_(){let e=this.colorFlip_();return e.left.left.isRed_()&&(e=e.rotateRight_(),e=e.colorFlip_()),e}rotateLeft_(){const e=this.copy(null,null,Xt.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight_(){const e=this.copy(null,null,Xt.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip_(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth_(){const e=this.check_();return Math.pow(2,e)<=this.count()+1}check_(){if(this.isRed_()&&this.left.isRed_())throw new Error("Red node has red child("+this.key+","+this.value+")");if(this.right.isRed_())throw new Error("Right child of ("+this.key+","+this.value+") is red");const e=this.left.check_();if(e!==this.right.check_())throw new Error("Black depths differ");return e+(this.isRed_()?0:1)}}Xt.RED=!0;Xt.BLACK=!1;class W3{copy(e,t,i,a,l){return this}insert(e,t,i){return new Xt(e,t,null)}remove(e,t){return this}count(){return 0}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}check_(){return 0}isRed_(){return!1}}class In{constructor(e,t=In.EMPTY_NODE){this.comparator_=e,this.root_=t}insert(e,t){return new In(this.comparator_,this.root_.insert(e,t,this.comparator_).copy(null,null,Xt.BLACK,null,null))}remove(e){return new In(this.comparator_,this.root_.remove(e,this.comparator_).copy(null,null,Xt.BLACK,null,null))}get(e){let t,i=this.root_;for(;!i.isEmpty();){if(t=this.comparator_(e,i.key),t===0)return i.value;t<0?i=i.left:t>0&&(i=i.right)}return null}getPredecessorKey(e){let t,i=this.root_,a=null;for(;!i.isEmpty();)if(t=this.comparator_(e,i.key),t===0){if(i.left.isEmpty())return a?a.key:null;for(i=i.left;!i.right.isEmpty();)i=i.right;return i.key}else t<0?i=i.left:t>0&&(a=i,i=i.right);throw new Error("Attempted to find predecessor key for a nonexistent key.  What gives?")}isEmpty(){return this.root_.isEmpty()}count(){return this.root_.count()}minKey(){return this.root_.minKey()}maxKey(){return this.root_.maxKey()}inorderTraversal(e){return this.root_.inorderTraversal(e)}reverseTraversal(e){return this.root_.reverseTraversal(e)}getIterator(e){return new Pd(this.root_,null,this.comparator_,!1,e)}getIteratorFrom(e,t){return new Pd(this.root_,e,this.comparator_,!1,t)}getReverseIteratorFrom(e,t){return new Pd(this.root_,e,this.comparator_,!0,t)}getReverseIterator(e){return new Pd(this.root_,null,this.comparator_,!0,e)}}In.EMPTY_NODE=new W3;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function X3(n,e){return xl(n.name,e.name)}function uv(n,e){return xl(n,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let P_;function Z3(n){P_=n}const qx=function(n){return typeof n=="number"?"number:"+vx(n):"string:"+n},Hx=function(n){if(n.isLeafNode()){const e=n.val();oe(typeof e=="string"||typeof e=="number"||typeof e=="object"&&Wi(e,".sv"),"Priority must be a string or number.")}else oe(n===P_||n.isEmpty(),"priority of unexpected type.");oe(n===P_||n.getPriority().isEmpty(),"Priority nodes can't have a priority of their own.")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let gS;class Yt{static set __childrenNodeConstructor(e){gS=e}static get __childrenNodeConstructor(){return gS}constructor(e,t=Yt.__childrenNodeConstructor.EMPTY_NODE){this.value_=e,this.priorityNode_=t,this.lazyHash_=null,oe(this.value_!==void 0&&this.value_!==null,"LeafNode shouldn't be created with null/undefined value."),Hx(this.priorityNode_)}isLeafNode(){return!0}getPriority(){return this.priorityNode_}updatePriority(e){return new Yt(this.value_,e)}getImmediateChild(e){return e===".priority"?this.priorityNode_:Yt.__childrenNodeConstructor.EMPTY_NODE}getChild(e){return Me(e)?this:Oe(e)===".priority"?this.priorityNode_:Yt.__childrenNodeConstructor.EMPTY_NODE}hasChild(){return!1}getPredecessorChildName(e,t){return null}updateImmediateChild(e,t){return e===".priority"?this.updatePriority(t):t.isEmpty()&&e!==".priority"?this:Yt.__childrenNodeConstructor.EMPTY_NODE.updateImmediateChild(e,t).updatePriority(this.priorityNode_)}updateChild(e,t){const i=Oe(e);return i===null?t:t.isEmpty()&&i!==".priority"?this:(oe(i!==".priority"||jr(e)===1,".priority must be the last token in a path"),this.updateImmediateChild(i,Yt.__childrenNodeConstructor.EMPTY_NODE.updateChild(ht(e),t)))}isEmpty(){return!1}numChildren(){return 0}forEachChild(e,t){return!1}val(e){return e&&!this.getPriority().isEmpty()?{".value":this.getValue(),".priority":this.getPriority().val()}:this.getValue()}hash(){if(this.lazyHash_===null){let e="";this.priorityNode_.isEmpty()||(e+="priority:"+qx(this.priorityNode_.val())+":");const t=typeof this.value_;e+=t+":",t==="number"?e+=vx(this.value_):e+=this.value_,this.lazyHash_=_x(e)}return this.lazyHash_}getValue(){return this.value_}compareTo(e){return e===Yt.__childrenNodeConstructor.EMPTY_NODE?1:e instanceof Yt.__childrenNodeConstructor?-1:(oe(e.isLeafNode(),"Unknown node type"),this.compareToLeafNode_(e))}compareToLeafNode_(e){const t=typeof e.value_,i=typeof this.value_,a=Yt.VALUE_TYPE_ORDER.indexOf(t),l=Yt.VALUE_TYPE_ORDER.indexOf(i);return oe(a>=0,"Unknown leaf type: "+t),oe(l>=0,"Unknown leaf type: "+i),a===l?i==="object"?0:this.value_<e.value_?-1:this.value_===e.value_?0:1:l-a}withIndex(){return this}isIndexed(){return!0}equals(e){if(e===this)return!0;if(e.isLeafNode()){const t=e;return this.value_===t.value_&&this.priorityNode_.equals(t.priorityNode_)}else return!1}}Yt.VALUE_TYPE_ORDER=["object","boolean","number","string"];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Gx,$x;function J3(n){Gx=n}function e6(n){$x=n}class t6 extends mm{compare(e,t){const i=e.node.getPriority(),a=t.node.getPriority(),l=i.compareTo(a);return l===0?xl(e.name,t.name):l}isDefinedOn(e){return!e.getPriority().isEmpty()}indexedValueChanged(e,t){return!e.getPriority().equals(t.getPriority())}minPost(){return Pe.MIN}maxPost(){return new Pe(Ur,new Yt("[PRIORITY-POST]",$x))}makePost(e,t){const i=Gx(e);return new Pe(t,new Yt("[PRIORITY-POST]",i))}toString(){return".priority"}}const yt=new t6;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const n6=Math.log(2);class i6{constructor(e){const t=l=>parseInt(Math.log(l)/n6,10),i=l=>parseInt(Array(l+1).join("1"),2);this.count=t(e+1),this.current_=this.count-1;const a=i(this.count);this.bits_=e+1&a}nextBitIsOne(){const e=!(this.bits_&1<<this.current_);return this.current_--,e}}const Cf=function(n,e,t,i){n.sort(e);const a=function(m,p){const y=p-m;let T,w;if(y===0)return null;if(y===1)return T=n[m],w=t?t(T):T,new Xt(w,T.node,Xt.BLACK,null,null);{const x=parseInt(y/2,10)+m,I=a(m,x),O=a(x+1,p);return T=n[x],w=t?t(T):T,new Xt(w,T.node,Xt.BLACK,I,O)}},l=function(m){let p=null,y=null,T=n.length;const w=function(I,O){const P=T-I,B=T;T-=I;const ee=a(P+1,B),Y=n[P],W=t?t(Y):Y;x(new Xt(W,Y.node,O,null,ee))},x=function(I){p?(p.left=I,p=I):(y=I,p=I)};for(let I=0;I<m.count;++I){const O=m.nextBitIsOne(),P=Math.pow(2,m.count-(I+1));O?w(P,Xt.BLACK):(w(P,Xt.BLACK),w(P,Xt.RED))}return y},u=new i6(n.length),d=l(u);return new In(i||e,d)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Qg;const Qo={};class xs{static get Default(){return oe(Qo&&yt,"ChildrenNode.ts has not been loaded"),Qg=Qg||new xs({".priority":Qo},{".priority":yt}),Qg}constructor(e,t){this.indexes_=e,this.indexSet_=t}get(e){const t=ol(this.indexes_,e);if(!t)throw new Error("No index defined for "+e);return t instanceof In?t:null}hasIndex(e){return Wi(this.indexSet_,e.toString())}addIndex(e,t){oe(e!==La,"KeyIndex always exists and isn't meant to be added to the IndexMap.");const i=[];let a=!1;const l=t.getIterator(Pe.Wrap);let u=l.getNext();for(;u;)a=a||e.isDefinedOn(u.node),i.push(u),u=l.getNext();let d;a?d=Cf(i,e.getCompare()):d=Qo;const m=e.toString(),p=Object.assign({},this.indexSet_);p[m]=e;const y=Object.assign({},this.indexes_);return y[m]=d,new xs(y,p)}addToIndexes(e,t){const i=nf(this.indexes_,(a,l)=>{const u=ol(this.indexSet_,l);if(oe(u,"Missing index implementation for "+l),a===Qo)if(u.isDefinedOn(e.node)){const d=[],m=t.getIterator(Pe.Wrap);let p=m.getNext();for(;p;)p.name!==e.name&&d.push(p),p=m.getNext();return d.push(e),Cf(d,u.getCompare())}else return Qo;else{const d=t.get(e.name);let m=a;return d&&(m=m.remove(new Pe(e.name,d))),m.insert(e,e.node)}});return new xs(i,this.indexSet_)}removeFromIndexes(e,t){const i=nf(this.indexes_,a=>{if(a===Qo)return a;{const l=t.get(e.name);return l?a.remove(new Pe(e.name,l)):a}});return new xs(i,this.indexSet_)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Gc;class we{static get EMPTY_NODE(){return Gc||(Gc=new we(new In(uv),null,xs.Default))}constructor(e,t,i){this.children_=e,this.priorityNode_=t,this.indexMap_=i,this.lazyHash_=null,this.priorityNode_&&Hx(this.priorityNode_),this.children_.isEmpty()&&oe(!this.priorityNode_||this.priorityNode_.isEmpty(),"An empty node cannot have a priority")}isLeafNode(){return!1}getPriority(){return this.priorityNode_||Gc}updatePriority(e){return this.children_.isEmpty()?this:new we(this.children_,e,this.indexMap_)}getImmediateChild(e){if(e===".priority")return this.getPriority();{const t=this.children_.get(e);return t===null?Gc:t}}getChild(e){const t=Oe(e);return t===null?this:this.getImmediateChild(t).getChild(ht(e))}hasChild(e){return this.children_.get(e)!==null}updateImmediateChild(e,t){if(oe(t,"We should always be passing snapshot nodes"),e===".priority")return this.updatePriority(t);{const i=new Pe(e,t);let a,l;t.isEmpty()?(a=this.children_.remove(e),l=this.indexMap_.removeFromIndexes(i,this.children_)):(a=this.children_.insert(e,t),l=this.indexMap_.addToIndexes(i,this.children_));const u=a.isEmpty()?Gc:this.priorityNode_;return new we(a,u,l)}}updateChild(e,t){const i=Oe(e);if(i===null)return t;{oe(Oe(e)!==".priority"||jr(e)===1,".priority must be the last token in a path");const a=this.getImmediateChild(i).updateChild(ht(e),t);return this.updateImmediateChild(i,a)}}isEmpty(){return this.children_.isEmpty()}numChildren(){return this.children_.count()}val(e){if(this.isEmpty())return null;const t={};let i=0,a=0,l=!0;if(this.forEachChild(yt,(u,d)=>{t[u]=d.val(e),i++,l&&we.INTEGER_REGEXP_.test(u)?a=Math.max(a,Number(u)):l=!1}),!e&&l&&a<2*i){const u=[];for(const d in t)u[d]=t[d];return u}else return e&&!this.getPriority().isEmpty()&&(t[".priority"]=this.getPriority().val()),t}hash(){if(this.lazyHash_===null){let e="";this.getPriority().isEmpty()||(e+="priority:"+qx(this.getPriority().val())+":"),this.forEachChild(yt,(t,i)=>{const a=i.hash();a!==""&&(e+=":"+t+":"+a)}),this.lazyHash_=e===""?"":_x(e)}return this.lazyHash_}getPredecessorChildName(e,t,i){const a=this.resolveIndex_(i);if(a){const l=a.getPredecessorKey(new Pe(e,t));return l?l.name:null}else return this.children_.getPredecessorKey(e)}getFirstChildName(e){const t=this.resolveIndex_(e);if(t){const i=t.minKey();return i&&i.name}else return this.children_.minKey()}getFirstChild(e){const t=this.getFirstChildName(e);return t?new Pe(t,this.children_.get(t)):null}getLastChildName(e){const t=this.resolveIndex_(e);if(t){const i=t.maxKey();return i&&i.name}else return this.children_.maxKey()}getLastChild(e){const t=this.getLastChildName(e);return t?new Pe(t,this.children_.get(t)):null}forEachChild(e,t){const i=this.resolveIndex_(e);return i?i.inorderTraversal(a=>t(a.name,a.node)):this.children_.inorderTraversal(t)}getIterator(e){return this.getIteratorFrom(e.minPost(),e)}getIteratorFrom(e,t){const i=this.resolveIndex_(t);if(i)return i.getIteratorFrom(e,a=>a);{const a=this.children_.getIteratorFrom(e.name,Pe.Wrap);let l=a.peek();for(;l!=null&&t.compare(l,e)<0;)a.getNext(),l=a.peek();return a}}getReverseIterator(e){return this.getReverseIteratorFrom(e.maxPost(),e)}getReverseIteratorFrom(e,t){const i=this.resolveIndex_(t);if(i)return i.getReverseIteratorFrom(e,a=>a);{const a=this.children_.getReverseIteratorFrom(e.name,Pe.Wrap);let l=a.peek();for(;l!=null&&t.compare(l,e)>0;)a.getNext(),l=a.peek();return a}}compareTo(e){return this.isEmpty()?e.isEmpty()?0:-1:e.isLeafNode()||e.isEmpty()?1:e===Yu?-1:0}withIndex(e){if(e===La||this.indexMap_.hasIndex(e))return this;{const t=this.indexMap_.addIndex(e,this.children_);return new we(this.children_,this.priorityNode_,t)}}isIndexed(e){return e===La||this.indexMap_.hasIndex(e)}equals(e){if(e===this)return!0;if(e.isLeafNode())return!1;{const t=e;if(this.getPriority().equals(t.getPriority()))if(this.children_.count()===t.children_.count()){const i=this.getIterator(yt),a=t.getIterator(yt);let l=i.getNext(),u=a.getNext();for(;l&&u;){if(l.name!==u.name||!l.node.equals(u.node))return!1;l=i.getNext(),u=a.getNext()}return l===null&&u===null}else return!1;else return!1}}resolveIndex_(e){return e===La?null:this.indexMap_.get(e.toString())}}we.INTEGER_REGEXP_=/^(0|[1-9]\d*)$/;class s6 extends we{constructor(){super(new In(uv),we.EMPTY_NODE,xs.Default)}compareTo(e){return e===this?0:1}equals(e){return e===this}getPriority(){return this}getImmediateChild(e){return we.EMPTY_NODE}isEmpty(){return!1}}const Yu=new s6;Object.defineProperties(Pe,{MIN:{value:new Pe(Ha,we.EMPTY_NODE)},MAX:{value:new Pe(Ur,Yu)}});Bx.__EMPTY_NODE=we.EMPTY_NODE;Yt.__childrenNodeConstructor=we;Z3(Yu);e6(Yu);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const r6=!0;function rn(n,e=null){if(n===null)return we.EMPTY_NODE;if(typeof n=="object"&&".priority"in n&&(e=n[".priority"]),oe(e===null||typeof e=="string"||typeof e=="number"||typeof e=="object"&&".sv"in e,"Invalid priority type found: "+typeof e),typeof n=="object"&&".value"in n&&n[".value"]!==null&&(n=n[".value"]),typeof n!="object"||".sv"in n){const t=n;return new Yt(t,rn(e))}if(!(n instanceof Array)&&r6){const t=[];let i=!1;if(Dn(n,(u,d)=>{if(u.substring(0,1)!=="."){const m=rn(d);m.isEmpty()||(i=i||!m.getPriority().isEmpty(),t.push(new Pe(u,m)))}}),t.length===0)return we.EMPTY_NODE;const l=Cf(t,X3,u=>u.name,uv);if(i){const u=Cf(t,yt.getCompare());return new we(l,rn(e),new xs({".priority":u},{".priority":yt}))}else return new we(l,rn(e),xs.Default)}else{let t=we.EMPTY_NODE;return Dn(n,(i,a)=>{if(Wi(n,i)&&i.substring(0,1)!=="."){const l=rn(a);(l.isLeafNode()||!l.isEmpty())&&(t=t.updateImmediateChild(i,l))}}),t.updatePriority(rn(e))}}J3(rn);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hv extends mm{constructor(e){super(),this.indexPath_=e,oe(!Me(e)&&Oe(e)!==".priority","Can't create PathIndex with empty path or .priority key")}extractChild(e){return e.getChild(this.indexPath_)}isDefinedOn(e){return!e.getChild(this.indexPath_).isEmpty()}compare(e,t){const i=this.extractChild(e.node),a=this.extractChild(t.node),l=i.compareTo(a);return l===0?xl(e.name,t.name):l}makePost(e,t){const i=rn(e),a=we.EMPTY_NODE.updateChild(this.indexPath_,i);return new Pe(t,a)}maxPost(){const e=we.EMPTY_NODE.updateChild(this.indexPath_,Yu);return new Pe(Ur,e)}toString(){return jx(this.indexPath_,0).join("/")}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class a6 extends mm{compare(e,t){const i=e.node.compareTo(t.node);return i===0?xl(e.name,t.name):i}isDefinedOn(e){return!0}indexedValueChanged(e,t){return!e.equals(t)}minPost(){return Pe.MIN}maxPost(){return Pe.MAX}makePost(e,t){const i=rn(e);return new Pe(t,i)}toString(){return".value"}}const Kx=new a6;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qx(n){return{type:"value",snapshotNode:n}}function pl(n,e){return{type:"child_added",snapshotNode:e,childName:n}}function xu(n,e){return{type:"child_removed",snapshotNode:e,childName:n}}function Iu(n,e,t){return{type:"child_changed",snapshotNode:e,childName:n,oldSnap:t}}function o6(n,e){return{type:"child_moved",snapshotNode:e,childName:n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dv{constructor(e){this.index_=e}updateChild(e,t,i,a,l,u){oe(e.isIndexed(this.index_),"A node must be indexed if only a child is updated");const d=e.getImmediateChild(t);return d.getChild(a).equals(i.getChild(a))&&d.isEmpty()===i.isEmpty()||(u!=null&&(i.isEmpty()?e.hasChild(t)?u.trackChildChange(xu(t,d)):oe(e.isLeafNode(),"A child remove without an old child only makes sense on a leaf node"):d.isEmpty()?u.trackChildChange(pl(t,i)):u.trackChildChange(Iu(t,i,d))),e.isLeafNode()&&i.isEmpty())?e:e.updateImmediateChild(t,i).withIndex(this.index_)}updateFullNode(e,t,i){return i!=null&&(e.isLeafNode()||e.forEachChild(yt,(a,l)=>{t.hasChild(a)||i.trackChildChange(xu(a,l))}),t.isLeafNode()||t.forEachChild(yt,(a,l)=>{if(e.hasChild(a)){const u=e.getImmediateChild(a);u.equals(l)||i.trackChildChange(Iu(a,l,u))}else i.trackChildChange(pl(a,l))})),t.withIndex(this.index_)}updatePriority(e,t){return e.isEmpty()?we.EMPTY_NODE:e.updatePriority(t)}filtersNodes(){return!1}getIndexedFilter(){return this}getIndex(){return this.index_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nu{constructor(e){this.indexedFilter_=new dv(e.getIndex()),this.index_=e.getIndex(),this.startPost_=Nu.getStartPost_(e),this.endPost_=Nu.getEndPost_(e),this.startIsInclusive_=!e.startAfterSet_,this.endIsInclusive_=!e.endBeforeSet_}getStartPost(){return this.startPost_}getEndPost(){return this.endPost_}matches(e){const t=this.startIsInclusive_?this.index_.compare(this.getStartPost(),e)<=0:this.index_.compare(this.getStartPost(),e)<0,i=this.endIsInclusive_?this.index_.compare(e,this.getEndPost())<=0:this.index_.compare(e,this.getEndPost())<0;return t&&i}updateChild(e,t,i,a,l,u){return this.matches(new Pe(t,i))||(i=we.EMPTY_NODE),this.indexedFilter_.updateChild(e,t,i,a,l,u)}updateFullNode(e,t,i){t.isLeafNode()&&(t=we.EMPTY_NODE);let a=t.withIndex(this.index_);a=a.updatePriority(we.EMPTY_NODE);const l=this;return t.forEachChild(yt,(u,d)=>{l.matches(new Pe(u,d))||(a=a.updateImmediateChild(u,we.EMPTY_NODE))}),this.indexedFilter_.updateFullNode(e,a,i)}updatePriority(e,t){return e}filtersNodes(){return!0}getIndexedFilter(){return this.indexedFilter_}getIndex(){return this.index_}static getStartPost_(e){if(e.hasStart()){const t=e.getIndexStartName();return e.getIndex().makePost(e.getIndexStartValue(),t)}else return e.getIndex().minPost()}static getEndPost_(e){if(e.hasEnd()){const t=e.getIndexEndName();return e.getIndex().makePost(e.getIndexEndValue(),t)}else return e.getIndex().maxPost()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class l6{constructor(e){this.withinDirectionalStart=t=>this.reverse_?this.withinEndPost(t):this.withinStartPost(t),this.withinDirectionalEnd=t=>this.reverse_?this.withinStartPost(t):this.withinEndPost(t),this.withinStartPost=t=>{const i=this.index_.compare(this.rangedFilter_.getStartPost(),t);return this.startIsInclusive_?i<=0:i<0},this.withinEndPost=t=>{const i=this.index_.compare(t,this.rangedFilter_.getEndPost());return this.endIsInclusive_?i<=0:i<0},this.rangedFilter_=new Nu(e),this.index_=e.getIndex(),this.limit_=e.getLimit(),this.reverse_=!e.isViewFromLeft(),this.startIsInclusive_=!e.startAfterSet_,this.endIsInclusive_=!e.endBeforeSet_}updateChild(e,t,i,a,l,u){return this.rangedFilter_.matches(new Pe(t,i))||(i=we.EMPTY_NODE),e.getImmediateChild(t).equals(i)?e:e.numChildren()<this.limit_?this.rangedFilter_.getIndexedFilter().updateChild(e,t,i,a,l,u):this.fullLimitUpdateChild_(e,t,i,l,u)}updateFullNode(e,t,i){let a;if(t.isLeafNode()||t.isEmpty())a=we.EMPTY_NODE.withIndex(this.index_);else if(this.limit_*2<t.numChildren()&&t.isIndexed(this.index_)){a=we.EMPTY_NODE.withIndex(this.index_);let l;this.reverse_?l=t.getReverseIteratorFrom(this.rangedFilter_.getEndPost(),this.index_):l=t.getIteratorFrom(this.rangedFilter_.getStartPost(),this.index_);let u=0;for(;l.hasNext()&&u<this.limit_;){const d=l.getNext();if(this.withinDirectionalStart(d))if(this.withinDirectionalEnd(d))a=a.updateImmediateChild(d.name,d.node),u++;else break;else continue}}else{a=t.withIndex(this.index_),a=a.updatePriority(we.EMPTY_NODE);let l;this.reverse_?l=a.getReverseIterator(this.index_):l=a.getIterator(this.index_);let u=0;for(;l.hasNext();){const d=l.getNext();u<this.limit_&&this.withinDirectionalStart(d)&&this.withinDirectionalEnd(d)?u++:a=a.updateImmediateChild(d.name,we.EMPTY_NODE)}}return this.rangedFilter_.getIndexedFilter().updateFullNode(e,a,i)}updatePriority(e,t){return e}filtersNodes(){return!0}getIndexedFilter(){return this.rangedFilter_.getIndexedFilter()}getIndex(){return this.index_}fullLimitUpdateChild_(e,t,i,a,l){let u;if(this.reverse_){const T=this.index_.getCompare();u=(w,x)=>T(x,w)}else u=this.index_.getCompare();const d=e;oe(d.numChildren()===this.limit_,"");const m=new Pe(t,i),p=this.reverse_?d.getFirstChild(this.index_):d.getLastChild(this.index_),y=this.rangedFilter_.matches(m);if(d.hasChild(t)){const T=d.getImmediateChild(t);let w=a.getChildAfterChild(this.index_,p,this.reverse_);for(;w!=null&&(w.name===t||d.hasChild(w.name));)w=a.getChildAfterChild(this.index_,w,this.reverse_);const x=w==null?1:u(w,m);if(y&&!i.isEmpty()&&x>=0)return l!=null&&l.trackChildChange(Iu(t,i,T)),d.updateImmediateChild(t,i);{l!=null&&l.trackChildChange(xu(t,T));const O=d.updateImmediateChild(t,we.EMPTY_NODE);return w!=null&&this.rangedFilter_.matches(w)?(l!=null&&l.trackChildChange(pl(w.name,w.node)),O.updateImmediateChild(w.name,w.node)):O}}else return i.isEmpty()?e:y&&u(p,m)>=0?(l!=null&&(l.trackChildChange(xu(p.name,p.node)),l.trackChildChange(pl(t,i))),d.updateImmediateChild(t,i).updateImmediateChild(p.name,we.EMPTY_NODE)):e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fv{constructor(){this.limitSet_=!1,this.startSet_=!1,this.startNameSet_=!1,this.startAfterSet_=!1,this.endSet_=!1,this.endNameSet_=!1,this.endBeforeSet_=!1,this.limit_=0,this.viewFrom_="",this.indexStartValue_=null,this.indexStartName_="",this.indexEndValue_=null,this.indexEndName_="",this.index_=yt}hasStart(){return this.startSet_}isViewFromLeft(){return this.viewFrom_===""?this.startSet_:this.viewFrom_==="l"}getIndexStartValue(){return oe(this.startSet_,"Only valid if start has been set"),this.indexStartValue_}getIndexStartName(){return oe(this.startSet_,"Only valid if start has been set"),this.startNameSet_?this.indexStartName_:Ha}hasEnd(){return this.endSet_}getIndexEndValue(){return oe(this.endSet_,"Only valid if end has been set"),this.indexEndValue_}getIndexEndName(){return oe(this.endSet_,"Only valid if end has been set"),this.endNameSet_?this.indexEndName_:Ur}hasLimit(){return this.limitSet_}hasAnchoredLimit(){return this.limitSet_&&this.viewFrom_!==""}getLimit(){return oe(this.limitSet_,"Only valid if limit has been set"),this.limit_}getIndex(){return this.index_}loadsAllData(){return!(this.startSet_||this.endSet_||this.limitSet_)}isDefault(){return this.loadsAllData()&&this.index_===yt}copy(){const e=new fv;return e.limitSet_=this.limitSet_,e.limit_=this.limit_,e.startSet_=this.startSet_,e.startAfterSet_=this.startAfterSet_,e.indexStartValue_=this.indexStartValue_,e.startNameSet_=this.startNameSet_,e.indexStartName_=this.indexStartName_,e.endSet_=this.endSet_,e.endBeforeSet_=this.endBeforeSet_,e.indexEndValue_=this.indexEndValue_,e.endNameSet_=this.endNameSet_,e.indexEndName_=this.indexEndName_,e.index_=this.index_,e.viewFrom_=this.viewFrom_,e}}function c6(n){return n.loadsAllData()?new dv(n.getIndex()):n.hasLimit()?new l6(n):new Nu(n)}function u6(n,e){const t=n.copy();return t.limitSet_=!0,t.limit_=e,t.viewFrom_="r",t}function h6(n,e){const t=n.copy();return t.index_=e,t}function _S(n){const e={};if(n.isDefault())return e;let t;if(n.index_===yt?t="$priority":n.index_===Kx?t="$value":n.index_===La?t="$key":(oe(n.index_ instanceof hv,"Unrecognized index type!"),t=n.index_.toString()),e.orderBy=Zt(t),n.startSet_){const i=n.startAfterSet_?"startAfter":"startAt";e[i]=Zt(n.indexStartValue_),n.startNameSet_&&(e[i]+=","+Zt(n.indexStartName_))}if(n.endSet_){const i=n.endBeforeSet_?"endBefore":"endAt";e[i]=Zt(n.indexEndValue_),n.endNameSet_&&(e[i]+=","+Zt(n.indexEndName_))}return n.limitSet_&&(n.isViewFromLeft()?e.limitToFirst=n.limit_:e.limitToLast=n.limit_),e}function yS(n){const e={};if(n.startSet_&&(e.sp=n.indexStartValue_,n.startNameSet_&&(e.sn=n.indexStartName_),e.sin=!n.startAfterSet_),n.endSet_&&(e.ep=n.indexEndValue_,n.endNameSet_&&(e.en=n.indexEndName_),e.ein=!n.endBeforeSet_),n.limitSet_){e.l=n.limit_;let t=n.viewFrom_;t===""&&(n.isViewFromLeft()?t="l":t="r"),e.vf=t}return n.index_!==yt&&(e.i=n.index_.toString()),e}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xf extends Lx{reportStats(e){throw new Error("Method not implemented.")}static getListenId_(e,t){return t!==void 0?"tag$"+t:(oe(e._queryParams.isDefault(),"should have a tag if it's not a default query."),e._path.toString())}constructor(e,t,i,a){super(),this.repoInfo_=e,this.onDataUpdate_=t,this.authTokenProvider_=i,this.appCheckTokenProvider_=a,this.log_=Qu("p:rest:"),this.listens_={}}listen(e,t,i,a){const l=e._path.toString();this.log_("Listen called for "+l+" "+e._queryIdentifier);const u=xf.getListenId_(e,i),d={};this.listens_[u]=d;const m=_S(e._queryParams);this.restRequest_(l+".json",m,(p,y)=>{let T=y;if(p===404&&(T=null,p=null),p===null&&this.onDataUpdate_(l,T,!1,i),ol(this.listens_,u)===d){let w;p?p===401?w="permission_denied":w="rest_error:"+p:w="ok",a(w,null)}})}unlisten(e,t){const i=xf.getListenId_(e,t);delete this.listens_[i]}get(e){const t=_S(e._queryParams),i=e._path.toString(),a=new qf;return this.restRequest_(i+".json",t,(l,u)=>{let d=u;l===404&&(d=null,l=null),l===null?(this.onDataUpdate_(i,d,!1,null),a.resolve(d)):a.reject(new Error(d))}),a.promise}refreshAuthToken(e){}restRequest_(e,t={},i){return t.format="export",Promise.all([this.authTokenProvider_.getToken(!1),this.appCheckTokenProvider_.getToken(!1)]).then(([a,l])=>{a&&a.accessToken&&(t.auth=a.accessToken),l&&l.token&&(t.ac=l.token);const u=(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host+e+"?ns="+this.repoInfo_.namespace+Tl(t);this.log_("Sending REST request for "+u);const d=new XMLHttpRequest;d.onreadystatechange=()=>{if(i&&d.readyState===4){this.log_("REST Response for "+u+" received. status:",d.status,"response:",d.responseText);let m=null;if(d.status>=200&&d.status<300){try{m=pu(d.responseText)}catch{kn("Failed to parse JSON response for "+u+": "+d.responseText)}i(null,m)}else d.status!==401&&d.status!==404&&kn("Got unsuccessful REST response for "+u+" Status: "+d.status),i(d.status);i=null}},d.open("GET",u,!0),d.send()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class d6{constructor(){this.rootNode_=we.EMPTY_NODE}getNode(e){return this.rootNode_.getChild(e)}updateSnapshot(e,t){this.rootNode_=this.rootNode_.updateChild(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function If(){return{value:null,children:new Map}}function Yx(n,e,t){if(Me(e))n.value=t,n.children.clear();else if(n.value!==null)n.value=n.value.updateChild(e,t);else{const i=Oe(e);n.children.has(i)||n.children.set(i,If());const a=n.children.get(i);e=ht(e),Yx(a,e,t)}}function L_(n,e,t){n.value!==null?t(e,n.value):f6(n,(i,a)=>{const l=new ot(e.toString()+"/"+i);L_(a,l,t)})}function f6(n,e){n.children.forEach((t,i)=>{e(i,t)})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class m6{constructor(e){this.collection_=e,this.last_=null}get(){const e=this.collection_.get(),t=Object.assign({},e);return this.last_&&Dn(this.last_,(i,a)=>{t[i]=t[i]-a}),this.last_=e,t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vS=10*1e3,p6=30*1e3,g6=5*60*1e3;class _6{constructor(e,t){this.server_=t,this.statsToReport_={},this.statsListener_=new m6(e);const i=vS+(p6-vS)*Math.random();lu(this.reportStats_.bind(this),Math.floor(i))}reportStats_(){const e=this.statsListener_.get(),t={};let i=!1;Dn(e,(a,l)=>{l>0&&Wi(this.statsToReport_,a)&&(t[a]=l,i=!0)}),i&&this.server_.reportStats(t),lu(this.reportStats_.bind(this),Math.floor(Math.random()*2*g6))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var yi;(function(n){n[n.OVERWRITE=0]="OVERWRITE",n[n.MERGE=1]="MERGE",n[n.ACK_USER_WRITE=2]="ACK_USER_WRITE",n[n.LISTEN_COMPLETE=3]="LISTEN_COMPLETE"})(yi||(yi={}));function Wx(){return{fromUser:!0,fromServer:!1,queryId:null,tagged:!1}}function mv(){return{fromUser:!1,fromServer:!0,queryId:null,tagged:!1}}function pv(n){return{fromUser:!1,fromServer:!0,queryId:n,tagged:!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nf{constructor(e,t,i){this.path=e,this.affectedTree=t,this.revert=i,this.type=yi.ACK_USER_WRITE,this.source=Wx()}operationForChild(e){if(Me(this.path)){if(this.affectedTree.value!=null)return oe(this.affectedTree.children.isEmpty(),"affectedTree should not have overlapping affected paths."),this;{const t=this.affectedTree.subtree(new ot(e));return new Nf(Ye(),t,this.revert)}}else return oe(Oe(this.path)===e,"operationForChild called for unrelated child."),new Nf(ht(this.path),this.affectedTree,this.revert)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ku{constructor(e,t){this.source=e,this.path=t,this.type=yi.LISTEN_COMPLETE}operationForChild(e){return Me(this.path)?new ku(this.source,Ye()):new ku(this.source,ht(this.path))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ga{constructor(e,t,i){this.source=e,this.path=t,this.snap=i,this.type=yi.OVERWRITE}operationForChild(e){return Me(this.path)?new Ga(this.source,Ye(),this.snap.getImmediateChild(e)):new Ga(this.source,ht(this.path),this.snap)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Du{constructor(e,t,i){this.source=e,this.path=t,this.children=i,this.type=yi.MERGE}operationForChild(e){if(Me(this.path)){const t=this.children.subtree(new ot(e));return t.isEmpty()?null:t.value?new Ga(this.source,Ye(),t.value):new Du(this.source,Ye(),t)}else return oe(Oe(this.path)===e,"Can't get a merge for a child not on the path of the operation"),new Du(this.source,ht(this.path),this.children)}toString(){return"Operation("+this.path+": "+this.source.toString()+" merge: "+this.children.toString()+")"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $a{constructor(e,t,i){this.node_=e,this.fullyInitialized_=t,this.filtered_=i}isFullyInitialized(){return this.fullyInitialized_}isFiltered(){return this.filtered_}isCompleteForPath(e){if(Me(e))return this.isFullyInitialized()&&!this.filtered_;const t=Oe(e);return this.isCompleteForChild(t)}isCompleteForChild(e){return this.isFullyInitialized()&&!this.filtered_||this.node_.hasChild(e)}getNode(){return this.node_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y6{constructor(e){this.query_=e,this.index_=this.query_._queryParams.getIndex()}}function v6(n,e,t,i){const a=[],l=[];return e.forEach(u=>{u.type==="child_changed"&&n.index_.indexedValueChanged(u.oldSnap,u.snapshotNode)&&l.push(o6(u.childName,u.snapshotNode))}),$c(n,a,"child_removed",e,i,t),$c(n,a,"child_added",e,i,t),$c(n,a,"child_moved",l,i,t),$c(n,a,"child_changed",e,i,t),$c(n,a,"value",e,i,t),a}function $c(n,e,t,i,a,l){const u=i.filter(d=>d.type===t);u.sort((d,m)=>T6(n,d,m)),u.forEach(d=>{const m=E6(n,d,l);a.forEach(p=>{p.respondsTo(d.type)&&e.push(p.createEvent(m,n.query_))})})}function E6(n,e,t){return e.type==="value"||e.type==="child_removed"||(e.prevName=t.getPredecessorChildName(e.childName,e.snapshotNode,n.index_)),e}function T6(n,e,t){if(e.childName==null||t.childName==null)throw El("Should only compare child_ events.");const i=new Pe(e.childName,e.snapshotNode),a=new Pe(t.childName,t.snapshotNode);return n.index_.compare(i,a)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pm(n,e){return{eventCache:n,serverCache:e}}function cu(n,e,t,i){return pm(new $a(e,t,i),n.serverCache)}function Xx(n,e,t,i){return pm(n.eventCache,new $a(e,t,i))}function V_(n){return n.eventCache.isFullyInitialized()?n.eventCache.getNode():null}function Ka(n){return n.serverCache.isFullyInitialized()?n.serverCache.getNode():null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Yg;const b6=()=>(Yg||(Yg=new In(o3)),Yg);class dt{static fromObject(e){let t=new dt(null);return Dn(e,(i,a)=>{t=t.set(new ot(i),a)}),t}constructor(e,t=b6()){this.value=e,this.children=t}isEmpty(){return this.value===null&&this.children.isEmpty()}findRootMostMatchingPathAndValue(e,t){if(this.value!=null&&t(this.value))return{path:Ye(),value:this.value};if(Me(e))return null;{const i=Oe(e),a=this.children.get(i);if(a!==null){const l=a.findRootMostMatchingPathAndValue(ht(e),t);return l!=null?{path:zt(new ot(i),l.path),value:l.value}:null}else return null}}findRootMostValueAndPath(e){return this.findRootMostMatchingPathAndValue(e,()=>!0)}subtree(e){if(Me(e))return this;{const t=Oe(e),i=this.children.get(t);return i!==null?i.subtree(ht(e)):new dt(null)}}set(e,t){if(Me(e))return new dt(t,this.children);{const i=Oe(e),l=(this.children.get(i)||new dt(null)).set(ht(e),t),u=this.children.insert(i,l);return new dt(this.value,u)}}remove(e){if(Me(e))return this.children.isEmpty()?new dt(null):new dt(null,this.children);{const t=Oe(e),i=this.children.get(t);if(i){const a=i.remove(ht(e));let l;return a.isEmpty()?l=this.children.remove(t):l=this.children.insert(t,a),this.value===null&&l.isEmpty()?new dt(null):new dt(this.value,l)}else return this}}get(e){if(Me(e))return this.value;{const t=Oe(e),i=this.children.get(t);return i?i.get(ht(e)):null}}setTree(e,t){if(Me(e))return t;{const i=Oe(e),l=(this.children.get(i)||new dt(null)).setTree(ht(e),t);let u;return l.isEmpty()?u=this.children.remove(i):u=this.children.insert(i,l),new dt(this.value,u)}}fold(e){return this.fold_(Ye(),e)}fold_(e,t){const i={};return this.children.inorderTraversal((a,l)=>{i[a]=l.fold_(zt(e,a),t)}),t(e,this.value,i)}findOnPath(e,t){return this.findOnPath_(e,Ye(),t)}findOnPath_(e,t,i){const a=this.value?i(t,this.value):!1;if(a)return a;if(Me(e))return null;{const l=Oe(e),u=this.children.get(l);return u?u.findOnPath_(ht(e),zt(t,l),i):null}}foreachOnPath(e,t){return this.foreachOnPath_(e,Ye(),t)}foreachOnPath_(e,t,i){if(Me(e))return this;{this.value&&i(t,this.value);const a=Oe(e),l=this.children.get(a);return l?l.foreachOnPath_(ht(e),zt(t,a),i):new dt(null)}}foreach(e){this.foreach_(Ye(),e)}foreach_(e,t){this.children.inorderTraversal((i,a)=>{a.foreach_(zt(e,i),t)}),this.value&&t(e,this.value)}foreachChild(e){this.children.inorderTraversal((t,i)=>{i.value&&e(t,i.value)})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vi{constructor(e){this.writeTree_=e}static empty(){return new vi(new dt(null))}}function uu(n,e,t){if(Me(e))return new vi(new dt(t));{const i=n.writeTree_.findRootMostValueAndPath(e);if(i!=null){const a=i.path;let l=i.value;const u=xn(a,e);return l=l.updateChild(u,t),new vi(n.writeTree_.set(a,l))}else{const a=new dt(t),l=n.writeTree_.setTree(e,a);return new vi(l)}}}function ES(n,e,t){let i=n;return Dn(t,(a,l)=>{i=uu(i,zt(e,a),l)}),i}function TS(n,e){if(Me(e))return vi.empty();{const t=n.writeTree_.setTree(e,new dt(null));return new vi(t)}}function U_(n,e){return eo(n,e)!=null}function eo(n,e){const t=n.writeTree_.findRootMostValueAndPath(e);return t!=null?n.writeTree_.get(t.path).getChild(xn(t.path,e)):null}function bS(n){const e=[],t=n.writeTree_.value;return t!=null?t.isLeafNode()||t.forEachChild(yt,(i,a)=>{e.push(new Pe(i,a))}):n.writeTree_.children.inorderTraversal((i,a)=>{a.value!=null&&e.push(new Pe(i,a.value))}),e}function kr(n,e){if(Me(e))return n;{const t=eo(n,e);return t!=null?new vi(new dt(t)):new vi(n.writeTree_.subtree(e))}}function j_(n){return n.writeTree_.isEmpty()}function gl(n,e){return Zx(Ye(),n.writeTree_,e)}function Zx(n,e,t){if(e.value!=null)return t.updateChild(n,e.value);{let i=null;return e.children.inorderTraversal((a,l)=>{a===".priority"?(oe(l.value!==null,"Priority writes must always be leaf nodes"),i=l.value):t=Zx(zt(n,a),l,t)}),!t.getChild(n).isEmpty()&&i!==null&&(t=t.updateChild(zt(n,".priority"),i)),t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gv(n,e){return nI(e,n)}function w6(n,e,t,i,a){oe(i>n.lastWriteId,"Stacking an older write on top of newer ones"),a===void 0&&(a=!0),n.allWrites.push({path:e,snap:t,writeId:i,visible:a}),a&&(n.visibleWrites=uu(n.visibleWrites,e,t)),n.lastWriteId=i}function S6(n,e){for(let t=0;t<n.allWrites.length;t++){const i=n.allWrites[t];if(i.writeId===e)return i}return null}function A6(n,e){const t=n.allWrites.findIndex(d=>d.writeId===e);oe(t>=0,"removeWrite called with nonexistent writeId.");const i=n.allWrites[t];n.allWrites.splice(t,1);let a=i.visible,l=!1,u=n.allWrites.length-1;for(;a&&u>=0;){const d=n.allWrites[u];d.visible&&(u>=t&&R6(d,i.path)?a=!1:_i(i.path,d.path)&&(l=!0)),u--}if(a){if(l)return C6(n),!0;if(i.snap)n.visibleWrites=TS(n.visibleWrites,i.path);else{const d=i.children;Dn(d,m=>{n.visibleWrites=TS(n.visibleWrites,zt(i.path,m))})}return!0}else return!1}function R6(n,e){if(n.snap)return _i(n.path,e);for(const t in n.children)if(n.children.hasOwnProperty(t)&&_i(zt(n.path,t),e))return!0;return!1}function C6(n){n.visibleWrites=Jx(n.allWrites,x6,Ye()),n.allWrites.length>0?n.lastWriteId=n.allWrites[n.allWrites.length-1].writeId:n.lastWriteId=-1}function x6(n){return n.visible}function Jx(n,e,t){let i=vi.empty();for(let a=0;a<n.length;++a){const l=n[a];if(e(l)){const u=l.path;let d;if(l.snap)_i(t,u)?(d=xn(t,u),i=uu(i,d,l.snap)):_i(u,t)&&(d=xn(u,t),i=uu(i,Ye(),l.snap.getChild(d)));else if(l.children){if(_i(t,u))d=xn(t,u),i=ES(i,d,l.children);else if(_i(u,t))if(d=xn(u,t),Me(d))i=ES(i,Ye(),l.children);else{const m=ol(l.children,Oe(d));if(m){const p=m.getChild(ht(d));i=uu(i,Ye(),p)}}}else throw El("WriteRecord should have .snap or .children")}}return i}function eI(n,e,t,i,a){if(!i&&!a){const l=eo(n.visibleWrites,e);if(l!=null)return l;{const u=kr(n.visibleWrites,e);if(j_(u))return t;if(t==null&&!U_(u,Ye()))return null;{const d=t||we.EMPTY_NODE;return gl(u,d)}}}else{const l=kr(n.visibleWrites,e);if(!a&&j_(l))return t;if(!a&&t==null&&!U_(l,Ye()))return null;{const u=function(p){return(p.visible||a)&&(!i||!~i.indexOf(p.writeId))&&(_i(p.path,e)||_i(e,p.path))},d=Jx(n.allWrites,u,e),m=t||we.EMPTY_NODE;return gl(d,m)}}}function I6(n,e,t){let i=we.EMPTY_NODE;const a=eo(n.visibleWrites,e);if(a)return a.isLeafNode()||a.forEachChild(yt,(l,u)=>{i=i.updateImmediateChild(l,u)}),i;if(t){const l=kr(n.visibleWrites,e);return t.forEachChild(yt,(u,d)=>{const m=gl(kr(l,new ot(u)),d);i=i.updateImmediateChild(u,m)}),bS(l).forEach(u=>{i=i.updateImmediateChild(u.name,u.node)}),i}else{const l=kr(n.visibleWrites,e);return bS(l).forEach(u=>{i=i.updateImmediateChild(u.name,u.node)}),i}}function N6(n,e,t,i,a){oe(i||a,"Either existingEventSnap or existingServerSnap must exist");const l=zt(e,t);if(U_(n.visibleWrites,l))return null;{const u=kr(n.visibleWrites,l);return j_(u)?a.getChild(t):gl(u,a.getChild(t))}}function k6(n,e,t,i){const a=zt(e,t),l=eo(n.visibleWrites,a);if(l!=null)return l;if(i.isCompleteForChild(t)){const u=kr(n.visibleWrites,a);return gl(u,i.getNode().getImmediateChild(t))}else return null}function D6(n,e){return eo(n.visibleWrites,e)}function O6(n,e,t,i,a,l,u){let d;const m=kr(n.visibleWrites,e),p=eo(m,Ye());if(p!=null)d=p;else if(t!=null)d=gl(m,t);else return[];if(d=d.withIndex(u),!d.isEmpty()&&!d.isLeafNode()){const y=[],T=u.getCompare(),w=l?d.getReverseIteratorFrom(i,u):d.getIteratorFrom(i,u);let x=w.getNext();for(;x&&y.length<a;)T(x,i)!==0&&y.push(x),x=w.getNext();return y}else return[]}function M6(){return{visibleWrites:vi.empty(),allWrites:[],lastWriteId:-1}}function kf(n,e,t,i){return eI(n.writeTree,n.treePath,e,t,i)}function _v(n,e){return I6(n.writeTree,n.treePath,e)}function wS(n,e,t,i){return N6(n.writeTree,n.treePath,e,t,i)}function Df(n,e){return D6(n.writeTree,zt(n.treePath,e))}function P6(n,e,t,i,a,l){return O6(n.writeTree,n.treePath,e,t,i,a,l)}function yv(n,e,t){return k6(n.writeTree,n.treePath,e,t)}function tI(n,e){return nI(zt(n.treePath,e),n.writeTree)}function nI(n,e){return{treePath:n,writeTree:e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L6{constructor(){this.changeMap=new Map}trackChildChange(e){const t=e.type,i=e.childName;oe(t==="child_added"||t==="child_changed"||t==="child_removed","Only child changes supported for tracking"),oe(i!==".priority","Only non-priority child changes can be tracked.");const a=this.changeMap.get(i);if(a){const l=a.type;if(t==="child_added"&&l==="child_removed")this.changeMap.set(i,Iu(i,e.snapshotNode,a.snapshotNode));else if(t==="child_removed"&&l==="child_added")this.changeMap.delete(i);else if(t==="child_removed"&&l==="child_changed")this.changeMap.set(i,xu(i,a.oldSnap));else if(t==="child_changed"&&l==="child_added")this.changeMap.set(i,pl(i,e.snapshotNode));else if(t==="child_changed"&&l==="child_changed")this.changeMap.set(i,Iu(i,e.snapshotNode,a.oldSnap));else throw El("Illegal combination of changes: "+e+" occurred after "+a)}else this.changeMap.set(i,e)}getChanges(){return Array.from(this.changeMap.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V6{getCompleteChild(e){return null}getChildAfterChild(e,t,i){return null}}const iI=new V6;class vv{constructor(e,t,i=null){this.writes_=e,this.viewCache_=t,this.optCompleteServerCache_=i}getCompleteChild(e){const t=this.viewCache_.eventCache;if(t.isCompleteForChild(e))return t.getNode().getImmediateChild(e);{const i=this.optCompleteServerCache_!=null?new $a(this.optCompleteServerCache_,!0,!1):this.viewCache_.serverCache;return yv(this.writes_,e,i)}}getChildAfterChild(e,t,i){const a=this.optCompleteServerCache_!=null?this.optCompleteServerCache_:Ka(this.viewCache_),l=P6(this.writes_,a,t,1,i,e);return l.length===0?null:l[0]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function U6(n){return{filter:n}}function j6(n,e){oe(e.eventCache.getNode().isIndexed(n.filter.getIndex()),"Event snap not indexed"),oe(e.serverCache.getNode().isIndexed(n.filter.getIndex()),"Server snap not indexed")}function z6(n,e,t,i,a){const l=new L6;let u,d;if(t.type===yi.OVERWRITE){const p=t;p.source.fromUser?u=z_(n,e,p.path,p.snap,i,a,l):(oe(p.source.fromServer,"Unknown source."),d=p.source.tagged||e.serverCache.isFiltered()&&!Me(p.path),u=Of(n,e,p.path,p.snap,i,a,d,l))}else if(t.type===yi.MERGE){const p=t;p.source.fromUser?u=B6(n,e,p.path,p.children,i,a,l):(oe(p.source.fromServer,"Unknown source."),d=p.source.tagged||e.serverCache.isFiltered(),u=F_(n,e,p.path,p.children,i,a,d,l))}else if(t.type===yi.ACK_USER_WRITE){const p=t;p.revert?u=G6(n,e,p.path,i,a,l):u=q6(n,e,p.path,p.affectedTree,i,a,l)}else if(t.type===yi.LISTEN_COMPLETE)u=H6(n,e,t.path,i,l);else throw El("Unknown operation type: "+t.type);const m=l.getChanges();return F6(e,u,m),{viewCache:u,changes:m}}function F6(n,e,t){const i=e.eventCache;if(i.isFullyInitialized()){const a=i.getNode().isLeafNode()||i.getNode().isEmpty(),l=V_(n);(t.length>0||!n.eventCache.isFullyInitialized()||a&&!i.getNode().equals(l)||!i.getNode().getPriority().equals(l.getPriority()))&&t.push(Qx(V_(e)))}}function sI(n,e,t,i,a,l){const u=e.eventCache;if(Df(i,t)!=null)return e;{let d,m;if(Me(t))if(oe(e.serverCache.isFullyInitialized(),"If change path is empty, we must have complete server data"),e.serverCache.isFiltered()){const p=Ka(e),y=p instanceof we?p:we.EMPTY_NODE,T=_v(i,y);d=n.filter.updateFullNode(e.eventCache.getNode(),T,l)}else{const p=kf(i,Ka(e));d=n.filter.updateFullNode(e.eventCache.getNode(),p,l)}else{const p=Oe(t);if(p===".priority"){oe(jr(t)===1,"Can't have a priority with additional path components");const y=u.getNode();m=e.serverCache.getNode();const T=wS(i,t,y,m);T!=null?d=n.filter.updatePriority(y,T):d=u.getNode()}else{const y=ht(t);let T;if(u.isCompleteForChild(p)){m=e.serverCache.getNode();const w=wS(i,t,u.getNode(),m);w!=null?T=u.getNode().getImmediateChild(p).updateChild(y,w):T=u.getNode().getImmediateChild(p)}else T=yv(i,p,e.serverCache);T!=null?d=n.filter.updateChild(u.getNode(),p,T,y,a,l):d=u.getNode()}}return cu(e,d,u.isFullyInitialized()||Me(t),n.filter.filtersNodes())}}function Of(n,e,t,i,a,l,u,d){const m=e.serverCache;let p;const y=u?n.filter:n.filter.getIndexedFilter();if(Me(t))p=y.updateFullNode(m.getNode(),i,null);else if(y.filtersNodes()&&!m.isFiltered()){const x=m.getNode().updateChild(t,i);p=y.updateFullNode(m.getNode(),x,null)}else{const x=Oe(t);if(!m.isCompleteForPath(t)&&jr(t)>1)return e;const I=ht(t),P=m.getNode().getImmediateChild(x).updateChild(I,i);x===".priority"?p=y.updatePriority(m.getNode(),P):p=y.updateChild(m.getNode(),x,P,I,iI,null)}const T=Xx(e,p,m.isFullyInitialized()||Me(t),y.filtersNodes()),w=new vv(a,T,l);return sI(n,T,t,a,w,d)}function z_(n,e,t,i,a,l,u){const d=e.eventCache;let m,p;const y=new vv(a,e,l);if(Me(t))p=n.filter.updateFullNode(e.eventCache.getNode(),i,u),m=cu(e,p,!0,n.filter.filtersNodes());else{const T=Oe(t);if(T===".priority")p=n.filter.updatePriority(e.eventCache.getNode(),i),m=cu(e,p,d.isFullyInitialized(),d.isFiltered());else{const w=ht(t),x=d.getNode().getImmediateChild(T);let I;if(Me(w))I=i;else{const O=y.getCompleteChild(T);O!=null?Ux(w)===".priority"&&O.getChild(zx(w)).isEmpty()?I=O:I=O.updateChild(w,i):I=we.EMPTY_NODE}if(x.equals(I))m=e;else{const O=n.filter.updateChild(d.getNode(),T,I,w,y,u);m=cu(e,O,d.isFullyInitialized(),n.filter.filtersNodes())}}}return m}function SS(n,e){return n.eventCache.isCompleteForChild(e)}function B6(n,e,t,i,a,l,u){let d=e;return i.foreach((m,p)=>{const y=zt(t,m);SS(e,Oe(y))&&(d=z_(n,d,y,p,a,l,u))}),i.foreach((m,p)=>{const y=zt(t,m);SS(e,Oe(y))||(d=z_(n,d,y,p,a,l,u))}),d}function AS(n,e,t){return t.foreach((i,a)=>{e=e.updateChild(i,a)}),e}function F_(n,e,t,i,a,l,u,d){if(e.serverCache.getNode().isEmpty()&&!e.serverCache.isFullyInitialized())return e;let m=e,p;Me(t)?p=i:p=new dt(null).setTree(t,i);const y=e.serverCache.getNode();return p.children.inorderTraversal((T,w)=>{if(y.hasChild(T)){const x=e.serverCache.getNode().getImmediateChild(T),I=AS(n,x,w);m=Of(n,m,new ot(T),I,a,l,u,d)}}),p.children.inorderTraversal((T,w)=>{const x=!e.serverCache.isCompleteForChild(T)&&w.value===null;if(!y.hasChild(T)&&!x){const I=e.serverCache.getNode().getImmediateChild(T),O=AS(n,I,w);m=Of(n,m,new ot(T),O,a,l,u,d)}}),m}function q6(n,e,t,i,a,l,u){if(Df(a,t)!=null)return e;const d=e.serverCache.isFiltered(),m=e.serverCache;if(i.value!=null){if(Me(t)&&m.isFullyInitialized()||m.isCompleteForPath(t))return Of(n,e,t,m.getNode().getChild(t),a,l,d,u);if(Me(t)){let p=new dt(null);return m.getNode().forEachChild(La,(y,T)=>{p=p.set(new ot(y),T)}),F_(n,e,t,p,a,l,d,u)}else return e}else{let p=new dt(null);return i.foreach((y,T)=>{const w=zt(t,y);m.isCompleteForPath(w)&&(p=p.set(y,m.getNode().getChild(w)))}),F_(n,e,t,p,a,l,d,u)}}function H6(n,e,t,i,a){const l=e.serverCache,u=Xx(e,l.getNode(),l.isFullyInitialized()||Me(t),l.isFiltered());return sI(n,u,t,i,iI,a)}function G6(n,e,t,i,a,l){let u;if(Df(i,t)!=null)return e;{const d=new vv(i,e,a),m=e.eventCache.getNode();let p;if(Me(t)||Oe(t)===".priority"){let y;if(e.serverCache.isFullyInitialized())y=kf(i,Ka(e));else{const T=e.serverCache.getNode();oe(T instanceof we,"serverChildren would be complete if leaf node"),y=_v(i,T)}y=y,p=n.filter.updateFullNode(m,y,l)}else{const y=Oe(t);let T=yv(i,y,e.serverCache);T==null&&e.serverCache.isCompleteForChild(y)&&(T=m.getImmediateChild(y)),T!=null?p=n.filter.updateChild(m,y,T,ht(t),d,l):e.eventCache.getNode().hasChild(y)?p=n.filter.updateChild(m,y,we.EMPTY_NODE,ht(t),d,l):p=m,p.isEmpty()&&e.serverCache.isFullyInitialized()&&(u=kf(i,Ka(e)),u.isLeafNode()&&(p=n.filter.updateFullNode(p,u,l)))}return u=e.serverCache.isFullyInitialized()||Df(i,Ye())!=null,cu(e,p,u,n.filter.filtersNodes())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $6{constructor(e,t){this.query_=e,this.eventRegistrations_=[];const i=this.query_._queryParams,a=new dv(i.getIndex()),l=c6(i);this.processor_=U6(l);const u=t.serverCache,d=t.eventCache,m=a.updateFullNode(we.EMPTY_NODE,u.getNode(),null),p=l.updateFullNode(we.EMPTY_NODE,d.getNode(),null),y=new $a(m,u.isFullyInitialized(),a.filtersNodes()),T=new $a(p,d.isFullyInitialized(),l.filtersNodes());this.viewCache_=pm(T,y),this.eventGenerator_=new y6(this.query_)}get query(){return this.query_}}function K6(n){return n.viewCache_.serverCache.getNode()}function Q6(n,e){const t=Ka(n.viewCache_);return t&&(n.query._queryParams.loadsAllData()||!Me(e)&&!t.getImmediateChild(Oe(e)).isEmpty())?t.getChild(e):null}function RS(n){return n.eventRegistrations_.length===0}function Y6(n,e){n.eventRegistrations_.push(e)}function CS(n,e,t){const i=[];if(t){oe(e==null,"A cancel should cancel all event registrations.");const a=n.query._path;n.eventRegistrations_.forEach(l=>{const u=l.createCancelEvent(t,a);u&&i.push(u)})}if(e){let a=[];for(let l=0;l<n.eventRegistrations_.length;++l){const u=n.eventRegistrations_[l];if(!u.matches(e))a.push(u);else if(e.hasAnyCallback()){a=a.concat(n.eventRegistrations_.slice(l+1));break}}n.eventRegistrations_=a}else n.eventRegistrations_=[];return i}function xS(n,e,t,i){e.type===yi.MERGE&&e.source.queryId!==null&&(oe(Ka(n.viewCache_),"We should always have a full cache before handling merges"),oe(V_(n.viewCache_),"Missing event cache, even though we have a server cache"));const a=n.viewCache_,l=z6(n.processor_,a,e,t,i);return j6(n.processor_,l.viewCache),oe(l.viewCache.serverCache.isFullyInitialized()||!a.serverCache.isFullyInitialized(),"Once a server snap is complete, it should never go back"),n.viewCache_=l.viewCache,rI(n,l.changes,l.viewCache.eventCache.getNode(),null)}function W6(n,e){const t=n.viewCache_.eventCache,i=[];return t.getNode().isLeafNode()||t.getNode().forEachChild(yt,(l,u)=>{i.push(pl(l,u))}),t.isFullyInitialized()&&i.push(Qx(t.getNode())),rI(n,i,t.getNode(),e)}function rI(n,e,t,i){const a=i?[i]:n.eventRegistrations_;return v6(n.eventGenerator_,e,t,a)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Mf;class X6{constructor(){this.views=new Map}}function Z6(n){oe(!Mf,"__referenceConstructor has already been defined"),Mf=n}function J6(){return oe(Mf,"Reference.ts has not been loaded"),Mf}function e9(n){return n.views.size===0}function Ev(n,e,t,i){const a=e.source.queryId;if(a!==null){const l=n.views.get(a);return oe(l!=null,"SyncTree gave us an op for an invalid query."),xS(l,e,t,i)}else{let l=[];for(const u of n.views.values())l=l.concat(xS(u,e,t,i));return l}}function t9(n,e,t,i,a){const l=e._queryIdentifier,u=n.views.get(l);if(!u){let d=kf(t,a?i:null),m=!1;d?m=!0:i instanceof we?(d=_v(t,i),m=!1):(d=we.EMPTY_NODE,m=!1);const p=pm(new $a(d,m,!1),new $a(i,a,!1));return new $6(e,p)}return u}function n9(n,e,t,i,a,l){const u=t9(n,e,i,a,l);return n.views.has(e._queryIdentifier)||n.views.set(e._queryIdentifier,u),Y6(u,t),W6(u,t)}function i9(n,e,t,i){const a=e._queryIdentifier,l=[];let u=[];const d=zr(n);if(a==="default")for(const[m,p]of n.views.entries())u=u.concat(CS(p,t,i)),RS(p)&&(n.views.delete(m),p.query._queryParams.loadsAllData()||l.push(p.query));else{const m=n.views.get(a);m&&(u=u.concat(CS(m,t,i)),RS(m)&&(n.views.delete(a),m.query._queryParams.loadsAllData()||l.push(m.query)))}return d&&!zr(n)&&l.push(new(J6())(e._repo,e._path)),{removed:l,events:u}}function aI(n){const e=[];for(const t of n.views.values())t.query._queryParams.loadsAllData()||e.push(t);return e}function al(n,e){let t=null;for(const i of n.views.values())t=t||Q6(i,e);return t}function oI(n,e){if(e._queryParams.loadsAllData())return gm(n);{const i=e._queryIdentifier;return n.views.get(i)}}function lI(n,e){return oI(n,e)!=null}function zr(n){return gm(n)!=null}function gm(n){for(const e of n.views.values())if(e.query._queryParams.loadsAllData())return e;return null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Pf;function s9(n){oe(!Pf,"__referenceConstructor has already been defined"),Pf=n}function r9(){return oe(Pf,"Reference.ts has not been loaded"),Pf}let a9=1;class IS{constructor(e){this.listenProvider_=e,this.syncPointTree_=new dt(null),this.pendingWriteTree_=M6(),this.tagToQueryMap=new Map,this.queryToTagMap=new Map}}function cI(n,e,t,i,a){return w6(n.pendingWriteTree_,e,t,i,a),a?Wu(n,new Ga(Wx(),e,t)):[]}function Pa(n,e,t=!1){const i=S6(n.pendingWriteTree_,e);if(A6(n.pendingWriteTree_,e)){let l=new dt(null);return i.snap!=null?l=l.set(Ye(),!0):Dn(i.children,u=>{l=l.set(new ot(u),!0)}),Wu(n,new Nf(i.path,l,t))}else return[]}function _m(n,e,t){return Wu(n,new Ga(mv(),e,t))}function o9(n,e,t){const i=dt.fromObject(t);return Wu(n,new Du(mv(),e,i))}function l9(n,e){return Wu(n,new ku(mv(),e))}function c9(n,e,t){const i=bv(n,t);if(i){const a=wv(i),l=a.path,u=a.queryId,d=xn(l,e),m=new ku(pv(u),d);return Sv(n,l,m)}else return[]}function B_(n,e,t,i,a=!1){const l=e._path,u=n.syncPointTree_.get(l);let d=[];if(u&&(e._queryIdentifier==="default"||lI(u,e))){const m=i9(u,e,t,i);e9(u)&&(n.syncPointTree_=n.syncPointTree_.remove(l));const p=m.removed;if(d=m.events,!a){const y=p.findIndex(w=>w._queryParams.loadsAllData())!==-1,T=n.syncPointTree_.findOnPath(l,(w,x)=>zr(x));if(y&&!T){const w=n.syncPointTree_.subtree(l);if(!w.isEmpty()){const x=d9(w);for(let I=0;I<x.length;++I){const O=x[I],P=O.query,B=dI(n,O);n.listenProvider_.startListening(hu(P),Lf(n,P),B.hashFn,B.onComplete)}}}!T&&p.length>0&&!i&&(y?n.listenProvider_.stopListening(hu(e),null):p.forEach(w=>{const x=n.queryToTagMap.get(ym(w));n.listenProvider_.stopListening(hu(w),x)}))}f9(n,p)}return d}function u9(n,e,t,i){const a=bv(n,i);if(a!=null){const l=wv(a),u=l.path,d=l.queryId,m=xn(u,e),p=new Ga(pv(d),m,t);return Sv(n,u,p)}else return[]}function h9(n,e,t,i){const a=bv(n,i);if(a){const l=wv(a),u=l.path,d=l.queryId,m=xn(u,e),p=dt.fromObject(t),y=new Du(pv(d),m,p);return Sv(n,u,y)}else return[]}function NS(n,e,t,i=!1){const a=e._path;let l=null,u=!1;n.syncPointTree_.foreachOnPath(a,(w,x)=>{const I=xn(w,a);l=l||al(x,I),u=u||zr(x)});let d=n.syncPointTree_.get(a);d?(u=u||zr(d),l=l||al(d,Ye())):(d=new X6,n.syncPointTree_=n.syncPointTree_.set(a,d));let m;l!=null?m=!0:(m=!1,l=we.EMPTY_NODE,n.syncPointTree_.subtree(a).foreachChild((x,I)=>{const O=al(I,Ye());O&&(l=l.updateImmediateChild(x,O))}));const p=lI(d,e);if(!p&&!e._queryParams.loadsAllData()){const w=ym(e);oe(!n.queryToTagMap.has(w),"View does not exist, but we have a tag");const x=m9();n.queryToTagMap.set(w,x),n.tagToQueryMap.set(x,w)}const y=gv(n.pendingWriteTree_,a);let T=n9(d,e,t,y,l,m);if(!p&&!u&&!i){const w=oI(d,e);T=T.concat(p9(n,e,w))}return T}function Tv(n,e,t){const a=n.pendingWriteTree_,l=n.syncPointTree_.findOnPath(e,(u,d)=>{const m=xn(u,e),p=al(d,m);if(p)return p});return eI(a,e,l,t,!0)}function Wu(n,e){return uI(e,n.syncPointTree_,null,gv(n.pendingWriteTree_,Ye()))}function uI(n,e,t,i){if(Me(n.path))return hI(n,e,t,i);{const a=e.get(Ye());t==null&&a!=null&&(t=al(a,Ye()));let l=[];const u=Oe(n.path),d=n.operationForChild(u),m=e.children.get(u);if(m&&d){const p=t?t.getImmediateChild(u):null,y=tI(i,u);l=l.concat(uI(d,m,p,y))}return a&&(l=l.concat(Ev(a,n,i,t))),l}}function hI(n,e,t,i){const a=e.get(Ye());t==null&&a!=null&&(t=al(a,Ye()));let l=[];return e.children.inorderTraversal((u,d)=>{const m=t?t.getImmediateChild(u):null,p=tI(i,u),y=n.operationForChild(u);y&&(l=l.concat(hI(y,d,m,p)))}),a&&(l=l.concat(Ev(a,n,i,t))),l}function dI(n,e){const t=e.query,i=Lf(n,t);return{hashFn:()=>(K6(e)||we.EMPTY_NODE).hash(),onComplete:a=>{if(a==="ok")return i?c9(n,t._path,i):l9(n,t._path);{const l=u3(a,t);return B_(n,t,null,l)}}}}function Lf(n,e){const t=ym(e);return n.queryToTagMap.get(t)}function ym(n){return n._path.toString()+"$"+n._queryIdentifier}function bv(n,e){return n.tagToQueryMap.get(e)}function wv(n){const e=n.indexOf("$");return oe(e!==-1&&e<n.length-1,"Bad queryKey."),{queryId:n.substr(e+1),path:new ot(n.substr(0,e))}}function Sv(n,e,t){const i=n.syncPointTree_.get(e);oe(i,"Missing sync point for query tag that we're tracking");const a=gv(n.pendingWriteTree_,e);return Ev(i,t,a,null)}function d9(n){return n.fold((e,t,i)=>{if(t&&zr(t))return[gm(t)];{let a=[];return t&&(a=aI(t)),Dn(i,(l,u)=>{a=a.concat(u)}),a}})}function hu(n){return n._queryParams.loadsAllData()&&!n._queryParams.isDefault()?new(r9())(n._repo,n._path):n}function f9(n,e){for(let t=0;t<e.length;++t){const i=e[t];if(!i._queryParams.loadsAllData()){const a=ym(i),l=n.queryToTagMap.get(a);n.queryToTagMap.delete(a),n.tagToQueryMap.delete(l)}}}function m9(){return a9++}function p9(n,e,t){const i=e._path,a=Lf(n,e),l=dI(n,t),u=n.listenProvider_.startListening(hu(e),a,l.hashFn,l.onComplete),d=n.syncPointTree_.subtree(i);if(a)oe(!zr(d.value),"If we're adding a query, it shouldn't be shadowed");else{const m=d.fold((p,y,T)=>{if(!Me(p)&&y&&zr(y))return[gm(y).query];{let w=[];return y&&(w=w.concat(aI(y).map(x=>x.query))),Dn(T,(x,I)=>{w=w.concat(I)}),w}});for(let p=0;p<m.length;++p){const y=m[p];n.listenProvider_.stopListening(hu(y),Lf(n,y))}}return u}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Av{constructor(e){this.node_=e}getImmediateChild(e){const t=this.node_.getImmediateChild(e);return new Av(t)}node(){return this.node_}}class Rv{constructor(e,t){this.syncTree_=e,this.path_=t}getImmediateChild(e){const t=zt(this.path_,e);return new Rv(this.syncTree_,t)}node(){return Tv(this.syncTree_,this.path_)}}const g9=function(n){return n=n||{},n.timestamp=n.timestamp||new Date().getTime(),n},kS=function(n,e,t){if(!n||typeof n!="object")return n;if(oe(".sv"in n,"Unexpected leaf node or priority contents"),typeof n[".sv"]=="string")return _9(n[".sv"],e,t);if(typeof n[".sv"]=="object")return y9(n[".sv"],e);oe(!1,"Unexpected server value: "+JSON.stringify(n,null,2))},_9=function(n,e,t){switch(n){case"timestamp":return t.timestamp;default:oe(!1,"Unexpected server value: "+n)}},y9=function(n,e,t){n.hasOwnProperty("increment")||oe(!1,"Unexpected server value: "+JSON.stringify(n,null,2));const i=n.increment;typeof i!="number"&&oe(!1,"Unexpected increment value: "+i);const a=e.node();if(oe(a!==null&&typeof a<"u","Expected ChildrenNode.EMPTY_NODE for nulls"),!a.isLeafNode())return i;const u=a.getValue();return typeof u!="number"?i:u+i},v9=function(n,e,t,i){return Cv(e,new Rv(t,n),i)},fI=function(n,e,t){return Cv(n,new Av(e),t)};function Cv(n,e,t){const i=n.getPriority().val(),a=kS(i,e.getImmediateChild(".priority"),t);let l;if(n.isLeafNode()){const u=n,d=kS(u.getValue(),e,t);return d!==u.getValue()||a!==u.getPriority().val()?new Yt(d,rn(a)):n}else{const u=n;return l=u,a!==u.getPriority().val()&&(l=l.updatePriority(new Yt(a))),u.forEachChild(yt,(d,m)=>{const p=Cv(m,e.getImmediateChild(d),t);p!==m&&(l=l.updateImmediateChild(d,p))}),l}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xv{constructor(e="",t=null,i={children:{},childCount:0}){this.name=e,this.parent=t,this.node=i}}function Iv(n,e){let t=e instanceof ot?e:new ot(e),i=n,a=Oe(t);for(;a!==null;){const l=ol(i.node.children,a)||{children:{},childCount:0};i=new xv(a,i,l),t=ht(t),a=Oe(t)}return i}function Nl(n){return n.node.value}function mI(n,e){n.node.value=e,q_(n)}function pI(n){return n.node.childCount>0}function E9(n){return Nl(n)===void 0&&!pI(n)}function vm(n,e){Dn(n.node.children,(t,i)=>{e(new xv(t,n,i))})}function gI(n,e,t,i){t&&e(n),vm(n,a=>{gI(a,e,!0)})}function T9(n,e,t){let i=n.parent;for(;i!==null;){if(e(i))return!0;i=i.parent}return!1}function Xu(n){return new ot(n.parent===null?n.name:Xu(n.parent)+"/"+n.name)}function q_(n){n.parent!==null&&b9(n.parent,n.name,n)}function b9(n,e,t){const i=E9(t),a=Wi(n.node.children,e);i&&a?(delete n.node.children[e],n.node.childCount--,q_(n)):!i&&!a&&(n.node.children[e]=t.node,n.node.childCount++,q_(n))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const w9=/[\[\].#$\/\u0000-\u001F\u007F]/,S9=/[\[\].#$\u0000-\u001F\u007F]/,Wg=10*1024*1024,_I=function(n){return typeof n=="string"&&n.length!==0&&!w9.test(n)},yI=function(n){return typeof n=="string"&&n.length!==0&&!S9.test(n)},A9=function(n){return n&&(n=n.replace(/^\/*\.info(\/|$)/,"/")),yI(n)},DS=function(n){return n===null||typeof n=="string"||typeof n=="number"&&!iv(n)||n&&typeof n=="object"&&Wi(n,".sv")},vI=function(n,e,t,i){i&&e===void 0||Nv(iy(n,"value"),e,t)},Nv=function(n,e,t){const i=t instanceof ot?new q3(t,n):t;if(e===void 0)throw new Error(n+"contains undefined "+ka(i));if(typeof e=="function")throw new Error(n+"contains a function "+ka(i)+" with contents = "+e.toString());if(iv(e))throw new Error(n+"contains "+e.toString()+" "+ka(i));if(typeof e=="string"&&e.length>Wg/3&&Hf(e)>Wg)throw new Error(n+"contains a string greater than "+Wg+" utf8 bytes "+ka(i)+" ('"+e.substring(0,50)+"...')");if(e&&typeof e=="object"){let a=!1,l=!1;if(Dn(e,(u,d)=>{if(u===".value")a=!0;else if(u!==".priority"&&u!==".sv"&&(l=!0,!_I(u)))throw new Error(n+" contains an invalid key ("+u+") "+ka(i)+`.  Keys must be non-empty strings and can't contain ".", "#", "$", "/", "[", or "]"`);H3(i,u),Nv(n,d,i),G3(i)}),a&&l)throw new Error(n+' contains ".value" child '+ka(i)+" in addition to actual children.")}},kv=function(n,e,t,i){if(!yI(t))throw new Error(iy(n,e)+'was an invalid path = "'+t+`". Paths must be non-empty strings and can't contain ".", "#", "$", "[", or "]"`)},R9=function(n,e,t,i){t&&(t=t.replace(/^\/*\.info(\/|$)/,"/")),kv(n,e,t)},EI=function(n,e){if(Oe(e)===".info")throw new Error(n+" failed = Can't modify data under /.info/")},C9=function(n,e){const t=e.path.toString();if(typeof e.repoInfo.host!="string"||e.repoInfo.host.length===0||!_I(e.repoInfo.namespace)&&e.repoInfo.host.split(":")[0]!=="localhost"||t.length!==0&&!A9(t))throw new Error(iy(n,"url")+`must be a valid firebase URL and the path can't contain ".", "#", "$", "[", or "]".`)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class x9{constructor(){this.eventLists_=[],this.recursionDepth_=0}}function Dv(n,e){let t=null;for(let i=0;i<e.length;i++){const a=e[i],l=a.getPath();t!==null&&!lv(l,t.path)&&(n.eventLists_.push(t),t=null),t===null&&(t={events:[],path:l}),t.events.push(a)}t&&n.eventLists_.push(t)}function TI(n,e,t){Dv(n,t),bI(n,i=>lv(i,e))}function Fs(n,e,t){Dv(n,t),bI(n,i=>_i(i,e)||_i(e,i))}function bI(n,e){n.recursionDepth_++;let t=!0;for(let i=0;i<n.eventLists_.length;i++){const a=n.eventLists_[i];if(a){const l=a.path;e(l)?(I9(n.eventLists_[i]),n.eventLists_[i]=null):t=!1}}t&&(n.eventLists_=[]),n.recursionDepth_--}function I9(n){for(let e=0;e<n.events.length;e++){const t=n.events[e];if(t!==null){n.events[e]=null;const i=t.getEventRunner();ou&&mn("event: "+t.toString()),Il(i)}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const N9="repo_interrupt",k9=25;class D9{constructor(e,t,i,a){this.repoInfo_=e,this.forceRestClient_=t,this.authTokenProvider_=i,this.appCheckProvider_=a,this.dataUpdateCount=0,this.statsListener_=null,this.eventQueue_=new x9,this.nextWriteId_=1,this.interceptServerDataCallback_=null,this.onDisconnect_=If(),this.transactionQueueTree_=new xv,this.persistentConnection_=null,this.key=this.repoInfo_.toURLString()}toString(){return(this.repoInfo_.secure?"https://":"http://")+this.repoInfo_.host}}function O9(n,e,t){if(n.stats_=av(n.repoInfo_),n.forceRestClient_||m3())n.server_=new xf(n.repoInfo_,(i,a,l,u)=>{OS(n,i,a,l,u)},n.authTokenProvider_,n.appCheckProvider_),setTimeout(()=>MS(n,!0),0);else{if(typeof t<"u"&&t!==null){if(typeof t!="object")throw new Error("Only objects are supported for option databaseAuthVariableOverride");try{Zt(t)}catch(i){throw new Error("Invalid authOverride provided: "+i)}}n.persistentConnection_=new Os(n.repoInfo_,e,(i,a,l,u)=>{OS(n,i,a,l,u)},i=>{MS(n,i)},i=>{M9(n,i)},n.authTokenProvider_,n.appCheckProvider_,t),n.server_=n.persistentConnection_}n.authTokenProvider_.addTokenChangeListener(i=>{n.server_.refreshAuthToken(i)}),n.appCheckProvider_.addTokenChangeListener(i=>{n.server_.refreshAppCheckToken(i.token)}),n.statsReporter_=v3(n.repoInfo_,()=>new _6(n.stats_,n.server_)),n.infoData_=new d6,n.infoSyncTree_=new IS({startListening:(i,a,l,u)=>{let d=[];const m=n.infoData_.getNode(i._path);return m.isEmpty()||(d=_m(n.infoSyncTree_,i._path,m),setTimeout(()=>{u("ok")},0)),d},stopListening:()=>{}}),Mv(n,"connected",!1),n.serverSyncTree_=new IS({startListening:(i,a,l,u)=>(n.server_.listen(i,l,a,(d,m)=>{const p=u(d,m);Fs(n.eventQueue_,i._path,p)}),[]),stopListening:(i,a)=>{n.server_.unlisten(i,a)}})}function wI(n){const t=n.infoData_.getNode(new ot(".info/serverTimeOffset")).val()||0;return new Date().getTime()+t}function Ov(n){return g9({timestamp:wI(n)})}function OS(n,e,t,i,a){n.dataUpdateCount++;const l=new ot(e);t=n.interceptServerDataCallback_?n.interceptServerDataCallback_(e,t):t;let u=[];if(a)if(i){const m=nf(t,p=>rn(p));u=h9(n.serverSyncTree_,l,m,a)}else{const m=rn(t);u=u9(n.serverSyncTree_,l,m,a)}else if(i){const m=nf(t,p=>rn(p));u=o9(n.serverSyncTree_,l,m)}else{const m=rn(t);u=_m(n.serverSyncTree_,l,m)}let d=l;u.length>0&&(d=Em(n,l)),Fs(n.eventQueue_,d,u)}function MS(n,e){Mv(n,"connected",e),e===!1&&L9(n)}function M9(n,e){Dn(e,(t,i)=>{Mv(n,t,i)})}function Mv(n,e,t){const i=new ot("/.info/"+e),a=rn(t);n.infoData_.updateSnapshot(i,a);const l=_m(n.infoSyncTree_,i,a);Fs(n.eventQueue_,i,l)}function SI(n){return n.nextWriteId_++}function P9(n,e,t,i,a){Pv(n,"set",{path:e.toString(),value:t,priority:i});const l=Ov(n),u=rn(t,i),d=Tv(n.serverSyncTree_,e),m=fI(u,d,l),p=SI(n),y=cI(n.serverSyncTree_,e,m,p,!0);Dv(n.eventQueue_,y),n.server_.put(e.toString(),u.val(!0),(w,x)=>{const I=w==="ok";I||kn("set at "+e+" failed: "+w);const O=Pa(n.serverSyncTree_,p,!I);Fs(n.eventQueue_,e,O),z9(n,a,w,x)});const T=II(n,e);Em(n,T),Fs(n.eventQueue_,T,[])}function L9(n){Pv(n,"onDisconnectEvents");const e=Ov(n),t=If();L_(n.onDisconnect_,Ye(),(a,l)=>{const u=v9(a,l,n.serverSyncTree_,e);Yx(t,a,u)});let i=[];L_(t,Ye(),(a,l)=>{i=i.concat(_m(n.serverSyncTree_,a,l));const u=II(n,a);Em(n,u)}),n.onDisconnect_=If(),Fs(n.eventQueue_,Ye(),i)}function V9(n,e,t){let i;Oe(e._path)===".info"?i=NS(n.infoSyncTree_,e,t):i=NS(n.serverSyncTree_,e,t),TI(n.eventQueue_,e._path,i)}function U9(n,e,t){let i;Oe(e._path)===".info"?i=B_(n.infoSyncTree_,e,t):i=B_(n.serverSyncTree_,e,t),TI(n.eventQueue_,e._path,i)}function j9(n){n.persistentConnection_&&n.persistentConnection_.interrupt(N9)}function Pv(n,...e){let t="";n.persistentConnection_&&(t=n.persistentConnection_.id+":"),mn(t,...e)}function z9(n,e,t,i){e&&Il(()=>{if(t==="ok")e(null);else{const a=(t||"error").toUpperCase();let l=a;i&&(l+=": "+i);const u=new Error(l);u.code=a,e(u)}})}function AI(n,e,t){return Tv(n.serverSyncTree_,e,t)||we.EMPTY_NODE}function Lv(n,e=n.transactionQueueTree_){if(e||Tm(n,e),Nl(e)){const t=CI(n,e);oe(t.length>0,"Sending zero length transaction queue"),t.every(a=>a.status===0)&&F9(n,Xu(e),t)}else pI(e)&&vm(e,t=>{Lv(n,t)})}function F9(n,e,t){const i=t.map(p=>p.currentWriteId),a=AI(n,e,i);let l=a;const u=a.hash();for(let p=0;p<t.length;p++){const y=t[p];oe(y.status===0,"tryToSendTransactionQueue_: items in queue should all be run."),y.status=1,y.retryCount++;const T=xn(e,y.path);l=l.updateChild(T,y.currentOutputSnapshotRaw)}const d=l.val(!0),m=e;n.server_.put(m.toString(),d,p=>{Pv(n,"transaction put response",{path:m.toString(),status:p});let y=[];if(p==="ok"){const T=[];for(let w=0;w<t.length;w++)t[w].status=2,y=y.concat(Pa(n.serverSyncTree_,t[w].currentWriteId)),t[w].onComplete&&T.push(()=>t[w].onComplete(null,!0,t[w].currentOutputSnapshotResolved)),t[w].unwatcher();Tm(n,Iv(n.transactionQueueTree_,e)),Lv(n,n.transactionQueueTree_),Fs(n.eventQueue_,e,y);for(let w=0;w<T.length;w++)Il(T[w])}else{if(p==="datastale")for(let T=0;T<t.length;T++)t[T].status===3?t[T].status=4:t[T].status=0;else{kn("transaction at "+m.toString()+" failed: "+p);for(let T=0;T<t.length;T++)t[T].status=4,t[T].abortReason=p}Em(n,e)}},u)}function Em(n,e){const t=RI(n,e),i=Xu(t),a=CI(n,t);return B9(n,a,i),i}function B9(n,e,t){if(e.length===0)return;const i=[];let a=[];const u=e.filter(d=>d.status===0).map(d=>d.currentWriteId);for(let d=0;d<e.length;d++){const m=e[d],p=xn(t,m.path);let y=!1,T;if(oe(p!==null,"rerunTransactionsUnderNode_: relativePath should not be null."),m.status===4)y=!0,T=m.abortReason,a=a.concat(Pa(n.serverSyncTree_,m.currentWriteId,!0));else if(m.status===0)if(m.retryCount>=k9)y=!0,T="maxretry",a=a.concat(Pa(n.serverSyncTree_,m.currentWriteId,!0));else{const w=AI(n,m.path,u);m.currentInputSnapshot=w;const x=e[d].update(w.val());if(x!==void 0){Nv("transaction failed: Data returned ",x,m.path);let I=rn(x);typeof x=="object"&&x!=null&&Wi(x,".priority")||(I=I.updatePriority(w.getPriority()));const P=m.currentWriteId,B=Ov(n),ee=fI(I,w,B);m.currentOutputSnapshotRaw=I,m.currentOutputSnapshotResolved=ee,m.currentWriteId=SI(n),u.splice(u.indexOf(P),1),a=a.concat(cI(n.serverSyncTree_,m.path,ee,m.currentWriteId,m.applyLocally)),a=a.concat(Pa(n.serverSyncTree_,P,!0))}else y=!0,T="nodata",a=a.concat(Pa(n.serverSyncTree_,m.currentWriteId,!0))}Fs(n.eventQueue_,t,a),a=[],y&&(e[d].status=2,function(w){setTimeout(w,Math.floor(0))}(e[d].unwatcher),e[d].onComplete&&(T==="nodata"?i.push(()=>e[d].onComplete(null,!1,e[d].currentInputSnapshot)):i.push(()=>e[d].onComplete(new Error(T),!1,null))))}Tm(n,n.transactionQueueTree_);for(let d=0;d<i.length;d++)Il(i[d]);Lv(n,n.transactionQueueTree_)}function RI(n,e){let t,i=n.transactionQueueTree_;for(t=Oe(e);t!==null&&Nl(i)===void 0;)i=Iv(i,t),e=ht(e),t=Oe(e);return i}function CI(n,e){const t=[];return xI(n,e,t),t.sort((i,a)=>i.order-a.order),t}function xI(n,e,t){const i=Nl(e);if(i)for(let a=0;a<i.length;a++)t.push(i[a]);vm(e,a=>{xI(n,a,t)})}function Tm(n,e){const t=Nl(e);if(t){let i=0;for(let a=0;a<t.length;a++)t[a].status!==2&&(t[i]=t[a],i++);t.length=i,mI(e,t.length>0?t:void 0)}vm(e,i=>{Tm(n,i)})}function II(n,e){const t=Xu(RI(n,e)),i=Iv(n.transactionQueueTree_,e);return T9(i,a=>{Xg(n,a)}),Xg(n,i),gI(i,a=>{Xg(n,a)}),t}function Xg(n,e){const t=Nl(e);if(t){const i=[];let a=[],l=-1;for(let u=0;u<t.length;u++)t[u].status===3||(t[u].status===1?(oe(l===u-1,"All SENT items should be at beginning of queue."),l=u,t[u].status=3,t[u].abortReason="set"):(oe(t[u].status===0,"Unexpected transaction status in abort"),t[u].unwatcher(),a=a.concat(Pa(n.serverSyncTree_,t[u].currentWriteId,!0)),t[u].onComplete&&i.push(t[u].onComplete.bind(null,new Error("set"),!1,null))));l===-1?mI(e,void 0):t.length=l+1,Fs(n.eventQueue_,Xu(e),a);for(let u=0;u<i.length;u++)Il(i[u])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function q9(n){let e="";const t=n.split("/");for(let i=0;i<t.length;i++)if(t[i].length>0){let a=t[i];try{a=decodeURIComponent(a.replace(/\+/g," "))}catch{}e+="/"+a}return e}function H9(n){const e={};n.charAt(0)==="?"&&(n=n.substring(1));for(const t of n.split("&")){if(t.length===0)continue;const i=t.split("=");i.length===2?e[decodeURIComponent(i[0])]=decodeURIComponent(i[1]):kn(`Invalid query segment '${t}' in query '${n}'`)}return e}const PS=function(n,e){const t=G9(n),i=t.namespace;t.domain==="firebase.com"&&zs(t.host+" is no longer supported. Please use <YOUR FIREBASE>.firebaseio.com instead"),(!i||i==="undefined")&&t.domain!=="localhost"&&zs("Cannot parse Firebase url. Please use https://<YOUR FIREBASE>.firebaseio.com"),t.secure||r3();const a=t.scheme==="ws"||t.scheme==="wss";return{repoInfo:new Ix(t.host,t.secure,i,a,e,"",i!==t.subdomain),path:new ot(t.pathString)}},G9=function(n){let e="",t="",i="",a="",l="",u=!0,d="https",m=443;if(typeof n=="string"){let p=n.indexOf("//");p>=0&&(d=n.substring(0,p-1),n=n.substring(p+2));let y=n.indexOf("/");y===-1&&(y=n.length);let T=n.indexOf("?");T===-1&&(T=n.length),e=n.substring(0,Math.min(y,T)),y<T&&(a=q9(n.substring(y,T)));const w=H9(n.substring(Math.min(n.length,T)));p=e.indexOf(":"),p>=0?(u=d==="https"||d==="wss",m=parseInt(e.substring(p+1),10)):p=e.length;const x=e.slice(0,p);if(x.toLowerCase()==="localhost")t="localhost";else if(x.split(".").length<=2)t=x;else{const I=e.indexOf(".");i=e.substring(0,I).toLowerCase(),t=e.substring(I+1),l=i}"ns"in w&&(l=w.ns)}return{host:e,port:m,domain:t,subdomain:i,secure:u,scheme:d,pathString:a,namespace:l}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const LS="-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz",$9=function(){let n=0;const e=[];return function(t){const i=t===n;n=t;let a;const l=new Array(8);for(a=7;a>=0;a--)l[a]=LS.charAt(t%64),t=Math.floor(t/64);oe(t===0,"Cannot push at time == 0");let u=l.join("");if(i){for(a=11;a>=0&&e[a]===63;a--)e[a]=0;e[a]++}else for(a=0;a<12;a++)e[a]=Math.floor(Math.random()*64);for(a=0;a<12;a++)u+=LS.charAt(e[a]);return oe(u.length===20,"nextPushId: Length should be 20."),u}}();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class K9{constructor(e,t,i,a){this.eventType=e,this.eventRegistration=t,this.snapshot=i,this.prevName=a}getPath(){const e=this.snapshot.ref;return this.eventType==="value"?e._path:e.parent._path}getEventType(){return this.eventType}getEventRunner(){return this.eventRegistration.getEventRunner(this)}toString(){return this.getPath().toString()+":"+this.eventType+":"+Zt(this.snapshot.exportVal())}}class Q9{constructor(e,t,i){this.eventRegistration=e,this.error=t,this.path=i}getPath(){return this.path}getEventType(){return"cancel"}getEventRunner(){return this.eventRegistration.getEventRunner(this)}toString(){return this.path.toString()+":cancel"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Y9{constructor(e,t){this.snapshotCallback=e,this.cancelCallback=t}onValue(e,t){this.snapshotCallback.call(null,e,t)}onCancel(e){return oe(this.hasCancelCallback,"Raising a cancel event on a listener with no cancel callback"),this.cancelCallback.call(null,e)}get hasCancelCallback(){return!!this.cancelCallback}matches(e){return this.snapshotCallback===e.snapshotCallback||this.snapshotCallback.userCallback!==void 0&&this.snapshotCallback.userCallback===e.snapshotCallback.userCallback&&this.snapshotCallback.context===e.snapshotCallback.context}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Zu{constructor(e,t,i,a){this._repo=e,this._path=t,this._queryParams=i,this._orderByCalled=a}get key(){return Me(this._path)?null:Ux(this._path)}get ref(){return new $r(this._repo,this._path)}get _queryIdentifier(){const e=yS(this._queryParams),t=sv(e);return t==="{}"?"default":t}get _queryObject(){return yS(this._queryParams)}isEqual(e){if(e=at(e),!(e instanceof Zu))return!1;const t=this._repo===e._repo,i=lv(this._path,e._path),a=this._queryIdentifier===e._queryIdentifier;return t&&i&&a}toJSON(){return this.toString()}toString(){return this._repo.toString()+B3(this._path)}}function W9(n,e){if(n._orderByCalled===!0)throw new Error(e+": You can't combine multiple orderBy calls.")}function X9(n){let e=null,t=null;if(n.hasStart()&&(e=n.getIndexStartValue()),n.hasEnd()&&(t=n.getIndexEndValue()),n.getIndex()===La){const i="Query: When ordering by key, you may only pass one argument to startAt(), endAt(), or equalTo().",a="Query: When ordering by key, the argument passed to startAt(), startAfter(), endAt(), endBefore(), or equalTo() must be a string.";if(n.hasStart()){if(n.getIndexStartName()!==Ha)throw new Error(i);if(typeof e!="string")throw new Error(a)}if(n.hasEnd()){if(n.getIndexEndName()!==Ur)throw new Error(i);if(typeof t!="string")throw new Error(a)}}else if(n.getIndex()===yt){if(e!=null&&!DS(e)||t!=null&&!DS(t))throw new Error("Query: When ordering by priority, the first argument passed to startAt(), startAfter() endAt(), endBefore(), or equalTo() must be a valid priority value (null, a number, or a string).")}else if(oe(n.getIndex()instanceof hv||n.getIndex()===Kx,"unknown index type."),e!=null&&typeof e=="object"||t!=null&&typeof t=="object")throw new Error("Query: First argument passed to startAt(), startAfter(), endAt(), endBefore(), or equalTo() cannot be an object.")}class $r extends Zu{constructor(e,t){super(e,t,new fv,!1)}get parent(){const e=zx(this._path);return e===null?null:new $r(this._repo,e)}get root(){let e=this;for(;e.parent!==null;)e=e.parent;return e}}class Vf{constructor(e,t,i){this._node=e,this.ref=t,this._index=i}get priority(){return this._node.getPriority().val()}get key(){return this.ref.key}get size(){return this._node.numChildren()}child(e){const t=new ot(e),i=Ou(this.ref,e);return new Vf(this._node.getChild(t),i,yt)}exists(){return!this._node.isEmpty()}exportVal(){return this._node.val(!0)}forEach(e){return this._node.isLeafNode()?!1:!!this._node.forEachChild(this._index,(i,a)=>e(new Vf(a,Ou(this.ref,i),yt)))}hasChild(e){const t=new ot(e);return!this._node.getChild(t).isEmpty()}hasChildren(){return this._node.isLeafNode()?!1:!this._node.isEmpty()}toJSON(){return this.exportVal()}val(){return this._node.val()}}function Ld(n,e){return n=at(n),n._checkNotDeleted("ref"),e!==void 0?Ou(n._root,e):n._root}function Ou(n,e){return n=at(n),Oe(n._path)===null?R9("child","path",e):kv("child","path",e),new $r(n._repo,zt(n._path,e))}function Z9(n,e){n=at(n),EI("push",n._path),vI("push",e,n._path,!0);const t=wI(n._repo),i=$9(t),a=Ou(n,i),l=Ou(n,i);let u;return u=Promise.resolve(l),a.then=u.then.bind(u),a.catch=u.then.bind(u,void 0),a}function Zg(n,e){n=at(n),EI("set",n._path),vI("set",e,n._path,!1);const t=new qf;return P9(n._repo,n._path,e,null,t.wrapCallback(()=>{})),t.promise}class Vv{constructor(e){this.callbackContext=e}respondsTo(e){return e==="value"}createEvent(e,t){const i=t._queryParams.getIndex();return new K9("value",this,new Vf(e.snapshotNode,new $r(t._repo,t._path),i))}getEventRunner(e){return e.getEventType()==="cancel"?()=>this.callbackContext.onCancel(e.error):()=>this.callbackContext.onValue(e.snapshot,null)}createCancelEvent(e,t){return this.callbackContext.hasCancelCallback?new Q9(this,e,t):null}matches(e){return e instanceof Vv?!e.callbackContext||!this.callbackContext?!0:e.callbackContext.matches(this.callbackContext):!1}hasAnyCallback(){return this.callbackContext!==null}}function J9(n,e,t,i,a){const l=new Y9(t,void 0),u=new Vv(l);return V9(n._repo,n,u),()=>U9(n._repo,n,u)}function VS(n,e,t,i){return J9(n,"value",e)}class NI{}class ez extends NI{constructor(e){super(),this._limit=e,this.type="limitToLast"}_apply(e){if(e._queryParams.hasLimit())throw new Error("limitToLast: Limit was already set (by another call to limitToFirst or limitToLast).");return new Zu(e._repo,e._path,u6(e._queryParams,this._limit),e._orderByCalled)}}function tz(n){if(Math.floor(n)!==n||n<=0)throw new Error("limitToLast: First argument must be a positive integer.");return new ez(n)}class nz extends NI{constructor(e){super(),this._path=e,this.type="orderByChild"}_apply(e){W9(e,"orderByChild");const t=new ot(this._path);if(Me(t))throw new Error("orderByChild: cannot pass in empty path. Use orderByValue() instead.");const i=new hv(t),a=h6(e._queryParams,i);return X9(a),new Zu(e._repo,e._path,a,!0)}}function iz(n){return kv("orderByChild","path",n),new nz(n)}function sz(n,...e){let t=at(n);for(const i of e)t=i._apply(t);return t}Z6($r);s9($r);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rz="FIREBASE_DATABASE_EMULATOR_HOST",H_={};let az=!1;function oz(n,e,t,i){n.repoInfo_=new Ix(e,!1,n.repoInfo_.namespace,n.repoInfo_.webSocketOnly,n.repoInfo_.nodeAdmin,n.repoInfo_.persistenceKey,n.repoInfo_.includeNamespaceInQueryParams,!0,t),i&&(n.authTokenProvider_=i)}function lz(n,e,t,i,a){let l=i||n.options.databaseURL;l===void 0&&(n.options.projectId||zs("Can't determine Firebase Database URL. Be sure to include  a Project ID when calling firebase.initializeApp()."),mn("Using default host for project ",n.options.projectId),l=`${n.options.projectId}-default-rtdb.firebaseio.com`);let u=PS(l,a),d=u.repoInfo,m;typeof process<"u"&&eS&&(m=eS[rz]),m?(l=`http://${m}?ns=${d.namespace}`,u=PS(l,a),d=u.repoInfo):u.repoInfo.secure;const p=new g3(n.name,n.options,e);C9("Invalid Firebase Database URL",u),Me(u.path)||zs("Database URL must point to the root of a Firebase Database (not including a child path).");const y=uz(d,n,p,new p3(n,t));return new hz(y,n)}function cz(n,e){const t=H_[e];(!t||t[n.key]!==n)&&zs(`Database ${e}(${n.repoInfo_}) has already been deleted.`),j9(n),delete t[n.key]}function uz(n,e,t,i){let a=H_[e.name];a||(a={},H_[e.name]=a);let l=a[n.toURLString()];return l&&zs("Database initialized multiple times. Please make sure the format of the database URL matches with each database() call."),l=new D9(n,az,t,i),a[n.toURLString()]=l,l}class hz{constructor(e,t){this._repoInternal=e,this.app=t,this.type="database",this._instanceStarted=!1}get _repo(){return this._instanceStarted||(O9(this._repoInternal,this.app.options.appId,this.app.options.databaseAuthVariableOverride),this._instanceStarted=!0),this._repoInternal}get _root(){return this._rootInternal||(this._rootInternal=new $r(this._repo,Ye())),this._rootInternal}_delete(){return this._rootInternal!==null&&(cz(this._repo,this.app.name),this._repoInternal=null,this._rootInternal=null),Promise.resolve()}_checkNotDeleted(e){this._rootInternal===null&&zs("Cannot call "+e+" on a deleted database.")}}function dz(n=Vu(),e){const t=qs(n,"database").getImmediate({identifier:e});if(!t._instanceStarted){const i=ey("database");i&&fz(t,...i)}return t}function fz(n,e,t,i={}){n=at(n),n._checkNotDeleted("useEmulator");const a=`${e}:${t}`,l=n._repoInternal;if(n._instanceStarted){if(a===n._repoInternal.repoInfo_.host&&Ps(i,l.repoInfo_.emulatorOptions))return;zs("connectDatabaseEmulator() cannot initialize or alter the emulator configuration after the database instance has started.")}let u;if(l.repoInfo_.nodeAdmin)i.mockUserToken&&zs('mockUserToken is not supported by the Admin SDK. For client access with mock users, please use the "firebase" package instead of "firebase-admin".'),u=new Xd(Xd.OWNER);else if(i.mockUserToken){const d=typeof i.mockUserToken=="string"?i.mockUserToken:ty(i.mockUserToken,n.app.options.projectId);u=new Xd(d)}oz(l,a,i,u)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mz(n){Jj(Fr),ri(new Hn("database",(e,{instanceIdentifier:t})=>{const i=e.getProvider("app").getImmediate(),a=e.getProvider("auth-internal"),l=e.getProvider("app-check-internal");return lz(i,a,l,t)},"PUBLIC").setMultipleInstances(!0)),pn(tS,nS,n),pn(tS,nS,"esm2017")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pz={".sv":"timestamp"};function gz(){return pz}Os.prototype.simpleListen=function(n,e){this.sendRequest("q",{p:n},e)};Os.prototype.echo=function(n,e){this.sendRequest("echo",{d:n},e)};mz();const _z={apiKey:"AIzaSyBKIIEdLFyvyugM8D3Pr5L-V0EzBLFpp98",authDomain:"comet-news-app.firebaseapp.com",projectId:"comet-news-app",storageBucket:"comet-news-app.firebasestorage.app",messagingSenderId:"41156810926",appId:"1:41156810926:web:7fb7a1b6f2f91ecdf8753f",measurementId:"G-GPVV60J73H",databaseURL:"https://comet-news-app-default-rtdb.firebaseio.com"},Ju=wA(_z);GM(Ju);const Is=H4(Ju),Uf=bj(Ju);Yj(Ju);const Vd=dz(Ju),kI=j.createContext(),eh=()=>j.useContext(kI),yz=({children:n})=>{const[e,t]=j.useState(null),[i,a]=j.useState(null),[l,u]=j.useState(!0),d=async p=>{if(!p)return null;try{const y=await Ky(Fa(Is,"users",p.uid));return y.exists()?y.data():(console.log("No profile data found for user"),null)}catch(y){return console.error("Error fetching user profile:",y),null}};j.useEffect(()=>uU(Uf,async y=>{if(t(y),y){const T=await d(y);a(T)}else a(null);u(!1)}),[]);const m={currentUser:e,userProfile:i,isAuthenticated:!!e,isAdmin:(i==null?void 0:i.role)==="admin",isModerator:(i==null?void 0:i.role)==="moderator"||(i==null?void 0:i.role)==="admin",loading:l};return v.jsx(kI.Provider,{value:m,children:!l&&n})},vz=({onCloseMobile:n})=>{const e=Yi(),t=Bs(),{theme:i,toggleTheme:a}=oA(),{isAuthenticated:l,userProfile:u,isAdmin:d}=eh(),m=y=>e.pathname===y,p=async()=>{try{await hU(Uf),t("/"),n&&n()}catch(y){console.error("Error signing out:",y)}};return v.jsxs("div",{className:"flex h-full flex-col bg-[hsl(var(--sidebar-background))] p-6 w-72",children:[v.jsxs("div",{className:"flex items-center justify-between w-full mb-6",children:[v.jsxs(At,{to:"/",className:"flex items-center gap-2",children:[v.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground",children:v.jsxs("svg",{viewBox:"0 0 24 24",className:"h-5 w-5",fill:"currentColor",children:[v.jsx("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"}),v.jsx("path",{d:"M8 12l4-4 4 4-4 4z"})]})}),v.jsx("span",{className:"text-2xl font-bold text-blue-500",children:"Comet"})]}),v.jsxs("div",{className:"flex items-center",children:[v.jsx("button",{onClick:a,className:"flex h-8 w-8 items-center justify-center rounded-full bg-sidebar-accent hover:bg-sidebar-accent/80 text-sidebar-foreground transition-colors","aria-label":i==="dark"?"Switch to light mode":"Switch to dark mode",children:i==="dark"?v.jsx(sA,{size:16}):v.jsx(tA,{size:16})}),v.jsx("button",{className:"ml-2 rounded-full p-1.5 text-sidebar-foreground hover:bg-sidebar-accent lg:hidden",onClick:n,"aria-label":"Close sidebar",children:v.jsx(fu,{size:20})})]})]}),v.jsxs("div",{className:"flex flex-1 flex-col gap-1",children:[v.jsxs(At,{to:"/",className:`flex items-center gap-3 rounded-md px-3 py-2 transition-colors ${m("/")?"bg-sidebar-accent font-medium text-sidebar-accent-foreground":"text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`,onClick:n,children:[v.jsx(ak,{size:20}),v.jsx("span",{children:"Home"})]}),v.jsxs(At,{to:"/chat",className:`flex items-center gap-3 rounded-md px-3 py-2 transition-colors ${m("/chat")?"bg-sidebar-accent font-medium text-sidebar-accent-foreground":"text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`,onClick:n,children:[v.jsx(As,{size:20}),v.jsx("span",{children:"Live Chat"})]}),d&&v.jsxs(At,{to:"/admin",className:`flex items-center gap-3 rounded-md px-3 py-2 transition-colors ${m("/admin")?"bg-sidebar-accent font-medium text-sidebar-accent-foreground":"text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`,onClick:n,children:[v.jsx(iA,{size:20}),v.jsx("span",{children:"Admin Dashboard"})]})]}),v.jsx("div",{className:"mt-auto",children:l?v.jsxs("div",{className:"space-y-3",children:[v.jsxs("div",{className:"flex items-center gap-3 px-2 py-3",children:[v.jsx("div",{className:"flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground",children:v.jsx(Uk,{size:18})}),v.jsxs("div",{className:"flex-1 overflow-hidden",children:[v.jsx("h3",{className:"truncate font-medium text-sidebar-foreground",children:(u==null?void 0:u.name)||"User"}),v.jsx("p",{className:"truncate text-xs text-sidebar-muted",children:(u==null?void 0:u.role)==="admin"?"Administrator":(u==null?void 0:u.role)==="moderator"?"Moderator":"User"})]})]}),v.jsx(Dt,{variant:"outline",className:"w-full justify-center border-sidebar-border text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",leftIcon:v.jsx(mk,{size:16}),onClick:p,children:"Logout"})]}):v.jsx(At,{to:"/login",children:v.jsx(Dt,{variant:"outline",className:"w-full justify-center border-sidebar-border text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",leftIcon:v.jsx(dk,{size:16}),onClick:n,children:"Login"})})})]})},DI=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1",OI="/api-proxy.php",Ez=async({country:n="us",category:e="",pageSize:t=10,page:i=1}={})=>{try{const a=new URLSearchParams({country:n,pageSize:t,page:i});if(e&&e!=="all"&&a.append("category",e.toLowerCase()),DI){a.append("apiKey","9e86b086579e4564ade2222bd30716ff");const u=await(await fetch(`https://newsapi.org/v2/top-headlines?${a.toString()}`)).json();if(u.status!=="ok")throw new Error(u.message||"Error fetching news");return u}else{a.append("endpoint","top-headlines");const u=await(await fetch(`${OI}?${a.toString()}`)).json();if(u.status!=="ok")throw new Error(u.message||"Error fetching news");return u}}catch(a){throw console.error("Error fetching top headlines:",a),a}},Tz=async({query:n,language:e="en",sortBy:t="publishedAt",pageSize:i=10,page:a=1}={})=>{try{const l=new URLSearchParams({q:n,language:e,sortBy:t,pageSize:i,page:a});if(DI){l.append("apiKey","9e86b086579e4564ade2222bd30716ff");const d=await(await fetch(`https://newsapi.org/v2/everything?${l.toString()}`)).json();if(d.status!=="ok")throw new Error(d.message||"Error searching news");return d}else{l.append("endpoint","everything");const d=await(await fetch(`${OI}?${l.toString()}`)).json();if(d.status!=="ok")throw new Error(d.message||"Error searching news");return d}}catch(l){throw console.error("Error searching news:",l),l}},jf=n=>{const e=new Date,t=new Date(n),i=e-t,a=Math.round(i/1e3),l=Math.round(a/60),u=Math.round(l/60),d=Math.round(u/24);if(a<60)return`${a} seconds ago`;if(l<60)return`${l} minute${l===1?"":"s"} ago`;if(u<24)return`${u} hour${u===1?"":"s"} ago`;if(d<7)return`${d} day${d===1?"":"s"} ago`;{const m={year:"numeric",month:"short",day:"numeric"};return t.toLocaleDateString("en-US",m)}},US="https://placehold.co/600x400?text=No+Image+Available",bz=()=>{const[n,e]=j.useState(""),[t,i]=j.useState(!1),[a,l]=j.useState([]),[u,d]=j.useState(!1),[m,p]=j.useState(null),[y,T]=j.useState(!1),w=j.useRef(null),x=j.useRef(null);j.useEffect(()=>{const B=ee=>{w.current&&!w.current.contains(ee.target)&&T(!1)};return document.addEventListener("mousedown",B),()=>{document.removeEventListener("mousedown",B)}},[]),j.useEffect(()=>{const B=ee=>{var Y;(ee.ctrlKey||ee.metaKey)&&ee.key==="k"?(ee.preventDefault(),(Y=x.current)==null||Y.focus()):ee.key==="Escape"&&T(!1)};return window.addEventListener("keydown",B),()=>{window.removeEventListener("keydown",B)}},[]);const I=async()=>{if(n.trim()){i(!0),d(!0),p(null),T(!0);try{const B=await Tz({query:n,pageSize:5});l(B.articles||[])}catch(B){console.error("Error searching news:",B),p("Failed to search for news. Please try again.")}finally{d(!1)}}},O=B=>{B.key==="Enter"&&I()},P=()=>{e(""),i(!1),l([]),T(!1)};return v.jsxs("div",{className:"relative w-full",ref:w,children:[v.jsxs("div",{className:"flex h-10 items-center rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--input))] px-4 text-[hsl(var(--foreground))]",children:[u?v.jsx(mu,{size:"sm",className:"mr-2"}):v.jsx(nA,{className:"mr-2 h-4 w-4 text-[hsl(var(--muted-foreground))]",onClick:I}),v.jsx("input",{ref:x,type:"text",placeholder:"Search for news...",className:"w-full bg-transparent outline-none placeholder:text-[hsl(var(--muted-foreground))]",value:n,onChange:B=>e(B.target.value),onKeyPress:O,onFocus:()=>n&&T(!0)}),n&&v.jsx("button",{onClick:P,className:"ml-2 rounded-full p-1 hover:bg-[hsl(var(--secondary))]",children:v.jsx(fu,{className:"h-4 w-4 text-[hsl(var(--muted-foreground))]"})})]}),v.jsxs("span",{className:"hidden sm:inline-block sm:pl-2 sm:text-xs sm:text-[hsl(var(--muted-foreground))]",children:["Press ",v.jsx("kbd",{className:"rounded border border-[hsl(var(--border))] bg-[hsl(var(--muted))] px-1.5 py-0.5 text-xs font-semibold",children:"Ctrl"})," + ",v.jsx("kbd",{className:"rounded border border-[hsl(var(--border))] bg-[hsl(var(--muted))] px-1.5 py-0.5 text-xs font-semibold",children:"K"})," to search"]}),y&&(u||a.length>0||m)&&v.jsx("div",{className:"absolute left-0 top-full z-50 mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--background))] shadow-lg",children:v.jsxs("div",{className:"p-2",children:[v.jsxs("div",{className:"flex items-center justify-between border-b border-[hsl(var(--border))] pb-2",children:[v.jsx("p",{className:"text-sm font-medium",children:"Search Results"}),v.jsx("button",{onClick:()=>T(!1),className:"rounded-full p-1 hover:bg-[hsl(var(--secondary))]",children:v.jsx(fu,{className:"h-4 w-4 text-[hsl(var(--muted-foreground))]"})})]}),u?v.jsx("div",{className:"flex justify-center py-8",children:v.jsx(mu,{size:"md"})}):m?v.jsx("div",{className:"p-4 text-center text-[hsl(var(--destructive))]",children:m}):a.length===0?v.jsxs("div",{className:"p-4 text-center text-[hsl(var(--muted-foreground))]",children:['No results found for "',n,'"']}):v.jsxs("div",{className:"mt-2 max-h-[60vh] overflow-auto",children:[a.map((B,ee)=>{var Y;return v.jsxs("div",{className:"flex cursor-pointer gap-3 rounded-md p-2 hover:bg-[hsl(var(--secondary))]",onClick:()=>window.open(B.url,"_blank"),children:[v.jsx("div",{className:"h-16 w-16 flex-shrink-0 overflow-hidden rounded-md",children:v.jsx("img",{src:B.urlToImage||US,alt:B.title,className:"h-full w-full object-cover",onError:W=>{W.target.src=US}})}),v.jsxs("div",{className:"flex-1",children:[v.jsx("h4",{className:"line-clamp-2 text-sm font-medium",children:B.title}),v.jsxs("div",{className:"mt-1 flex items-center gap-1 text-xs text-[hsl(var(--muted-foreground))]",children:[v.jsx("span",{children:((Y=B.source)==null?void 0:Y.name)||"News Source"}),v.jsx("span",{children:"•"}),v.jsx("span",{children:jf(B.publishedAt)})]})]})]},`${B.title}-${ee}`)}),v.jsx("div",{className:"mt-2 border-t border-[hsl(var(--border))] p-2",children:v.jsx(Dt,{variant:"link",className:"w-full justify-center",onClick:()=>{T(!1)},children:"View all results"})})]})]})})]})},wz=()=>v.jsx("footer",{className:"border-t border-[hsl(var(--border))] bg-[hsl(var(--background))] px-4 py-8",children:v.jsxs("div",{className:"container mx-auto",children:[v.jsxs("div",{className:"grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",children:[v.jsxs("div",{children:[v.jsxs("div",{className:"flex items-center gap-2",children:[v.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground",children:v.jsxs("svg",{viewBox:"0 0 24 24",className:"h-5 w-5",fill:"currentColor",children:[v.jsx("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"}),v.jsx("path",{d:"M8 12l4-4 4 4-4 4z"})]})}),v.jsx("span",{className:"text-xl font-bold",children:"Comet"})]}),v.jsx("p",{className:"mt-4 text-sm text-[hsl(var(--muted-foreground))]",children:"Delivering the latest and most relevant news from around the globe, 24/7."})]}),v.jsxs("div",{className:"mt-8 sm:mt-0",children:[v.jsx("h3",{className:"text-lg font-semibold",children:"Categories"}),v.jsxs("ul",{className:"mt-4 grid grid-cols-2 gap-2 sm:grid-cols-1",children:[v.jsx("li",{children:v.jsx(At,{to:"/",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Breaking News"})}),v.jsx("li",{children:v.jsx(At,{to:"/",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"World"})}),v.jsx("li",{children:v.jsx(At,{to:"/",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Business"})}),v.jsx("li",{children:v.jsx(At,{to:"/",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Technology"})}),v.jsx("li",{children:v.jsx(At,{to:"/",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Entertainment"})})]})]}),v.jsxs("div",{className:"mt-8 md:mt-0",children:[v.jsx("h3",{className:"text-lg font-semibold",children:"Company"}),v.jsxs("ul",{className:"mt-4 grid grid-cols-2 gap-2 sm:grid-cols-1",children:[v.jsx("li",{children:v.jsx(At,{to:"/about",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"About Us"})}),v.jsx("li",{children:v.jsx(At,{to:"/careers",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Careers"})}),v.jsx("li",{children:v.jsx(At,{to:"/contact",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Contact"})}),v.jsx("li",{children:v.jsx(At,{to:"/privacy",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Privacy Policy"})}),v.jsx("li",{children:v.jsx(At,{to:"/terms",className:"text-sm text-[hsl(var(--muted-foreground))] transition-colors hover:text-foreground",children:"Terms of Service"})})]})]}),v.jsxs("div",{className:"mt-8 lg:mt-0",children:[v.jsx("h3",{className:"text-lg font-semibold",children:"Connect with us"}),v.jsxs("div",{className:"mt-4 flex space-x-4",children:[v.jsx("a",{href:"https://facebook.com",target:"_blank",rel:"noopener noreferrer",className:"rounded-full p-2 transition-colors hover:bg-[hsl(var(--secondary))]",children:v.jsx(sk,{size:20})}),v.jsx("a",{href:"https://twitter.com",target:"_blank",rel:"noopener noreferrer",className:"rounded-full p-2 transition-colors hover:bg-[hsl(var(--secondary))]",children:v.jsx(Lk,{size:20})}),v.jsx("a",{href:"https://instagram.com",target:"_blank",rel:"noopener noreferrer",className:"rounded-full p-2 transition-colors hover:bg-[hsl(var(--secondary))]",children:v.jsx(lk,{size:20})}),v.jsx("a",{href:"https://linkedin.com",target:"_blank",rel:"noopener noreferrer",className:"rounded-full p-2 transition-colors hover:bg-[hsl(var(--secondary))]",children:v.jsx(uk,{size:20})})]}),v.jsxs("div",{className:"mt-6",children:[v.jsx("h4",{className:"text-sm font-medium",children:"Subscribe to our newsletter"}),v.jsxs("div",{className:"mt-2 flex max-w-sm",children:[v.jsx("input",{type:"email",placeholder:"Your email address",className:"flex-1 rounded-l-md border border-[hsl(var(--border))] bg-[hsl(var(--input))] px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-[hsl(var(--ring))]"}),v.jsx("button",{className:"rounded-r-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90",children:"Subscribe"})]})]})]})]}),v.jsx("div",{className:"mt-8 border-t border-[hsl(var(--border))] pt-8 text-center",children:v.jsxs("p",{className:"text-sm text-[hsl(var(--muted-foreground))]",children:["© ",new Date().getFullYear()," Comet News. All rights reserved."]})})]})}),Sz=()=>{const{theme:n,toggleTheme:e}=oA(),[t,i]=j.useState(!1),a=()=>i(!t);return v.jsxs("div",{className:`${n} min-h-screen bg-[hsl(var(--background))] text-[hsl(var(--foreground))]`,children:[t&&v.jsx("div",{className:"fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden",onClick:a}),v.jsx("div",{className:`fixed left-0 top-0 z-50 h-screen w-72 transform bg-[hsl(var(--sidebar-background))] transition-transform duration-300 ease-in-out lg:translate-x-0 ${t?"translate-x-0":"-translate-x-full lg:translate-x-0"}`,children:v.jsx(vz,{onCloseMobile:()=>i(!1)})}),v.jsxs("div",{className:"lg:ml-72",children:[v.jsx("header",{className:"sticky top-0 z-50 bg-[hsl(var(--background))] p-4 shadow-sm",children:v.jsxs("div",{className:"flex items-center justify-between gap-4",children:[v.jsxs("div",{className:"flex items-center gap-2",children:[v.jsx("button",{className:"rounded-full p-2 hover:bg-[hsl(var(--secondary))] lg:hidden",onClick:a,children:v.jsx(yk,{size:22})}),v.jsx("button",{className:"rounded-full p-2 hover:bg-[hsl(var(--secondary))] lg:hidden",onClick:e,"aria-label":n==="dark"?"Switch to light mode":"Switch to dark mode",children:n==="dark"?v.jsx(sA,{size:20}):v.jsx(tA,{size:20})})]}),v.jsx("div",{className:"flex-grow",children:v.jsx(bz,{})})]})}),v.jsx("main",{className:"container mx-auto px-4 py-6",children:v.jsx(r2,{})}),v.jsx(wz,{})]})]})},Ud="https://placehold.co/600x400?text=No+Image+Available",Az=()=>{var he,M;const[n,e]=j.useState("all"),[t,i]=j.useState([]),[a,l]=j.useState(null),[u,d]=j.useState(!0),[m,p]=j.useState(null),[y,T]=j.useState(1),[w,x]=j.useState(!0),[I,O]=j.useState(!1),P=Bs(),B=[{name:"all",label:"All",icon:null},{name:"breaking",label:"Breaking",icon:v.jsx(rA,{size:16})},{name:"business",label:"Business",icon:null},{name:"entertainment",label:"Entertainment",icon:null},{name:"health",label:"Health",icon:null},{name:"science",label:"Science",icon:null},{name:"sports",label:"Sports",icon:null},{name:"technology",label:"Technology",icon:null}];j.useEffect(()=>{i([]),T(1),x(!0),d(!0),ee(1)},[n]),j.useEffect(()=>{y>1&&ee(y)},[y]);const ee=async(A=1)=>{try{const N=await Ez({country:"us",category:n==="breaking"||n==="all"?"":n,page:A,pageSize:10});N.articles.length===0?x(!1):(A===1?(l(N.articles[0]),i(N.articles.slice(1))):i(L=>[...L,...N.articles]),x(N.totalResults>A*10))}catch(C){p("Failed to load news. Please try again later."),console.error("Error fetching news:",C)}finally{d(!1),O(!1)}},Y=()=>{O(!0),T(A=>A+1)},W=A=>{var L,z,D;let C="bg-blue-600",N=((L=A.source)==null?void 0:L.name)||"News";if((z=A.title)!=null&&z.toLowerCase().includes("breaking")||(D=A.description)!=null&&D.toLowerCase().includes("breaking"))C="bg-red-500",N="BREAKING NEWS";else if(n!=="all"){const tt=B.find(ze=>ze.name===n);if(tt)switch(N=tt.label,n){case"business":C="bg-blue-600";break;case"entertainment":C="bg-pink-600";break;case"health":C="bg-green-600";break;case"science":C="bg-purple-600";break;case"sports":C="bg-orange-600";break;case"technology":C="bg-indigo-600";break;default:C="bg-gray-600"}}return{color:C,label:N}},re=(A,C)=>{P(`/article/${C===-1?"featured":C}`,{state:{article:A}})};return v.jsxs("div",{className:"space-y-6",children:[v.jsxs("div",{className:"flex items-center gap-3",children:[v.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground",children:v.jsxs("svg",{viewBox:"0 0 24 24",className:"h-5 w-5",fill:"currentColor",children:[v.jsx("path",{d:"M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"}),v.jsx("path",{d:"M8 12l4-4 4 4-4 4z"})]})}),v.jsx("h1",{className:"text-3xl font-bold",children:"Comet News"})]}),v.jsx("p",{className:"text-muted",children:"Stay updated with the latest news across all categories"}),u&&!a?v.jsx("div",{className:"flex justify-center py-20",children:v.jsx(mu,{size:"xl"})}):m?v.jsx("div",{className:"bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-4",children:v.jsx("p",{className:"text-red-700 dark:text-red-400",children:m})}):v.jsxs(v.Fragment,{children:[a&&v.jsxs("div",{className:"relative mt-8 overflow-hidden rounded-lg border border-border",children:[v.jsx("img",{src:a.urlToImage||Ud,alt:a.title,className:"h-64 w-full object-cover sm:h-72 md:h-80 lg:h-96",onError:A=>{A.target.src=Ud}}),v.jsxs("div",{className:"absolute inset-0 bg-gradient-to-t from-black/80 to-transparent p-4 flex flex-col justify-end sm:p-6",children:[v.jsxs("div",{className:"mb-4 space-y-1",children:[v.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[v.jsx("span",{className:"rounded bg-red-500 px-2 py-1 text-xs font-medium text-white",children:W(a).label}),((he=a.source)==null?void 0:he.name)&&v.jsx("span",{className:"rounded bg-blue-600 px-2 py-1 text-xs font-medium text-white",children:a.source.name})]}),v.jsx("h2",{className:"text-xl font-bold text-white sm:text-2xl md:text-3xl",children:a.title}),v.jsx("p",{className:"text-sm text-gray-200 md:text-base lg:text-lg",children:a.description})]}),v.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",children:[v.jsxs("div",{className:"flex items-center gap-2 text-xs sm:text-sm text-gray-300",children:[v.jsx("span",{children:((M=a.source)==null?void 0:M.name)||"News Source"}),v.jsx("span",{children:"•"}),v.jsx("span",{children:jf(a.publishedAt)})]}),v.jsx(Dt,{variant:"destructive",size:"md",onClick:()=>re(a,-1),children:"Read Full Story"})]})]})]}),v.jsx("div",{className:"mt-8",children:v.jsx("div",{className:"flex items-center space-x-2 overflow-x-auto pb-4 scrollbar-hide",children:B.map(A=>v.jsxs("button",{className:`flex whitespace-nowrap items-center gap-1 rounded-md px-4 py-2 font-medium transition-colors ${n===A.name?"bg-secondary text-foreground":"text-muted hover:bg-secondary/50 hover:text-foreground"}`,onClick:()=>e(A.name),children:[A.icon,v.jsx("span",{children:A.label})]},A.name))})}),u&&t.length===0?v.jsx("div",{className:"flex justify-center py-20",children:v.jsx(mu,{size:"xl"})}):v.jsxs(v.Fragment,{children:[v.jsx("div",{className:"mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-1",children:t.map((A,C)=>{var L;const N=W(A);return v.jsxs("div",{className:"group flex flex-col overflow-hidden rounded-lg border border-border hover:border-primary/30 transition-all sm:flex-row",children:[v.jsxs("div",{className:"relative h-48 w-full sm:h-auto sm:w-48 sm:min-w-48",children:[v.jsx("span",{className:`absolute left-0 top-0 z-10 rounded-br ${N.color} px-2 py-1 text-xs font-bold text-white`,children:N.label}),v.jsx("img",{src:A.urlToImage||Ud,alt:A.title,className:"h-full w-full object-cover transition-transform duration-300 group-hover:scale-105",onError:z=>{z.target.src=Ud}})]}),v.jsxs("div",{className:"flex flex-1 flex-col justify-between p-4",children:[v.jsxs("div",{children:[v.jsxs("div",{className:"flex items-center text-sm text-muted",children:[v.jsx("span",{children:((L=A.source)==null?void 0:L.name)||"News Source"}),v.jsx("span",{className:"mx-2",children:"•"}),v.jsx("span",{children:jf(A.publishedAt)})]}),v.jsx("h3",{className:"mt-2 text-xl font-semibold text-foreground group-hover:text-primary transition-colors",children:A.title}),v.jsx("p",{className:"mt-2 text-muted",children:A.description||"No description available"})]}),v.jsx("div",{className:"flex justify-end",children:v.jsx(Dt,{variant:"secondary",size:"sm",onClick:()=>re(A,C),children:"Read more"})})]})]},`${A.title}-${C}`)})}),t.length>0&&v.jsx("div",{className:"mt-8 flex justify-center",children:w?v.jsx(Dt,{variant:"primary",size:"md",className:"group relative overflow-hidden",isLoading:I,disabled:I,onClick:Y,rightIcon:!I&&v.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:v.jsx("path",{d:"M12 5V19M12 19L5 12M12 19L19 12",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),children:"Load More News"}):v.jsx("p",{className:"text-muted",children:"No more articles to load"})})]})]})]})},Rz=()=>{const[n,e]=j.useState("all"),[t,i]=j.useState([]),[a,l]=j.useState([]),[u,d]=j.useState(!0),[m,p]=j.useState(""),[y,T]=j.useState(0),w=Bs(),{isAuthenticated:x,isAdmin:I}=eh(),O=[{id:"all",name:"All"},{id:"trending",name:"Trending",icon:v.jsx(t_,{size:14})},{id:"local",name:"Local"},{id:"news",name:"News"},{id:"technology",name:"Technology"},{id:"business",name:"Business"},{id:"politics",name:"Politics"},{id:"sports",name:"Sports"},{id:"health",name:"Health"},{id:"entertainment",name:"Entertainment"}];j.useEffect(()=>{(async()=>{d(!0);try{const re=AC(C_(Is,"chatRooms"),RC("createdAt","desc")),M=(await kC(re)).docs.map(C=>({id:C.id,...C.data(),timeAgo:C.data().createdAt?P(C.data().createdAt.toDate()):"Recently"}));i(M),l(M);const A=M.reduce((C,N)=>C+(N.participants||0),0);T(A)}catch(re){console.error("Error fetching chat rooms:",re)}finally{d(!1)}})()},[]),j.useEffect(()=>{l(n==="all"?t:n==="trending"?t.filter(W=>W.isHot):t.filter(W=>{var re;return((re=W.category)==null?void 0:re.toLowerCase())===n}))},[n,t]),j.useEffect(()=>{if(!m.trim())l(n==="all"?t:n==="trending"?t.filter(W=>W.isHot):t.filter(W=>{var re;return((re=W.category)==null?void 0:re.toLowerCase())===n}));else{const W=m.toLowerCase().trim();l(t.filter(re=>re.title.toLowerCase().includes(W)||re.description.toLowerCase().includes(W)))}},[m,t,n]);const P=W=>{const re=Math.floor((new Date-W)/1e3);let he=re/31536e3;return he>1?Math.floor(he)+" years ago":(he=re/2592e3,he>1?Math.floor(he)+" months ago":(he=re/86400,he>1?Math.floor(he)+" days ago":(he=re/3600,he>1?Math.floor(he)+" hours ago":(he=re/60,he>1?Math.floor(he)+" minutes ago":"Just now"))))},B=W=>{w(`/chat/${W}`)},ee=a.filter(W=>W.isHot),Y=a.filter(W=>!W.isHot);return v.jsxs("div",{className:"w-full max-w-6xl mx-auto",children:[v.jsxs("div",{className:"mb-4",children:[v.jsxs("div",{className:"flex items-center gap-3",children:[v.jsx(As,{size:24,className:"text-primary"}),v.jsx("h1",{className:"text-2xl font-bold",children:"Live Chatrooms"})]}),v.jsx("p",{className:"mt-2 text-muted",children:"Join live conversations about today's most important topics"})]}),v.jsxs("div",{className:"flex items-center gap-6 mt-4",children:[v.jsxs("div",{className:"flex items-center text-muted",children:[v.jsx(Jc,{size:18,className:"mr-2"}),v.jsx("span",{className:"font-medium",children:y})," people online"]}),v.jsxs("div",{className:"flex items-center text-muted",children:[v.jsx(As,{size:18,className:"mr-2"}),v.jsx("span",{className:"font-medium",children:t.length})," active discussions"]})]}),v.jsxs("div",{className:"relative mt-6 mb-4",children:[v.jsx(nA,{size:18,className:"absolute left-3 top-1/2 -translate-y-1/2 text-muted"}),v.jsx("input",{type:"text",placeholder:"Search discussions...",value:m,onChange:W=>p(W.target.value),className:"w-full rounded-lg bg-secondary border border-border py-2 pl-10 pr-4 text-foreground placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-primary/30"})]}),v.jsx("div",{className:"flex items-center space-x-1 overflow-x-auto mt-2 pb-2 scrollbar-hide border-b border-border",children:O.map(W=>v.jsxs("button",{className:`flex whitespace-nowrap items-center gap-1 rounded-md px-4 py-2 font-medium transition-colors ${n===W.id?"bg-primary text-white":"text-muted hover:bg-secondary"}`,onClick:()=>e(W.id),children:[W.icon&&v.jsx("span",{children:W.icon}),v.jsx("span",{children:W.name})]},W.id))}),u?v.jsxs("div",{className:"flex justify-center items-center py-20",children:[v.jsx("div",{className:"inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"}),v.jsx("span",{className:"ml-2 text-muted",children:"Loading discussions..."})]}):v.jsxs(v.Fragment,{children:[ee.length>0&&v.jsxs("div",{className:"mt-8",children:[v.jsxs("div",{className:"flex items-center gap-2 mb-4",children:[v.jsx(t_,{size:20,className:"text-primary"}),v.jsx("h2",{className:"text-xl font-bold",children:"Trending Discussions"})]}),v.jsx("div",{className:"space-y-4",children:ee.map(W=>v.jsx("div",{className:"block rounded-lg border border-border bg-secondary hover:border-primary/50 transition-all cursor-pointer",onClick:()=>B(W.id),children:v.jsxs("div",{className:"p-4",children:[v.jsxs("div",{className:"flex justify-between items-start mb-1",children:[v.jsxs("div",{className:"flex items-center",children:[v.jsx("h3",{className:"text-lg font-medium",children:W.title}),W.isHot&&v.jsxs("span",{className:"ml-2 bg-orange-600/20 text-orange-400 text-xs px-2 py-0.5 rounded flex items-center",children:[v.jsx(rA,{size:12,className:"mr-1"}),"Hot"]})]}),v.jsxs("div",{className:"flex items-center text-xs text-muted",children:[v.jsx(Jc,{size:14,className:"mr-1"}),v.jsx("span",{children:W.participants||0}),v.jsx(Jd,{size:14,className:"ml-3 mr-1"}),v.jsx("span",{children:W.timeAgo})]})]}),v.jsx("p",{className:"text-sm text-muted",children:W.description})]})},W.id))})]}),Y.length>0&&v.jsxs("div",{className:"mt-8",children:[v.jsxs("div",{className:"flex items-center gap-2 mb-4",children:[v.jsx(As,{size:20,className:"text-primary"}),v.jsx("h2",{className:"text-xl font-bold",children:"Discussions"})]}),v.jsx("div",{className:"space-y-4",children:Y.map(W=>v.jsx("div",{className:"block rounded-lg border border-border bg-secondary hover:border-primary/50 transition-all cursor-pointer",onClick:()=>B(W.id),children:v.jsxs("div",{className:"p-4",children:[v.jsxs("div",{className:"flex justify-between items-start mb-1",children:[v.jsxs("div",{className:"flex items-center gap-2",children:[v.jsx("h3",{className:"text-lg font-medium",children:W.title}),v.jsx("span",{className:"bg-blue-600/20 text-blue-400 text-xs px-2 py-0.5 rounded",children:W.category})]}),v.jsxs("div",{className:"flex items-center text-xs text-muted",children:[v.jsx(Jc,{size:14,className:"mr-1"}),v.jsx("span",{children:W.participants||0}),v.jsx(Jd,{size:14,className:"ml-3 mr-1"}),v.jsx("span",{children:W.timeAgo})]})]}),v.jsx("p",{className:"text-sm text-muted",children:W.description})]})},W.id))})]}),a.length===0&&v.jsxs("div",{className:"text-center py-16",children:[v.jsx(As,{size:40,className:"mx-auto text-muted mb-4"}),v.jsx("h3",{className:"text-xl font-medium mb-2",children:"No discussions found"}),v.jsx("p",{className:"text-muted",children:m?"Try a different search term":"There are no chat rooms in this category yet"})]})]}),v.jsx("div",{className:"mt-8 pb-6 flex flex-col sm:flex-row gap-2",children:x?I&&v.jsx(Dt,{variant:"primary",className:"w-full justify-center py-2",leftIcon:v.jsx(As,{size:16}),onClick:()=>w("/admin"),children:"Manage Chat Rooms"}):v.jsx(Dt,{variant:"outline",className:"w-full justify-center border-border py-2 text-foreground hover:bg-secondary",leftIcon:v.jsx(As,{size:16}),onClick:()=>window.location.href="/login",children:"Login to Join Discussions"})})]})},Cz=()=>{const{chatId:n}=$S(),e=Bs(),{currentUser:t,userProfile:i,isAdmin:a}=eh(),[l,u]=j.useState(""),[d,m]=j.useState(!1),p=j.useRef(null),[y,T]=j.useState({title:"Loading...",onlineUsers:0}),[w,x]=j.useState(!0),[I,O]=j.useState(null),[P,B]=j.useState([{id:"welcome",system:!0,content:"Welcome to the chat room! Please be respectful of other users.",time:""}]),[ee,Y]=j.useState([]),W=j.useRef(null);j.useEffect(()=>{n&&(async()=>{try{x(!0);const C=Fa(Is,"chatRooms",n),N=await Ky(C);if(N.exists()){const L=N.data();T({title:L.title,onlineUsers:0,description:L.description}),x(!1)}else O("Chat room not found"),e("/chat")}catch(C){console.error("Error fetching chat room:",C),O("Failed to load chat room"),x(!1)}})()},[n,e]),j.useEffect(()=>{if(!n||!t)return;const A=Ld(Vd,`chatRooms/${n}/presence/${t.uid}`),C={name:(i==null?void 0:i.name)||t.email||"Anonymous",role:(i==null?void 0:i.role)||"user",lastSeen:gz()};return Zg(A,C),()=>{Zg(A,null)}},[n,t,i]),j.useEffect(()=>{if(!n)return;const A=Ld(Vd,`chatRooms/${n}/presence`),C=VS(A,N=>{const L=N.val()||{},z=Object.entries(L).map(([D,tt])=>({uid:D,...tt}));Y(z),T(D=>({...D,onlineUsers:z.length}))});return()=>C()},[n]),j.useEffect(()=>{if(!n)return;const A=Ld(Vd,`chatRooms/${n}/messages`),C=sz(A,iz("timestamp"),tz(100)),N=VS(C,L=>{const z=L.val()||{},D=Object.entries(z).map(([tt,ze])=>({id:tt,user:ze.userName||"Anonymous",content:ze.text,time:ze.timestamp?new Date(ze.timestamp).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"",role:ze.userRole,isYou:t&&ze.userId===t.uid,system:ze.system,timestamp:ze.timestamp})).sort((tt,ze)=>{const X=tt.timestamp||0,ce=ze.timestamp||0;return X-ce});B([{id:"welcome",system:!0,content:"Welcome to the chat room! Please be respectful of other users.",time:""},...D])});return()=>N()},[n,t]),j.useEffect(()=>{var A;(A=W.current)==null||A.scrollIntoView({behavior:"smooth"})},[P]);const re=async A=>{if(A.preventDefault(),!(!l.trim()||!t))try{const C=Ld(Vd,`chatRooms/${n}/messages`),N=Z9(C);await Zg(N,{text:l,userId:t.uid,userName:(i==null?void 0:i.name)||t.email||"Anonymous",userRole:(i==null?void 0:i.role)||"user",timestamp:Date.now(),isAdmin:a||!1}),u("")}catch(C){console.error("Error sending message:",C),O("Failed to send message")}},he=A=>(A||"A").charAt(0).toUpperCase(),M=()=>{document.fullscreenElement?(document.exitFullscreen?document.exitFullscreen():document.webkitExitFullscreen?document.webkitExitFullscreen():document.msExitFullscreen&&document.msExitFullscreen(),m(!1)):(p.current.requestFullscreen?p.current.requestFullscreen():p.current.webkitRequestFullscreen?p.current.webkitRequestFullscreen():p.current.msRequestFullscreen&&p.current.msRequestFullscreen(),m(!0))};return j.useEffect(()=>{const A=()=>{m(!!document.fullscreenElement)};return document.addEventListener("fullscreenchange",A),document.addEventListener("webkitfullscreenchange",A),document.addEventListener("mozfullscreenchange",A),document.addEventListener("MSFullscreenChange",A),()=>{document.removeEventListener("fullscreenchange",A),document.removeEventListener("webkitfullscreenchange",A),document.removeEventListener("mozfullscreenchange",A),document.removeEventListener("MSFullscreenChange",A)}},[]),w?v.jsxs("div",{className:"flex items-center justify-center h-full",children:[v.jsx("div",{className:"inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"}),v.jsx("span",{className:"ml-2",children:"Loading chat room..."})]}):I?v.jsxs("div",{className:"flex flex-col items-center justify-center h-full p-4",children:[v.jsx("p",{className:"text-red-400 mb-4",children:I}),v.jsx(Dt,{variant:"primary",onClick:()=>e("/chat"),children:"Return to Chat Rooms"})]}):v.jsxs("div",{ref:p,className:"h-full w-full flex flex-col",children:[v.jsx("div",{className:"sticky top-0 z-10 border-b border-border bg-card p-4",children:v.jsxs("div",{className:"flex items-center justify-between",children:[v.jsxs("div",{className:"flex items-center space-x-4",children:[v.jsx(At,{to:"/chat",className:"rounded-full p-2 hover:bg-secondary",children:v.jsx(K2,{size:20})}),v.jsxs("div",{children:[v.jsx("h1",{className:"text-lg font-semibold",children:y.title}),v.jsxs("div",{className:"flex items-center text-xs text-muted",children:[v.jsx(Jc,{size:14,className:"mr-1"}),v.jsxs("span",{children:[y.onlineUsers," online"]})]})]})]}),v.jsxs("div",{className:"flex items-center space-x-3",children:[v.jsx("button",{className:"rounded-full p-2 hover:bg-secondary",children:v.jsx(Fk,{size:18})}),v.jsx("button",{className:"rounded-full p-2 hover:bg-secondary",onClick:M,"aria-label":d?"Exit full screen":"Enter full screen",title:d?"Exit full screen":"Enter full screen",children:d?v.jsx(Tk,{size:18}):v.jsx(gk,{size:18})}),v.jsx("button",{className:"rounded-full p-2 hover:bg-secondary",children:v.jsx(ek,{size:18})})]})]})}),v.jsx("div",{className:"flex-1 overflow-y-auto p-4 bg-background",children:v.jsxs("div",{className:"mx-auto max-w-3xl",children:[P.map(A=>v.jsx("div",{className:"mb-4",children:A.system?v.jsx("div",{className:"my-2 flex justify-center",children:v.jsx("div",{className:"rounded-full bg-secondary px-4 py-1 text-xs text-muted",children:A.content})}):A.isYou?v.jsxs("div",{className:"flex items-start justify-end",children:[v.jsxs("div",{className:"flex-1 text-right",children:[v.jsxs("div",{className:"flex items-center justify-end",children:[v.jsx("span",{className:"font-medium text-foreground",children:A.user}),a&&v.jsx("span",{className:"ml-2 rounded px-2 py-0.5 text-xs font-semibold bg-purple-700 dark:bg-purple-900 text-purple-100",children:"ADMIN"})]}),v.jsx("div",{className:"mt-1 rounded-lg bg-primary p-3 text-sm text-primary-foreground inline-block",children:A.content}),v.jsx("div",{className:"mt-1 text-xs text-muted",children:A.time})]}),v.jsx("div",{className:"ml-3 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground",children:he(A.user)})]}):v.jsxs("div",{className:"flex items-start",children:[v.jsx("div",{className:"mr-3 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-secondary text-sm font-semibold text-secondary-foreground",children:he(A.user)}),v.jsxs("div",{className:"flex-1",children:[v.jsxs("div",{className:"flex items-center",children:[v.jsx("span",{className:"font-medium text-foreground",children:A.user}),A.role&&(A.role==="admin"||A.isAdmin)&&v.jsx("span",{className:"ml-2 rounded px-2 py-0.5 text-xs font-semibold bg-purple-700 dark:bg-purple-900 text-purple-100",children:"ADMIN"}),A.role&&A.role==="moderator"&&v.jsx("span",{className:"ml-2 rounded px-2 py-0.5 text-xs font-semibold bg-green-700 dark:bg-green-900 text-green-100",children:"MOD"})]}),v.jsx("div",{className:"mt-1 rounded-lg bg-secondary p-3 text-sm text-foreground",children:A.content}),v.jsx("div",{className:"mt-1 text-xs text-muted",children:A.time})]})]})},A.id)),v.jsx("div",{ref:W})]})}),v.jsx("div",{className:"border-t border-border bg-card p-4",children:v.jsxs("form",{onSubmit:re,className:"mx-auto max-w-3xl",children:[v.jsxs("div",{className:"flex items-center gap-2",children:[v.jsx("input",{type:"text",value:l,onChange:A=>u(A.target.value),placeholder:t?"Type a message...":"Sign in to join the conversation",className:"flex-1 rounded-lg bg-secondary border border-border px-4 py-3 text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50",disabled:!t}),v.jsx(Dt,{type:"submit",variant:"primary",className:"aspect-square p-3",disabled:!l.trim()||!t,"aria-label":"Send message",children:v.jsx(xk,{size:18})})]}),!t&&v.jsx("div",{className:"text-center mt-2",children:v.jsx(At,{to:"/login",className:"text-primary hover:underline text-sm",children:"Sign in to participate in the discussion"})})]})})]})},xz=()=>{const[n,e]=j.useState("login"),[t,i]=j.useState(""),[a,l]=j.useState(""),[u,d]=j.useState(""),[m,p]=j.useState(""),[y,T]=j.useState(!1),w=Bs(),x=async O=>{O.preventDefault(),p(""),T(!0);try{const P=await oU(Uf,a,u),B=await Ky(Fa(Is,"users",P.user.uid));B.exists()?console.log("User logged in successfully:",B.data()):console.log("User logged in but no profile found"),w("/")}catch(P){switch(console.error("Error logging in:",P),P.code){case"auth/invalid-credential":case"auth/user-not-found":case"auth/wrong-password":p("Invalid email or password");break;case"auth/too-many-requests":p("Too many failed login attempts. Please try again later");break;case"auth/user-disabled":p("This account has been disabled");break;default:p("Failed to log in. Please try again")}}finally{T(!1)}},I=async O=>{O.preventDefault(),p(""),T(!0);try{const B=(await aU(Uf,a,u)).user;await sV(Fa(Is,"users",B.uid),{name:t,email:a,role:"user",createdAt:ru(),updatedAt:ru()}),console.log("User registered successfully:",B),w("/")}catch(P){switch(console.error("Error signing up:",P),P.code){case"auth/email-already-in-use":p("Email address is already in use");break;case"auth/invalid-email":p("Invalid email address");break;case"auth/weak-password":p("Password is too weak. Use at least 6 characters");break;default:p("Failed to create account. Please try again")}}finally{T(!1)}};return v.jsx("div",{className:"flex flex-col items-center justify-center w-full py-12",children:v.jsxs("div",{className:"w-full max-w-lg px-6",children:[v.jsx("div",{className:"flex justify-center mb-8",children:v.jsxs("div",{className:"text-primary text-4xl font-bold flex items-center",children:[v.jsxs("svg",{className:"w-8 h-8 mr-2 text-primary",viewBox:"0 0 24 24",fill:"currentColor",children:[v.jsx("circle",{cx:"12",cy:"12",r:"10",stroke:"currentColor",fill:"none",strokeWidth:"2"}),v.jsx("circle",{cx:"12",cy:"12",r:"3",fill:"currentColor"})]}),"Comet"]})}),v.jsxs("div",{className:"bg-card border border-border rounded-xl overflow-hidden shadow-lg",children:[v.jsxs("div",{className:"grid grid-cols-2",children:[v.jsx("button",{onClick:()=>e("login"),className:`py-4 text-center font-medium text-lg transition-all duration-200 ${n==="login"?"bg-secondary text-primary border-b-2 border-primary":"bg-card text-muted border-b border-border hover:text-foreground"}`,children:"Login"}),v.jsx("button",{onClick:()=>e("signup"),className:`py-4 text-center font-medium text-lg transition-all duration-200 ${n==="signup"?"bg-secondary text-primary border-b-2 border-primary":"bg-card text-muted border-b border-border hover:text-foreground"}`,children:"Sign Up"})]}),v.jsxs("div",{className:"p-8",children:[m&&v.jsx("div",{className:"bg-red-500/10 dark:bg-red-900/30 border border-red-600 dark:border-red-800 text-red-800 dark:text-red-100 px-4 py-3 rounded mb-4",children:m}),n==="login"&&v.jsxs("div",{children:[v.jsx("h2",{className:"text-2xl font-bold mb-6 text-foreground",children:"Welcome back"}),v.jsx("p",{className:"text-muted mb-8",children:"Please enter your details to sign in"}),v.jsxs("form",{onSubmit:x,className:"space-y-5",children:[v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Email"}),v.jsx("input",{type:"email",placeholder:"Enter your email",value:a,onChange:O=>l(O.target.value),className:"w-full p-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all",required:!0,disabled:y})]}),v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Password"}),v.jsx("input",{type:"password",placeholder:"••••••••",value:u,onChange:O=>d(O.target.value),className:"w-full p-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all",required:!0,disabled:y})]}),v.jsxs("div",{className:"flex items-center justify-between",children:[v.jsxs("div",{className:"flex items-center",children:[v.jsx("input",{type:"checkbox",id:"remember",className:"w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary/50"}),v.jsx("label",{htmlFor:"remember",className:"ml-2 text-sm text-muted",children:"Remember me"})]}),v.jsx("a",{href:"#",className:"text-sm text-primary hover:underline",children:"Forgot password?"})]}),v.jsx(Dt,{type:"submit",className:"w-full py-3 mt-2",variant:"primary",disabled:y,isLoading:y,children:"Sign In"})]})]}),n==="signup"&&v.jsxs("div",{children:[v.jsx("h2",{className:"text-2xl font-bold mb-6 text-foreground",children:"Create an account"}),v.jsx("p",{className:"text-muted mb-8",children:"Enter your details to get started"}),v.jsxs("form",{onSubmit:I,className:"space-y-5",children:[v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Name"}),v.jsx("input",{type:"text",placeholder:"Enter your full name",value:t,onChange:O=>i(O.target.value),className:"w-full p-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all",required:!0,disabled:y})]}),v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Email"}),v.jsx("input",{type:"email",placeholder:"Enter your email",value:a,onChange:O=>l(O.target.value),className:"w-full p-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all",required:!0,disabled:y})]}),v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Password"}),v.jsx("input",{type:"password",placeholder:"Create a strong password",value:u,onChange:O=>d(O.target.value),className:"w-full p-3 rounded-lg bg-secondary border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all",required:!0,disabled:y,minLength:6})]}),v.jsxs("div",{className:"flex items-center",children:[v.jsx("input",{type:"checkbox",id:"terms",className:"w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary/50",required:!0,disabled:y}),v.jsxs("label",{htmlFor:"terms",className:"ml-2 text-sm text-muted",children:["I agree to the ",v.jsx("a",{href:"#",className:"text-primary hover:underline",children:"Terms"})," and ",v.jsx("a",{href:"#",className:"text-primary hover:underline",children:"Privacy Policy"})]})]}),v.jsx(Dt,{type:"submit",className:"w-full py-3 mt-2",variant:"primary",disabled:y,isLoading:y,children:"Create Account"})]})]})]})]})]})})},Iz="https://placehold.co/600x400?text=No+Image+Available",Nz=()=>{var I;const{articleId:n}=$S(),e=Yi(),t=Bs(),[i,a]=j.useState(null),[l,u]=j.useState(!0),[d,m]=j.useState(!0);j.useEffect(()=>{var O;(O=e.state)!=null&&O.article?(a(e.state.article),u(!1)):t("/")},[e.state,t]);const p=()=>{m(!d)},y=O=>{if(!O)return[];let P=[];if(O.content){const B=O.content.replace(/\[\+\d+ chars\]$/,"");P.push(B)}return O.description&&(!P.length||!P[0].includes(O.description))&&P.unshift(O.description),P.length===0&&P.push("Full article content is not available. Please visit the original source for the complete article."),P},T=O=>{var Y;if(!O)return[];const P=`${O.title} ${O.description||""} ${O.content||""}`.toLowerCase(),ee=["politics","economy","technology","science","health","sports","entertainment","business","world","national","education","environment","climate","finance","markets","ai","artificial intelligence","cryptocurrency","blockchain","innovation","research","development"].filter(W=>P.includes(W));return O.category&&ee.unshift(O.category.toLowerCase()),(Y=O.source)!=null&&Y.name&&ee.push(O.source.name.toLowerCase()),[...new Set(ee)].slice(0,5)};if(l)return v.jsx("div",{className:"flex justify-center items-center h-64",children:v.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"})});if(!i)return v.jsxs("div",{className:"text-center py-10",children:[v.jsx("h2",{className:"text-2xl font-bold",children:"Article not found"}),v.jsxs("p",{className:"mt-4 text-muted",children:["The article you're looking for couldn't be found.",v.jsx(At,{to:"/",className:"text-primary ml-2",children:"Return to home"})]})]});const w=y(i),x=T(i);return v.jsxs("div",{className:"max-w-4xl mx-auto",children:[v.jsx("h1",{className:"text-3xl font-bold mb-4",children:i.title}),v.jsx("div",{className:"w-full h-64 sm:h-80 md:h-96 bg-secondary rounded-lg mb-6 flex items-center justify-center overflow-hidden",children:i.urlToImage?v.jsx("img",{src:i.urlToImage,alt:i.title,className:"w-full h-full object-cover",onError:O=>{O.target.onerror=null,O.target.src=Iz}}):v.jsx("div",{className:"text-muted flex items-center justify-center h-full w-full",children:v.jsxs("svg",{xmlns:"http://www.w3.org/2000/svg",width:"64",height:"64",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[v.jsx("rect",{x:"3",y:"3",width:"18",height:"18",rx:"2",ry:"2"}),v.jsx("circle",{cx:"8.5",cy:"8.5",r:"1.5"}),v.jsx("polyline",{points:"21 15 16 10 5 21"})]})})}),v.jsxs("div",{className:"flex items-center text-sm text-muted mb-6",children:[v.jsx("span",{children:((I=i.source)==null?void 0:I.name)||"Unknown Source"}),v.jsx("span",{className:"mx-2",children:"•"}),v.jsxs("div",{className:"flex items-center",children:[v.jsx(Jd,{size:14,className:"mr-1"}),v.jsx("span",{children:jf(i.publishedAt)})]}),i.author&&v.jsxs(v.Fragment,{children:[v.jsx("span",{className:"mx-2",children:"•"}),v.jsxs("span",{children:["By ",i.author]})]})]}),v.jsxs("div",{className:"bg-card rounded-lg overflow-hidden mb-6 shadow-sm",children:[v.jsxs("div",{className:"flex items-center justify-between p-4 bg-secondary border-b border-border",children:[v.jsx("h2",{className:"text-lg font-medium",children:"Article Content"}),v.jsx("button",{onClick:p,className:"flex items-center text-sm text-muted hover:text-foreground transition-colors",children:d?v.jsxs(v.Fragment,{children:[v.jsx("span",{className:"mr-1",children:"Hide Article"}),v.jsx(X2,{size:16})]}):v.jsxs(v.Fragment,{children:[v.jsx("span",{className:"mr-1",children:"Show Article"}),v.jsx(Y2,{size:16})]})})]}),d&&v.jsxs("div",{className:"p-6 text-foreground",children:[w.map((O,P)=>v.jsx("p",{className:"mb-4 leading-relaxed",children:O},P)),i.url&&v.jsx("div",{className:"mt-8 pt-4 border-t border-border",children:v.jsx("a",{href:i.url,target:"_blank",rel:"noopener noreferrer",className:"text-primary hover:underline",children:"Read the full article at the original source"})})]})]}),v.jsxs("div",{className:"mb-8",children:[v.jsx("h3",{className:"text-sm text-muted mb-2",children:"Related Tags"}),v.jsx("div",{className:"flex flex-wrap gap-2",children:x.map(O=>v.jsx("span",{className:"px-3 py-1 bg-secondary rounded-full text-sm text-foreground hover:bg-secondary/80 transition-colors cursor-pointer",children:O},O))})]}),v.jsx("div",{className:"mt-6 mb-10",children:v.jsx(At,{to:"/",className:"inline-flex items-center px-4 py-2 border border-border rounded-md text-sm font-medium text-foreground hover:bg-secondary transition-colors",children:"← Back to Articles"})})]})},kz=["Trending","Local","News","Technology","Business","Politics","Sports","Health","Entertainment","Other"],Dz=()=>{const{userProfile:n,currentUser:e}=eh(),t=Bs(),[i,a]=j.useState([]),[l,u]=j.useState(!0),[d,m]=j.useState(null),[p,y]=j.useState(!1),[T,w]=j.useState(!1),[x,I]=j.useState(null),[O,P]=j.useState({title:"",description:"",category:"News",isHot:!1}),B=async()=>{u(!0);try{const C=AC(C_(Is,"chatRooms"),RC("createdAt","desc")),L=(await kC(C)).docs.map(z=>({id:z.id,...z.data()}));a(L)}catch(C){console.error("Error fetching chat rooms:",C),m("Failed to load chat rooms")}finally{u(!1)}};j.useEffect(()=>{B()},[]);const ee=C=>{const{name:N,value:L,type:z,checked:D}=C.target;P(tt=>({...tt,[N]:z==="checkbox"?D:L}))},Y=async C=>{C.preventDefault();try{if(!n||!e){m("User information is not available. Please try logging out and back in.");return}const N={...O,participants:0,createdAt:ru(),updatedAt:ru(),createdBy:{uid:e.uid,name:(n==null?void 0:n.name)||"Admin",role:(n==null?void 0:n.role)||"admin"},active:!0};await oV(C_(Is,"chatRooms"),N),P({title:"",description:"",category:"News",isHot:!1}),y(!1),B()}catch(N){console.error("Error creating chat room:",N),m("Failed to create chat room: "+N.message)}},W=async C=>{if(C.preventDefault(),!!x)try{const N=Fa(Is,"chatRooms",x.id);await rV(N,{...O,updatedAt:ru()}),I(null),w(!1),B()}catch(N){console.error("Error updating chat room:",N),m("Failed to update chat room")}},re=async C=>{if(confirm("Are you sure you want to delete this chat room? This action cannot be undone."))try{await aV(Fa(Is,"chatRooms",C)),B()}catch(N){console.error("Error deleting chat room:",N),m("Failed to delete chat room")}},he=C=>{I(C),P({title:C.title,description:C.description,category:C.category,isHot:C.isHot||!1}),w(!0),y(!1),window.scrollTo({top:0,behavior:"smooth"})},M=C=>{t(`/chat/${C}`)},A=()=>{y(!1),w(!1),I(null),P({title:"",description:"",category:"News",isHot:!1})};return v.jsxs("div",{className:"max-w-6xl mx-auto",children:[v.jsxs("div",{className:"flex justify-between items-center mb-6",children:[v.jsxs("div",{children:[v.jsxs("h1",{className:"text-2xl font-bold flex items-center gap-2",children:[v.jsx(iA,{className:"text-primary"}),"Admin Dashboard"]}),v.jsxs("p",{className:"text-muted mt-1",children:["Welcome ",n==null?void 0:n.name,", manage your chat rooms here"]})]}),!p&&!T&&v.jsx(Dt,{variant:"primary",onClick:()=>y(!0),leftIcon:v.jsx(Rd,{size:16}),children:"Create Chat Room"})]}),d&&v.jsxs("div",{className:"bg-red-500/10 dark:bg-red-900/30 border border-red-600 dark:border-red-800 text-red-800 dark:text-red-100 px-4 py-3 rounded mb-4",children:[d,v.jsx("button",{className:"float-right",onClick:()=>m(null),"aria-label":"Dismiss",children:v.jsx(fu,{size:18})})]}),(p||T)&&v.jsxs("div",{className:"bg-card rounded-lg border border-border p-4 mb-6",children:[v.jsx("h2",{className:"text-lg font-semibold mb-4 flex items-center",children:T?v.jsxs(v.Fragment,{children:[v.jsx(hb,{size:18,className:"mr-2 text-primary"}),"Edit Chat Room"]}):v.jsxs(v.Fragment,{children:[v.jsx(Rd,{size:18,className:"mr-2 text-primary"}),"Create New Chat Room"]})}),v.jsxs("form",{onSubmit:T?W:Y,className:"space-y-4",children:[v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Title"}),v.jsx("input",{type:"text",name:"title",value:O.title,onChange:ee,className:"w-full p-2 rounded-md bg-secondary border border-border text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 focus:border-primary",placeholder:"Enter chat room title",required:!0,maxLength:100})]}),v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Description"}),v.jsx("textarea",{name:"description",value:O.description,onChange:ee,className:"w-full p-2 rounded-md bg-secondary border border-border text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 focus:border-primary",placeholder:"Enter chat room description",rows:3,required:!0,maxLength:250})]}),v.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[v.jsxs("div",{children:[v.jsx("label",{className:"block text-sm font-medium text-foreground mb-1",children:"Category"}),v.jsx("select",{name:"category",value:O.category,onChange:ee,className:"w-full p-2 rounded-md bg-secondary border border-border text-foreground focus:outline-none focus:ring-1 focus:ring-primary/50 focus:border-primary",required:!0,children:kz.map(C=>v.jsx("option",{value:C,children:C},C))})]}),v.jsxs("div",{className:"flex items-center mt-6",children:[v.jsx("input",{type:"checkbox",id:"isHot",name:"isHot",checked:O.isHot,onChange:ee,className:"w-4 h-4 rounded border-border bg-secondary text-primary focus:ring-primary/50"}),v.jsx("label",{htmlFor:"isHot",className:"ml-2 text-sm text-foreground",children:"Mark as Hot/Trending"})]})]}),v.jsxs("div",{className:"flex justify-end gap-2 pt-2",children:[v.jsx(Dt,{type:"button",variant:"outline",onClick:A,leftIcon:v.jsx(fu,{size:16}),children:"Cancel"}),v.jsxs(Dt,{type:"submit",variant:"primary",leftIcon:T?v.jsx(Ak,{size:16}):v.jsx(Rd,{size:16}),children:[T?"Update":"Create"," Chat Room"]})]})]})]}),v.jsxs("div",{children:[v.jsxs("h2",{className:"text-xl font-bold mb-4 flex items-center",children:[v.jsx(As,{size:20,className:"mr-2 text-primary"}),"Manage Chat Rooms"]}),l?v.jsxs("div",{className:"text-center py-8",children:[v.jsx("div",{className:"inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"}),v.jsx("p",{className:"mt-2 text-muted",children:"Loading chat rooms..."})]}):i.length===0?v.jsxs("div",{className:"text-center py-8 bg-card rounded-lg border border-border",children:[v.jsx(As,{size:40,className:"mx-auto text-muted mb-2"}),v.jsx("p",{className:"text-muted",children:"No chat rooms found"}),v.jsx(Dt,{variant:"primary",size:"sm",onClick:()=>y(!0),leftIcon:v.jsx(Rd,{size:16}),className:"mt-4",children:"Create your first chat room"})]}):v.jsx("div",{className:"space-y-4",children:i.map(C=>v.jsxs("div",{className:"flex flex-col sm:flex-row justify-between rounded-lg border border-border bg-card",children:[v.jsxs("div",{className:"p-4 flex-grow",children:[v.jsxs("div",{className:"flex flex-wrap gap-2 items-start mb-1",children:[v.jsx("h3",{className:"text-lg font-medium",children:C.title}),v.jsxs("div",{className:"flex flex-wrap gap-2",children:[v.jsx("span",{className:"bg-blue-600/20 text-blue-400 text-xs px-2 py-0.5 rounded",children:C.category}),C.isHot&&v.jsxs("span",{className:"bg-orange-600/20 text-orange-400 text-xs px-2 py-0.5 rounded flex items-center",children:[v.jsx(t_,{size:10,className:"mr-1"}),"Hot"]})]})]}),v.jsx("p",{className:"text-sm text-muted mb-2",children:C.description}),v.jsxs("div",{className:"flex items-center text-xs text-muted",children:[v.jsx(Jc,{size:12,className:"mr-1"}),v.jsxs("span",{children:[C.participants||0," participants"]}),C.createdAt&&v.jsxs(v.Fragment,{children:[v.jsx(Jd,{size:12,className:"ml-3 mr-1"}),v.jsxs("span",{children:["Created: ",new Date(C.createdAt.toDate()).toLocaleDateString()]})]})]})]}),v.jsxs("div",{className:"flex sm:flex-col flex-row items-stretch sm:items-end justify-end p-4 gap-2",children:[v.jsx(Dt,{variant:"secondary",size:"sm",leftIcon:v.jsx(nk,{size:14}),onClick:()=>M(C.id),children:"View"}),v.jsx(Dt,{variant:"outline",size:"sm",leftIcon:v.jsx(hb,{size:14}),onClick:()=>he(C),children:"Edit"}),v.jsx(Dt,{variant:"destructive",size:"sm",leftIcon:v.jsx(Ok,{size:14}),onClick:()=>re(C.id),children:"Delete"})]})]},C.id))})]})]})},Oz=({children:n})=>{const{isAuthenticated:e,isAdmin:t,loading:i}=eh();return i?v.jsx("div",{className:"flex justify-center items-center h-screen",children:"Loading..."}):!e||!t?v.jsx(s2,{to:"/",replace:!0}):n};function Mz(){return v.jsx(k2,{basename:"",children:v.jsx(o2,{children:v.jsxs(Er,{path:"/",element:v.jsx(Sz,{}),children:[v.jsx(Er,{index:!0,element:v.jsx(Az,{})}),v.jsx(Er,{path:"/chat",element:v.jsx(Rz,{})}),v.jsx(Er,{path:"/chat/:chatId",element:v.jsx(Cz,{})}),v.jsx(Er,{path:"/article/:articleId",element:v.jsx(Nz,{})}),v.jsx(Er,{path:"/login",element:v.jsx(xz,{})}),v.jsx(Er,{path:"/admin",element:v.jsx(Oz,{children:v.jsx(Dz,{})})})]})})})}function Pz(){return v.jsx(yz,{children:v.jsx(Mz,{})})}fN.createRoot(document.getElementById("root")).render(v.jsx(j.StrictMode,{children:v.jsx(Gk,{children:v.jsx(Pz,{})})}));
